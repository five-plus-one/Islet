# 五加一 UI UX 设计体系

面向五加一产品的共同视觉语言、交互模式与组件规范。

设计站：[ui.five-plus-one.com](https://ui.five-plus-one.com)。

组件目录随共享组件一起发布，包含基础控件、设置、模型供应商、资源管理、数据分析等交互示例，以及课栈、阅卷、账号与个人主页示例。设计网站提供交互演示、属性说明和可复制代码；组件包支持 React 19 与 TypeScript。

- [UI UX 设计调研](docs/research/ui-ux-research-2026-10-19.md)

品牌色统一为 **#FD8B07**。产品使用独立主题：课栈蓝、批改助手绿、OnePass 紫；支持深浅主题。根元素使用 `data-product="brand | kezhan | marker | onepass"`，品牌色不随产品主题变化。

## 使用

```sh
npm install
npm run dev
```

访问 http://127.0.0.1:5178/ 。`npm run build` 检查组件目录与可复制示例，构建设计网站和带类型声明的组件包，并生成 `release.json` 版本清单；`npm test` 执行回归测试。

在本项目执行 `npm run build` 和 `npm pack`，然后在其他项目安装生成的 `fiveplusone-ui-0.5.0.tgz`：

```tsx
import { Button, Card } from '@fiveplusone/ui';
import '@fiveplusone/ui/styles.css';

export function Welcome() {
  return <Card><h2>开始新的想法</h2><Button onClick={() => location.assign('/notes/new')}>新建笔记</Button></Card>;
}
```

当前为本地集成版本，尚未发布至公共包仓库。

## 工作区能力

- CommerceWorkspace / DirectoryWorkspace / PlatformWorkspace：会员计费、用户组、站点和平台管理。
- AISettingsWorkspace / SkillsWorkspace：完整模型配置、技能导入与编辑。
- NotebookManagerWorkspace / NotebookPublishing：课程来源、预览、发布与历史。
- NoteEditorWorkspace / CourseContentWorkspace / SharedReadingPage：保存会话、阅读、例题、练习与分享。
- CanvasWorkspace / ExperimentLibrary / LearningExperiment：画布修订、真实学科实验与课程原件。
- LectureWorkspace：音视频、逐词讲稿、章节跳转和 Markdown 课堂笔记。
- WorkspaceLayout：多栏拖动、折叠、宽度保存、嵌套分屏和命令式控制。
- ChatComposer / MessageList：受控草稿、附件、引用、中文输入、虚拟列表和流式粘底。
- MarkdownEditor：课栈 Markdown 节点、工具栏、公式与矩阵、表格、代码、卡片和 Yjs 协作。

代码块支持 Tab 缩进、Shift+Tab 减少缩进，选中多行时按完整行调整；Enter 延续当前缩进，Backspace 按缩进级别退格。Ctrl/⌘+Enter 在代码块下方继续正文，Esc 将焦点移到语言与操作栏，随后可用 Tab 导航。触屏可使用代码块操作栏的缩进按钮。Mermaid 源码支持相同的缩进与换行习惯，Esc 或 Ctrl/⌘+Enter 完成编辑。

在段落开头连续输入三个反引号即可创建代码块，接着输入语言名称并按空格或回车确认。代码块和行内代码按代码语法显示，正文中的标签保留标签样式。
- MemberSearch / ShareLink / AttachmentPicker / UploadQueue：成员搜索、链接权限、资料选择与上传进度。
- MemberAccess：成员角色、邀请、提交反馈与只读展示。
- VideoPlayer：授权播放源、控制器引用、播放位置和字幕接入。
- ResourcePreview：PDF、Word、PowerPoint、表格、图片、音视频与文本预览入口。
- PdfPreview：课栈分页预览、延迟加载、转换等待、缩放、跳页及重试。
- HorizontalScrollbar：拖动和键盘操作的横向滚动条。
- FileTree：层级展开、键盘导航、选择、新建、重命名和移除回调。
- CollaborativeEditor：Tiptap 编辑、Yjs 共享文档和 Hocuspocus 连接适配。

Office 转换依赖接入项目的预览服务；跨设备协作依赖鉴权、持久化及 WebSocket 服务。网站中的 Office 页面为预制设计样例，双编辑器演示使用真实共享文档，演示不承担生产存储。

- [设计规范](docs/design/design-system.md)
- [接入与课栈适配](docs/design/integration.md)
- [课栈迁移接口与验收](docs/kezhan-migration-guide.md)
- [0.5.0 组件抽取与交付验证](docs/kezhan-ui-0.5.0-acceptance.md)
- [课栈工作区接入契约](docs/kezhan-workspace-contracts.md)
- [0.4.1 抽取与设计复核](docs/kezhan-ui-0.4.1-review.md)
- [0.4.0 交付与验收](docs/kezhan-ui-0.4.0-acceptance.md)
- [课栈组件来源映射](docs/kezhan-component-map-2026-10-20.md)
- [组件设计与接入审计](docs/component-design-audit-2026-10-20.md)
- [设计站部署](docs/deployment.md)

`src/lib` 为组件包，`src/catalog.tsx` 与 `src/workspace-gallery.tsx` 为目录，`src/main.tsx` 为设计网站，`tests` 为回归测试。

代码块支持括号与引号配对、选区包裹、闭合符跳过、成对删除，以及括号之间换行后的缩进。尖括号结合语言与输入位置配对。

`/cpp`、`/py`、`/js` 等命令插入对应语言代码块；定义、定理、例题、易错点、记忆卡和推导等卡片支持中文、拼音与英文检索。`workspaceTabShortcut` 统一原生客户端标签快捷键与网页替代键，业务宿主负责保存、权限与路由。

## 网页入口中的账号菜单

品牌入口可从 `@fiveplusone/ui/app-surfaces` 导入 `AccountMenu`、`ThemeToggle` 和 `TooltipProvider`，同时加载 `@fiveplusone/ui/app-surfaces.css`。该样式入口包含头像、账号说明、操作间距及弹层主题；账号数据和导航由业务提供。

快捷命令支持 `/dy` 定义、`/dl` 定理、`/lt` 例题、`/td` 推导、`/db` 对比、`/jyk` 记忆卡。明确缩写优先，多个匹配项按账号使用频次推荐。宿主通过 `configureEditorCommandUsage` 注入账号存储，`mergeEditorCommandUsage` 合并多设备计数。
