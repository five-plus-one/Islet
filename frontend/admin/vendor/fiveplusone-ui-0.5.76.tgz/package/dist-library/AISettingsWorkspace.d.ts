export interface EditableAIModel {
    id: string;
    label: string;
    modelType: "text" | "image";
    contextK: number;
    cacheTtlSec: number;
    inputPrice: number;
    outputPrice: number;
    cachedInputPrice?: number;
    cacheWritePrice?: number;
    vision: boolean;
    tools: boolean;
    thinking: boolean;
    thinkingRequired: boolean;
    thinkingLevels: string[];
    apiProtocol: "openai" | "anthropic" | "siliconflow";
    reasoningField?: string;
    thinkingRequestStyle: string;
    imageApiStyle: "auto" | "openai" | "siliconflow";
    sizes: string[];
    maxCount: number;
}
export interface EditableAPIGroup {
    id: string;
    name: string;
    baseUrl: string;
    apiKey: string;
    models: EditableAIModel[];
}
export interface AISettings {
    groups: EditableAPIGroup[];
    defaultModel: string;
    excerptModel: string;
    selectionModel: string;
    imageTextModel: string;
    fallbackModel: string;
    defaultThinking: boolean;
    defaultSearch: boolean;
    thinkingEffort: string;
    globalContext: string;
    disabledTools: string[];
    imageEnabled: boolean;
    fontSize?: number;
    fontFamily?: string;
}
export interface AISettingsWorkspaceProps {
    value: AISettings;
    builtInModels?: {
        id: string;
        label: string;
    }[];
    tools?: {
        id: string;
        label: string;
        description?: string;
    }[];
    onSave: (value: AISettings) => Promise<void> | void;
    onExportChats?: () => Promise<void> | void;
    onExportSettings?: (value: AISettings) => Promise<void> | void;
}
export declare const createEditableAIModel: () => EditableAIModel;
export declare function validateAISettings(value: unknown): value is AISettings;
export declare function replaceAIModelReferences(value: AISettings, replacements: Record<string, string>): AISettings;
export declare function AISettingsWorkspace({ value, builtInModels, tools, onSave, onExportChats, onExportSettings, }: AISettingsWorkspaceProps): import("react").JSX.Element;
