/** AgentTrace - 从课栈 chat/AgentTrace 提取
 *
 * 展示 AI 的推理与工具调用过程：可折叠、可逐步展开，
 * 运行中显示活动指示，失败步骤有独立状态。
 */
import { type ReactNode } from "react";
export type TraceStatus = "pending" | "running" | "done" | "error";
export interface TraceStep {
    id: string;
    title: string;
    detail?: string;
    status: TraceStatus;
    meta?: ReactNode;
}
export interface AgentTraceProps {
    steps: TraceStep[];
    /** 是否正在流式输出：自动展开最后一步 */
    streaming?: boolean;
    /** 总耗时（毫秒） */
    durationMs?: number;
    /** 初始是否展开 */
    defaultOpen?: boolean;
    title?: string;
}
export declare function AgentTrace({ steps, streaming, durationMs, defaultOpen, title, }: AgentTraceProps): import("react").JSX.Element;
