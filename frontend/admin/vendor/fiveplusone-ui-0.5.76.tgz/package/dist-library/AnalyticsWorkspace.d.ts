import { type ReactNode } from 'react';
import './analytics-workspace.css';
export type AnalyticsTable = {
    title: string;
    columns: string[];
    rows: ReactNode[][];
};
export type AnalyticsTrend = {
    label: string;
    value: number;
    minutes: number;
};
export declare function AnalyticsWorkspace({ title, description, metrics, tables, loading, error, onRefresh, children, navigation, trend, personal }: {
    title: string;
    description: string;
    metrics: {
        label: string;
        value: ReactNode;
    }[];
    tables: AnalyticsTable[];
    loading?: boolean;
    error?: string;
    onRefresh: () => void;
    children?: ReactNode;
    navigation?: ReactNode;
    trend?: AnalyticsTrend[];
    personal?: boolean;
}): import("react").JSX.Element;
