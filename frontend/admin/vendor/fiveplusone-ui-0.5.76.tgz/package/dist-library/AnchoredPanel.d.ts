import { type ReactNode, type RefObject } from "react";
export interface AnchoredPanelProps {
    anchor: RefObject<HTMLElement | null>;
    open: boolean;
    onClose: () => void;
    children: ReactNode;
    label: string;
    id?: string;
    role?: "dialog" | "menu" | "listbox";
    width?: number;
    maxHeight?: number;
    className?: string;
    initialFocus?: RefObject<HTMLElement | null>;
    /** Suggestion lists keep typing in their anchor; dialogs and menus receive focus. */
    autoFocus?: boolean;
}
export declare function AnchoredPanel({ anchor, open, onClose, children, label, id, role, width, maxHeight, className, initialFocus, autoFocus, }: AnchoredPanelProps): import("react").ReactPortal | null;
