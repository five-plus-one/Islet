import { type CSSProperties, type ReactNode } from "react";
import { type ProductTheme } from "./themes";
export interface ContentTypography {
    font: string;
    fontSize: number;
    lineHeight: number;
    inherit: boolean;
}
export interface AppearancePreferences {
    theme: "light" | "dark" | "system";
    mode: "default" | "colorful" | "custom";
    lightAccent: string;
    darkAccent: string;
    selection: string;
    font: string;
    regions: Record<string, ContentTypography>;
    uiFontSize?: number;
    readingFontSize?: number;
}
export declare const READING_FONTS: {
    fontFamily: string;
    value: string;
    label: string;
}[];
/** Apply these variables to the host appearance scope; the selected product supplies the default palette. */
export declare function appearanceStyles(value: AppearancePreferences, systemDark?: boolean, product?: ProductTheme): CSSProperties;
export declare function resolveContentTypography(value: AppearancePreferences, region: string): CSSProperties;
export declare function AppearanceWorkspace({ value, onChange, onReset, product, heading, regions, }: {
    value: AppearancePreferences;
    onChange: (value: AppearancePreferences) => void;
    onReset: () => void;
    product?: ProductTheme;
    heading?: boolean;
    regions?: {
        id: string;
        label: string;
    }[];
}): import("react").JSX.Element;
export interface LearningRecord {
    id: string;
    subject: string;
    chapter: string;
    last: number;
    best: number;
    attempts: number;
    updatedAt?: string;
}
export declare function LearningRecords({ records, onOpen, onClear, shortcuts, appearance, }: {
    records: LearningRecord[];
    onOpen: (id: string) => void;
    onClear: () => Promise<void> | void;
    shortcuts?: ReactNode;
    appearance?: ReactNode;
}): import("react").JSX.Element;
