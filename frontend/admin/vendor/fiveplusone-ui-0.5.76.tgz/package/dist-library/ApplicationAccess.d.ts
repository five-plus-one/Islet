import { type ReactNode } from 'react';
import './application-access.css';
export interface ApplicationAccessProps {
    brand: ReactNode;
    headerActions?: ReactNode;
    serviceName: string;
    loading?: boolean;
    busy?: boolean;
    error?: string;
    onRetry?: () => void;
    request?: {
        name: string;
        returnLabel?: string;
        kind?: 'connection' | 'task' | 'change';
        allowEmptySelection?: boolean;
        purpose?: string;
        notice?: string;
        permissions: {
            label: string;
            description?: string;
        }[];
        items: {
            id: string;
            title: string;
            detail?: string;
            permissions?: string[];
        }[];
        changes?: {
            before: string;
            after: string;
        };
        changeSet?: {
            title: string;
            before: string;
            after: string;
        }[];
    };
    completed?: {
        title: string;
        description: string;
    };
    onDone?: () => void;
    doneLabel?: string;
    codeEntry?: {
        value: string;
        onChange: (value: string) => void;
        onSubmit: () => void;
    };
    selectedIds?: string[];
    onSelectionChange?: (ids: string[]) => void;
    onApprove?: () => void;
    onCancel?: () => void;
    connections?: {
        id: string;
        name: string;
        permissions: string;
        detail: string;
        status: 'active' | 'expired' | 'revoked';
    }[];
    onRevoke?: (id: string) => void;
}
/** App-owned permissions and persistence, shared authorization and connection UX. */
export declare function ApplicationAccess({ brand, headerActions, serviceName, request, completed, onDone, doneLabel, codeEntry, selectedIds, onSelectionChange, onApprove, onCancel, connections, onRevoke, loading, busy, error, onRetry }: ApplicationAccessProps): import("react").JSX.Element;
