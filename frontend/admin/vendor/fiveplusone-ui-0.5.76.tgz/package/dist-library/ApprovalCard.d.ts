/** ApprovalCard - 从课栈 chat/ImageGenCard 提取
 *
 * 需要用户明确批准的 AI 操作卡片：展示提示词与将要消耗的资源，
 * 未批准前不执行。用于生图、付费调用等不可自动继续的任务。
 */
import type { ReactNode } from "react";
export interface ApprovalCardProps {
    title?: string;
    /** 将要执行的内容，例如提示词 */
    prompt?: string;
    /** 关键参数列表 */
    details?: {
        label: string;
        value: ReactNode;
    }[];
    /** 费用或资源提示 */
    cost?: ReactNode;
    status?: "idle" | "approved" | "running" | "done" | "cancelled" | "error";
    onApprove: () => void;
    onCancel: () => void;
    /** 完成后显示的结果区域 */
    children?: ReactNode;
}
export declare function ApprovalCard({ title, prompt, details, cost, status, onApprove, onCancel, children, }: ApprovalCardProps): import("react").JSX.Element;
