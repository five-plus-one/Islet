export interface PickableAttachment {
    id: string;
    name: string;
    detail?: string;
    disabled?: boolean;
}
export interface AttachmentPickerProps {
    items: PickableAttachment[];
    selectedIds: string[];
    onChange: (ids: string[]) => void;
    onConfirm: (ids: string[]) => Promise<void> | void;
    loading?: boolean;
    error?: string;
    onSearch?: (query: string) => void;
    onLoadMore?: () => void;
    hasMore?: boolean;
}
export declare function AttachmentPicker({ items, selectedIds, onChange, onConfirm, loading, error, onSearch, onLoadMore, hasMore }: AttachmentPickerProps): import("react").JSX.Element;
