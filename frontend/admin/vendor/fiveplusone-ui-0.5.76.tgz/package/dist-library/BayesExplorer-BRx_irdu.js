import { jsxs as t, jsx as e } from "react/jsx-runtime";
import { learningAlpha as V } from "./index.js";
import { memo as Y, useState as T } from "react";
const l = "var(--fp-primary)", C = "var(--fp-primary-soft)", F = "#0f766e", d = "#dc2626", H = "var(--bg-muted)";
function h(n) {
  return (n * 100).toFixed(1) + "%";
}
function i(n) {
  return n.toFixed(4);
}
const w = 1e3, k = 40, E = 25, A = 360, O = 200, j = A / k, B = O / E;
function q(n, s, x, D) {
  const u = n + s + x + D, N = [], o = k * E / u, c = {
    TP: Math.round(n * o),
    FP: Math.round(s * o),
    FN: Math.round(x * o),
    TN: 0
  };
  c.TN = k * E - c.TP - c.FP - c.FN;
  const r = ["TP", "FP", "FN", "TN"];
  let v = 0;
  for (const m of r) {
    const f = c[m];
    for (let p = 0; p < f; p++)
      N.push({
        type: m,
        col: v % k,
        row: Math.floor(v / k)
      }), v++;
  }
  return N;
}
function z(n, s) {
  return s === "positive" && (n === "TP" || n === "FP") ? n === "TP" ? l : d : s === "disease" && (n === "TP" || n === "FN") ? n === "TP" ? l : F : {
    TP: l,
    FP: d,
    FN: F,
    TN: H
  }[n];
}
function J(n, s) {
  return s === "positive" ? n === "TP" || n === "FP" ? 1 : 0.2 : s === "disease" ? n === "TP" || n === "FN" ? 1 : 0.2 : 0.85;
}
function G({
  label: n,
  value: s,
  min: x,
  max: D,
  step: u,
  onChange: N,
  color: o,
  note: c
}) {
  return /* @__PURE__ */ t("div", { className: "space-y-1", children: [
    /* @__PURE__ */ t("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: n }),
      /* @__PURE__ */ e(
        "span",
        {
          className: "rounded-md px-2 py-0.5 text-[13px] font-mono font-bold",
          style: {
            background: o ? V(o, "22") : C,
            color: o ?? l
          },
          children: h(s)
        }
      )
    ] }),
    c && /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--ink-soft)] leading-relaxed", children: c }),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: x,
        max: D,
        step: u,
        value: s,
        onChange: (r) => N(Number(r.target.value)),
        className: "w-full accent-[var(--accent)] h-1.5 cursor-pointer",
        style: { accentColor: o ?? l }
      }
    )
  ] });
}
function K() {
  const [n, s] = T(0.01), [x, D] = T(0.9), [u, N] = T(0.95), [o, c] = T("all"), r = n, v = 1 - r, m = x, f = 1 - u, p = m * r + f * v, g = p > 0 ? m * r / p : 0, S = Math.round(r * w), L = w - S, b = Math.round(m * S), R = S - b, y = Math.round(f * L), _ = L - y, M = b + y, $ = q(b, y, R, _);
  return /* @__PURE__ */ t("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ t("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "贝叶斯推断可视化" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "调整患病率、灵敏度、特异度，观察「阳性中真正患病」的后验概率如何变化。" })
    ] }),
    /* @__PURE__ */ t("div", { className: "space-y-4 rounded-lg bg-[var(--bg-muted)] px-4 py-3", children: [
      /* @__PURE__ */ e(
        G,
        {
          label: "患病率 P(D)（先验）",
          value: n,
          min: 1e-3,
          max: 0.3,
          step: 1e-3,
          onChange: s,
          color: l,
          note: "患病率极低时，即使灵敏度很高，假阳性也可能淹没真阳性。"
        }
      ),
      /* @__PURE__ */ e(
        G,
        {
          label: "灵敏度 P(+|D)（患病者检出率）",
          value: x,
          min: 0.5,
          max: 0.999,
          step: 1e-3,
          onChange: D,
          color: F,
          note: "灵敏度越高，漏诊（FN）越少，「患病者被正确检出」越多。"
        }
      ),
      /* @__PURE__ */ e(
        G,
        {
          label: "特异度 P(−|D̄)（健康者排除率）",
          value: u,
          min: 0.5,
          max: 0.999,
          step: 1e-3,
          onChange: N,
          color: d,
          note: "特异度越高，误报（FP）越少，假阳性率 = 1 − 特异度越小。"
        }
      )
    ] }),
    /* @__PURE__ */ t("div", { children: [
      /* @__PURE__ */ t("div", { className: "mb-2 flex flex-wrap gap-1.5", children: [
        [
          { key: "all", label: "全体人群" },
          { key: "positive", label: "检测阳性" },
          { key: "disease", label: "实际患病" }
        ].map((a) => /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => c(a.key),
            className: "rounded-lg px-2.5 py-1 text-[12px] font-medium transition-colors " + (a.key === o ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--accent-weak)]"),
            children: a.label
          },
          a.key
        )),
        /* @__PURE__ */ t("span", { className: "ml-auto self-center text-[11px] text-[var(--ink-soft)]", children: [
          "每格 ≈ ",
          (w / (k * E)).toFixed(1),
          " 人（总 ",
          w,
          " 人）"
        ] })
      ] }),
      /* @__PURE__ */ e(
        "svg",
        {
          viewBox: `0 0 ${A} ${O}`,
          className: "w-full rounded-lg border border-[var(--line)]",
          style: { maxHeight: 220 },
          children: $.map((a, P) => /* @__PURE__ */ e(
            "rect",
            {
              x: a.col * j + 0.5,
              y: a.row * B + 0.5,
              width: j - 1,
              height: B - 1,
              fill: z(a.type, o),
              opacity: J(a.type, o),
              rx: 0.8
            },
            P
          ))
        }
      ),
      /* @__PURE__ */ e("div", { className: "mt-2 flex flex-wrap gap-x-4 gap-y-1", children: [
        { color: l, label: "真阳性 TP（患病+阳）", n: b },
        { color: d, label: "假阳性 FP（健康+阳）", n: y },
        { color: F, label: "假阴性 FN（患病+阴）", n: R },
        { color: H, label: "真阴性 TN（健康+阴）", n: _ }
      ].map(({ color: a, label: P, n: W }) => /* @__PURE__ */ t(
        "div",
        {
          className: "flex items-center gap-1.5 text-[11px] text-[var(--ink-soft)]",
          children: [
            /* @__PURE__ */ e(
              "span",
              {
                className: "inline-block h-3 w-3 rounded-sm flex-shrink-0",
                style: { background: a }
              }
            ),
            /* @__PURE__ */ e("span", { children: P }),
            /* @__PURE__ */ e("span", { className: "font-mono font-semibold text-[var(--ink)]", children: W })
          ]
        },
        P
      )) })
    ] }),
    /* @__PURE__ */ t(
      "div",
      {
        className: "rounded-lg border-2 p-4 space-y-3",
        style: { borderColor: l, background: C },
        children: [
          /* @__PURE__ */ t("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ e("span", { className: "text-[14px] font-bold text-[var(--ink)]", children: "后验概率 P(D | +)" }),
            /* @__PURE__ */ e(
              "span",
              {
                className: "text-[22px] font-extrabold font-mono",
                style: { color: l },
                children: h(g)
              }
            )
          ] }),
          /* @__PURE__ */ t("p", { className: "text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
            "检测阳性的 ",
            /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: M }),
            " 人中， 真正患病的只有 ",
            /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: b }),
            " 人， 有",
            " ",
            /* @__PURE__ */ e("b", { style: { color: d }, children: y }),
            " 人是假阳性。",
            g < 0.5 && /* @__PURE__ */ e("span", { className: "block mt-1 font-semibold", style: { color: d }, children: "[!] 即使检测阳性，实际患病概率仍不足 50%！这是「基率谬误」的典型体现。" })
          ] }),
          /* @__PURE__ */ t("div", { children: [
            /* @__PURE__ */ t("div", { className: "mb-1 flex justify-between text-[11px] text-[var(--ink-soft)]", children: [
              /* @__PURE__ */ t("span", { style: { color: l }, children: [
                "真阳性 ",
                b
              ] }),
              /* @__PURE__ */ t("span", { style: { color: d }, children: [
                "假阳性 ",
                y
              ] })
            ] }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "h-5 w-full rounded-full overflow-hidden flex",
                style: { background: d },
                children: /* @__PURE__ */ e(
                  "div",
                  {
                    className: "h-full rounded-full transition-all duration-300",
                    style: {
                      width: M > 0 ? `${b / M * 100}%` : "0%",
                      background: l
                    }
                  }
                )
              }
            ),
            /* @__PURE__ */ t("div", { className: "mt-1 text-center text-[11px] text-[var(--ink-soft)]", children: [
              "阳性中真患病占比 = ",
              h(g)
            ] })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ t("div", { className: "space-y-3", children: [
      /* @__PURE__ */ t("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 text-[12px] leading-loose text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "全概率公式" }),
        /* @__PURE__ */ e("div", { className: "font-mono", children: "P(+) = P(+|D)·P(D) + P(+|D̄)·P(D̄)" }),
        /* @__PURE__ */ t("div", { className: "font-mono mt-0.5", children: [
          "     ",
          "   = ",
          i(m),
          " × ",
          i(r),
          " + ",
          i(f),
          " × ",
          i(v)
        ] }),
        /* @__PURE__ */ t("div", { className: "font-mono mt-0.5", children: [
          "     ",
          "   =",
          " ",
          /* @__PURE__ */ e("span", { style: { color: l, fontWeight: 700 }, children: i(m * r) }),
          " + ",
          /* @__PURE__ */ e("span", { style: { color: d, fontWeight: 700 }, children: i(f * v) }),
          " = ",
          /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: i(p) })
        ] })
      ] }),
      /* @__PURE__ */ t("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 text-[12px] leading-loose text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "贝叶斯公式" }),
        /* @__PURE__ */ e("div", { className: "font-mono", children: "P(D|+) = P(+|D)·P(D) / P(+)" }),
        /* @__PURE__ */ t("div", { className: "font-mono mt-0.5", children: [
          "       ",
          "    =",
          " ",
          /* @__PURE__ */ e("span", { style: { color: l, fontWeight: 700 }, children: i(m * r) }),
          " / ",
          /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: i(p) })
        ] }),
        /* @__PURE__ */ t("div", { className: "font-mono mt-0.5", children: [
          "       ",
          "    =",
          " ",
          /* @__PURE__ */ e(
            "span",
            {
              className: "text-[15px] font-extrabold",
              style: { color: l },
              children: i(g)
            }
          ),
          " ≈ ",
          /* @__PURE__ */ e("span", { style: { color: l, fontWeight: 700 }, children: h(g) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
      {
        label: "人群患病率 P(D)",
        val: h(r),
        bg: C,
        col: l
      },
      {
        label: "检测阳性率 P(+)",
        val: h(p),
        bg: "rgba(16,185,129,0.10)",
        col: F
      },
      {
        label: "假阳性率 P(+|D̄)",
        val: h(f),
        bg: "rgba(244,63,94,0.10)",
        col: d
      },
      {
        label: "后验 P(D|+)",
        val: h(g),
        bg: C,
        col: l
      }
    ].map(({ label: a, val: P, bg: W, col: I }) => /* @__PURE__ */ t(
      "div",
      {
        className: "rounded-lg p-2.5 text-center",
        style: { background: W },
        children: [
          /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)] leading-snug", children: a }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "text-[16px] font-extrabold font-mono mt-0.5",
              style: { color: I },
              children: P
            }
          )
        ]
      },
      a
    )) }),
    /* @__PURE__ */ t("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "直觉提示：" }),
      "当患病率很低时，即使检测很准（高灵敏度+高特异度），绝大多数阳性仍是假阳性——这就是",
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "基率谬误" }),
      "（Base Rate Fallacy）。 提高先验（患病率）或提高特异度，都能显著改善后验。 点击「检测阳性」可高亮看清楚蓝（TP）vs 红（FP）的比例。"
    ] })
  ] });
}
const ee = Y(K);
export {
  ee as default
};
