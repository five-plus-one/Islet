import { jsxs as a, jsx as t } from "react/jsx-runtime";
import { memo as L, useState as N } from "react";
const R = {
  dispersion: "色散力",
  dipole: "偶极-偶极",
  hydrogen: "氢键"
}, A = {
  dispersion: "#94a3b8",
  dipole: "#6366f1",
  hydrogen: "#ef4444"
}, b = [
  {
    id: "alkane-series",
    title: "正构烷烃同系列",
    description: "同类型分子间作用力（色散力），比较分子量对沸点的影响。",
    molecules: [
      { name: "甲烷", formula: "CH₄", force: "dispersion", bp: -161.5 },
      { name: "乙烷", formula: "C₂H₆", force: "dispersion", bp: -88.6 },
      { name: "丁烷", formula: "C₄H₁₀", force: "dispersion", bp: -0.5 },
      { name: "己烷", formula: "C₆H₁₄", force: "dispersion", bp: 68.7 }
    ],
    explanation: "四者主导作用力都是色散力。分子量越大、电子数越多，瞬时偶极越易产生且越强，色散力越大，因此沸点随碳链增长（分子量增大）而单调升高。"
  },
  {
    id: "pentane-isomers",
    title: "同分异构体（支链效应）",
    description: "分子式同为 C₅H₁₂，比较支链程度对沸点的影响。",
    molecules: [
      { name: "正戊烷", formula: "C₅H₁₂", force: "dispersion", bp: 36 },
      { name: "异戊烷", formula: "C₅H₁₂", force: "dispersion", bp: 28 },
      { name: "新戊烷", formula: "C₅H₁₂", force: "dispersion", bp: 9.5 }
    ],
    explanation: "三者分子量相同、均为色散力主导。支链越多分子越趋近球形，表面积越小、分子间接触面越少，色散力越弱，因此沸点：正戊烷 > 异戊烷 > 新戊烷。"
  },
  {
    id: "hydrogen-bond",
    title: "氢键组（C₂H₆O 与乙烷对比）",
    description: "相近分子量下，比较色散力、偶极力与氢键的强弱差异。",
    molecules: [
      { name: "乙烷", formula: "C₂H₆", force: "dispersion", bp: -88.6 },
      { name: "二甲醚", formula: "CH₃OCH₃", force: "dipole", bp: -24 },
      { name: "乙醇", formula: "C₂H₅OH", force: "hydrogen", bp: 78.4 }
    ],
    explanation: "乙烷只有弱色散力，沸点最低；二甲醚分子有极性 C–O–C，存在偶极-偶极作用，沸点升高；乙醇含 –OH，分子间能形成氢键（最强），需要更多能量才能气化，沸点最高（78.4℃）。可见氢键 > 偶极力 > 色散力。"
  }
];
function P(d, x) {
  return d.length !== x.length ? !1 : d.every((i, c) => i === x[c]);
}
function _() {
  const [d, x] = N(b[0].id), [i, c] = N([]), [s, g] = N(!1), u = b.find((e) => e.id === d) ?? b[0], o = u.molecules, y = o.map((e, r) => r).sort((e, r) => o[e].bp - o[r].bp);
  function S(e) {
    x(e), c([]), g(!1);
  }
  function z(e) {
    s || c((r) => r.includes(e) ? r : [...r, e]);
  }
  function M() {
    c([]), g(!1);
  }
  function j() {
    g(!0);
  }
  const C = i.length === o.length, w = s && P(i, y), H = o.map((e) => e.bp), h = Math.min(...H, 0), O = Math.max(...H, 0) - h || 1, v = 520, f = 40 + o.length * 52, m = 120, B = v - m - 70, p = m + (0 - h) / O * B;
  return /* @__PURE__ */ a("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ t("h3", { className: "text-lg font-semibold text-[var(--ink)]", children: "分子间作用力与沸点比较" }),
    /* @__PURE__ */ t("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "选择一组分子，先按「沸点从低到高」猜测排列顺序，再揭晓真实沸点并理解背后的分子间作用力原理。" }),
    /* @__PURE__ */ t("div", { className: "mt-4 flex flex-wrap gap-2", children: b.map((e) => {
      const r = e.id === d;
      return /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => S(e.id),
          className: "rounded-lg border px-3 py-1.5 text-sm transition-colors " + (r ? "border-indigo-500 bg-indigo-500 text-white" : "border-[var(--line)] bg-[var(--bg-muted)] text-[var(--ink)] hover:border-indigo-400"),
          children: e.title
        },
        e.id
      );
    }) }),
    /* @__PURE__ */ t("p", { className: "mt-3 text-sm text-[var(--ink-soft)]", children: u.description }),
    /* @__PURE__ */ a("div", { className: "mt-4 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
      /* @__PURE__ */ t("div", { className: "mb-2 text-sm font-medium text-[var(--ink)]", children: "1. 点击分子，按你认为的「沸点从低 → 高」依次排列：" }),
      /* @__PURE__ */ t("div", { className: "flex flex-wrap gap-2", children: o.map((e, r) => {
        const n = i.includes(r), l = i.indexOf(r);
        return /* @__PURE__ */ a(
          "button",
          {
            type: "button",
            disabled: s || n,
            onClick: () => z(r),
            className: "relative rounded-lg border px-3 py-2 text-sm transition-colors " + (n ? "cursor-default border-indigo-300 bg-[var(--bg-elevated)] text-[var(--ink-soft)] opacity-60" : "border-[var(--line)] bg-[var(--bg-elevated)] text-[var(--ink)] hover:border-indigo-400"),
            children: [
              /* @__PURE__ */ t("span", { className: "font-medium", children: e.name }),
              " ",
              /* @__PURE__ */ t("span", { className: "text-xs text-[var(--ink-soft)]", children: e.formula }),
              n && /* @__PURE__ */ t("span", { className: "ml-1 inline-flex h-5 w-5 items-center justify-center rounded-full bg-indigo-500 text-xs text-white", children: l + 1 })
            ]
          },
          e.name + r
        );
      }) }),
      i.length > 0 && /* @__PURE__ */ a("div", { className: "mt-3 flex flex-wrap items-center gap-1.5 text-sm text-[var(--ink)]", children: [
        /* @__PURE__ */ t("span", { className: "text-[var(--ink-soft)]", children: "你的顺序：" }),
        i.map((e, r) => /* @__PURE__ */ a("span", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ t("span", { className: "rounded bg-[var(--bg-elevated)] px-2 py-0.5 ring-1 ring-[var(--line)]", children: o[e].name }),
          r < i.length - 1 && /* @__PURE__ */ t("span", { className: "text-[var(--ink-soft)]", children: "→" })
        ] }, e))
      ] }),
      /* @__PURE__ */ a("div", { className: "mt-3 flex flex-wrap gap-2", children: [
        /* @__PURE__ */ t(
          "button",
          {
            type: "button",
            disabled: !C || s,
            onClick: j,
            className: "rounded-lg px-3 py-1.5 text-sm font-medium transition-colors " + (C && !s ? "bg-indigo-500 text-white hover:bg-indigo-600" : "cursor-not-allowed bg-[var(--bg-muted)] text-[var(--ink-soft)] ring-1 ring-[var(--line)]"),
            children: "揭晓答案"
          }
        ),
        /* @__PURE__ */ t(
          "button",
          {
            type: "button",
            onClick: M,
            className: "rounded-lg border border-[var(--line)] bg-[var(--bg-elevated)] px-3 py-1.5 text-sm text-[var(--ink)] transition-colors hover:border-indigo-400",
            children: "重新猜"
          }
        )
      ] })
    ] }),
    s && /* @__PURE__ */ a("div", { className: "mt-4", children: [
      /* @__PURE__ */ t(
        "div",
        {
          className: "mb-3 rounded-lg px-3 py-2 text-sm font-medium " + (w ? "bg-emerald-500/10 text-[var(--color-success)] ring-1 ring-emerald-500/30" : "bg-amber-500/10 text-[var(--color-warning)] ring-1 ring-amber-500/30"),
          children: w ? "完全正确！你的排序与真实沸点一致。" : "差一点～ 正确顺序见下方条形图。"
        }
      ),
      /* @__PURE__ */ t("div", { className: "mb-2 text-sm font-medium text-[var(--ink)]", children: "2. 真实沸点（℃）— 从低到高" }),
      /* @__PURE__ */ t("div", { className: "overflow-x-auto", children: /* @__PURE__ */ a(
        "svg",
        {
          width: v,
          height: f,
          viewBox: `0 0 ${v} ${f}`,
          role: "img",
          "aria-label": "各分子真实沸点条形图",
          children: [
            /* @__PURE__ */ t(
              "line",
              {
                x1: p,
                y1: 10,
                x2: p,
                y2: f - 10,
                stroke: "var(--line)",
                strokeDasharray: "4 3"
              }
            ),
            /* @__PURE__ */ t(
              "text",
              {
                x: p,
                y: f - 2,
                fontSize: 10,
                textAnchor: "middle",
                fill: "var(--ink-soft)",
                children: "0℃"
              }
            ),
            y.map((e, r) => {
              const n = o[e], l = 20 + r * 52, k = m + (n.bp - h) / O * B, E = Math.min(p, k), G = Math.abs(k - p);
              return /* @__PURE__ */ a("g", { children: [
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: m - 8,
                    y: l + 18,
                    fontSize: 12,
                    textAnchor: "end",
                    fill: "var(--ink)",
                    children: n.name
                  }
                ),
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: m - 8,
                    y: l + 31,
                    fontSize: 9,
                    textAnchor: "end",
                    fill: "var(--ink-soft)",
                    children: n.formula
                  }
                ),
                /* @__PURE__ */ t(
                  "rect",
                  {
                    x: E,
                    y: l,
                    width: Math.max(G, 2),
                    height: 26,
                    rx: 3,
                    fill: A[n.force]
                  }
                ),
                /* @__PURE__ */ a(
                  "text",
                  {
                    x: k + (n.bp >= 0 ? 6 : -6),
                    y: l + 18,
                    fontSize: 11,
                    textAnchor: n.bp >= 0 ? "start" : "end",
                    fill: "var(--ink)",
                    children: [
                      n.bp,
                      "℃"
                    ]
                  }
                )
              ] }, n.name + e);
            })
          ]
        }
      ) }),
      /* @__PURE__ */ t("div", { className: "mt-2 flex flex-wrap gap-3 text-xs text-[var(--ink-soft)]", children: Object.keys(R).map((e) => /* @__PURE__ */ a("span", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t(
          "span",
          {
            className: "inline-block h-3 w-3 rounded-sm",
            style: { backgroundColor: A[e] }
          }
        ),
        R[e]
      ] }, e)) }),
      /* @__PURE__ */ a("div", { className: "mt-3 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3 text-sm leading-relaxed text-[var(--ink)]", children: [
        /* @__PURE__ */ t("span", { className: "font-medium", children: "为什么？" }),
        " ",
        u.explanation
      ] })
    ] })
  ] });
}
const $ = L(_);
export {
  $ as default
};
