import { jsxs as t, jsx as e } from "react/jsx-runtime";
import { memo as F, useState as B, useMemo as S } from "react";
const f = "var(--fp-primary)", b = [
  { symbol: "H", name: "氢", en: 2.1 },
  { symbol: "C", name: "碳", en: 2.5 },
  { symbol: "N", name: "氮", en: 3 },
  { symbol: "O", name: "氧", en: 3.5 },
  { symbol: "F", name: "氟", en: 4 },
  { symbol: "Cl", name: "氯", en: 3 },
  { symbol: "Br", name: "溴", en: 2.8 },
  { symbol: "S", name: "硫", en: 2.5 }
];
function M(r) {
  return r < 0.6 ? {
    type: "nonpolar",
    label: "非极性共价键",
    description: "电负性差很小（Δχ < 0.6），成键电子对几乎均等地被两个原子共享，分子无明显正负电荷中心。",
    color: "#16a34a"
  } : r < 1.7 ? {
    type: "polar",
    label: "极性共价键",
    description: "电负性差中等（0.6 ≤ Δχ < 1.7），成键电子对偏向电负性较大的原子，使其带部分负电荷 δ−，另一原子带部分正电荷 δ+。",
    color: f
  } : {
    type: "ionic",
    label: "离子键",
    description: "电负性差很大（Δχ ≥ 1.7），电子几乎完全转移给电负性较大的原子，形成正、负离子并以静电引力结合。",
    color: "#dc2626"
  };
}
function W({
  title: r,
  value: g,
  onChange: s
}) {
  return /* @__PURE__ */ t("div", { className: "flex-1", children: [
    /* @__PURE__ */ e("div", { className: "mb-1 text-xs font-medium text-[var(--ink-soft)]", children: r }),
    /* @__PURE__ */ e("div", { className: "flex flex-wrap gap-1.5", children: b.map((a) => {
      const l = a.en === g;
      return /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => s(a.en),
          className: "rounded-lg border px-2.5 py-1 text-sm transition-colors",
          style: {
            borderColor: l ? f : "var(--line)",
            background: l ? f : "var(--bg-muted)",
            color: l ? "var(--fp-on-primary)" : "var(--ink)"
          },
          children: [
            /* @__PURE__ */ e("span", { className: "font-semibold", children: a.symbol }),
            /* @__PURE__ */ e("span", { className: "ml-1 text-[11px] opacity-80", children: a.en.toFixed(1) })
          ]
        },
        a.symbol
      );
    }) })
  ] });
}
function X() {
  const [r, g] = B(2.1), [s, a] = B(4), l = b.find((u) => u.en === r) ?? b[0], h = b.find((u) => u.en === s) ?? b[0], o = S(() => Math.abs(r - s), [r, s]), i = S(
    () => M(o),
    [o]
  ), v = s >= r, k = o === 0 ? "" : v ? "δ+" : "δ−", N = o === 0 ? "" : v ? "δ−" : "δ+", A = 360, C = 150, n = 70, m = 100, x = 260, d = 28, w = 110, p = Math.min(w, o / 3.5 * w), c = (m + x) / 2, y = n + d + 28, z = v ? c - p / 2 : c + p / 2, E = v ? c + p / 2 : c - p / 2;
  return /* @__PURE__ */ t("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "text-base font-semibold text-[var(--ink)]", children: "电负性与键极性探索器" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "选择两个成键原子，实时计算电负性差 Δχ 并判定键的类型，下方用偶极箭头直观展示键的极性。" }),
    /* @__PURE__ */ t("div", { className: "mt-4 flex flex-col gap-3 sm:flex-row", children: [
      /* @__PURE__ */ e(W, { title: "原子 A", value: r, onChange: g }),
      /* @__PURE__ */ e(W, { title: "原子 B", value: s, onChange: a })
    ] }),
    /* @__PURE__ */ t("div", { className: "mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2", children: [
      /* @__PURE__ */ t("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
        /* @__PURE__ */ e("div", { className: "text-xs text-[var(--ink-soft)]", children: "电负性差 Δχ" }),
        /* @__PURE__ */ e("div", { className: "mt-0.5 text-2xl font-bold text-[var(--ink)]", children: o.toFixed(1) }),
        /* @__PURE__ */ t("div", { className: "mt-0.5 text-xs text-[var(--ink-soft)]", children: [
          "|",
          l.en.toFixed(1),
          " − ",
          h.en.toFixed(1),
          "| = ",
          l.symbol,
          "–",
          h.symbol
        ] })
      ] }),
      /* @__PURE__ */ t(
        "div",
        {
          className: "rounded-lg border p-3",
          style: {
            borderColor: i.color,
            background: "var(--bg-muted)"
          },
          children: [
            /* @__PURE__ */ e("div", { className: "text-xs text-[var(--ink-soft)]", children: "键的类型" }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "mt-0.5 text-lg font-bold",
                style: { color: i.color },
                children: i.label
              }
            )
          ]
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "mt-4 flex justify-center rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-2", children: /* @__PURE__ */ t(
      "svg",
      {
        width: "100%",
        viewBox: `0 0 ${A} ${C}`,
        role: "img",
        "aria-label": `${l.symbol} 与 ${h.symbol} 成键的偶极示意图`,
        style: { maxWidth: A },
        children: [
          /* @__PURE__ */ e("defs", { children: /* @__PURE__ */ e(
            "marker",
            {
              id: "bpe-arrowhead",
              markerWidth: "10",
              markerHeight: "10",
              refX: "8",
              refY: "3",
              orient: "auto",
              markerUnits: "strokeWidth",
              children: /* @__PURE__ */ e("path", { d: "M0,0 L8,3 L0,6 Z", fill: i.color })
            }
          ) }),
          /* @__PURE__ */ e(
            "line",
            {
              x1: m + d,
              y1: n,
              x2: x - d,
              y2: n,
              stroke: "var(--line)",
              strokeWidth: 4
            }
          ),
          /* @__PURE__ */ e(
            "circle",
            {
              cx: m,
              cy: n,
              r: d,
              fill: "var(--bg-muted)",
              stroke: f,
              strokeWidth: 2.5
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: m,
              y: n + 5,
              textAnchor: "middle",
              fontSize: "18",
              fontWeight: "700",
              fill: "var(--ink)",
              children: l.symbol
            }
          ),
          k && /* @__PURE__ */ e(
            "text",
            {
              x: m,
              y: n - d - 8,
              textAnchor: "middle",
              fontSize: "13",
              fontWeight: "700",
              fill: i.color,
              children: k
            }
          ),
          /* @__PURE__ */ e(
            "circle",
            {
              cx: x,
              cy: n,
              r: d,
              fill: "var(--bg-muted)",
              stroke: f,
              strokeWidth: 2.5
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x,
              y: n + 5,
              textAnchor: "middle",
              fontSize: "18",
              fontWeight: "700",
              fill: "var(--ink)",
              children: h.symbol
            }
          ),
          N && /* @__PURE__ */ e(
            "text",
            {
              x,
              y: n - d - 8,
              textAnchor: "middle",
              fontSize: "13",
              fontWeight: "700",
              fill: i.color,
              children: N
            }
          ),
          o > 0 && /* @__PURE__ */ e(
            "line",
            {
              x1: z,
              y1: y,
              x2: E,
              y2: y,
              stroke: i.color,
              strokeWidth: 3,
              markerEnd: "url(#bpe-arrowhead)"
            }
          ),
          o === 0 && /* @__PURE__ */ e(
            "text",
            {
              x: c,
              y: y + 4,
              textAnchor: "middle",
              fontSize: "12",
              fill: "var(--ink-soft)",
              children: "无偶极（对称分布）"
            }
          ),
          o > 0 && /* @__PURE__ */ e(
            "text",
            {
              x: c,
              y: y + 22,
              textAnchor: "middle",
              fontSize: "11",
              fill: "var(--ink-soft)",
              children: "偶极矩方向（指向 δ−）"
            }
          )
        ]
      }
    ) }),
    /* @__PURE__ */ e("p", { className: "mt-3 text-sm leading-relaxed text-[var(--ink-soft)]", children: i.description }),
    /* @__PURE__ */ t("div", { className: "mt-3 flex flex-wrap gap-2 text-xs", children: [
      /* @__PURE__ */ e("span", { className: "rounded-md border border-[var(--line)] px-2 py-1 text-[var(--ink-soft)]", children: "Δχ < 0.6 非极性共价键" }),
      /* @__PURE__ */ e("span", { className: "rounded-md border border-[var(--line)] px-2 py-1 text-[var(--ink-soft)]", children: "0.6 ≤ Δχ < 1.7 极性共价键" }),
      /* @__PURE__ */ e("span", { className: "rounded-md border border-[var(--line)] px-2 py-1 text-[var(--ink-soft)]", children: "Δχ ≥ 1.7 离子键" })
    ] })
  ] });
}
const H = F(X);
export {
  H as default
};
