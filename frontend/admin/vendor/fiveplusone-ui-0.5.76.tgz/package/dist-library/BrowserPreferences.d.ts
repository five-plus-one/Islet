export interface BrowserBookmark {
    id: string;
    name: string;
    url: string;
}
export declare function normalizeBrowserUrl(value: string): string;
export declare function BrowserPreferences({ bookmarks, homeUrl, onAdd, onRemove, onOpen, onHomeChange, }: {
    bookmarks: BrowserBookmark[];
    homeUrl: string;
    onAdd: (bookmark: Omit<BrowserBookmark, "id">) => Promise<void> | void;
    onRemove: (id: string) => Promise<void> | void;
    onOpen: (id: string) => void;
    onHomeChange: (url: string) => Promise<void> | void;
}): import("react").JSX.Element;
