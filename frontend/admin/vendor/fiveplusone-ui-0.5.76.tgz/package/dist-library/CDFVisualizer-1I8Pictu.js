import { jsxs as l, jsx as e, Fragment as R } from "react/jsx-runtime";
import { memo as Ye, useState as S, useRef as Me, useCallback as _, useEffect as Ne } from "react";
const x = "var(--fp-primary)", me = "var(--fp-primary-soft)", Ge = "#7c3aed33", Oe = "var(--ink)", ie = "var(--ink-soft)", Y = "var(--line)", we = "var(--bg-muted)", N = "#059669", p = "#d97706", ye = 540, $e = 200, f = 48, Ue = 20, u = 16, Ze = 36, B = ye - f - Ue, M = $e - u - Ze;
function de(t, s, r) {
  return t < 0 || t > s || !Number.isInteger(t) ? 0 : Ke(s, t) * Math.pow(r, t) * Math.pow(1 - r, s - t);
}
function Ke(t, s) {
  if (s === 0 || s === t) return 1;
  s > t - s && (s = t - s);
  let r = 1;
  for (let c = 0; c < s; c++)
    r = r * (t - c) / (c + 1);
  return r;
}
function ue(t, s, r) {
  let c = 0;
  for (let G = 0; G <= Math.floor(t); G++)
    c += de(G, s, r);
  return Math.min(c, 1);
}
function se(t, s, r) {
  const c = (t - s) / r;
  return Math.exp(-0.5 * c * c) / (r * Math.sqrt(2 * Math.PI));
}
function qe(t) {
  const s = 1 / (1 + 0.3275911 * Math.abs(t)), c = 1 - s * (0.254829592 + s * (-0.284496736 + s * (1.421413741 + s * (-1.453152027 + s * 1.061405429)))) * Math.exp(-t * t);
  return t >= 0 ? c : -c;
}
function Qe(t, s, r) {
  return 0.5 * (1 + qe((t - s) / (r * Math.SQRT2)));
}
function ae(t, s) {
  return t < 0 ? 0 : s * Math.exp(-s * t);
}
function Je(t, s) {
  return t < 0 ? 0 : 1 - Math.exp(-s * t);
}
function v(t, s, r) {
  return f + (t - s) / (r - s) * B;
}
function pe(t, s, r) {
  return s + (t - f) / B * (r - s);
}
function w(t, s) {
  return u + (1 - t / s) * M;
}
function be(t, s) {
  const r = Me(!1), c = _(
    (W) => {
      const y = s.current;
      if (!y) return 0;
      const j = y.getBoundingClientRect(), V = ye / j.width;
      return (W - j.left) * V;
    },
    [s]
  ), G = _(
    (W) => {
      W.preventDefault(), r.current = !0, t(c(W.clientX));
    },
    [t, c]
  ), k = _(
    (W) => {
      r.current && t(c(W.clientX));
    },
    [t, c]
  ), Q = _(() => {
    r.current = !1;
  }, []);
  Ne(() => (window.addEventListener("mousemove", k), window.addEventListener("mouseup", Q), () => {
    window.removeEventListener("mousemove", k), window.removeEventListener("mouseup", Q);
  }), [k, Q]);
  const P = _(
    (W) => {
      W.preventDefault(), r.current = !0, t(c(W.touches[0].clientX));
    },
    [t, c]
  ), J = _(
    (W) => {
      r.current && t(c(W.touches[0].clientX));
    },
    [t, c]
  ), $ = _(() => {
    r.current = !1;
  }, []);
  return Ne(() => (window.addEventListener("touchmove", J, { passive: !1 }), window.addEventListener("touchend", $), () => {
    window.removeEventListener("touchmove", J), window.removeEventListener("touchend", $);
  }), [J, $]), { onMouseDown: G, onTouchStart: P };
}
function C(t) {
  return t.toFixed(4);
}
function ce(t, s, r) {
  return Math.max(s, Math.min(r, t));
}
function et() {
  const [t, s] = S("binomial"), [r] = S(10), [c, G] = S(0.4), [k, Q] = S(0), [P, J] = S(1), [$, W] = S(1), [y, j] = S(4), [V, ee] = S(2), [O, te] = S(6), [F, We] = S(!1), [ne, Pe] = S("pdf"), le = Me(null), De = () => t === "binomial" ? { xMin: -0.5, xMax: r + 0.5 } : t === "normal" ? {
    xMin: k - 4 * P,
    xMax: k + 4 * P
  } : { xMin: 0, xMax: 8 / $ }, { xMin: d, xMax: h } = De(), A = (n) => t === "binomial" ? ue(n, r, c) : t === "normal" ? Qe(n, k, P) : Je(n, $), Ce = (n, o) => {
    const i = Math.min(n, o), a = Math.max(n, o);
    return t === "binomial" ? ue(a, r, c) - ue(i - 1, r, c) : A(a) - A(i);
  }, xe = (n) => ce(n, d, h), U = (() => {
    if (t === "binomial") {
      let n = 0;
      for (let o = 0; o <= r; o++) {
        const i = de(o, r, c);
        i > n && (n = i);
      }
      return n * 1.3;
    }
    return t === "normal" ? se(k, k, P) * 1.3 : ae(0, $) * 1.3;
  })(), Le = () => {
    if (t === "binomial") return "";
    const n = 200, o = [];
    for (let i = 0; i <= n; i++) {
      const a = d + i / n * (h - d), b = t === "normal" ? se(a, k, P) : ae(a, $), g = v(a, d, h), E = w(b, U);
      o.push(`${i === 0 ? "M" : "L"}${g.toFixed(2)},${E.toFixed(2)}`);
    }
    return o.join(" ");
  }, Se = () => {
    if (t === "binomial") return "";
    const n = 300, o = [];
    for (let i = 0; i <= n; i++) {
      const a = d + i / n * (h - d), b = A(a), g = v(a, d, h), E = w(b, 1);
      o.push(`${i === 0 ? "M" : "L"}${g.toFixed(2)},${E.toFixed(2)}`);
    }
    return o.join(" ");
  }, Ae = (n) => {
    if (t === "binomial") return "";
    const o = 150, i = d, a = Math.min(n, h), b = v(i, d, h), g = v(a, d, h), E = u + M, L = [`M${b.toFixed(2)},${E.toFixed(2)}`];
    for (let T = 0; T <= o; T++) {
      const H = i + T / o * (a - i), re = t === "normal" ? se(H, k, P) : ae(H, $), he = v(H, d, h), fe = w(re, U);
      L.push(`L${he.toFixed(2)},${fe.toFixed(2)}`);
    }
    return L.push(`L${g.toFixed(2)},${E.toFixed(2)}`), L.push("Z"), L.join(" ");
  }, ze = (n, o) => {
    if (t === "binomial") return "";
    const i = 150, a = Math.max(Math.min(n, o), d), b = Math.min(Math.max(n, o), h), g = v(a, d, h), E = v(b, d, h), L = u + M, T = [`M${g.toFixed(2)},${L.toFixed(2)}`];
    for (let H = 0; H <= i; H++) {
      const re = a + H / i * (b - a), he = t === "normal" ? se(re, k, P) : ae(re, $), fe = v(re, d, h), Re = w(he, U);
      T.push(`L${fe.toFixed(2)},${Re.toFixed(2)}`);
    }
    return T.push(`L${E.toFixed(2)},${L.toFixed(2)}`), T.push("Z"), T.join(" ");
  }, Xe = _(
    (n) => {
      const o = xe(pe(n, d, h));
      j(t === "binomial" ? Math.round(ce(o, 0, r)) : o);
    },
    [d, h, t, r]
  ), Ee = _(
    (n) => {
      const o = xe(pe(n, d, h));
      ee(t === "binomial" ? Math.round(ce(o, 0, r)) : o);
    },
    [d, h, t, r]
  ), Te = _(
    (n) => {
      const o = xe(pe(n, d, h));
      te(t === "binomial" ? Math.round(ce(o, 0, r)) : o);
    },
    [d, h, t, r]
  ), ge = be(Xe, le), ve = be(Ee, le), ke = be(Te, le), Be = (n) => {
    s(n), n === "binomial" ? (j(4), ee(2), te(6)) : n === "normal" ? (j(0), ee(-1), te(1)) : (j(1), ee(0.5), te(2));
  }, I = A(y), oe = Ce(V, O), Z = Math.min(V, O), K = Math.max(V, O), _e = (() => {
    if (t !== "binomial") return [];
    const n = [], o = B / (r + 1) * 0.6;
    for (let i = 0; i <= r; i++) {
      const a = de(i, r, c), b = v(i, d, h), g = w(a, U), E = u + M - g;
      let L = Y;
      if (!F)
        L = i <= Math.floor(y) ? x : Y;
      else {
        const T = Math.min(Math.round(V), Math.round(O)), H = Math.max(Math.round(V), Math.round(O));
        L = i >= T && i <= H ? p : Y;
      }
      n.push({ k: i, sx: b, sy: g, barH: E, barW: o, fill: L, p: a });
    }
    return n;
  })(), je = () => {
    const n = [];
    let o = 0;
    const i = w(0, 1);
    n.push(`M${f.toFixed(2)},${i.toFixed(2)}`);
    for (let a = 0; a <= r; a++) {
      const b = v(a, d, h), g = o;
      o += de(a, r, c), n.push(`L${b.toFixed(2)},${w(g, 1).toFixed(2)}`), n.push(`L${b.toFixed(2)},${w(o, 1).toFixed(2)}`);
    }
    return n.push(`L${(f + B).toFixed(2)},${w(1, 1).toFixed(2)}`), n.join(" ");
  }, D = v(y, d, h), z = v(V, d, h), X = v(O, d, h), Ve = (() => {
    if (t === "binomial")
      return Array.from({ length: r + 1 }, (o, i) => i);
    const n = 7;
    return Array.from(
      { length: n },
      (o, i) => d + i / (n - 1) * (h - d)
    );
  })(), Ie = [0, 0.25, 0.5, 0.75, 1].map((n) => n * U).filter((n) => n <= U), Fe = t === "binomial" ? `B(${r}, ${c})` : t === "normal" ? `N(${k}, ${P}²)` : `Exp(${$})`, He = [0, 0.25, 0.5, 0.75, 1], m = u + M, q = w(I, 1);
  return /* @__PURE__ */ l("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ l("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "分布函数 F(x) 可视化" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "拖动竖线，直观理解 F(x) = P(X ≤ x) 的含义；切换分布观察形态变化。" })
    ] }),
    /* @__PURE__ */ l("div", { className: "flex flex-wrap gap-2 items-center", children: [
      /* @__PURE__ */ e("span", { className: "text-[12px] font-semibold text-[var(--ink-soft)]", children: "分布：" }),
      [
        { key: "binomial", label: "离散 B(10, p)" },
        { key: "normal", label: "连续 N(μ, σ²)" },
        { key: "exponential", label: "连续 Exp(λ)" }
      ].map(({ key: n, label: o }) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => Be(n),
          className: "rounded-lg px-3 py-1 text-[12px] font-medium transition-colors " + (t === n ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--accent-weak)]"),
          children: o
        },
        n
      )),
      /* @__PURE__ */ e("div", { className: "ml-auto flex gap-1.5", children: ["pdf", "cdf"].map((n) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => Pe(n),
          className: "rounded-lg px-2.5 py-1 text-[11px] font-semibold transition-colors " + (ne === n ? "bg-[var(--ink)] text-[var(--bg-elevated)]" : "bg-[var(--bg-muted)] text-[var(--ink-soft)]"),
          children: n === "pdf" ? t === "binomial" ? "PMF" : "PDF" : "CDF"
        },
        n
      )) })
    ] }),
    /* @__PURE__ */ l("div", { className: "flex flex-wrap gap-x-6 gap-y-2 rounded-lg bg-[var(--bg-muted)] px-4 py-2.5 text-[12px]", children: [
      t === "binomial" && /* @__PURE__ */ l("label", { className: "flex items-center gap-2 text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("span", { children: "p =" }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0.05,
            max: 0.95,
            step: 0.05,
            value: c,
            onChange: (n) => G(Number(n.target.value)),
            className: "w-24 cursor-pointer",
            style: { accentColor: x }
          }
        ),
        /* @__PURE__ */ e("b", { className: "font-mono text-[var(--ink)]", children: c.toFixed(2) })
      ] }),
      t === "normal" && /* @__PURE__ */ l(R, { children: [
        /* @__PURE__ */ l("label", { className: "flex items-center gap-2 text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ e("span", { children: "μ =" }),
          /* @__PURE__ */ e(
            "input",
            {
              type: "range",
              min: -3,
              max: 3,
              step: 0.5,
              value: k,
              onChange: (n) => {
                Q(Number(n.target.value)), j(Number(n.target.value));
              },
              className: "w-20 cursor-pointer",
              style: { accentColor: x }
            }
          ),
          /* @__PURE__ */ e("b", { className: "font-mono text-[var(--ink)]", children: k.toFixed(1) })
        ] }),
        /* @__PURE__ */ l("label", { className: "flex items-center gap-2 text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ e("span", { children: "σ =" }),
          /* @__PURE__ */ e(
            "input",
            {
              type: "range",
              min: 0.5,
              max: 3,
              step: 0.25,
              value: P,
              onChange: (n) => J(Number(n.target.value)),
              className: "w-20 cursor-pointer",
              style: { accentColor: x }
            }
          ),
          /* @__PURE__ */ e("b", { className: "font-mono text-[var(--ink)]", children: P.toFixed(2) })
        ] })
      ] }),
      t === "exponential" && /* @__PURE__ */ l("label", { className: "flex items-center gap-2 text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("span", { children: "λ =" }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0.25,
            max: 3,
            step: 0.25,
            value: $,
            onChange: (n) => W(Number(n.target.value)),
            className: "w-20 cursor-pointer",
            style: { accentColor: x }
          }
        ),
        /* @__PURE__ */ e("b", { className: "font-mono text-[var(--ink)]", children: $.toFixed(2) })
      ] }),
      /* @__PURE__ */ l("label", { className: "flex items-center gap-2 text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("span", { children: "区间模式" }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => We((n) => !n),
            className: "relative inline-flex h-5 w-9 rounded-full transition-colors " + (F ? "bg-[var(--accent)]" : "bg-[var(--line)]"),
            children: /* @__PURE__ */ e(
              "span",
              {
                className: "absolute top-0.5 left-0.5 h-4 w-4 rounded-full bg-[var(--fp-surface)] shadow transition-transform " + (F ? "translate-x-4" : "translate-x-0")
              }
            )
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ l(
      "svg",
      {
        ref: le,
        viewBox: `0 0 ${ye} ${$e}`,
        className: "w-full select-none touch-none rounded-lg border border-[var(--line)]",
        style: { maxHeight: 240, cursor: "ew-resize" },
        children: [
          /* @__PURE__ */ e(
            "rect",
            {
              x: f,
              y: u,
              width: B,
              height: M,
              fill: we
            }
          ),
          ne === "pdf" && /* @__PURE__ */ l(R, { children: [
            Ie.map((n) => {
              const o = w(n, U);
              return /* @__PURE__ */ l("g", { children: [
                /* @__PURE__ */ e(
                  "line",
                  {
                    x1: f,
                    y1: o,
                    x2: f + B,
                    y2: o,
                    stroke: Y,
                    strokeWidth: 0.8
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: f - 4,
                    y: o + 3,
                    fontSize: 9,
                    textAnchor: "end",
                    fill: ie,
                    children: n.toFixed(2)
                  }
                )
              ] }, n);
            }),
            t !== "binomial" && !F && /* @__PURE__ */ e("path", { d: Ae(y), fill: Ge, stroke: "none" }),
            t !== "binomial" && F && /* @__PURE__ */ e(
              "path",
              {
                d: ze(V, O),
                fill: `${p}33`,
                stroke: "none"
              }
            ),
            t !== "binomial" && /* @__PURE__ */ e(
              "path",
              {
                d: Le(),
                fill: "none",
                stroke: x,
                strokeWidth: 2,
                strokeLinejoin: "round"
              }
            ),
            t === "binomial" && _e.map(({ k: n, sx: o, sy: i, barH: a, barW: b, fill: g }) => /* @__PURE__ */ e(
              "rect",
              {
                x: o - b / 2,
                y: i,
                width: b,
                height: a,
                fill: g,
                rx: 2,
                opacity: 0.85
              },
              n
            )),
            /* @__PURE__ */ e(
              "line",
              {
                x1: f,
                y1: m,
                x2: f + B,
                y2: m,
                stroke: Y,
                strokeWidth: 1
              }
            ),
            !F && /* @__PURE__ */ l("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: D,
                  y1: u,
                  x2: D,
                  y2: m,
                  stroke: x,
                  strokeWidth: 1.5,
                  strokeDasharray: "4 3"
                }
              ),
              /* @__PURE__ */ l("g", { ...ge, style: { cursor: "ew-resize" }, children: [
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: D - 10,
                    y: u,
                    width: 20,
                    height: M,
                    fill: "transparent"
                  }
                ),
                /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: D,
                    cy: m,
                    r: 7,
                    fill: x,
                    stroke: "white",
                    strokeWidth: 1.5
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: D,
                    y: m + 16,
                    fontSize: 10,
                    textAnchor: "middle",
                    fill: x,
                    fontWeight: "bold",
                    children: "x"
                  }
                )
              ] })
            ] }),
            F && /* @__PURE__ */ l(R, { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: z,
                  y1: u,
                  x2: z,
                  y2: m,
                  stroke: N,
                  strokeWidth: 1.5,
                  strokeDasharray: "4 3"
                }
              ),
              /* @__PURE__ */ l("g", { ...ve, style: { cursor: "ew-resize" }, children: [
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: z - 10,
                    y: u,
                    width: 20,
                    height: M,
                    fill: "transparent"
                  }
                ),
                /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: z,
                    cy: m,
                    r: 7,
                    fill: N,
                    stroke: "white",
                    strokeWidth: 1.5
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: z,
                    y: m + 16,
                    fontSize: 10,
                    textAnchor: "middle",
                    fill: N,
                    fontWeight: "bold",
                    children: "a"
                  }
                )
              ] }),
              /* @__PURE__ */ e(
                "line",
                {
                  x1: X,
                  y1: u,
                  x2: X,
                  y2: m,
                  stroke: p,
                  strokeWidth: 1.5,
                  strokeDasharray: "4 3"
                }
              ),
              /* @__PURE__ */ l("g", { ...ke, style: { cursor: "ew-resize" }, children: [
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: X - 10,
                    y: u,
                    width: 20,
                    height: M,
                    fill: "transparent"
                  }
                ),
                /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: X,
                    cy: m,
                    r: 7,
                    fill: p,
                    stroke: "white",
                    strokeWidth: 1.5
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: X,
                    y: m + 16,
                    fontSize: 10,
                    textAnchor: "middle",
                    fill: p,
                    fontWeight: "bold",
                    children: "b"
                  }
                )
              ] })
            ] })
          ] }),
          ne === "cdf" && /* @__PURE__ */ l(R, { children: [
            He.map((n) => {
              const o = w(n, 1);
              return /* @__PURE__ */ l("g", { children: [
                /* @__PURE__ */ e(
                  "line",
                  {
                    x1: f,
                    y1: o,
                    x2: f + B,
                    y2: o,
                    stroke: Y,
                    strokeWidth: 0.8
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: f - 4,
                    y: o + 3,
                    fontSize: 9,
                    textAnchor: "end",
                    fill: ie,
                    children: n.toFixed(2)
                  }
                )
              ] }, n);
            }),
            t !== "binomial" && /* @__PURE__ */ e(
              "path",
              {
                d: Se(),
                fill: "none",
                stroke: x,
                strokeWidth: 2.2,
                strokeLinejoin: "round"
              }
            ),
            t === "binomial" && /* @__PURE__ */ e(
              "path",
              {
                d: je(),
                fill: "none",
                stroke: x,
                strokeWidth: 2,
                strokeLinejoin: "round"
              }
            ),
            /* @__PURE__ */ e(
              "line",
              {
                x1: f,
                y1: m,
                x2: f + B,
                y2: m,
                stroke: Y,
                strokeWidth: 1
              }
            ),
            !F && /* @__PURE__ */ l("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: D,
                  y1: u,
                  x2: D,
                  y2: q,
                  stroke: x,
                  strokeWidth: 1.5,
                  strokeDasharray: "4 3"
                }
              ),
              /* @__PURE__ */ e(
                "line",
                {
                  x1: f,
                  y1: q,
                  x2: D,
                  y2: q,
                  stroke: x,
                  strokeWidth: 1.5,
                  strokeDasharray: "4 3"
                }
              ),
              /* @__PURE__ */ e(
                "rect",
                {
                  x: 0,
                  y: q - 8,
                  width: f - 4,
                  height: 14,
                  fill: "var(--bg-elevated)",
                  rx: 2
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: f - 5,
                  y: q + 4,
                  fontSize: 9.5,
                  textAnchor: "end",
                  fill: x,
                  fontWeight: "bold",
                  children: I.toFixed(3)
                }
              ),
              /* @__PURE__ */ e(
                "circle",
                {
                  cx: D,
                  cy: q,
                  r: 4.5,
                  fill: x,
                  stroke: "white",
                  strokeWidth: 1.5
                }
              ),
              /* @__PURE__ */ l("g", { ...ge, style: { cursor: "ew-resize" }, children: [
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: D - 10,
                    y: u,
                    width: 20,
                    height: M,
                    fill: "transparent"
                  }
                ),
                /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: D,
                    cy: m,
                    r: 7,
                    fill: x,
                    stroke: "white",
                    strokeWidth: 1.5
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: D,
                    y: m + 16,
                    fontSize: 10,
                    textAnchor: "middle",
                    fill: x,
                    fontWeight: "bold",
                    children: "x"
                  }
                )
              ] })
            ] }),
            F && /* @__PURE__ */ l(R, { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: z,
                  y1: u,
                  x2: z,
                  y2: m,
                  stroke: N,
                  strokeWidth: 1.5,
                  strokeDasharray: "4 3"
                }
              ),
              /* @__PURE__ */ l("g", { ...ve, style: { cursor: "ew-resize" }, children: [
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: z - 10,
                    y: u,
                    width: 20,
                    height: M,
                    fill: "transparent"
                  }
                ),
                /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: z,
                    cy: m,
                    r: 7,
                    fill: N,
                    stroke: "white",
                    strokeWidth: 1.5
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: z,
                    y: m + 16,
                    fontSize: 10,
                    textAnchor: "middle",
                    fill: N,
                    fontWeight: "bold",
                    children: "a"
                  }
                )
              ] }),
              /* @__PURE__ */ e(
                "line",
                {
                  x1: X,
                  y1: u,
                  x2: X,
                  y2: m,
                  stroke: p,
                  strokeWidth: 1.5,
                  strokeDasharray: "4 3"
                }
              ),
              /* @__PURE__ */ l("g", { ...ke, style: { cursor: "ew-resize" }, children: [
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: X - 10,
                    y: u,
                    width: 20,
                    height: M,
                    fill: "transparent"
                  }
                ),
                /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: X,
                    cy: m,
                    r: 7,
                    fill: p,
                    stroke: "white",
                    strokeWidth: 1.5
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: X,
                    y: m + 16,
                    fontSize: 10,
                    textAnchor: "middle",
                    fill: p,
                    fontWeight: "bold",
                    children: "b"
                  }
                )
              ] }),
              (() => {
                const n = A(Z), o = A(K), i = w(n, 1), a = w(o, 1), b = v(Z, d, h), g = v(K, d, h);
                return /* @__PURE__ */ l(R, { children: [
                  /* @__PURE__ */ e(
                    "line",
                    {
                      x1: f,
                      y1: i,
                      x2: b,
                      y2: i,
                      stroke: N,
                      strokeWidth: 1,
                      strokeDasharray: "3 2",
                      opacity: 0.7
                    }
                  ),
                  /* @__PURE__ */ e(
                    "line",
                    {
                      x1: f,
                      y1: a,
                      x2: g,
                      y2: a,
                      stroke: p,
                      strokeWidth: 1,
                      strokeDasharray: "3 2",
                      opacity: 0.7
                    }
                  ),
                  /* @__PURE__ */ e(
                    "text",
                    {
                      x: f - 4,
                      y: i + 4,
                      fontSize: 8.5,
                      textAnchor: "end",
                      fill: N,
                      fontWeight: "bold",
                      children: n.toFixed(3)
                    }
                  ),
                  /* @__PURE__ */ e(
                    "text",
                    {
                      x: f - 4,
                      y: a + 4,
                      fontSize: 8.5,
                      textAnchor: "end",
                      fill: p,
                      fontWeight: "bold",
                      children: o.toFixed(3)
                    }
                  ),
                  /* @__PURE__ */ e(
                    "line",
                    {
                      x1: f - 14,
                      y1: i,
                      x2: f - 14,
                      y2: a,
                      stroke: x,
                      strokeWidth: 1.5,
                      markerStart: "url(#arrowUp)",
                      markerEnd: "url(#arrowDown)"
                    }
                  )
                ] });
              })()
            ] }),
            /* @__PURE__ */ l("defs", { children: [
              /* @__PURE__ */ e(
                "marker",
                {
                  id: "arrowUp",
                  markerWidth: "6",
                  markerHeight: "6",
                  refX: "3",
                  refY: "3",
                  orient: "auto",
                  children: /* @__PURE__ */ e("path", { d: "M3,6 L0,3 L6,3 Z", fill: x })
                }
              ),
              /* @__PURE__ */ e(
                "marker",
                {
                  id: "arrowDown",
                  markerWidth: "6",
                  markerHeight: "6",
                  refX: "3",
                  refY: "3",
                  orient: "auto-start-reverse",
                  children: /* @__PURE__ */ e("path", { d: "M3,0 L0,3 L6,3 Z", fill: x })
                }
              )
            ] })
          ] }),
          Ve.map((n) => {
            const o = v(n, d, h);
            return /* @__PURE__ */ l("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: o,
                  y1: m,
                  x2: o,
                  y2: m + 4,
                  stroke: ie,
                  strokeWidth: 0.8
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: o,
                  y: m + 13,
                  fontSize: 9,
                  textAnchor: "middle",
                  fill: ie,
                  children: t === "binomial" ? n : n.toFixed(1)
                }
              )
            ] }, n);
          }),
          /* @__PURE__ */ e(
            "text",
            {
              x: f - 22,
              y: u + M / 2,
              fontSize: 9,
              fill: ie,
              textAnchor: "middle",
              transform: `rotate(-90, ${f - 22}, ${u + M / 2})`,
              children: ne === "pdf" ? t === "binomial" ? "P(X=k)" : "f(x)" : "F(x)"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: f + B - 4,
              y: u + 12,
              fontSize: 10,
              textAnchor: "end",
              fill: x,
              fontWeight: "bold",
              children: Fe
            }
          )
        ]
      }
    ),
    F ? (
      /* 区间模式：P(a≤X≤b) 面板 */
      /* @__PURE__ */ l(
        "div",
        {
          className: "rounded-lg border-2 p-4 space-y-2",
          style: { borderColor: p, background: `${p}15` },
          children: [
            /* @__PURE__ */ l("div", { className: "flex items-center justify-between flex-wrap gap-2", children: [
              /* @__PURE__ */ l("span", { className: "text-[13px] font-bold text-[var(--ink)]", children: [
                "P(",
                "a≤X≤b",
                ") = F(b) − F(a",
                t === "binomial" ? "−" : "",
                ")"
              ] }),
              /* @__PURE__ */ e(
                "span",
                {
                  className: "rounded-md bg-[var(--bg-elevated)] px-3 py-0.5 text-[18px] font-mono font-extrabold",
                  style: { color: p },
                  children: C(oe)
                }
              )
            ] }),
            /* @__PURE__ */ l("div", { className: "flex gap-4 flex-wrap text-[12px]", children: [
              /* @__PURE__ */ l("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ e(
                  "span",
                  {
                    className: "w-2 h-2 rounded-full inline-block",
                    style: { background: N }
                  }
                ),
                /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)]", children: "a =" }),
                /* @__PURE__ */ e("b", { className: "font-mono", style: { color: N }, children: t === "binomial" ? Z.toFixed(0) : Z.toFixed(3) }),
                /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)]", children: " → F(a) =" }),
                /* @__PURE__ */ e("b", { className: "font-mono", style: { color: N }, children: C(A(Z)) })
              ] }),
              /* @__PURE__ */ l("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ e(
                  "span",
                  {
                    className: "w-2 h-2 rounded-full inline-block",
                    style: { background: p }
                  }
                ),
                /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)]", children: "b =" }),
                /* @__PURE__ */ e("b", { className: "font-mono", style: { color: p }, children: t === "binomial" ? K.toFixed(0) : K.toFixed(3) }),
                /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)]", children: " → F(b) =" }),
                /* @__PURE__ */ e("b", { className: "font-mono", style: { color: p }, children: C(A(K)) })
              ] })
            ] }),
            /* @__PURE__ */ l("p", { className: "text-[12px] text-[var(--ink-soft)]", children: [
              "P(a≤X≤b) = F(b) − F(a",
              t === "binomial" ? "⁻" : "",
              ") =",
              " ",
              /* @__PURE__ */ e("b", { style: { color: p }, children: C(A(K)) }),
              " −",
              " ",
              /* @__PURE__ */ e("b", { style: { color: N }, children: C(A(Z)) }),
              " =",
              " ",
              /* @__PURE__ */ e("b", { style: { color: p }, children: C(oe) })
            ] }),
            /* @__PURE__ */ e("div", { className: "h-4 w-full rounded-full bg-[var(--bg-elevated)] overflow-hidden border border-[var(--line)]", children: /* @__PURE__ */ e(
              "div",
              {
                className: "h-full rounded-full transition-all duration-200",
                style: { width: `${oe * 100}%`, background: p }
              }
            ) }),
            /* @__PURE__ */ l("div", { className: "text-center text-[11px] text-[var(--ink-soft)]", children: [
              "区间概率 ",
              (oe * 100).toFixed(2),
              "%"
            ] })
          ]
        }
      )
    ) : (
      /* 单滑块：F(x) 面板 */
      /* @__PURE__ */ l(
        "div",
        {
          className: "rounded-lg border-2 p-4 space-y-2",
          style: { borderColor: x, background: me },
          children: [
            /* @__PURE__ */ l("div", { className: "flex items-center justify-between flex-wrap gap-2", children: [
              /* @__PURE__ */ e("span", { className: "text-[13px] font-bold text-[var(--ink)]", children: "F(x) = P(X ≤ x)" }),
              /* @__PURE__ */ l("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ e("span", { className: "text-[12px] text-[var(--ink-soft)]", children: "x =" }),
                /* @__PURE__ */ e(
                  "span",
                  {
                    className: "rounded-md bg-[var(--bg-elevated)] px-2 py-0.5 text-[13px] font-mono font-bold",
                    style: { color: x },
                    children: t === "binomial" ? y.toFixed(0) : y.toFixed(3)
                  }
                ),
                /* @__PURE__ */ e("span", { className: "text-[18px] font-mono text-[var(--ink-soft)]", children: "→" }),
                /* @__PURE__ */ e(
                  "span",
                  {
                    className: "rounded-md bg-[var(--bg-elevated)] px-3 py-0.5 text-[18px] font-mono font-extrabold",
                    style: { color: x },
                    children: C(I)
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] leading-relaxed", children: t === "binomial" ? /* @__PURE__ */ l(R, { children: [
              "P(X ≤ ",
              Math.floor(y),
              ") = 累加 P(X=0) + P(X=1) + … + P(X=",
              Math.floor(y),
              ")， 即左侧蓝色柱子概率之和 =",
              " ",
              /* @__PURE__ */ e("b", { style: { color: x }, children: C(I) })
            ] }) : /* @__PURE__ */ l(R, { children: [
              "左侧阴影面积 =",
              t === "normal" ? ` ∫₋∞^{${y.toFixed(2)}} f(t) dt` : ` ∫₀^{${y.toFixed(2)}} f(t) dt`,
              " = ",
              /* @__PURE__ */ e("b", { style: { color: x }, children: C(I) })
            ] }) }),
            /* @__PURE__ */ e("div", { className: "h-4 w-full rounded-full bg-[var(--bg-elevated)] overflow-hidden border border-[var(--line)]", children: /* @__PURE__ */ e(
              "div",
              {
                className: "h-full rounded-full transition-all duration-200",
                style: { width: `${I * 100}%`, background: x }
              }
            ) }),
            /* @__PURE__ */ l("div", { className: "text-center text-[11px] text-[var(--ink-soft)]", children: [
              "累积概率 ",
              (I * 100).toFixed(2),
              "%"
            ] })
          ]
        }
      )
    ),
    /* @__PURE__ */ l("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "分布函数的核心性质：" }),
      /* @__PURE__ */ l("span", { className: "ml-1", children: [
        "① F(−∞)=0，F(+∞)=1；② F(x) 单调不减；③ 右连续 F(x⁺)=F(x)；",
        t === "binomial" ? " 离散型在整数处有跳跃，P(X=k)=F(k)−F(k−1)。" : " 连续型 P(X=x)=0，F(x)=∫f(t)dt，区间概率=面积差。"
      ] }),
      /* @__PURE__ */ e("span", { className: "ml-1 block mt-1", children: ne === "pdf" ? "拖动竖线观察左侧阴影面积（即 F(x)）实时变化；开启「区间模式」可计算 P(a≤X≤b)。" : "切换到 CDF 视图可看到 F(x) 曲线，交叉点的纵坐标即为累积概率值。" })
    ] }),
    /* @__PURE__ */ e("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4 text-center", children: [
      {
        label: "分布",
        val: Fe,
        color: x,
        bg: me
      },
      {
        label: "F(x) 值",
        val: C(I),
        color: x,
        bg: me
      },
      {
        label: "1 − F(x)",
        val: C(1 - I),
        color: Oe,
        bg: we
      },
      {
        label: F ? "区间概率" : "当前 x",
        val: F ? C(oe) : t === "binomial" ? Math.floor(y).toFixed(0) : y.toFixed(3),
        color: F ? p : N,
        bg: F ? `${p}15` : `${N}15`
      }
    ].map(({ label: n, val: o, color: i, bg: a }) => /* @__PURE__ */ l(
      "div",
      {
        className: "rounded-lg p-2.5",
        style: { background: a },
        children: [
          /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: n }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "text-[14px] font-extrabold font-mono mt-0.5",
              style: { color: i },
              children: o
            }
          )
        ]
      },
      n
    )) })
  ] });
}
const rt = Ye(et);
export {
  rt as default
};
