import { jsxs as o, jsx as t } from "react/jsx-runtime";
import { memo as et, useState as N, useCallback as nt } from "react";
const u = "var(--fp-primary)", X = "var(--fp-primary-soft)", y = "#0f766e", at = "#0f766e22", W = "#ea580c", ot = "var(--line)", M = 520, G = 220, p = 46, L = 14, i = 14, st = 32, rt = M - p - L, f = G - i - st;
function q(a) {
  if (a === "uniform")
    return {
      name: "均匀分布 U(0,1)",
      shortName: "均匀",
      mean: 0.5,
      variance: 1 / 12,
      sample: () => Math.random()
    };
  if (a === "exponential")
    return {
      name: "指数分布 Exp(1)",
      shortName: "指数",
      mean: 1,
      variance: 1,
      sample: () => -Math.log(1 - Math.random())
    };
  if (a === "poisson")
    return {
      name: "泊松分布 P(λ=2)",
      shortName: "泊松",
      mean: 2,
      variance: 2,
      sample: () => {
        const c = Math.exp(-2);
        let h = 0, r = 1;
        do
          h++, r *= Math.random();
        while (r > c);
        return h - 1;
      }
    };
  const s = 10, e = 0.3;
  return {
    name: "二项分布 B(10,0.3)",
    shortName: "二项",
    mean: s * e,
    variance: s * e * (1 - e),
    sample: () => {
      let d = 0;
      for (let c = 0; c < s; c++)
        Math.random() < e && d++;
      return d;
    }
  };
}
function E(a) {
  return Math.exp(-0.5 * a * a) / Math.sqrt(2 * Math.PI);
}
function lt(a) {
  const s = 1 / (1 + 0.2316419 * Math.abs(a)), e = s * (0.31938153 + s * (-0.356563782 + s * (1.781477937 + s * (-1.821255978 + s * 1.330274429)))), d = 1 - E(Math.abs(a)) * e;
  return a >= 0 ? d : 1 - d;
}
function it(a) {
  const s = a.length;
  if (s === 0) return 0;
  let e = 0;
  for (let d = 0; d < s; d++) {
    const c = (d + 1) / s, h = lt(a[d]), r = Math.abs(c - h), m = Math.abs(c - 1 / s - h);
    r > e && (e = r), m > e && (e = m);
  }
  return e;
}
function B(a, s) {
  const c = 8 / s, h = Array.from({ length: s }, (m, x) => {
    const g = -4 + x * c, F = g + c;
    return { z: g + c / 2, left: g, right: F, count: 0, density: 0 };
  });
  for (const m of a) {
    const x = Math.floor((m - -4) / c);
    x >= 0 && x < s && h[x].count++;
  }
  const r = a.length;
  for (const m of h)
    m.density = r > 0 ? m.count / (r * c) : 0;
  return h;
}
function k(a) {
  return p + (a + 4) / 8 * rt;
}
function V(a, s) {
  return i + f - a / s * f;
}
function ct({
  label: a,
  value: s,
  min: e,
  max: d,
  step: c,
  fmt: h,
  onChange: r,
  color: m
}) {
  return /* @__PURE__ */ o("div", { className: "flex items-center gap-3", children: [
    /* @__PURE__ */ t("span", { className: "w-24 shrink-0 text-[12px] font-semibold text-[var(--ink)]", children: a }),
    /* @__PURE__ */ t(
      "input",
      {
        type: "range",
        min: e,
        max: d,
        step: c,
        value: s,
        onChange: (x) => r(Number(x.target.value)),
        className: "flex-1 h-1.5 cursor-pointer",
        style: { accentColor: m ?? u }
      }
    ),
    /* @__PURE__ */ t(
      "span",
      {
        className: "w-12 shrink-0 rounded-md px-2 py-0.5 text-center text-[12px] font-mono font-bold",
        style: { background: (m ?? u) + "22", color: m ?? u },
        children: h(s)
      }
    )
  ] });
}
function dt() {
  const [a, s] = N("uniform"), [e, d] = N(5), [c, h] = N([]), [r, m] = N(null), [x, g] = N(!1), [F, j] = N(0), T = 1e4, R = 40, v = q(a), O = nt(() => {
    const n = q(a), l = n.mean, b = Math.sqrt(n.variance), C = Math.sqrt(e), A = new Array(T);
    for (let D = 0; D < T; D++) {
      let w = 0;
      for (let K = 0; K < e; K++)
        w += n.sample();
      const tt = w / e;
      A[D] = (tt - l) / (b / C);
    }
    const z = A.slice().sort((D, w) => D - w), P = it(z);
    h(A), m(P), g(!0), j(T);
  }, [a, e]), H = x && c.length > 0 ? B(c, R) : B([], R), U = Math.max(...H.map((n) => n.density), 1e-3), Z = E(0), _ = Math.max(U, Z) * 1.1, I = [];
  for (let n = 0; n <= 100; n++) {
    const l = -4 + 8 * n / 100;
    I.push([k(l), V(E(l), _)]);
  }
  const Y = I.map(([n, l], b) => `${b === 0 ? "M" : "L"}${n.toFixed(1)},${l.toFixed(1)}`).join(" "), J = [-3, -2, -1, 0, 1, 2, 3], S = r === null ? u : r < 0.01 ? y : r < 0.03 ? "#ca8a04" : W, $ = r === null ? "—" : r < 0.01 ? "极好 [OK]" : r < 0.03 ? "良好" : "尚可", Q = e >= 30 ? y : e >= 10 ? "#ca8a04" : W;
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ t("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "中心极限定理模拟实验室" }),
      /* @__PURE__ */ t("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "任选底层分布，调整样本量 n，模拟 10000 组后观察标准化样本均值收敛到 N(0,1)。" })
    ] }),
    /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3", children: [
      /* @__PURE__ */ o("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ t("span", { className: "w-24 shrink-0 text-[12px] font-semibold text-[var(--ink)]", children: "底层分布" }),
        /* @__PURE__ */ t("div", { className: "flex flex-wrap gap-1.5", children: ["uniform", "exponential", "poisson", "binomial"].map((n) => {
          const l = q(n);
          return /* @__PURE__ */ t(
            "button",
            {
              type: "button",
              onClick: () => {
                s(n), g(!1), h([]), m(null);
              },
              className: "rounded-lg px-2.5 py-1 text-[12px] font-medium transition-colors " + (n === a ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-elevated)] border border-[var(--line)] text-[var(--ink-soft)] hover:border-[var(--accent)]"),
              children: l.shortName
            },
            n
          );
        }) })
      ] }),
      /* @__PURE__ */ o("div", { className: "text-[11px] text-[var(--ink-soft)] pl-1", children: [
        v.name,
        /* @__PURE__ */ o("span", { className: "ml-3", children: [
          "μ = ",
          v.mean.toFixed(4)
        ] }),
        /* @__PURE__ */ o("span", { className: "ml-3", children: [
          "σ² = ",
          v.variance.toFixed(4)
        ] }),
        /* @__PURE__ */ o("span", { className: "ml-3", children: [
          "σ = ",
          Math.sqrt(v.variance).toFixed(4)
        ] })
      ] }),
      /* @__PURE__ */ t(
        ct,
        {
          label: "样本量 n",
          value: e,
          min: 1,
          max: 50,
          step: 1,
          fmt: (n) => String(n),
          onChange: (n) => {
            d(n), g(!1), h([]), m(null);
          },
          color: u
        }
      ),
      /* @__PURE__ */ t(
        "div",
        {
          className: "text-[11px] font-medium px-1 transition-colors",
          style: { color: Q },
          children: e < 10 ? `n=${e}：样本量太小，近似效果差；建议 n ≥ 30` : e < 30 ? `n=${e}：接近正态，但仍有偏差；n ≥ 30 通常已足够` : `n=${e} ≥ 30：CLT 近似效果很好`
        }
      ),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: O,
          className: "w-full rounded-lg bg-[var(--accent)] py-1.5 text-[13px] font-bold text-white hover:opacity-90 transition-opacity",
          children: "模拟 10000 组，计算标准化 X̄ₙ"
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ t("span", { className: "font-semibold text-[var(--ink)]", children: "标准化公式：" }),
      /* @__PURE__ */ o("span", { className: "font-mono ml-1", children: [
        "Z = (X̄ₙ − μ) / (σ / √n)",
        " = ",
        "(X̄ₙ − ",
        v.mean.toFixed(3),
        ") / (",
        Math.sqrt(v.variance).toFixed(3),
        " / √",
        e,
        ")"
      ] }),
      /* @__PURE__ */ o("span", { className: "ml-2 text-[11px]", children: [
        "→ 分母 σ/√n =",
        " ",
        (Math.sqrt(v.variance) / Math.sqrt(e)).toFixed(4)
      ] })
    ] }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ o("div", { className: "mb-1 flex items-center justify-between", children: [
        /* @__PURE__ */ o("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: [
          "标准化 Z 的直方图",
          x && /* @__PURE__ */ o("span", { className: "ml-2 font-normal text-[var(--ink-soft)]", children: [
            "（",
            F.toLocaleString(),
            " 组 × n=",
            e,
            "）"
          ] })
        ] }),
        x && r !== null && /* @__PURE__ */ o(
          "span",
          {
            className: "text-[11px] rounded-md px-2 py-0.5 font-mono font-bold",
            style: { background: S + "22", color: S },
            children: [
              "K-S = ",
              r.toFixed(4),
              " ",
              $
            ]
          }
        )
      ] }),
      /* @__PURE__ */ o(
        "svg",
        {
          viewBox: `0 0 ${M} ${G}`,
          className: "w-full rounded-lg border border-[var(--line)]",
          style: { background: "var(--bg-muted)" },
          children: [
            [0.1, 0.2, 0.3, 0.4].map((n) => {
              const l = V(n, _);
              return l < i || l > i + f ? null : /* @__PURE__ */ o("g", { children: [
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: p,
                    y1: l,
                    x2: M - L,
                    y2: l,
                    stroke: ot,
                    strokeWidth: 1
                  }
                ),
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: p - 4,
                    y: l + 3,
                    fontSize: "9",
                    textAnchor: "end",
                    fill: "var(--ink-faint)",
                    children: n.toFixed(1)
                  }
                )
              ] }, n);
            }),
            x && H.map((n, l) => {
              const b = k(n.left), C = k(n.right), A = Math.max(C - b - 1, 1), z = n.density / _ * f, P = i + f - z;
              return /* @__PURE__ */ t(
                "rect",
                {
                  x: b,
                  y: P,
                  width: A,
                  height: z,
                  fill: u,
                  opacity: 0.55,
                  rx: 0.5
                },
                l
              );
            }),
            /* @__PURE__ */ t(
              "path",
              {
                d: Y,
                fill: "none",
                stroke: y,
                strokeWidth: 2,
                opacity: 0.9
              }
            ),
            /* @__PURE__ */ t(
              "line",
              {
                x1: p,
                y1: i + f,
                x2: M - L,
                y2: i + f,
                stroke: "var(--line)",
                strokeWidth: 1
              }
            ),
            /* @__PURE__ */ t(
              "line",
              {
                x1: p,
                y1: i,
                x2: p,
                y2: i + f,
                stroke: "var(--line)",
                strokeWidth: 1
              }
            ),
            J.map((n) => {
              const l = k(n);
              return /* @__PURE__ */ o("g", { children: [
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: l,
                    y1: i + f,
                    x2: l,
                    y2: i + f + 4,
                    stroke: "var(--ink-faint)",
                    strokeWidth: 1
                  }
                ),
                /* @__PURE__ */ t(
                  "text",
                  {
                    x: l,
                    y: i + f + 12,
                    fontSize: "9",
                    textAnchor: "middle",
                    fill: "var(--ink-faint)",
                    children: n
                  }
                )
              ] }, n);
            }),
            /* @__PURE__ */ t(
              "line",
              {
                x1: k(0),
                y1: i,
                x2: k(0),
                y2: i + f,
                stroke: "var(--accent)",
                strokeWidth: 1,
                strokeDasharray: "4 3",
                opacity: 0.5
              }
            ),
            !x && /* @__PURE__ */ t(
              "text",
              {
                x: M / 2,
                y: G / 2 - 4,
                textAnchor: "middle",
                fontSize: "13",
                fill: "var(--ink-faint)",
                children: "点击「模拟」开始实验"
              }
            ),
            /* @__PURE__ */ t(
              "text",
              {
                x: p - 4,
                y: i - 4,
                fontSize: "9",
                textAnchor: "end",
                fill: "var(--ink-faint)",
                children: "密度"
              }
            ),
            /* @__PURE__ */ t(
              "text",
              {
                x: M - L,
                y: i + f + 24,
                fontSize: "9",
                textAnchor: "end",
                fill: "var(--ink-faint)",
                children: "Z"
              }
            ),
            /* @__PURE__ */ t(
              "line",
              {
                x1: p + 8,
                y1: i + 10,
                x2: p + 28,
                y2: i + 10,
                stroke: y,
                strokeWidth: 2
              }
            ),
            /* @__PURE__ */ t("text", { x: p + 32, y: i + 13, fontSize: "9", fill: y, children: "N(0,1) 理论曲线" }),
            /* @__PURE__ */ t(
              "rect",
              {
                x: p + 120,
                y: i + 5,
                width: 12,
                height: 10,
                fill: u,
                opacity: 0.55,
                rx: 1
              }
            ),
            /* @__PURE__ */ t("text", { x: p + 136, y: i + 13, fontSize: "9", fill: u, children: "实验直方图" })
          ]
        }
      )
    ] }),
    x && /* @__PURE__ */ t("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
      {
        label: "模拟组数",
        val: F.toLocaleString(),
        bg: X,
        col: u
      },
      {
        label: "每组样本量 n",
        val: String(e),
        bg: e >= 30 ? at : "#f59e0b22",
        col: e >= 30 ? y : "#b45309"
      },
      {
        label: "σ/√n（理论标准误）",
        val: (Math.sqrt(v.variance) / Math.sqrt(e)).toFixed(4),
        bg: "#0369a122",
        col: "#0369a1"
      },
      {
        label: "K-S 距离",
        val: r !== null ? r.toFixed(4) : "—",
        bg: r !== null ? S + "22" : X,
        col: S
      }
    ].map(({ label: n, val: l, bg: b, col: C }) => /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg p-2.5 text-center",
        style: { background: b },
        children: [
          /* @__PURE__ */ t("div", { className: "text-[10px] text-[var(--ink-soft)] leading-snug", children: n }),
          /* @__PURE__ */ t(
            "div",
            {
              className: "text-[15px] font-extrabold font-mono mt-0.5",
              style: { color: C },
              children: l
            }
          )
        ]
      },
      n
    )) }),
    /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 text-[12px] leading-loose text-[var(--ink-soft)] space-y-1", children: [
      /* @__PURE__ */ t("div", { className: "font-semibold text-[13px] text-[var(--ink)]", children: "中心极限定理（CLT）" }),
      /* @__PURE__ */ t("div", { className: "font-mono text-[11px]", children: "设 X₁, X₂, …, Xₙ 独立同分布，均值 μ，方差 σ²（有限）" }),
      /* @__PURE__ */ o("div", { className: "font-mono text-[11px]", children: [
        "Z = (X̄ₙ − μ) / (σ/√n)",
        /* @__PURE__ */ t("span", { className: "ml-2 font-sans not-italic", children: "→ N(0,1)（n → ∞）" })
      ] }),
      /* @__PURE__ */ o("div", { className: "mt-1 text-[11px]", children: [
        "无论底层分布是什么形状（均匀、指数、泊松…），只要均值和方差有限， 样本均值标准化后的分布就趋向标准正态分布。",
        /* @__PURE__ */ t(
          "span",
          {
            className: "ml-1 font-semibold",
            style: { color: e >= 30 ? y : W },
            children: "n ≥ 30 通常已足够接近正态。"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ t("span", { className: "font-semibold text-[var(--ink)]", children: "K-S 统计量（Kolmogorov–Smirnov）：" }),
      "衡量实验经验分布 Fₙ(z) 与理论正态 CDF Φ(z) 的最大偏差。 值越小说明越接近 N(0,1)。一般 D < 0.01 表示拟合极好， D < 0.03 表示良好。",
      x && r !== null && /* @__PURE__ */ o("span", { className: "ml-1 font-bold", style: { color: S }, children: [
        "当前 D = ",
        r.toFixed(4),
        "（",
        $,
        "）。"
      ] }),
      !x && /* @__PURE__ */ t("span", { className: "ml-1", children: "点击「模拟」后显示。" })
    ] })
  ] });
}
const ht = et(dt);
export {
  ht as default
};
