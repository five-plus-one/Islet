import { type ReactNode } from "react";
import type { CanvasBlock } from "./canvas/engines/types";
import { MoleculeRenderContext } from "./canvas/renderers/MoleculeRenderer";
export type { CanvasBlock, CanvasDiagnostic, PlotSpec, CanvasAttrs, PlotAttrs, } from "./canvas/engines/types";
export { CanvasBlockRenderer } from "./canvas/CanvasBlockRenderer";
export { CanvasRevisionPanel } from "./canvas/CanvasRevisionPanel";
export { CanvasDiagnosticPanel } from "./canvas/CanvasDiagnosticPanel";
export { default as SvgCanvas } from "./canvas/SvgCanvas";
export { FunctionPlot } from "./canvas/FunctionPlot";
export { compileMathExpr, calculateTicks } from "./canvas/canvasUtils";
export { sanitizeSvg } from "./canvas/engines/sanitizeSvg";
export interface CanvasWorkspaceProps {
    value: CanvasBlock;
    onChange: (block: CanvasBlock) => void;
    onRevise?: (block: CanvasBlock, instruction: string, signal: AbortSignal) => Promise<CanvasBlock>;
    renderMolecule?: React.ContextType<typeof MoleculeRenderContext>;
    recorder?: ReactNode;
    onDiagnostic?: (error: unknown) => void;
}
export declare function CanvasWorkspace({ value, onChange, onRevise, renderMolecule, recorder, onDiagnostic, }: CanvasWorkspaceProps): import("react").JSX.Element;
