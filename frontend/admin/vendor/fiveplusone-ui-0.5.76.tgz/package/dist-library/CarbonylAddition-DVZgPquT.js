import { jsxs as i, jsx as e } from "react/jsx-runtime";
import { memo as c, useState as s } from "react";
import { motion as o } from "framer-motion";
const d = [
  {
    id: "HCN",
    label: "HCN（氢氰酸）",
    nuSymbol: "⁻CN",
    productType: "α-羟基腈（氰醇）",
    productNote: "CN⁻ 进攻羰基碳，O 接 H 得 —C(OH)(CN)—",
    mechanism: "氰根 CN⁻ 作为亲核试剂进攻缺电子的羰基碳，C=O 的 π 电子转移到氧上形成醇盐氧负离子，质子化后得到 α-羟基腈。"
  },
  {
    id: "RMgX",
    label: "RMgX（格氏试剂）",
    nuSymbol: "R⁻",
    productType: "醇（加水后）",
    productNote: "碳负离子 R⁻ 加成生成醇盐，水解后得醇",
    mechanism: "格氏试剂提供强亲核的碳负离子 R⁻，进攻羰基碳形成 C—C 键，氧成为醇盐氧负离子，再加水（酸性后处理）质子化得到醇。"
  },
  {
    id: "ROH",
    label: "ROH（醇）",
    nuSymbol: "RO⁻ / ROH",
    productType: "半缩醛 / 缩醛",
    productNote: "一分子醇加成得半缩醛，再与一分子醇脱水得缩醛",
    mechanism: "醇氧上的孤对电子进攻羰基碳（通常酸催化），先生成半缩醛（—C(OH)(OR)—），再与第二分子醇脱去一分子水形成缩醛（—C(OR)₂—）。"
  },
  {
    id: "RNH2",
    label: "RNH₂（伯胺）",
    nuSymbol: "R–NH₂",
    productType: "亚胺（失水，Schiff 碱）",
    productNote: "胺加成得氨基醇中间体，再脱水生成 C=N 亚胺",
    mechanism: "伯胺氮上的孤对电子进攻羰基碳，加成得到半缩胺醇（氨基醇）中间体，随后质子转移并脱去一分子水，形成含 C=N 的亚胺（Schiff 碱）。"
  },
  {
    id: "NaBH4",
    label: "NaBH₄（氢负离子源）",
    nuSymbol: "H⁻",
    productType: "醇",
    productNote: "H⁻ 加到羰基碳，O 质子化得醇",
    mechanism: "硼氢化钠提供氢负离子 H⁻，进攻羰基碳完成还原，π 电子转移到氧形成醇盐氧负离子，质子化后得到醇（醛→伯醇，酮→仲醇）。"
  }
];
function m() {
  const [n, l] = s("HCN"), r = d.find((t) => t.id === n) ?? d[0];
  return /* @__PURE__ */ i("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "text-lg font-semibold text-[var(--ink)]", children: "羰基亲核加成（Nucleophilic Addition）" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "羰基 C=O 中氧电负性大，使碳带部分正电荷（δ+）、氧带部分负电荷（δ−）。 亲核试剂 Nu 进攻缺电子的羰基碳，C=O 的 π 电子转移到氧上，完成亲核加成。" }),
    /* @__PURE__ */ e("div", { className: "mt-4 flex flex-wrap gap-2", children: d.map((t) => {
      const a = t.id === n;
      return /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => l(t.id),
          className: [
            "rounded-lg border px-3 py-1.5 text-sm transition-colors",
            a ? "border-indigo-500 bg-indigo-600 text-white" : "border-[var(--line)] bg-[var(--bg-muted)] text-[var(--ink)] hover:border-indigo-400"
          ].join(" "),
          children: t.label
        },
        t.id
      );
    }) }),
    /* @__PURE__ */ e("div", { className: "mt-4 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-2", children: /* @__PURE__ */ i(
      "svg",
      {
        viewBox: "0 0 420 200",
        className: "h-auto w-full",
        role: "img",
        "aria-label": "羰基亲核加成示意图",
        children: [
          /* @__PURE__ */ e(
            "text",
            {
              x: "40",
              y: "105",
              textAnchor: "middle",
              className: "fill-emerald-600",
              fontSize: "18",
              fontWeight: "700",
              children: r.nuSymbol
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "40",
              y: "128",
              textAnchor: "middle",
              fontSize: "11",
              fill: "var(--ink-soft)",
              children: "亲核试剂 Nu"
            }
          ),
          /* @__PURE__ */ e(
            o.line,
            {
              x1: "78",
              y1: "100",
              x2: "178",
              y2: "100",
              stroke: "#059669",
              strokeWidth: "2.5",
              markerEnd: "url(#nuArrow)",
              initial: { pathLength: 0, opacity: 0.3 },
              animate: { pathLength: [0, 1, 1], opacity: [0.3, 1, 0.3] },
              transition: { duration: 2, repeat: 1 / 0, ease: "easeInOut" }
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "200",
              y: "106",
              textAnchor: "middle",
              fontSize: "26",
              fontWeight: "700",
              fill: "var(--ink)",
              children: "C"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "200",
              y: "78",
              textAnchor: "middle",
              fontSize: "13",
              fill: "#dc2626",
              fontWeight: "700",
              children: "δ+"
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: "222",
              y1: "94",
              x2: "288",
              y2: "94",
              stroke: "var(--ink)",
              strokeWidth: "2"
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: "222",
              y1: "104",
              x2: "288",
              y2: "104",
              stroke: "var(--ink)",
              strokeWidth: "2"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "308",
              y: "106",
              textAnchor: "middle",
              fontSize: "26",
              fontWeight: "700",
              fill: "#2563eb",
              children: "O"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "308",
              y: "78",
              textAnchor: "middle",
              fontSize: "13",
              fill: "#2563eb",
              fontWeight: "700",
              children: "δ−"
            }
          ),
          /* @__PURE__ */ e(
            o.path,
            {
              d: "M 255 88 Q 285 55 305 80",
              fill: "none",
              stroke: "#7c3aed",
              strokeWidth: "2",
              markerEnd: "url(#piArrow)",
              initial: { opacity: 0.25 },
              animate: { opacity: [0.25, 1, 0.25] },
              transition: {
                duration: 2,
                repeat: 1 / 0,
                ease: "easeInOut",
                delay: 0.6
              }
            }
          ),
          /* @__PURE__ */ e("text", { x: "270", y: "48", textAnchor: "middle", fontSize: "11", fill: "#7c3aed", children: "π 电子 → O" }),
          /* @__PURE__ */ e(
            "line",
            {
              x1: "186",
              y1: "118",
              x2: "160",
              y2: "150",
              stroke: "var(--ink-soft)",
              strokeWidth: "1.5"
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: "214",
              y1: "118",
              x2: "240",
              y2: "150",
              stroke: "var(--ink-soft)",
              strokeWidth: "1.5"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "150",
              y: "166",
              textAnchor: "middle",
              fontSize: "11",
              fill: "var(--ink-soft)",
              children: "R / H"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "248",
              y: "166",
              textAnchor: "middle",
              fontSize: "11",
              fill: "var(--ink-soft)",
              children: "R' / H"
            }
          ),
          /* @__PURE__ */ i("defs", { children: [
            /* @__PURE__ */ e(
              "marker",
              {
                id: "nuArrow",
                markerWidth: "8",
                markerHeight: "8",
                refX: "6",
                refY: "3",
                orient: "auto",
                children: /* @__PURE__ */ e("path", { d: "M0,0 L6,3 L0,6 Z", fill: "#059669" })
              }
            ),
            /* @__PURE__ */ e(
              "marker",
              {
                id: "piArrow",
                markerWidth: "8",
                markerHeight: "8",
                refX: "6",
                refY: "3",
                orient: "auto",
                children: /* @__PURE__ */ e("path", { d: "M0,0 L6,3 L0,6 Z", fill: "#7c3aed" })
              }
            )
          ] })
        ]
      }
    ) }),
    /* @__PURE__ */ i("div", { className: "mt-4 grid gap-3 sm:grid-cols-2", children: [
      /* @__PURE__ */ i("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
        /* @__PURE__ */ e("p", { className: "text-xs font-medium text-[var(--ink-soft)]", children: "产物类型" }),
        /* @__PURE__ */ e("p", { className: "mt-1 text-base font-semibold text-indigo-600", children: r.productType }),
        /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink)]", children: r.productNote })
      ] }),
      /* @__PURE__ */ i("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
        /* @__PURE__ */ e("p", { className: "text-xs font-medium text-[var(--ink-soft)]", children: "加成机理" }),
        /* @__PURE__ */ e("p", { className: "mt-1 text-sm leading-relaxed text-[var(--ink)]", children: r.mechanism })
      ] })
    ] }),
    /* @__PURE__ */ e("p", { className: "mt-3 text-xs text-[var(--ink-soft)]", children: "通则：亲核试剂（绿色 Nu）进攻带 δ+ 的羰基碳，C=O 的 π 键断裂、电子对（紫色箭头） 转移到带 δ− 的氧上，氧成为氧负离子，再经质子化或后续脱水得到最终产物。" })
  ] });
}
const p = c(m);
export {
  p as default
};
