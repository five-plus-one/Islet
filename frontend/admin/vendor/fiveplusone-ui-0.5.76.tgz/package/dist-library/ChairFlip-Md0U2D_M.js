import { jsxs as r, jsx as t } from "react/jsx-runtime";
import { memo as g, useState as v } from "react";
import { motion as k } from "framer-motion";
const o = [
  {
    x: 70,
    y: 150,
    axialDir: { dx: 0, dy: -1 },
    equatorialDir: { dx: -0.9, dy: 0.45 }
  },
  {
    x: 130,
    y: 185,
    axialDir: { dx: 0, dy: 1 },
    equatorialDir: { dx: -0.9, dy: -0.45 }
  },
  {
    x: 200,
    y: 150,
    axialDir: { dx: 0, dy: -1 },
    equatorialDir: { dx: 0.9, dy: 0.45 }
  },
  {
    x: 270,
    y: 110,
    axialDir: { dx: 0, dy: 1 },
    equatorialDir: { dx: 0.9, dy: -0.45 }
  },
  {
    x: 210,
    y: 75,
    axialDir: { dx: 0, dy: -1 },
    equatorialDir: { dx: -0.9, dy: 0.45 }
  },
  {
    x: 140,
    y: 110,
    axialDir: { dx: 0, dy: 1 },
    equatorialDir: { dx: 0.9, dy: -0.45 }
  }
], c = 30, N = 0, l = "#dc2626", s = "#2563eb";
function y(e) {
  return {
    x1: e.x,
    y1: e.y,
    x2: e.x + e.axialDir.dx * c,
    y2: e.y + e.axialDir.dy * c
  };
}
function D(e) {
  return {
    x1: e.x,
    y1: e.y,
    x2: e.x + e.equatorialDir.dx * c,
    y2: e.y + e.equatorialDir.dy * c
  };
}
function q() {
  const [e, u] = v(!1), d = !e, h = d ? "a（直立键 / axial）" : "e（平伏键 / equatorial）", p = d ? "甲基目前在 a 键，1,3-直立位有较大位阻，能量较高（不利）。" : "甲基目前在 e 键（赤道键），位阻最小，能量较低（更稳定，优势构象）。";
  return /* @__PURE__ */ r("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ t("h3", { className: "text-base font-semibold text-[var(--ink)]", children: "环己烷椅式翻转：直立键 a ⇄ 平伏键 e" }),
    /* @__PURE__ */ r("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: [
      "椅式构象的六个碳交替分布在上下两层，每个碳带一根",
      /* @__PURE__ */ t("span", { style: { color: l }, className: "font-medium", children: "直立键 a" }),
      "和一根",
      /* @__PURE__ */ t("span", { style: { color: s }, className: "font-medium", children: "平伏键 e" }),
      '。点击"翻转"会在两个等能（取代基除外）的椅式间切换——',
      /* @__PURE__ */ t("b", { children: "翻转后 a 键全部变 e 键、e 键全部变 a 键" }),
      "。"
    ] }),
    /* @__PURE__ */ r("div", { className: "mt-3 flex flex-col items-center", children: [
      /* @__PURE__ */ r(
        k.svg,
        {
          width: 340,
          height: 230,
          viewBox: "0 0 340 230",
          className: "rounded-lg bg-[var(--bg-muted)]",
          animate: { scaleY: e ? -1 : 1 },
          transition: { duration: 0.6, ease: "easeInOut" },
          style: { transformOrigin: "center" },
          children: [
            o.map((i, a) => {
              const n = o[(a + 1) % o.length];
              return /* @__PURE__ */ t(
                "line",
                {
                  x1: i.x,
                  y1: i.y,
                  x2: n.x,
                  y2: n.y,
                  stroke: "var(--ink)",
                  strokeWidth: 2.5,
                  strokeLinecap: "round"
                },
                `ring-${a}`
              );
            }),
            o.map((i, a) => {
              const n = y(i), x = D(i), m = !e, b = m ? l : s, f = m ? s : l;
              return /* @__PURE__ */ r("g", { children: [
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: n.x1,
                    y1: n.y1,
                    x2: n.x2,
                    y2: n.y2,
                    stroke: b,
                    strokeWidth: 2,
                    strokeLinecap: "round"
                  }
                ),
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: x.x1,
                    y1: x.y1,
                    x2: x.x2,
                    y2: x.y2,
                    stroke: f,
                    strokeWidth: 2,
                    strokeLinecap: "round"
                  }
                )
              ] }, `bonds-${a}`);
            }),
            (() => {
              const i = o[N], a = y(i);
              return /* @__PURE__ */ r("g", { children: [
                /* @__PURE__ */ t(
                  "circle",
                  {
                    cx: a.x2,
                    cy: a.y2,
                    r: 11,
                    fill: d ? l : s,
                    opacity: 0.18,
                    stroke: d ? l : s,
                    strokeWidth: 1.5
                  }
                ),
                /* @__PURE__ */ t(
                  "g",
                  {
                    transform: e ? `translate(${a.x2} ${a.y2}) scale(1 -1) translate(${-a.x2} ${-a.y2})` : void 0,
                    children: /* @__PURE__ */ t(
                      "text",
                      {
                        x: a.x2,
                        y: a.y2 + 4,
                        textAnchor: "middle",
                        fontSize: 11,
                        fontWeight: 600,
                        fill: "var(--ink)",
                        children: "CH₃"
                      }
                    )
                  }
                )
              ] });
            })()
          ]
        }
      ),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => u((i) => !i),
          className: "mt-3 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-5 py-2 text-sm font-medium text-[var(--ink)] transition-colors hover:bg-[var(--bg-elevated)]",
          children: "翻转椅式（ring flip）"
        }
      )
    ] }),
    /* @__PURE__ */ r("div", { className: "mt-3 flex flex-wrap items-center gap-4 text-xs text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ r("span", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t(
          "span",
          {
            className: "inline-block h-2.5 w-4 rounded",
            style: { backgroundColor: l }
          }
        ),
        "a 键 · 直立键 axial"
      ] }),
      /* @__PURE__ */ r("span", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t(
          "span",
          {
            className: "inline-block h-2.5 w-4 rounded",
            style: { backgroundColor: s }
          }
        ),
        "e 键 · 平伏键 equatorial"
      ] })
    ] }),
    /* @__PURE__ */ r("div", { className: "mt-3 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3 text-sm", children: [
      /* @__PURE__ */ r("p", { className: "text-[var(--ink)]", children: [
        "甲基（CH₃）当前处于：",
        /* @__PURE__ */ t("b", { children: h })
      ] }),
      /* @__PURE__ */ t("p", { className: "mt-1 text-[var(--ink-soft)]", children: p }),
      /* @__PURE__ */ r("p", { className: "mt-2 text-[var(--ink-soft)]", children: [
        "结论：",
        /* @__PURE__ */ t("b", { className: "text-[var(--ink)]", children: "大取代基偏好 e 键（赤道键）" }),
        "——平伏取向避开了 1,3-直立相互作用，使该椅式构象成为优势（更稳定）构象。"
      ] })
    ] })
  ] });
}
const O = g(q);
export {
  O as default
};
