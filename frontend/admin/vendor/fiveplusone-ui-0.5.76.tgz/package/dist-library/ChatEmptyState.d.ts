/** ChatEmptyState - 从课栈 chat/ChatEmptyState 提取
 *
 * AI 对话为空时展示：欢迎语、当前学习主题与快捷提问。
 */
import { type ReactNode } from "react";
export interface ChatEmptyStateProps {
    /** 例如「数学」「物理」 */
    subjectName?: string;
    /** 当前学习内容 */
    topic?: string;
    /** 快捷提问 */
    prompts?: string[];
    onPrompt?: (prompt: string) => void;
    /** 自定义图标 */
    icon?: ReactNode;
    title?: string;
    description?: string;
}
export declare function ChatEmptyState({ subjectName, topic, prompts, onPrompt, icon, title, description, }: ChatEmptyStateProps): import("react").JSX.Element;
