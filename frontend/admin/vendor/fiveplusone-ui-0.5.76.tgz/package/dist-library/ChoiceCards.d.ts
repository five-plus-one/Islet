import { type ReactNode } from 'react';
export interface ChoiceCardOption {
    value: string;
    title: string;
    description: string;
    icon?: ReactNode;
    disabled?: boolean;
}
export declare function ChoiceCards({ label, value, options, onChange }: {
    label: string;
    value: string;
    options: ChoiceCardOption[];
    onChange: (value: string) => void;
}): import("react").JSX.Element;
