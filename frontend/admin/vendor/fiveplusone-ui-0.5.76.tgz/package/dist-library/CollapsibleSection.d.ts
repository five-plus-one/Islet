/** CollapsibleSection - 从课栈 review/CollapsibleSection 提取
 *
 * 标题行 + 高度动画的小节，用于原文、解析等长内容。
 * 与 Accordion 的区别：条目独立、可嵌入任意容器，并支持右侧附加信息。
 */
import { type ReactNode } from "react";
export interface CollapsibleSectionProps {
    label: ReactNode;
    children: ReactNode;
    defaultOpen?: boolean;
    /** 标题行右侧附加信息，例如字数 */
    meta?: ReactNode;
    className?: string;
}
export declare function CollapsibleSection({ label, children, defaultOpen, meta, className, }: CollapsibleSectionProps): import("react").JSX.Element;
