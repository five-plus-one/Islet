export interface EditableCommercePlan {
    id: string;
    name: string;
    days: number;
    priceYuan: number;
    credits: number;
    discount: number;
    enabled: boolean;
}
export interface ModelRate {
    input: number;
    cachedInput: number;
    output: number;
}
export interface CommerceSettings {
    enabled: boolean;
    creditsPerYuan: number;
    costMultiplier?: number;
    replyCredits?: number;
    gateway: string;
    pid: string;
    secret: string;
    serviceRates: {
        quarkOcrRequest: number;
        documentOrganization: number;
        webSearch: number;
    };
    modelRates?: Record<string, ModelRate>;
    rateOverrides?: string[];
    plans: EditableCommercePlan[];
    pricingSyncedAt?: string;
    pricingGroup?: string;
    pricingExchangeRate?: number;
    pricingGroupRatio?: number;
}
export interface CommerceWorkspaceProps {
    value: CommerceSettings;
    onSave: (value: CommerceSettings) => Promise<CommerceSettings | void> | CommerceSettings | void;
    onSyncPrices?: (reset: string[]) => Promise<CommerceSettings>;
    readOnly?: boolean;
}
export declare function validateCommerceSettings(value: CommerceSettings): string | undefined;
export declare function CommerceWorkspace({ value, onSave, onSyncPrices, readOnly, }: CommerceWorkspaceProps): import("react").JSX.Element;
