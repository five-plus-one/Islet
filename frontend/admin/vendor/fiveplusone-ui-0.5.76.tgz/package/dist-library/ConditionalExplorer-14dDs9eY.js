import { jsxs as n, jsx as e } from "react/jsx-runtime";
import { learningAlpha as _ } from "./index.js";
import { memo as F, useState as A } from "react";
const i = "var(--fp-primary)", N = "var(--fp-primary-soft)", w = "#0d9488", $ = "color-mix(in srgb, #ccfbf1 24%, var(--fp-surface))", G = "#d1d5db", B = [
  [0.06, 0.09, 0.15],
  [0.08, 0.12, 0.2],
  [0.06, 0.09, 0.15]
], I = [
  [0.2, 0.08, 0.02],
  [0.08, 0.22, 0.06],
  [0.02, 0.06, 0.26]
];
function J(t) {
  return Math.max(0, t);
}
function R(t) {
  let o = 0;
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) o += t[r][c];
  return o === 0 ? t : t.map((r) => r.map((c) => c / o));
}
function j(t) {
  return [0, 1, 2].map((o) => t[0][o] + t[1][o] + t[2][o]);
}
function S(t, o) {
  const r = t[o][0] + t[o][1] + t[o][2];
  return r === 0 ? [0, 0, 0] : t[o].map((c) => c / r);
}
const Y = 180, y = 120, h = 28, T = (Y - 2 * h) / 3;
function L({ values: t, color: o, label: r, xLabels: c }) {
  const m = Math.max(...t, 1e-3), P = y - h - 14;
  return /* @__PURE__ */ n("div", { className: "flex flex-col items-center gap-1", children: [
    /* @__PURE__ */ e(
      "span",
      {
        className: "text-[11px] font-semibold px-2 py-0.5 rounded",
        style: { background: _(o, "22"), color: o },
        children: r
      }
    ),
    /* @__PURE__ */ n(
      "svg",
      {
        viewBox: `0 0 ${Y} ${y}`,
        className: "w-full",
        style: { maxWidth: Y },
        children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: h,
              y1: y - 20,
              x2: Y - h,
              y2: y - 20,
              stroke: "var(--line)",
              strokeWidth: 1
            }
          ),
          [0.25, 0.5, 0.75].map((p) => {
            const x = y - 20 - p * P;
            return /* @__PURE__ */ n("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: h,
                  y1: x,
                  x2: Y - h,
                  y2: x,
                  stroke: "var(--line)",
                  strokeWidth: 1
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: h - 4,
                  y: x + 3,
                  fontSize: "8",
                  textAnchor: "end",
                  fill: "var(--ink-faint)",
                  children: p
                }
              )
            ] }, p);
          }),
          t.map((p, x) => {
            const v = p / m * P, f = T * 0.6, g = h + x * T + T / 2, b = g - f / 2, u = y - 20 - v;
            return /* @__PURE__ */ n("g", { children: [
              /* @__PURE__ */ e(
                "rect",
                {
                  x: b,
                  y: u,
                  width: f,
                  height: v,
                  fill: o,
                  opacity: 0.85,
                  rx: 2
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: g,
                  y: u - 3,
                  fontSize: "8.5",
                  textAnchor: "middle",
                  fill: o,
                  fontWeight: "700",
                  children: p.toFixed(3)
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: g,
                  y: y - 6,
                  fontSize: "9",
                  textAnchor: "middle",
                  fill: "var(--ink-soft)",
                  children: c[x]
                }
              )
            ] }, x);
          })
        ]
      }
    )
  ] });
}
function X(t) {
  return t.toFixed(3);
}
function D() {
  const [t, o] = A(R(B)), [r, c] = A(null), [m, P] = A(!1);
  function p() {
    const l = !m;
    P(l), o(R(l ? I : B)), c(null);
  }
  function x(l, s, a) {
    const d = parseFloat(a), C = isNaN(d) ? 0 : J(d), M = t.map(
      (W, H) => W.map((O, z) => H === l && z === s ? C : O)
    );
    o(R(M));
  }
  const v = j(t), f = r !== null ? S(t, r) : null, g = [
    t[0][0] + t[0][1] + t[0][2],
    t[1][0] + t[1][1] + t[1][2],
    t[2][0] + t[2][1] + t[2][2]
  ], b = ["x₁", "x₂", "x₃"], u = ["y₁", "y₂", "y₃"];
  function E() {
    for (let l = 0; l < 3; l++) {
      const s = S(t, l);
      for (let a = 0; a < 3; a++)
        if (Math.abs(s[a] - v[a]) > 0.03) return !1;
    }
    return !0;
  }
  const k = E();
  return /* @__PURE__ */ n("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ n("div", { className: "flex items-start justify-between gap-3 flex-wrap", children: [
      /* @__PURE__ */ n("div", { children: [
        /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "条件分布探索器" }),
        /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "点击左表中的一行（选定 Y=yᵢ），右侧自动计算并对比 P(X|Y=yᵢ) 与边缘 P(X)。" })
      ] }),
      /* @__PURE__ */ n(
        "button",
        {
          type: "button",
          onClick: p,
          className: "flex items-center gap-2 rounded-lg border px-3 py-1.5 text-[12px] font-medium transition-colors",
          style: {
            borderColor: m ? i : "var(--line)",
            background: m ? N : "var(--bg-muted)",
            color: m ? i : "var(--ink-soft)"
          },
          children: [
            /* @__PURE__ */ e(
              "span",
              {
                className: "inline-block h-4 w-7 rounded-full transition-all relative",
                style: { background: m ? i : "var(--line)" },
                children: /* @__PURE__ */ e(
                  "span",
                  {
                    className: "absolute top-0.5 h-3 w-3 rounded-full bg-[var(--fp-surface)] transition-all",
                    style: { left: m ? "14px" : "2px" }
                  }
                )
              }
            ),
            m ? "X 与 Y 正相关" : "X 与 Y 独立"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "rounded-lg px-3 py-2 text-[12px] font-medium leading-snug",
        style: {
          background: k ? $ : N,
          color: k ? w : i
        },
        children: k ? "当前联合分布近似独立：P(X|Y=yᵢ) ≈ P(X)，条件分布与边缘分布几乎相同。" : "当前联合分布不独立：P(X|Y=yᵢ) 随 i 变化而变化，条件信息改变了 X 的分布。"
      }
    ),
    /* @__PURE__ */ n("div", { className: "grid grid-cols-1 gap-5 lg:grid-cols-2", children: [
      /* @__PURE__ */ n("div", { children: [
        /* @__PURE__ */ n("div", { className: "mb-2 flex items-center justify-between", children: [
          /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "联合分布 P(X=xⱼ, Y=yᵢ)" }),
          /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)]", children: "点击行选定 Y=yᵢ" })
        ] }),
        /* @__PURE__ */ e("div", { className: "overflow-x-auto", children: /* @__PURE__ */ n("table", { className: "w-full text-[12px] border-collapse", children: [
          /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ n("tr", { children: [
            /* @__PURE__ */ e("th", { className: "w-10 py-1.5 text-left text-[var(--ink-soft)] font-normal pr-2", children: "Y \\ X" }),
            b.map((l) => /* @__PURE__ */ e(
              "th",
              {
                className: "py-1.5 text-center font-semibold text-[var(--ink)]",
                children: l
              },
              l
            )),
            /* @__PURE__ */ e("th", { className: "py-1.5 text-center font-semibold text-[var(--ink-soft)]", children: "P(Y)" })
          ] }) }),
          /* @__PURE__ */ n("tbody", { children: [
            [0, 1, 2].map((l) => {
              const s = r === l;
              return /* @__PURE__ */ n(
                "tr",
                {
                  onClick: () => c(s ? null : l),
                  className: "cursor-pointer transition-colors",
                  style: {
                    background: s ? N : "transparent"
                  },
                  children: [
                    /* @__PURE__ */ n(
                      "td",
                      {
                        className: "py-1.5 pr-2 font-semibold rounded-l-md",
                        style: {
                          color: s ? i : "var(--ink-soft)"
                        },
                        children: [
                          u[l],
                          s && /* @__PURE__ */ e(
                            "span",
                            {
                              className: "ml-1 text-[9px] font-bold uppercase",
                              style: { color: i },
                              children: "OK"
                            }
                          )
                        ]
                      }
                    ),
                    [0, 1, 2].map((a) => /* @__PURE__ */ e("td", { className: "py-1 px-1 text-center", children: /* @__PURE__ */ e(
                      "input",
                      {
                        type: "number",
                        min: "0",
                        max: "1",
                        step: "0.01",
                        value: X(t[l][a]),
                        onClick: (d) => d.stopPropagation(),
                        onChange: (d) => x(l, a, d.target.value),
                        className: "w-16 rounded border text-center text-[12px] font-mono py-0.5 focus:outline-none focus:ring-1",
                        style: {
                          borderColor: s ? i : "var(--line)",
                          background: s ? "var(--bg-elevated)" : "var(--bg-muted)",
                          color: s ? i : "var(--ink)"
                        }
                      }
                    ) }, a)),
                    /* @__PURE__ */ e(
                      "td",
                      {
                        className: "py-1.5 text-center font-mono font-semibold rounded-r-md",
                        style: {
                          color: s ? i : "var(--ink-soft)"
                        },
                        children: X(g[l])
                      }
                    )
                  ]
                },
                l
              );
            }),
            /* @__PURE__ */ n("tr", { className: "border-t border-[var(--line)]", children: [
              /* @__PURE__ */ e("td", { className: "pt-2 text-[var(--ink-soft)] font-normal text-[11px]", children: "P(X)" }),
              v.map((l, s) => /* @__PURE__ */ e(
                "td",
                {
                  className: "pt-2 text-center font-mono font-semibold text-[var(--ink)]",
                  children: X(l)
                },
                s
              )),
              /* @__PURE__ */ e("td", { className: "pt-2 text-center font-mono text-[var(--ink-soft)]", children: "1.000" })
            ] })
          ] })
        ] }) }),
        r === null && /* @__PURE__ */ e("div", { className: "mt-3 rounded-lg border border-dashed border-[var(--line)] py-3 text-center text-[12px] text-[var(--ink-soft)]", children: "← 点击任意行，查看该 Y 值下的条件分布" })
      ] }),
      /* @__PURE__ */ n("div", { className: "space-y-3", children: [
        /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "分布对比" }),
        /* @__PURE__ */ e(
          L,
          {
            values: v,
            color: G,
            label: "边缘分布 P(X)",
            xLabels: b
          }
        ),
        f !== null && r !== null ? /* @__PURE__ */ e(
          L,
          {
            values: f,
            color: i,
            label: `条件分布 P(X | Y=${u[r]})`,
            xLabels: b
          }
        ) : /* @__PURE__ */ n(
          "div",
          {
            className: "rounded-lg border border-dashed text-center py-6 text-[12px] text-[var(--ink-soft)]",
            style: {
              borderColor: _(i, "55"),
              background: _(N, "55")
            },
            children: [
              "选中左侧某行后",
              /* @__PURE__ */ e("br", {}),
              "此处显示条件分布 P(X|Y=yᵢ)"
            ]
          }
        ),
        f !== null && r !== null && /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-3 py-2.5 space-y-1.5", children: [
          /* @__PURE__ */ n("div", { className: "text-[11px] font-semibold text-[var(--ink)] mb-1", children: [
            "各列偏差 |P(X=xⱼ|Y=",
            u[r],
            ") − P(X=xⱼ)|"
          ] }),
          b.map((l, s) => {
            const a = Math.abs(f[s] - v[s]), d = a > 0.05;
            return /* @__PURE__ */ n("div", { className: "flex items-center gap-2 text-[11px]", children: [
              /* @__PURE__ */ e("span", { className: "w-4 font-semibold text-[var(--ink-soft)]", children: l }),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "flex-1 h-3 rounded-full overflow-hidden",
                  style: { background: "var(--line)" },
                  children: /* @__PURE__ */ e(
                    "div",
                    {
                      className: "h-full rounded-full transition-all duration-300",
                      style: {
                        width: `${Math.min(a / 0.5, 1) * 100}%`,
                        background: d ? i : w
                      }
                    }
                  )
                }
              ),
              /* @__PURE__ */ e(
                "span",
                {
                  className: "w-12 text-right font-mono font-semibold",
                  style: { color: d ? i : w },
                  children: a.toFixed(3)
                }
              ),
              d && /* @__PURE__ */ e("span", { className: "text-[10px]", style: { color: i }, children: "差异显著" })
            ] }, s);
          }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "mt-1.5 text-[11px] leading-snug",
              style: { color: k ? w : i },
              children: k ? "差异极小 → X 与 Y 独立，条件分布 = 边缘分布。" : "差异明显 → X 与 Y 不独立，知道 Y=yᵢ 会改变对 X 的预期。"
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-2 text-[12px]", children: [
      /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)]", children: "核心公式" }),
      /* @__PURE__ */ n("div", { className: "font-mono text-[var(--ink-soft)] leading-loose space-y-1", children: [
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e("span", { className: "text-[var(--ink)] font-semibold", children: "边缘分布：" }),
          " ",
          "P(X=xⱼ) = Σᵢ P(X=xⱼ, Y=yᵢ)"
        ] }),
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e("span", { className: "text-[var(--ink)] font-semibold", children: "条件分布：" }),
          " ",
          "P(X=xⱼ | Y=yᵢ) = P(X=xⱼ, Y=yᵢ) / P(Y=yᵢ)"
        ] }),
        r !== null && f !== null && /* @__PURE__ */ n(
          "div",
          {
            className: "mt-1 rounded px-2 py-1 text-[11.5px] font-mono",
            style: { background: N, color: i },
            children: [
              "当前：P(Y=",
              u[r],
              ") = ",
              X(g[r]),
              "， 归一化后得到右侧紫色柱状图。"
            ]
          }
        ),
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e("span", { className: "text-[var(--ink)] font-semibold", children: "独立充要：" }),
          " ",
          "P(X=xⱼ | Y=yᵢ) = P(X=xⱼ)，对所有 i, j 成立"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "grid grid-cols-3 gap-2", children: [0, 1, 2].map((l) => {
      const s = S(t, l), a = r === l;
      return /* @__PURE__ */ n(
        "div",
        {
          className: "rounded-lg p-2.5 text-center cursor-pointer border transition-all",
          style: {
            borderColor: a ? i : "var(--line)",
            background: a ? N : "var(--bg-muted)"
          },
          onClick: () => c(a ? null : l),
          children: [
            /* @__PURE__ */ n(
              "div",
              {
                className: "text-[10px] font-semibold mb-1",
                style: { color: a ? i : "var(--ink-soft)" },
                children: [
                  "Y = ",
                  u[l]
                ]
              }
            ),
            /* @__PURE__ */ e("div", { className: "space-y-0.5", children: s.map((d, C) => /* @__PURE__ */ n(
              "div",
              {
                className: "text-[11px] font-mono flex justify-between px-1",
                style: { color: a ? i : "var(--ink)" },
                children: [
                  /* @__PURE__ */ e("span", { children: b[C] }),
                  /* @__PURE__ */ e("span", { className: "font-semibold", children: X(d) })
                ]
              },
              C
            )) }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "mt-1 text-[9px]",
                style: { color: a ? i : "var(--ink-soft)" },
                children: a ? "已选中" : "点击查看"
              }
            )
          ]
        },
        l
      );
    }) }),
    /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "使用指南：" }),
      "① 点击左表中任意行（Y=yᵢ）激活该条件； ② 右侧出现紫色柱状图，即为 P(X|Y=yᵢ) 的归一化结果； ③ 与灰色边缘分布 P(X) 对比，差异越大说明 X 与 Y 越相关； ④ 切换「相关性开关」加载预设独立或正相关联合分布； ⑤ 直接修改表格数值自定义联合分布，系统自动归一化。"
    ] })
  ] });
}
const Q = F(D);
export {
  Q as default
};
