export interface ContentSkeletonProps {
    label?: string;
    variant?: "document" | "list";
}
export declare function ContentSkeleton({ label, variant }: ContentSkeletonProps): import("react").JSX.Element;
