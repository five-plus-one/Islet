import { type ReactNode } from "react";
export interface ContextMenuItem {
    id: string;
    label: string;
    icon?: ReactNode;
    shortcut?: string;
    disabled?: boolean;
    danger?: boolean;
    checked?: boolean;
    separator?: boolean;
    children?: ContextMenuItem[];
    onSelect?: () => void;
}
export interface ContextMenuProps {
    children: ReactNode;
    items: ContextMenuItem[] | (() => ContextMenuItem[]);
    label?: string;
    disabled?: boolean;
    tabIndex?: number;
    onOpen?: (event: React.MouseEvent | React.KeyboardEvent) => boolean | void;
}
/** Pointer and keyboard context actions share the same focus and dismissal contract. */
export declare function ContextMenu({ children, items, label, disabled, tabIndex, onOpen, }: ContextMenuProps): import("react").JSX.Element;
