import { jsxs as o, jsx as n } from "react/jsx-runtime";
import { learningAlpha as G } from "./index.js";
import { memo as ot, useState as X, useCallback as st } from "react";
const S = "var(--fp-primary)", D = "#0d9488", E = "#ea580c", H = "var(--line)", tt = "var(--bg-muted)", et = 480, L = 200, x = { top: 16, right: 16, bottom: 36, left: 42 }, $ = et - x.left - x.right, M = L - x.top - x.bottom, j = {
  normal: {
    label: "正态分布 N(μ,σ²)",
    params: [
      ["均值 μ", "p1", -3, 3, 0.1],
      ["标准差 σ", "p2", 0.2, 3, 0.1]
    ],
    mean: (t) => t.p1,
    variance: (t) => t.p2 * t.p2,
    sample: (t) => {
      const a = 1 - Math.random(), e = Math.random();
      return t.p1 + t.p2 * Math.sqrt(-2 * Math.log(a)) * Math.cos(2 * Math.PI * e);
    },
    pdf: (t, a) => {
      const e = a.p2, m = a.p1;
      return Math.exp(-0.5 * ((t - m) / e) ** 2) / (e * Math.sqrt(2 * Math.PI));
    },
    support: (t) => [t.p1 - 4 * t.p2, t.p1 + 4 * t.p2]
  },
  uniform: {
    label: "均匀分布 U(a,b)",
    params: [
      ["左端 a", "p1", -5, 4, 0.5],
      ["右端 b", "p2", -4, 5, 0.5]
    ],
    mean: (t) => (t.p1 + t.p2) / 2,
    variance: (t) => Math.max(0, (t.p2 - t.p1) ** 2 / 12),
    sample: (t) => t.p1 + Math.random() * Math.max(1e-3, t.p2 - t.p1),
    pdf: (t, a) => {
      const e = a.p2 - a.p1;
      return e <= 0 ? 0 : t >= a.p1 && t <= a.p2 ? 1 / e : 0;
    },
    support: (t) => [t.p1 - 0.5, t.p2 + 0.5]
  },
  exponential: {
    label: "指数分布 Exp(λ)",
    params: [
      ["速率 λ", "p1", 0.2, 4, 0.1],
      ["偏移 c", "p2", 0, 3, 0.25]
    ],
    mean: (t) => t.p2 + 1 / t.p1,
    variance: (t) => 1 / (t.p1 * t.p1),
    sample: (t) => t.p2 + -Math.log(1 - Math.random()) / t.p1,
    pdf: (t, a) => {
      const e = t - a.p2;
      return e < 0 ? 0 : a.p1 * Math.exp(-a.p1 * e);
    },
    support: (t) => [t.p2, t.p2 + 8 / t.p1]
  },
  bernoulli: {
    label: "伯努利分布 B(p)",
    params: [
      ["成功概率 p", "p1", 0.05, 0.95, 0.05],
      ["倍率 k", "p2", 1, 5, 1]
    ],
    mean: (t) => t.p1 * t.p2,
    variance: (t) => t.p1 * (1 - t.p1) * t.p2 * t.p2,
    sample: (t) => Math.random() < t.p1 ? t.p2 : 0,
    support: () => [-0.5, 5.5]
  }
};
function I(t, a) {
  const e = j[t.type], m = [];
  for (let c = 0; c < a; c++) m.push(e.sample(t));
  return m;
}
function rt(t, a, e, m) {
  const c = new Array(m).fill(0), r = e - a;
  if (r <= 0) return c;
  for (const i of t) {
    const u = Math.floor((i - a) / r * m), l = Math.min(Math.max(u, 0), m - 1);
    c[l]++;
  }
  return c;
}
function nt(t, a) {
  return t === "normal" && a === "normal" || t === "uniform" && a === "uniform" || t === "exponential" && a === "exponential";
}
function lt(t, a, e) {
  const m = a.type, c = e.type;
  if (m === "normal" && c === "normal") {
    const r = a.p1 + e.p1, i = Math.sqrt(a.p2 ** 2 + e.p2 ** 2);
    return Math.exp(-0.5 * ((t - r) / i) ** 2) / (i * Math.sqrt(2 * Math.PI));
  }
  if (m === "exponential" && c === "exponential") {
    const r = a.p1, i = e.p1, u = a.p2 + e.p2, l = t - u;
    return l < 0 ? 0 : Math.abs(r - i) < 1e-6 ? r * r * l * Math.exp(-r * l) : r * i / (i - r) * (Math.exp(-r * l) - Math.exp(-i * l));
  }
  if (m === "uniform" && c === "uniform") {
    const r = a.p1, i = Math.max(a.p1 + 1e-3, a.p2), u = e.p1, l = Math.max(e.p1 + 1e-3, e.p2), F = i - r, N = l - u, p = r + u, d = i + l;
    if (t <= p || t >= d) return 0;
    const b = t - p, k = i - r, g = l - u, f = Math.min(b, k), h = Math.max(0, b - g);
    return f <= h ? 0 : (f - h) / (F * N);
  }
  return 0;
}
function Q({ label: t, color: a, dist: e, onChange: m }) {
  const c = j[e.type], r = ["normal", "uniform", "exponential", "bernoulli"];
  function i(p) {
    m({
      normal: { type: "normal", p1: 0, p2: 1 },
      uniform: { type: "uniform", p1: -1, p2: 1 },
      exponential: { type: "exponential", p1: 1, p2: 0 },
      bernoulli: { type: "bernoulli", p1: 0.5, p2: 2 }
    }[p]);
  }
  function u(p, d) {
    m({ ...e, [p]: d });
  }
  const l = e.type === "uniform" ? Math.max(e.p1 + 0.5, e.p2) : e.p2, F = c.mean(e), N = c.variance({ ...e, p2: l });
  return /* @__PURE__ */ o(
    "div",
    {
      className: "flex-1 rounded-lg p-3 space-y-3",
      style: {
        background: G(a, "18"),
        border: `1.5px solid ${G(a, "44")}`
      },
      children: [
        /* @__PURE__ */ o("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ n(
            "span",
            {
              className: "inline-block h-3 w-3 rounded-full flex-shrink-0",
              style: { background: a }
            }
          ),
          /* @__PURE__ */ n("span", { className: "font-semibold text-[13px]", style: { color: a }, children: t })
        ] }),
        /* @__PURE__ */ n("div", { className: "flex flex-wrap gap-1", children: r.map((p) => /* @__PURE__ */ n(
          "button",
          {
            type: "button",
            onClick: () => i(p),
            className: "rounded-md px-2 py-0.5 text-[11px] font-medium transition-colors",
            style: e.type === p ? { background: a, color: "#fff" } : {
              background: "var(--bg-muted)",
              color: "var(--ink-soft)"
            },
            children: p === "normal" ? "正态" : p === "uniform" ? "均匀" : p === "exponential" ? "指数" : "伯努利"
          },
          p
        )) }),
        c.params.map(([p, d, b, k, g]) => {
          const f = d, h = f === "p2" ? l : e[f];
          return /* @__PURE__ */ o("div", { className: "space-y-0.5", children: [
            /* @__PURE__ */ o("div", { className: "flex justify-between text-[11px]", children: [
              /* @__PURE__ */ n("span", { className: "text-[var(--ink-soft)]", children: p }),
              /* @__PURE__ */ n("span", { className: "font-mono font-bold", style: { color: a }, children: h.toFixed(2) })
            ] }),
            /* @__PURE__ */ n(
              "input",
              {
                type: "range",
                min: b,
                max: k,
                step: g,
                value: h,
                onChange: (A) => u(f, Number(A.target.value)),
                className: "w-full h-1.5 cursor-pointer",
                style: { accentColor: a }
              }
            )
          ] }, d);
        }),
        /* @__PURE__ */ o("div", { className: "flex gap-3 text-[11px] text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ o("span", { children: [
            "E =",
            " ",
            /* @__PURE__ */ n("b", { style: { color: a }, className: "font-mono", children: F.toFixed(3) })
          ] }),
          /* @__PURE__ */ o("span", { children: [
            "Var =",
            " ",
            /* @__PURE__ */ n("b", { style: { color: a }, className: "font-mono", children: N.toFixed(3) })
          ] })
        ] })
      ]
    }
  );
}
function ct({
  bins: t,
  sampleCount: a,
  binMin: e,
  binMax: m,
  xDist: c,
  yDist: r,
  showPdf: i
}) {
  const u = t.length, l = m - e, F = l / u, N = t.map((s) => s / (a * F)), p = Math.max(...N, 1e-3), d = [], b = i && nt(c.type, r.type);
  if (b)
    for (let v = 0; v <= 200; v++) {
      const y = e + v / 200 * l, Y = lt(y, c, r);
      d.push([y, Y]);
    }
  const k = b ? Math.max(p, ...d.map((s) => s[1]), 1e-3) : p;
  function g(s) {
    return x.left + (s - e) / l * $;
  }
  function f(s) {
    return x.top + M - s / k * M;
  }
  const h = 5, A = [];
  for (let s = 0; s <= h; s++)
    A.push(e + s / h * l);
  const Z = b && d.length > 1 ? d.map(
    ([s, v], y) => `${y === 0 ? "M" : "L"}${g(s).toFixed(2)},${f(v).toFixed(2)}`
  ).join(" ") : "";
  return /* @__PURE__ */ o("svg", { viewBox: `0 0 ${et} ${L}`, className: "w-full", children: [
    /* @__PURE__ */ n(
      "rect",
      {
        x: x.left,
        y: x.top,
        width: $,
        height: M,
        fill: tt,
        stroke: H
      }
    ),
    [0.25, 0.5, 0.75, 1].map((s) => {
      const v = s * k, y = f(v);
      return /* @__PURE__ */ o("g", { children: [
        /* @__PURE__ */ n(
          "line",
          {
            x1: x.left,
            y1: y,
            x2: x.left + $,
            y2: y,
            stroke: H,
            strokeDasharray: "3 3"
          }
        ),
        /* @__PURE__ */ n(
          "text",
          {
            x: x.left - 4,
            y: y + 3,
            fontSize: 9,
            textAnchor: "end",
            fill: "var(--ink-faint)",
            children: v.toFixed(2)
          }
        )
      ] }, s);
    }),
    N.map((s, v) => {
      const y = g(e + v * F), Y = $ / u - 0.5, C = s / k * M, B = x.top + M - C;
      return /* @__PURE__ */ n(
        "rect",
        {
          x: y + 0.25,
          y: B,
          width: Math.max(Y, 0.5),
          height: Math.max(C, 0),
          fill: S,
          opacity: 0.55,
          rx: 0.5
        },
        v
      );
    }),
    b && Z && /* @__PURE__ */ n(
      "path",
      {
        d: Z,
        fill: "none",
        stroke: E,
        strokeWidth: 2,
        strokeLinejoin: "round"
      }
    ),
    A.map((s) => /* @__PURE__ */ o("g", { children: [
      /* @__PURE__ */ n(
        "line",
        {
          x1: g(s),
          y1: x.top + M,
          x2: g(s),
          y2: x.top + M + 3,
          stroke: "var(--ink-faint)"
        }
      ),
      /* @__PURE__ */ n(
        "text",
        {
          x: g(s),
          y: x.top + M + 13,
          fontSize: 9,
          textAnchor: "middle",
          fill: "var(--ink-faint)",
          children: s.toFixed(1)
        }
      )
    ] }, s)),
    /* @__PURE__ */ n(
      "text",
      {
        x: x.left + $ / 2,
        y: L - 2,
        fontSize: 10,
        textAnchor: "middle",
        fill: "var(--ink-faint)",
        children: "Z = X + Y"
      }
    ),
    /* @__PURE__ */ n(
      "text",
      {
        x: 9,
        y: x.top + M / 2,
        fontSize: 9,
        textAnchor: "middle",
        fill: "var(--ink-faint)",
        transform: `rotate(-90, 9, ${x.top + M / 2})`,
        children: "密度"
      }
    )
  ] });
}
const w = 5e3, it = 50;
function pt() {
  const [t, a] = X({
    type: "normal",
    p1: 0,
    p2: 1
  }), [e, m] = X({
    type: "normal",
    p1: 0,
    p2: 1
  }), [c, r] = X([]), [i, u] = X([-6, 6]), [l, F] = X(0), [N, p] = X(!0), [d, b] = X(!1), k = j[t.type], g = j[e.type], f = {
    ...t,
    p2: t.type === "uniform" ? Math.max(t.p1 + 0.5, t.p2) : t.p2
  }, h = {
    ...e,
    p2: e.type === "uniform" ? Math.max(e.p1 + 0.5, e.p2) : e.p2
  }, A = k.mean(f), Z = g.mean(h), s = k.variance(f), v = g.variance(h), y = A + Z, Y = s + v, C = !(t.type === "uniform" && t.p2 <= t.p1 || e.type === "uniform" && e.p2 <= e.p1), B = st(() => {
    if (!C || d) return;
    b(!0), I(f, w).map((P, J) => P + I(h, 1)[0]);
    const V = [];
    for (let P = 0; P < w; P++)
      V.push(I(f, 1)[0] + I(h, 1)[0]);
    const _ = [...V].sort((P, J) => P - J), W = _[Math.floor(w * 5e-3)], O = _[Math.ceil(w * 0.995)], K = (O - W) * 0.1, T = W - K, U = O + K, at = rt(V, T, U, it);
    r(at), u([T, U]), F((P) => P + 1), b(!1);
  }, [f, h, C, d]), q = c.length > 0, z = N && nt(t.type, e.type);
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ n("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "卷积演示：Z = X + Y 的分布" }),
      /* @__PURE__ */ o("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: [
        "分别选择 X、Y 的分布类型与参数，运行蒙特卡洛模拟",
        " ",
        w.toLocaleString(),
        " 次，观察 Z 的经验分布与理论 PDF。"
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "flex gap-3 flex-col sm:flex-row", children: [
      /* @__PURE__ */ n(
        Q,
        {
          label: "X 分布",
          color: D,
          dist: t,
          onChange: a
        }
      ),
      /* @__PURE__ */ n("div", { className: "flex items-center justify-center text-[18px] font-bold text-[var(--ink-soft)] select-none", children: "+" }),
      /* @__PURE__ */ n(
        Q,
        {
          label: "Y 分布",
          color: S,
          dist: e,
          onChange: m
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-1.5", children: [
      /* @__PURE__ */ n("div", { className: "text-[12px] font-semibold text-[var(--ink)] mb-1", children: "独立随机变量之和的期望与方差（可加性）" }),
      /* @__PURE__ */ o("div", { className: "font-mono text-[11px] text-[var(--ink-soft)] space-y-0.5", children: [
        /* @__PURE__ */ o("div", { children: [
          "E[Z] = E[X] + E[Y]",
          /* @__PURE__ */ o("span", { className: "ml-3", children: [
            "=",
            " ",
            /* @__PURE__ */ n("span", { style: { color: D }, className: "font-bold", children: A.toFixed(3) }),
            " ",
            "+",
            " ",
            /* @__PURE__ */ n("span", { style: { color: S }, className: "font-bold", children: Z.toFixed(3) }),
            " ",
            "=",
            " ",
            /* @__PURE__ */ n("span", { className: "font-bold text-[var(--ink)]", children: y.toFixed(3) })
          ] })
        ] }),
        /* @__PURE__ */ o("div", { children: [
          "Var[Z] = Var[X] + Var[Y]",
          /* @__PURE__ */ o("span", { className: "ml-3", children: [
            "=",
            " ",
            /* @__PURE__ */ n("span", { style: { color: D }, className: "font-bold", children: s.toFixed(3) }),
            " ",
            "+",
            " ",
            /* @__PURE__ */ n("span", { style: { color: S }, className: "font-bold", children: v.toFixed(3) }),
            " ",
            "=",
            " ",
            /* @__PURE__ */ n("span", { className: "font-bold text-[var(--ink)]", children: Y.toFixed(3) })
          ] })
        ] }),
        z && /* @__PURE__ */ n("div", { className: "text-[10px] mt-1 text-[var(--ink-soft)]", children: "[OK] 此组合有解析卷积公式，橙色曲线为理论 PDF" })
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ n(
        "button",
        {
          type: "button",
          onClick: B,
          disabled: !C || d,
          className: "rounded-lg px-4 py-1.5 text-[13px] font-semibold text-white transition-opacity",
          style: {
            background: C ? S : "var(--ink-faint)",
            opacity: d ? 0.7 : 1
          },
          children: d ? "模拟中..." : `模拟 ${w.toLocaleString()} 次`
        }
      ),
      q && /* @__PURE__ */ o("label", { className: "flex items-center gap-1.5 text-[12px] text-[var(--ink-soft)] cursor-pointer select-none", children: [
        /* @__PURE__ */ n(
          "input",
          {
            type: "checkbox",
            checked: N,
            onChange: (R) => p(R.target.checked),
            className: "cursor-pointer",
            style: { accentColor: E }
          }
        ),
        /* @__PURE__ */ n("span", { style: { color: E }, className: "font-medium", children: "叠加理论 PDF" })
      ] }),
      !C && /* @__PURE__ */ n("span", { className: "text-[11px] text-red-500", children: "均匀分布需要 b > a" }),
      l > 0 && /* @__PURE__ */ o("span", { className: "ml-auto text-[11px] text-[var(--ink-soft)]", children: [
        "已模拟 ",
        l,
        " 次"
      ] })
    ] }),
    q ? /* @__PURE__ */ o("div", { className: "space-y-2", children: [
      /* @__PURE__ */ n(
        ct,
        {
          bins: c,
          sampleCount: w,
          binMin: i[0],
          binMax: i[1],
          xDist: f,
          yDist: h,
          showPdf: N
        }
      ),
      /* @__PURE__ */ o("div", { className: "flex flex-wrap gap-4 text-[11px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ o("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ n(
            "span",
            {
              className: "inline-block h-3 w-5 rounded-sm opacity-60",
              style: { background: S }
            }
          ),
          "经验直方图（密度）"
        ] }),
        z && /* @__PURE__ */ o("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ n(
            "span",
            {
              className: "inline-block h-0.5 w-5",
              style: { background: E }
            }
          ),
          /* @__PURE__ */ n("span", { style: { color: E }, children: "理论 PDF（卷积解析式）" })
        ] }),
        !z && N && /* @__PURE__ */ n("div", { className: "text-[10px] text-[var(--ink-soft)] opacity-60", children: "（该组合暂无解析 PDF，仅显示经验分布）" })
      ] }),
      /* @__PURE__ */ n("div", { className: "grid grid-cols-3 gap-2 text-center", children: [
        { label: "理论 E[Z]", val: y.toFixed(4), color: S },
        {
          label: "理论 σ[Z]",
          val: Math.sqrt(Math.max(0, Y)).toFixed(4),
          color: D
        },
        { label: "理论 Var[Z]", val: Y.toFixed(4), color: E }
      ].map(({ label: R, val: V, color: _ }) => /* @__PURE__ */ o(
        "div",
        {
          className: "rounded-lg p-2",
          style: { background: G(_, "18") },
          children: [
            /* @__PURE__ */ n("div", { className: "text-[10px] text-[var(--ink-soft)]", children: R }),
            /* @__PURE__ */ n(
              "div",
              {
                className: "text-[14px] font-extrabold font-mono",
                style: { color: _ },
                children: V
              }
            )
          ]
        },
        R
      )) })
    ] }) : /* @__PURE__ */ n(
      "div",
      {
        className: "rounded-lg flex items-center justify-center",
        style: {
          height: L,
          background: tt,
          border: `1px dashed ${H}`
        },
        children: /* @__PURE__ */ o("div", { className: "text-center space-y-1", children: [
          /* @__PURE__ */ n("div", { className: "text-[13px] text-[var(--ink-soft)]", children: "点击「模拟」按钮开始" }),
          /* @__PURE__ */ o("div", { className: "text-[11px]", style: { color: S }, children: [
            "将生成 ",
            w.toLocaleString(),
            " 对 (X,Y) 样本，计算 Z = X + Y"
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ o("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ n("span", { className: "font-semibold text-[var(--ink)]", children: "核心洞察：" }),
      "当 X 和 Y 相互独立时，Z = X+Y 的分布由卷积决定：",
      /* @__PURE__ */ n("span", { className: "font-mono mx-1", children: "f_Z(z) = ∫ f_X(x)·f_Y(z−x)dx" }),
      "。期望和方差均可加，但分布形状取决于具体类型—— 两个正态相加仍是正态，两个均匀相加得三角/梯形，两个指数相加得 Erlang。 尝试混合不同类型，观察中心极限定理的收敛趋势！"
    ] })
  ] });
}
const ft = ot(pt);
export {
  ft as default
};
