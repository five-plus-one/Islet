import { jsxs as o, jsx as e, Fragment as j } from "react/jsx-runtime";
import { memo as F, useState as Y, useCallback as H, useMemo as O } from "react";
const x = "var(--fp-primary)", A = "var(--fp-primary-soft)", p = "#ea580c", R = "color-mix(in srgb, #fff7ed 24%, var(--fp-surface))", q = "var(--line)", h = 380, d = 300, r = 40, T = h - r * 2, E = d - r * 2;
function _() {
  const n = Math.random(), s = Math.random();
  return Math.sqrt(-2 * Math.log(Math.max(n, 1e-10))) * Math.cos(2 * Math.PI * s);
}
function $(n, s) {
  const i = [];
  for (let m = 0; m < s; m++) {
    const c = _(), f = _(), g = c, y = n * c + Math.sqrt(Math.max(0, 1 - n * n)) * f;
    i.push({ x: g, y });
  }
  return i;
}
function B(n) {
  const s = [];
  for (let i = 0; i < n; i++) {
    const m = _() * 1.2, c = _() * 0.15, f = m * m + c;
    s.push({ x: m, y: f });
  }
  return s;
}
function I(n) {
  const s = n.length;
  if (s < 2) return 0;
  const i = n.reduce((u, v) => u + v.x, 0) / s, m = n.reduce((u, v) => u + v.y, 0) / s;
  let c = 0, f = 0, g = 0;
  for (const u of n) {
    const v = u.x - i, b = u.y - m;
    c += v * b, f += v * v, g += b * b;
  }
  const y = Math.sqrt(f * g);
  return y < 1e-10 ? 0 : c / y;
}
const C = 3.5, L = 14;
function w(n) {
  return r + (n + C) / (2 * C) * T;
}
function D(n, s) {
  return r + E - (n + s) / (2 * s) * E;
}
function U({ value: n, onChange: s }) {
  const i = n.toFixed(2), m = n > 0.5 ? x : n < -0.5 ? p : "var(--ink-soft)";
  return /* @__PURE__ */ o("div", { className: "space-y-2", children: [
    /* @__PURE__ */ o("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "相关系数 ρ（rho）" }),
      /* @__PURE__ */ o(
        "span",
        {
          className: "rounded-md px-2.5 py-0.5 text-[14px] font-mono font-bold",
          style: { background: A, color: m },
          children: [
            n >= 0 ? "+" : "",
            i
          ]
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "relative", children: [
      /* @__PURE__ */ e(
        "input",
        {
          type: "range",
          min: -1,
          max: 1,
          step: 0.01,
          value: n,
          onChange: (c) => s(Number(c.target.value)),
          className: "w-full h-2 cursor-pointer rounded-full appearance-none",
          style: { accentColor: x }
        }
      ),
      /* @__PURE__ */ o("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)] mt-1", children: [
        /* @__PURE__ */ e("span", { children: "−1（完全负相关）" }),
        /* @__PURE__ */ e("span", { children: "0" }),
        /* @__PURE__ */ e("span", { children: "+1（完全正相关）" })
      ] })
    ] })
  ] });
}
function V() {
  const [n, s] = Y(0.6), [i, m] = Y("normal"), [c, f] = Y(
    () => $(0.6, 200)
  ), [g, y] = Y(!0), u = H((t, a) => {
    f(a === "uncorr-dependent" ? B(200) : $(t, 200)), y(!0);
  }, []);
  function v(t) {
    s(t), i === "normal" && f($(t, 200));
  }
  function b() {
    const t = i === "normal" ? "uncorr-dependent" : "normal";
    m(t), u(n, t);
  }
  function G() {
    u(n, i), y(!1), setTimeout(() => y(!0), 10);
  }
  const k = O(() => I(c), [c]), l = i === "uncorr-dependent", N = l ? L : C;
  function P(t) {
    const a = Math.abs(t);
    return a < 0.05 ? "几乎无线性关系" : a < 0.3 ? t > 0 ? "弱正相关" : "弱负相关" : a < 0.6 ? t > 0 ? "中等正相关" : "中等负相关" : a < 0.85 ? t > 0 ? "强正相关" : "强负相关" : a < 0.99 ? t > 0 ? "极强正相关" : "极强负相关" : t > 0 ? "完全正相关（退化为直线）" : "完全负相关（退化为直线）";
  }
  const S = Math.abs(n) >= 0.98 && i === "normal", W = i === "normal" ? Math.atan(n) * (180 / Math.PI) : 0, z = l ? [0, 4, 9] : [-3, 0, 3];
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "相关系数可视化实验室" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5 leading-relaxed", children: "拖动 ρ 滑块实时生成二维正态散点云，直观感受相关系数的几何意义。 底部可切换「不相关但不独立」的经典反例。" })
    ] }),
    /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3", children: [
      /* @__PURE__ */ e(U, { value: n, onChange: v }),
      S && /* @__PURE__ */ o(
        "div",
        {
          className: "mt-2 rounded-md px-3 py-1.5 text-[11px] font-medium leading-snug",
          style: { background: A, color: x },
          children: [
            "ρ ≈ ",
            n > 0 ? "+1" : "−1",
            "：散点退化为一条直线！ X 与 Y 存在严格线性关系 Y = ",
            n > 0 ? "" : "−",
            "X（方差消失）。"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "relative rounded-lg overflow-hidden border border-[var(--line)]", children: [
      /* @__PURE__ */ o(
        "div",
        {
          className: "absolute top-2 right-2 z-10 rounded-lg px-3 py-1.5 shadow-sm text-center",
          style: {
            background: l ? R : A,
            border: `1.5px solid ${l ? p : x}`
          },
          children: [
            /* @__PURE__ */ e(
              "div",
              {
                className: "text-[10px] font-medium",
                style: { color: l ? p : x },
                children: "样本相关系数 r"
              }
            ),
            /* @__PURE__ */ o(
              "div",
              {
                className: "text-[18px] font-extrabold font-mono leading-tight",
                style: { color: l ? p : x },
                children: [
                  k >= 0 ? "+" : "",
                  k.toFixed(3)
                ]
              }
            ),
            !l && /* @__PURE__ */ e("div", { className: "text-[9px] mt-0.5", style: { color: x }, children: P(k) })
          ]
        }
      ),
      /* @__PURE__ */ o(
        "svg",
        {
          viewBox: `0 0 ${h} ${d}`,
          className: "w-full",
          style: { maxHeight: 320 },
          children: [
            /* @__PURE__ */ e(
              "rect",
              {
                x: r,
                y: r,
                width: T,
                height: E,
                fill: "var(--bg-muted)",
                stroke: q
              }
            ),
            [-3, -2, -1, 0, 1, 2, 3].map((t) => {
              const a = w(t);
              return a < r || a > h - r ? null : /* @__PURE__ */ e(
                "line",
                {
                  x1: a,
                  y1: r,
                  x2: a,
                  y2: d - r,
                  stroke: t === 0 ? "var(--ink-faint)" : "var(--line)",
                  strokeWidth: t === 0 ? 1.5 : 1,
                  strokeDasharray: t === 0 ? void 0 : "3 3"
                },
                `vg${t}`
              );
            }),
            z.map((t) => {
              const a = D(t, N);
              return a < r || a > d - r ? null : /* @__PURE__ */ e(
                "line",
                {
                  x1: r,
                  y1: a,
                  x2: h - r,
                  y2: a,
                  stroke: t === 0 ? "var(--ink-faint)" : "var(--line)",
                  strokeWidth: t === 0 ? 1.5 : 1,
                  strokeDasharray: t === 0 ? void 0 : "3 3"
                },
                `hg${t}`
              );
            }),
            [-3, 0, 3].map((t) => {
              const a = w(t);
              return /* @__PURE__ */ e(
                "text",
                {
                  x: a,
                  y: d - r + 13,
                  fontSize: 9,
                  textAnchor: "middle",
                  fill: "var(--ink-faint)",
                  children: t
                },
                `xl${t}`
              );
            }),
            z.map((t) => {
              const a = D(t, N);
              return a < r || a > d - r ? null : /* @__PURE__ */ e(
                "text",
                {
                  x: r - 5,
                  y: a + 3,
                  fontSize: 9,
                  textAnchor: "end",
                  fill: "var(--ink-faint)",
                  children: t
                },
                `yl${t}`
              );
            }),
            /* @__PURE__ */ e(
              "text",
              {
                x: h / 2,
                y: d - 5,
                fontSize: 10,
                textAnchor: "middle",
                fill: "var(--ink-faint)",
                fontStyle: "italic",
                children: "X"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: 10,
                y: d / 2,
                fontSize: 10,
                textAnchor: "middle",
                fill: "var(--ink-faint)",
                fontStyle: "italic",
                transform: `rotate(-90, 10, ${d / 2})`,
                children: "Y"
              }
            ),
            i === "normal" && !S && /* @__PURE__ */ e(
              "ellipse",
              {
                cx: h / 2,
                cy: d / 2,
                rx: T / 2 * 0.72,
                ry: E / 2 * 0.72 * Math.sqrt(Math.max(0.02, 1 - n * n)),
                fill: "none",
                stroke: x,
                strokeWidth: 1.2,
                strokeDasharray: "6 4",
                opacity: 0.35,
                transform: `rotate(${-W}, ${h / 2}, ${d / 2})`
              }
            ),
            S && /* @__PURE__ */ e(
              "line",
              {
                x1: r,
                y1: n > 0 ? d - r : r,
                x2: h - r,
                y2: n > 0 ? r : d - r,
                stroke: x,
                strokeWidth: 2.5,
                opacity: 0.8
              }
            ),
            /* @__PURE__ */ e("g", { children: g && c.map((t, a) => {
              const X = w(
                Math.max(-C, Math.min(C, t.x))
              ), M = D(
                Math.max(-N, Math.min(N, t.y)),
                N
              );
              return X < r || X > h - r || M < r || M > d - r ? null : /* @__PURE__ */ e(
                "circle",
                {
                  cx: X,
                  cy: M,
                  r: 2.2,
                  fill: l ? p : x,
                  opacity: 0.45
                },
                a
              );
            }) }),
            i === "normal" && /* @__PURE__ */ o(j, { children: [
              /* @__PURE__ */ e(
                "text",
                {
                  x: h - r + 2,
                  y: r - 4,
                  fontSize: 8,
                  fill: "var(--ink-faint)",
                  textAnchor: "end",
                  children: "ρ=+1 →直线"
                }
              ),
              /* @__PURE__ */ e("text", { x: r, y: r - 4, fontSize: 8, fill: "var(--ink-faint)", children: "ρ=−1 →直线" })
            ] }),
            l && /* @__PURE__ */ e(
              "text",
              {
                x: h - r - 4,
                y: r + 16,
                fontSize: 10,
                fill: p,
                textAnchor: "end",
                fontStyle: "italic",
                children: "Y = X² (抛物线)"
              }
            )
          ]
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "grid grid-cols-3 gap-2", children: [
      {
        label: "设定 ρ",
        val: l ? "N/A" : (n >= 0 ? "+" : "") + n.toFixed(2),
        color: l ? "var(--ink-soft)" : x,
        bg: l ? "var(--bg-muted)" : A
      },
      {
        label: "样本 r",
        val: (k >= 0 ? "+" : "") + k.toFixed(3),
        color: l ? p : x,
        bg: l ? R : A
      },
      {
        label: "样本量 n",
        val: `${c.length}`,
        color: "var(--ink-soft)",
        bg: "var(--bg-muted)"
      }
    ].map(({ label: t, val: a, color: X, bg: M }) => /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg p-2.5 text-center",
        style: { background: M },
        children: [
          /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: t }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "text-[17px] font-extrabold font-mono mt-0.5",
              style: { color: X },
              children: a
            }
          )
        ]
      },
      t
    )) }),
    /* @__PURE__ */ o("div", { className: "flex flex-wrap gap-2", children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: G,
          className: "rounded-lg px-4 py-1.5 text-[13px] font-medium text-white hover:opacity-90 transition-opacity",
          style: { background: x },
          children: "重新采样"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: b,
          className: [
            "rounded-lg px-4 py-1.5 text-[13px] font-medium transition-all border",
            l ? "text-white border-transparent" : "border-[var(--line)] text-[var(--ink-soft)] hover:border-[var(--accent)]"
          ].join(" "),
          style: l ? { background: p } : { background: "var(--bg-muted)" },
          children: l ? "返回：正态散点" : "展示：不相关但不独立（Y=X²）"
        }
      )
    ] }),
    l && /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg border px-4 py-3 text-[12px] leading-relaxed space-y-1.5",
        style: { borderColor: p, background: R },
        children: [
          /* @__PURE__ */ e("div", { className: "font-bold text-[13px]", style: { color: p }, children: "反例：不相关 ≠ 独立！" }),
          /* @__PURE__ */ o("p", { className: "text-[var(--ink-soft)]", children: [
            "上图中 Y = X²（加微小噪音），X 服从 N(0,1)。 由于 X 与 X² 关于原点对称，协方差",
            /* @__PURE__ */ o("span", { className: "font-mono font-semibold text-[var(--ink)]", children: [
              " ",
              "Cov(X, X²) = E[X³] − E[X]·E[X²] = 0"
            ] }),
            "， 所以样本相关系数 r ≈ 0。"
          ] }),
          /* @__PURE__ */ o("p", { className: "text-[var(--ink-soft)]", children: [
            "但 X 和 Y=X² 显然",
            /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "高度相关" }),
            "：知道 X，就能精确预测 Y！ 这揭示了相关系数只能度量",
            /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "线性" }),
            "关系， 「ρ=0（不相关）」并不意味着「独立」。"
          ] }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "mt-1 rounded-md px-3 py-1.5 text-[11px] font-semibold",
              style: { background: "#fef3c7", color: "#92400e" },
              children: "口诀：独立 ⟹ 不相关；但不相关 ⇏ 独立"
            }
          )
        ]
      }
    ),
    !l && /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] border border-[var(--line)] px-4 py-3 text-[12px] text-[var(--ink-soft)] leading-relaxed space-y-1", children: [
      /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)]", children: "几何直觉" }),
      /* @__PURE__ */ o("p", { children: [
        "相关系数 ρ ∈ [−1, 1] 描述两个随机变量",
        /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "线性关联" }),
        "的强度与方向。 散点云的形状近似一个椭圆——ρ=0 时椭圆轴对齐（圆形），ρ→±1 时椭圆退化为直线。"
      ] }),
      /* @__PURE__ */ o("p", { children: [
        "公式：",
        /* @__PURE__ */ e("span", { className: "font-mono text-[var(--ink)]", children: "ρ = Cov(X,Y) / (σ_X · σ_Y)" }),
        "， 是归一化的协方差，取值始终在 [−1, 1] 内。"
      ] }),
      /* @__PURE__ */ e("p", { children: "样本估计量 r 与 ρ 之间存在随机误差（n 越大越准）， 可多次点击「重新采样」观察 r 的波动范围。" })
    ] }),
    /* @__PURE__ */ o("div", { className: "grid grid-cols-1 gap-2 sm:grid-cols-2", children: [
      /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-3 py-2.5 text-[11px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[12px] text-[var(--ink)] mb-1", children: "协方差定义" }),
        /* @__PURE__ */ o("div", { className: "font-mono leading-loose", children: [
          "Cov(X,Y) = E[(X−μ_X)(Y−μ_Y)]",
          /* @__PURE__ */ e("br", {}),
          "           ",
          " = E[XY] − E[X]·E[Y]"
        ] })
      ] }),
      /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-3 py-2.5 text-[11px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("div", { className: "font-semibold text-[12px] text-[var(--ink)] mb-1", children: "皮尔逊相关系数" }),
        /* @__PURE__ */ o("div", { className: "font-mono leading-loose", children: [
          "ρ(X,Y) = Cov(X,Y) / (σ_X·σ_Y)",
          /* @__PURE__ */ e("br", {}),
          "样本 r = Σ(xᵢ−x̄)(yᵢ−ȳ) / √[Σ(xᵢ−x̄)²·Σ(yᵢ−ȳ)²]"
        ] })
      ] })
    ] })
  ] });
}
const Q = F(V);
export {
  Q as default
};
