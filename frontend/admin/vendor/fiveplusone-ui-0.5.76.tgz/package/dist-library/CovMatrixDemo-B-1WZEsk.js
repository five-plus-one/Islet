import { jsxs as n, jsx as e, Fragment as j } from "react/jsx-runtime";
import { learningAlpha as H } from "./index.js";
import { memo as X, useState as A, useCallback as Q } from "react";
const x = "var(--fp-primary)", B = "var(--fp-primary-soft)", u = "#dc2626", I = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))", G = "var(--line)", P = "var(--ink-soft)", w = 400, C = 340, a = w / 2, i = C / 2, F = 70;
function K(o, r, s) {
  const h = o + s, m = o * s - r * r, M = Math.max(0, (h / 2) ** 2 - m), f = Math.sqrt(M), p = h / 2 - f, v = h / 2 + f;
  let d;
  if (Math.abs(r) > 1e-10) {
    const l = Math.hypot(v - o, r);
    d = [(v - o) / l, r / l];
  } else
    d = o >= s ? [1, 0] : [0, 1];
  const c = [-d[1], d[0]];
  return { lambda1: p, lambda2: v, v1: c, v2: d };
}
function V(o, r, s) {
  return o <= 0 || r <= 0 ? !1 : o * r - s * s * o * r >= 0 && o + r >= 0;
}
function Y(o, r, s, h, m, M, f, p, v = 120) {
  if (s < 0 || h <= 0) return "";
  const d = Math.sqrt(Math.max(0, h)) * f * p, c = Math.sqrt(Math.max(0, s)) * f * p, l = [];
  for (let S = 0; S <= v; S++) {
    const y = S / v * 2 * Math.PI, b = d * Math.cos(y), g = c * Math.sin(y), k = o + b * M[0] + g * m[0], W = r - (b * M[1] + g * m[1]);
    l.push(`${k.toFixed(2)},${W.toFixed(2)}`);
  }
  return l.join(" ");
}
function _({
  label: o,
  symbol: r,
  value: s,
  min: h,
  max: m,
  step: M,
  onChange: f,
  color: p,
  fmt: v
}) {
  const d = v ? v(s) : s.toFixed(2);
  return /* @__PURE__ */ n("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ e("span", { className: "w-28 shrink-0 text-[12px] text-[var(--ink-soft)]", children: o }),
    /* @__PURE__ */ e(
      "span",
      {
        className: "w-8 shrink-0 text-right text-[11px] font-mono font-semibold",
        style: { color: p ?? x },
        children: r
      }
    ),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: h,
        max: m,
        step: M,
        value: s,
        onChange: (c) => f(Number(c.target.value)),
        className: "flex-1 h-1.5 cursor-pointer",
        style: { accentColor: p ?? x }
      }
    ),
    /* @__PURE__ */ e(
      "span",
      {
        className: "w-14 shrink-0 rounded px-1.5 py-0.5 text-center text-[12px] font-mono font-bold",
        style: { background: (p ?? x) + "18", color: p ?? x },
        children: d
      }
    )
  ] });
}
function J() {
  const [o, r] = A(1), [s, h] = A(0.5), [m, M] = A(0.6), [f, p] = A(!0), [v, d] = A(null), c = m * Math.sqrt(o) * Math.sqrt(s), l = V(o, s, m), S = o * s - c * c, { lambda1: y, lambda2: b, v1: g, v2: k } = K(o, c, s), W = [
    { k: 1, opacity: 1, dash: "" },
    { k: 2, opacity: 0.6, dash: "5,3" },
    { k: 3, opacity: 0.35, dash: "3,4" }
  ], D = Math.sqrt(Math.max(0, b)) * F, L = Math.sqrt(Math.max(0, y)) * F, O = [-2, -1, 0, 1, 2], R = [
    { name: "正相关", s1: 1.5, s2: 1, r: 0.8 },
    { name: "负相关", s1: 1.5, s2: 1, r: -0.8 },
    { name: "独立", s1: 1.2, s2: 0.6, r: 0 },
    { name: "强压缩", s1: 3, s2: 0.3, r: 0.3 }
  ], T = Q(
    (t) => {
      r(t.s1), h(t.s2), M(t.r), d(t.name);
    },
    []
  ), $ = (t) => t.toFixed(3), N = (t) => t.toFixed(2);
  return /* @__PURE__ */ n("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ n("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "协方差矩阵与等高线椭圆" }),
      /* @__PURE__ */ e("p", { className: "mt-0.5 text-[12px] text-[var(--ink-soft)]", children: "调整 2×2 协方差矩阵的参数，实时观察二维正态分布等高线椭圆的形状、方向与特征值变化。" })
    ] }),
    /* @__PURE__ */ n("div", { className: "flex flex-col gap-4 lg:flex-row", children: [
      /* @__PURE__ */ e("div", { className: "flex-1 min-w-0", children: /* @__PURE__ */ n(
        "svg",
        {
          viewBox: `0 0 ${w} ${C}`,
          className: "w-full rounded-lg border border-[var(--line)]",
          style: { background: "var(--bg-muted)", maxHeight: 340 },
          children: [
            O.map((t) => /* @__PURE__ */ n("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: a + t * F,
                  y1: 20,
                  x2: a + t * F,
                  y2: C - 20,
                  stroke: t === 0 ? "var(--ink-faint)" : G,
                  strokeWidth: t === 0 ? 1.2 : 0.8,
                  strokeDasharray: t !== 0 ? "4,4" : void 0
                }
              ),
              /* @__PURE__ */ e(
                "line",
                {
                  x1: 20,
                  y1: i - t * F,
                  x2: w - 20,
                  y2: i - t * F,
                  stroke: t === 0 ? "var(--ink-faint)" : G,
                  strokeWidth: t === 0 ? 1.2 : 0.8,
                  strokeDasharray: t !== 0 ? "4,4" : void 0
                }
              ),
              t !== 0 && /* @__PURE__ */ n(j, { children: [
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: a + t * F,
                    y: i + 14,
                    fontSize: "10",
                    textAnchor: "middle",
                    fill: P,
                    children: t
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: a - 10,
                    y: i - t * F + 4,
                    fontSize: "10",
                    textAnchor: "end",
                    fill: P,
                    children: t
                  }
                )
              ] })
            ] }, `grid-${t}`)),
            /* @__PURE__ */ e(
              "text",
              {
                x: w - 18,
                y: i + 14,
                fontSize: "12",
                fill: "var(--ink)",
                fontStyle: "italic",
                children: "x₁"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: a + 8,
                y: 24,
                fontSize: "12",
                fill: "var(--ink)",
                fontStyle: "italic",
                children: "x₂"
              }
            ),
            l && W.map(({ k: t, opacity: z, dash: q }) => /* @__PURE__ */ e(
              "polyline",
              {
                points: Y(
                  a,
                  i,
                  y,
                  b,
                  g,
                  k,
                  t,
                  F
                ),
                fill: H(
                  x,
                  Math.round(z * 30).toString(16).padStart(2, "0")
                ),
                stroke: x,
                strokeWidth: t === 1 ? 2 : 1.2,
                strokeOpacity: z,
                strokeDasharray: q || void 0
              },
              `ellipse-${t}`
            )),
            !l && /* @__PURE__ */ n("g", { children: [
              /* @__PURE__ */ e(
                "rect",
                {
                  x: a - 120,
                  y: i - 30,
                  width: 240,
                  height: 60,
                  rx: 8,
                  fill: I,
                  stroke: u,
                  strokeWidth: 1.5
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: a,
                  y: i - 5,
                  fontSize: "13",
                  textAnchor: "middle",
                  fill: u,
                  fontWeight: "700",
                  children: "矩阵非正定！"
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: a,
                  y: i + 14,
                  fontSize: "11",
                  textAnchor: "middle",
                  fill: u,
                  children: "|ρ| 过大或方差为零，无法定义椭圆"
                }
              )
            ] }),
            f && l && /* @__PURE__ */ n(j, { children: [
              [1, -1].map((t) => /* @__PURE__ */ e(
                "line",
                {
                  x1: a,
                  y1: i,
                  x2: a + t * k[0] * D,
                  y2: i - t * k[1] * D,
                  stroke: "#f59e0b",
                  strokeWidth: 2.2,
                  strokeLinecap: "round"
                },
                `v2-${t}`
              )),
              /* @__PURE__ */ e(
                "text",
                {
                  x: a + k[0] * (D + 14),
                  y: i - k[1] * (D + 14) + 4,
                  fontSize: "11",
                  fill: "#d97706",
                  fontWeight: "700",
                  textAnchor: "middle",
                  children: "√λ₂"
                }
              ),
              [1, -1].map((t) => /* @__PURE__ */ e(
                "line",
                {
                  x1: a,
                  y1: i,
                  x2: a + t * g[0] * L,
                  y2: i - t * g[1] * L,
                  stroke: "#10b981",
                  strokeWidth: 2.2,
                  strokeLinecap: "round"
                },
                `v1-${t}`
              )),
              /* @__PURE__ */ e(
                "text",
                {
                  x: a + g[0] * (L + 14),
                  y: i - g[1] * (L + 14) + 4,
                  fontSize: "11",
                  fill: "#059669",
                  fontWeight: "700",
                  textAnchor: "middle",
                  children: "√λ₁"
                }
              ),
              /* @__PURE__ */ e("circle", { cx: a, cy: i, r: 3, fill: x })
            ] }),
            l && /* @__PURE__ */ e("g", { children: W.map(({ k: t, opacity: z, dash: q }, E) => /* @__PURE__ */ n("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: w - 90,
                  y1: C - 50 + E * 16,
                  x2: w - 74,
                  y2: C - 50 + E * 16,
                  stroke: x,
                  strokeWidth: 1.8,
                  strokeOpacity: z,
                  strokeDasharray: q || void 0
                }
              ),
              /* @__PURE__ */ n(
                "text",
                {
                  x: w - 70,
                  y: C - 46 + E * 16,
                  fontSize: "10",
                  fill: P,
                  children: [
                    t,
                    "σ 等高线"
                  ]
                }
              )
            ] }, `legend-${t}`)) })
          ]
        }
      ) }),
      /* @__PURE__ */ n("div", { className: "w-full lg:w-56 shrink-0 space-y-3", children: [
        /* @__PURE__ */ n(
          "div",
          {
            className: "rounded-lg p-3 text-[13px]",
            style: { background: l ? B : I },
            children: [
              /* @__PURE__ */ e(
                "div",
                {
                  className: "text-[11px] font-semibold mb-2",
                  style: { color: l ? x : u },
                  children: "协方差矩阵 Σ"
                }
              ),
              /* @__PURE__ */ n("div", { className: "flex items-center gap-1", children: [
                /* @__PURE__ */ n("div", { className: "flex flex-col items-end text-[18px] text-[var(--ink-soft)]", children: [
                  /* @__PURE__ */ e("span", { children: "⎡" }),
                  /* @__PURE__ */ e("span", { children: "⎣" })
                ] }),
                /* @__PURE__ */ n("div", { className: "flex-1 space-y-1", children: [
                  /* @__PURE__ */ n("div", { className: "flex justify-around font-mono text-[12px]", children: [
                    /* @__PURE__ */ e("span", { style: { color: x }, className: "font-bold", children: N(o) }),
                    /* @__PURE__ */ e("span", { style: { color: "#7c3aed" }, children: $(c) })
                  ] }),
                  /* @__PURE__ */ n("div", { className: "flex justify-around font-mono text-[12px]", children: [
                    /* @__PURE__ */ e("span", { style: { color: "#7c3aed" }, children: $(c) }),
                    /* @__PURE__ */ e("span", { style: { color: "#2563eb" }, className: "font-bold", children: N(s) })
                  ] })
                ] }),
                /* @__PURE__ */ n("div", { className: "flex flex-col items-start text-[18px] text-[var(--ink-soft)]", children: [
                  /* @__PURE__ */ e("span", { children: "⎤" }),
                  /* @__PURE__ */ e("span", { children: "⎦" })
                ] })
              ] }),
              /* @__PURE__ */ n("div", { className: "mt-2 text-[10px] text-[var(--ink-soft)]", children: [
                "det(Σ) =",
                " ",
                /* @__PURE__ */ e(
                  "span",
                  {
                    className: "font-mono font-bold",
                    style: { color: S >= -1e-9 ? x : u },
                    children: S.toFixed(4)
                  }
                )
              ] })
            ]
          }
        ),
        /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3 space-y-2", children: [
          /* @__PURE__ */ e("div", { className: "text-[11px] font-semibold text-[var(--ink)]", children: "特征值 / 特征向量" }),
          /* @__PURE__ */ n("div", { children: [
            /* @__PURE__ */ n("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ e(
                "span",
                {
                  className: "inline-block h-2.5 w-2.5 rounded-full",
                  style: { background: "#10b981" }
                }
              ),
              /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)]", children: "λ₁（短半轴²）" })
            ] }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "font-mono text-[13px] font-bold",
                style: { color: "#059669" },
                children: y >= 0 ? y.toFixed(4) : /* @__PURE__ */ e("span", { style: { color: u }, children: "≤ 0 !" })
              }
            ),
            /* @__PURE__ */ n("div", { className: "text-[10px] text-[var(--ink-soft)] font-mono", children: [
              "v₁ ≈ (",
              g[0].toFixed(3),
              ", ",
              g[1].toFixed(3),
              ")"
            ] }),
            /* @__PURE__ */ n("div", { className: "text-[10px] text-[var(--ink-soft)]", children: [
              "短轴 =",
              " ",
              y >= 0 ? Math.sqrt(Math.max(0, y)).toFixed(3) : "—"
            ] })
          ] }),
          /* @__PURE__ */ n("div", { children: [
            /* @__PURE__ */ n("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ e(
                "span",
                {
                  className: "inline-block h-2.5 w-2.5 rounded-full",
                  style: { background: "#f59e0b" }
                }
              ),
              /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)]", children: "λ₂（长半轴²）" })
            ] }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "font-mono text-[13px] font-bold",
                style: { color: "#d97706" },
                children: b >= 0 ? b.toFixed(4) : /* @__PURE__ */ e("span", { style: { color: u }, children: "≤ 0 !" })
              }
            ),
            /* @__PURE__ */ n("div", { className: "text-[10px] text-[var(--ink-soft)] font-mono", children: [
              "v₂ ≈ (",
              k[0].toFixed(3),
              ", ",
              k[1].toFixed(3),
              ")"
            ] }),
            /* @__PURE__ */ n("div", { className: "text-[10px] text-[var(--ink-soft)]", children: [
              "长轴 =",
              " ",
              b >= 0 ? Math.sqrt(Math.max(0, b)).toFixed(3) : "—"
            ] })
          ] }),
          /* @__PURE__ */ n("div", { className: "border-t border-[var(--line)] pt-1.5 text-[10px] text-[var(--ink-soft)]", children: [
            "椭圆旋转角:",
            " ",
            /* @__PURE__ */ n("span", { className: "font-mono font-semibold text-[var(--ink)]", children: [
              (Math.atan2(k[1], k[0]) * 180 / Math.PI).toFixed(1),
              "°"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ e(
          "div",
          {
            className: "rounded-lg px-3 py-2 text-center text-[12px] font-bold",
            style: {
              background: l ? "#dcfce7" : I,
              color: l ? "#15803d" : u,
              border: `1.5px solid ${l ? "#86efac" : u}`
            },
            children: l ? "半正定 [OK]" : "非正定 [X] — |ρ| 须 < 1"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3", children: [
      /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "调整协方差矩阵参数" }),
      /* @__PURE__ */ e(
        _,
        {
          label: "方差 σ₁²（X₁方向）",
          symbol: "σ₁²",
          value: o,
          min: 0.1,
          max: 4,
          step: 0.05,
          onChange: (t) => {
            r(t), d(null);
          },
          color: x,
          fmt: N
        }
      ),
      /* @__PURE__ */ e(
        _,
        {
          label: "方差 σ₂²（X₂方向）",
          symbol: "σ₂²",
          value: s,
          min: 0.1,
          max: 4,
          step: 0.05,
          onChange: (t) => {
            h(t), d(null);
          },
          color: "#2563eb",
          fmt: N
        }
      ),
      /* @__PURE__ */ e(
        _,
        {
          label: "相关系数 ρ",
          symbol: "ρ",
          value: m,
          min: -0.99,
          max: 0.99,
          step: 0.01,
          onChange: (t) => {
            M(t), d(null);
          },
          color: "#7c3aed",
          fmt: N
        }
      )
    ] }),
    /* @__PURE__ */ n("div", { className: "flex flex-wrap items-center gap-2", children: [
      /* @__PURE__ */ n(
        "button",
        {
          type: "button",
          onClick: () => p((t) => !t),
          className: "rounded-lg px-3 py-1.5 text-[12px] font-medium transition-colors " + (f ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--line)]"),
          children: [
            f ? "隐藏" : "显示",
            "特征向量轴"
          ]
        }
      ),
      /* @__PURE__ */ e("div", { className: "h-4 border-l border-[var(--line)]" }),
      /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)]", children: "快速预设：" }),
      R.map((t) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => T(t),
          className: "rounded-lg px-2.5 py-1 text-[12px] font-medium transition-colors " + (v === t.name ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--line)]"),
          children: t.name
        },
        t.name
      ))
    ] }),
    /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-4 py-3 space-y-2 text-[12px] text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)]", children: "原理速查" }),
      /* @__PURE__ */ n("div", { className: "space-y-1 leading-relaxed", children: [
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e("span", { className: "font-mono font-semibold text-[var(--ink)]", children: "等高线方程" }),
          "： (x − μ)ᵀ Σ⁻¹ (x − μ) = k²，是以原点为中心的椭圆（k = 1, 2, 3）"
        ] }),
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e("span", { className: "font-mono font-semibold text-[var(--ink)]", children: "谱分解" }),
          "： Σ = Q Λ Qᵀ，其中 Λ = diag(λ₁, λ₂)，Q 的列为特征向量 v₁, v₂"
        ] }),
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e("span", { className: "font-mono font-semibold text-[var(--ink)]", children: "椭圆轴长" }),
          "： 长半轴 = √λ₂ · k，短半轴 = √λ₁ · k；方向 = 特征向量 v₂, v₁"
        ] }),
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e("span", { className: "font-mono font-semibold text-[var(--ink)]", children: "ρ 的含义" }),
          "： |ρ| 越大，椭圆越细（越扁）；ρ 的符号决定椭圆倾斜方向（右上 vs 右下）"
        ] }),
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ e("span", { className: "font-mono font-semibold text-[var(--ink)]", children: "正定条件" }),
          "： σ₁², σ₂² > 0 且 |ρ| < 1（等价 det(Σ) = σ₁²σ₂²(1 − ρ²) > 0）"
        ] })
      ] }),
      /* @__PURE__ */ n(
        "div",
        {
          className: "mt-2 rounded bg-[var(--bg-elevated)] px-3 py-2 font-mono text-[11px] border border-[var(--line)]",
          style: { color: l ? "var(--ink)" : u },
          children: [
            /* @__PURE__ */ n("div", { children: [
              "Σ = [[",
              N(o),
              ", ",
              $(c),
              "], [",
              $(c),
              ", ",
              N(s),
              "]]"
            ] }),
            /* @__PURE__ */ n("div", { children: [
              "det = σ₁²·σ₂²·(1−ρ²) = ",
              N(o),
              "·",
              N(s),
              "·(1−",
              N(m),
              "²) =",
              " ",
              /* @__PURE__ */ e("span", { style: { color: l ? x : u, fontWeight: 700 }, children: S.toFixed(4) })
            ] }),
            /* @__PURE__ */ n("div", { children: [
              "λ₁ = ",
              y.toFixed(4),
              ", λ₂ = ",
              b.toFixed(4),
              ", tr =",
              " ",
              (y + b).toFixed(4)
            ] })
          ]
        }
      )
    ] })
  ] });
}
const te = X(J);
export {
  te as default
};
