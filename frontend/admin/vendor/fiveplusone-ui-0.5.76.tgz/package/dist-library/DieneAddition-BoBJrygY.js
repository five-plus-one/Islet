import { jsxs as t, jsx as e } from "react/jsx-runtime";
import { memo as f, useState as u, useMemo as c } from "react";
function h(i) {
  const d = 80 - (Math.min(40, Math.max(-80, i)) - -80) / 120 * 60, x = 100 - d;
  return {
    twelve: Math.round(d),
    fourteen: Math.round(x)
  };
}
function v() {
  const [i, r] = u(-80), n = c(() => h(i), [i]), l = n.twelve >= n.fourteen, s = c(() => i <= -40 ? "低温区 · 动力学控制" : i >= 10 ? "高温区 · 热力学控制" : "过渡区", [i]);
  return /* @__PURE__ */ t("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "text-lg font-semibold text-[var(--ink)]", children: "共轭二烯的 1,2- 加成 vs 1,4- 加成" }),
    /* @__PURE__ */ t("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: [
      "以",
      " ",
      /* @__PURE__ */ e("span", { className: "font-medium text-[var(--ink)]", children: "1,3-丁二烯 + HBr" }),
      " ",
      "为例，拖动温度滑块观察两种加成产物比例的变化：低温利于",
      /* @__PURE__ */ t("span", { className: "font-medium text-[#2563eb]", children: [
        " ",
        "动力学产物（1,2-加成）"
      ] }),
      "， 高温利于",
      /* @__PURE__ */ t("span", { className: "font-medium text-[#dc2626]", children: [
        " ",
        "热力学产物（1,4-加成）"
      ] }),
      "。"
    ] }),
    /* @__PURE__ */ t("div", { className: "mt-4 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
      /* @__PURE__ */ t("div", { className: "flex items-baseline justify-between", children: [
        /* @__PURE__ */ e(
          "label",
          {
            htmlFor: "diene-temp",
            className: "text-sm font-medium text-[var(--ink)]",
            children: "反应温度"
          }
        ),
        /* @__PURE__ */ t("span", { className: "text-sm font-semibold tabular-nums text-[var(--ink)]", children: [
          i,
          " ℃",
          /* @__PURE__ */ e("span", { className: "ml-2 text-xs font-normal text-[var(--ink-soft)]", children: s })
        ] })
      ] }),
      /* @__PURE__ */ e(
        "input",
        {
          id: "diene-temp",
          type: "range",
          min: -80,
          max: 40,
          step: 5,
          value: i,
          onChange: (d) => r(Number(d.target.value)),
          className: "mt-2 w-full accent-[#7c3aed]"
        }
      ),
      /* @__PURE__ */ t("div", { className: "mt-1 flex justify-between text-xs text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("span", { children: "-80 ℃（低温）" }),
        /* @__PURE__ */ e("span", { children: "+40 ℃（高温）" })
      ] })
    ] }),
    /* @__PURE__ */ t("div", { className: "mt-4 space-y-3", children: [
      /* @__PURE__ */ e(
        m,
        {
          label: "1,2-加成产物 · 3-溴-1-丁烯",
          tag: "动力学产物（低温，生成快）",
          percent: n.twelve,
          color: "#2563eb",
          active: l
        }
      ),
      /* @__PURE__ */ e(
        m,
        {
          label: "1,4-加成产物 · 1-溴-2-丁烯",
          tag: "热力学产物（高温，更稳定）",
          percent: n.fourteen,
          color: "#dc2626",
          active: !l
        }
      )
    ] }),
    /* @__PURE__ */ t("div", { className: "mt-5 grid grid-cols-1 gap-3 md:grid-cols-3", children: [
      /* @__PURE__ */ t("figure", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
        /* @__PURE__ */ t(
          "svg",
          {
            viewBox: "0 0 200 90",
            className: "w-full",
            role: "img",
            "aria-label": "1,3-丁二烯结构",
            children: [
              /* @__PURE__ */ e("text", { x: "6", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH₂" }),
              /* @__PURE__ */ e(o, { x1: 36, x2: 66, y: 36 }),
              /* @__PURE__ */ e("text", { x: "68", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH" }),
              /* @__PURE__ */ e(a, { x1: 90, x2: 110, y: 36 }),
              /* @__PURE__ */ e("text", { x: "112", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH" }),
              /* @__PURE__ */ e(o, { x1: 134, x2: 164, y: 36 }),
              /* @__PURE__ */ e("text", { x: "166", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH₂" }),
              /* @__PURE__ */ e("text", { x: "6", y: "70", fontSize: "9", fill: "var(--ink-soft)", children: "C1 — C2 = C3 — C4 共轭体系" })
            ]
          }
        ),
        /* @__PURE__ */ e("figcaption", { className: "mt-1 text-center text-xs font-medium text-[var(--ink)]", children: "反应物：1,3-丁二烯" })
      ] }),
      /* @__PURE__ */ t(
        "figure",
        {
          className: "rounded-lg border p-3 transition-colors",
          style: {
            borderColor: l ? "#2563eb" : "var(--line)",
            backgroundColor: l ? "rgba(37,99,235,0.1)" : "var(--bg-muted)"
          },
          children: [
            /* @__PURE__ */ t(
              "svg",
              {
                viewBox: "0 0 200 90",
                className: "w-full",
                role: "img",
                "aria-label": "3-溴-1-丁烯结构",
                children: [
                  /* @__PURE__ */ e("text", { x: "6", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH₂" }),
                  /* @__PURE__ */ e(o, { x1: 36, x2: 66, y: 36 }),
                  /* @__PURE__ */ e("text", { x: "68", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH" }),
                  /* @__PURE__ */ e(a, { x1: 90, x2: 110, y: 36 }),
                  /* @__PURE__ */ e("text", { x: "108", y: "40", fontSize: "11", fill: "var(--ink)", children: "CHBr" }),
                  /* @__PURE__ */ e(a, { x1: 142, x2: 162, y: 36 }),
                  /* @__PURE__ */ e("text", { x: "164", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH₃" }),
                  /* @__PURE__ */ e("text", { x: "6", y: "70", fontSize: "9", fill: "#2563eb", children: "H 加 C1，Br 加 C2（1,2-加成）" })
                ]
              }
            ),
            /* @__PURE__ */ e("figcaption", { className: "mt-1 text-center text-xs font-medium text-[#2563eb]", children: "1,2-加成：3-溴-1-丁烯" })
          ]
        }
      ),
      /* @__PURE__ */ t(
        "figure",
        {
          className: "rounded-lg border p-3 transition-colors",
          style: {
            borderColor: l ? "var(--line)" : "#dc2626",
            backgroundColor: l ? "var(--bg-muted)" : "rgba(220,38,38,0.1)"
          },
          children: [
            /* @__PURE__ */ t(
              "svg",
              {
                viewBox: "0 0 200 90",
                className: "w-full",
                role: "img",
                "aria-label": "1-溴-2-丁烯结构",
                children: [
                  /* @__PURE__ */ e("text", { x: "2", y: "40", fontSize: "11", fill: "var(--ink)", children: "BrCH₂" }),
                  /* @__PURE__ */ e(a, { x1: 40, x2: 60, y: 36 }),
                  /* @__PURE__ */ e("text", { x: "62", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH" }),
                  /* @__PURE__ */ e(o, { x1: 84, x2: 114, y: 36 }),
                  /* @__PURE__ */ e("text", { x: "116", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH" }),
                  /* @__PURE__ */ e(a, { x1: 138, x2: 158, y: 36 }),
                  /* @__PURE__ */ e("text", { x: "160", y: "40", fontSize: "11", fill: "var(--ink)", children: "CH₃" }),
                  /* @__PURE__ */ e("text", { x: "6", y: "70", fontSize: "9", fill: "#dc2626", children: "H 加 C1，Br 加 C4（1,4-加成）" })
                ]
              }
            ),
            /* @__PURE__ */ e("figcaption", { className: "mt-1 text-center text-xs font-medium text-[#dc2626]", children: "1,4-加成：1-溴-2-丁烯" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ t("div", { className: "mt-5 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
      /* @__PURE__ */ e("h4", { className: "text-sm font-semibold text-[var(--ink)]", children: "为什么会有两个加成位置？——烯丙基碳正离子的共振" }),
      /* @__PURE__ */ t(
        "svg",
        {
          viewBox: "0 0 360 70",
          className: "mt-2 w-full max-w-md",
          role: "img",
          "aria-label": "烯丙基碳正离子共振",
          children: [
            /* @__PURE__ */ e("text", { x: "2", y: "30", fontSize: "10", fill: "var(--ink)", children: "CH₂=CH–CH⁺–CH₃" }),
            /* @__PURE__ */ e(
              "line",
              {
                x1: "120",
                y1: "26",
                x2: "160",
                y2: "26",
                stroke: "var(--ink-soft)",
                strokeWidth: "1"
              }
            ),
            /* @__PURE__ */ e("polygon", { points: "160,26 153,23 153,29", fill: "var(--ink-soft)" }),
            /* @__PURE__ */ e("polygon", { points: "120,26 127,23 127,29", fill: "var(--ink-soft)" }),
            /* @__PURE__ */ e("text", { x: "168", y: "30", fontSize: "10", fill: "var(--ink)", children: "⁺CH₂–CH=CH–CH₃" }),
            /* @__PURE__ */ e("text", { x: "2", y: "55", fontSize: "9", fill: "var(--ink-soft)", children: "正电荷离域在 C2 与 C4 之间，Br⁻ 既可进攻 C2（→1,2）也可进攻 C4（→1,4）" })
          ]
        }
      ),
      /* @__PURE__ */ t("ul", { className: "mt-2 space-y-1 text-xs text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ t("li", { children: [
          "• HBr 中的",
          " ",
          /* @__PURE__ */ e("span", { className: "font-medium text-[var(--ink)]", children: "H⁺ 先加到 C1" }),
          "， 生成烯丙基型碳正离子，正电荷通过共振离域在 C2 和 C4 上。"
        ] }),
        /* @__PURE__ */ t("li", { children: [
          "•",
          " ",
          /* @__PURE__ */ e("span", { className: "font-medium text-[#2563eb]", children: "低温（动力学控制）" }),
          "：Br⁻ 优先进攻电荷密度更高、距离更近的 C2， 过渡态能垒低、生成快 → 主要得 ",
          /* @__PURE__ */ e("span", { className: "font-medium", children: "1,2-加成产物" }),
          "。"
        ] }),
        /* @__PURE__ */ t("li", { children: [
          "•",
          " ",
          /* @__PURE__ */ e("span", { className: "font-medium text-[#dc2626]", children: "高温（热力学控制）" }),
          "：反应可逆，体系趋向更稳定产物； 1,4-产物是",
          /* @__PURE__ */ e("span", { className: "font-medium", children: " 内（二取代）双键" }),
          "，更稳定 → 主要得 ",
          /* @__PURE__ */ e("span", { className: "font-medium", children: "1,4-加成产物" }),
          "。"
        ] })
      ] })
    ] })
  ] });
}
function m({ label: i, tag: r, percent: n, color: l, active: s }) {
  return /* @__PURE__ */ t("div", { children: [
    /* @__PURE__ */ t("div", { className: "flex items-baseline justify-between", children: [
      /* @__PURE__ */ t("span", { className: "text-sm font-medium text-[var(--ink)]", children: [
        i,
        s && /* @__PURE__ */ e(
          "span",
          {
            className: "ml-2 rounded px-1.5 py-0.5 text-[10px] font-semibold text-white",
            style: { backgroundColor: l },
            children: "主产物"
          }
        )
      ] }),
      /* @__PURE__ */ t("span", { className: "text-sm font-semibold tabular-nums", style: { color: l }, children: [
        n,
        "%"
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "mt-1 h-4 w-full overflow-hidden rounded-full bg-[var(--bg-muted)]", children: /* @__PURE__ */ e(
      "div",
      {
        className: "h-full rounded-full transition-all duration-300 ease-out",
        style: { width: `${n}%`, backgroundColor: l }
      }
    ) }),
    /* @__PURE__ */ e("p", { className: "mt-0.5 text-xs", style: { color: l }, children: r })
  ] });
}
function a({ x1: i, x2: r, y: n }) {
  return /* @__PURE__ */ e("line", { x1: i, y1: n, x2: r, y2: n, stroke: "var(--ink)", strokeWidth: "1.4" });
}
function o({ x1: i, x2: r, y: n }) {
  return /* @__PURE__ */ t("g", { children: [
    /* @__PURE__ */ e(
      "line",
      {
        x1: i,
        y1: n - 2.5,
        x2: r,
        y2: n - 2.5,
        stroke: "var(--ink)",
        strokeWidth: "1.4"
      }
    ),
    /* @__PURE__ */ e(
      "line",
      {
        x1: i,
        y1: n + 2.5,
        x2: r,
        y2: n + 2.5,
        stroke: "var(--ink)",
        strokeWidth: "1.4"
      }
    )
  ] });
}
const p = f(v);
export {
  p as default
};
