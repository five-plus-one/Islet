import { jsxs as a, jsx as e } from "react/jsx-runtime";
import { memo as h, useState as u } from "react";
const m = [
  {
    formula: "-OH",
    name: "羟基",
    directing: "ortho-para",
    activating: !0,
    isHalogen: !1,
    reason: "氧上孤对电子与苯环 p-π 共轭，向环上供电子（+C 效应强于 -I 诱导吸电子），使邻、对位电子云密度升高。"
  },
  {
    formula: "-NH₂",
    name: "氨基",
    directing: "ortho-para",
    activating: !0,
    isHalogen: !1,
    reason: "氮上孤对电子与苯环强共轭供电子（+C），活化能力很强，邻、对位电子云密度显著升高。"
  },
  {
    formula: "-OCH₃",
    name: "甲氧基",
    directing: "ortho-para",
    activating: !0,
    isHalogen: !1,
    reason: "氧的孤对电子与环共轭供电子（+C），整体表现为供电子、活化苯环。"
  },
  {
    formula: "-CH₃",
    name: "甲基",
    directing: "ortho-para",
    activating: !0,
    isHalogen: !1,
    reason: "通过 σ 超共轭与 +I 诱导效应向环供电子，使邻、对位电子云密度升高，属弱活化基。"
  },
  {
    formula: "-Cl",
    name: "氯",
    directing: "ortho-para",
    activating: !1,
    isHalogen: !0,
    reason: "特例：卤素 -I 诱导吸电子（钝化苯环）强于其弱 +C 共轭供电子，故整体致钝；但共轭主要补偿邻、对位，反应仍主要进入邻、对位。"
  },
  {
    formula: "-Br",
    name: "溴",
    directing: "ortho-para",
    activating: !1,
    isHalogen: !0,
    reason: "特例：卤素以 -I 诱导吸电子为主，钝化苯环；弱 +C 共轭使邻、对位相对受益，反应主要进入邻、对位。"
  },
  {
    formula: "-NO₂",
    name: "硝基",
    directing: "meta",
    activating: !1,
    isHalogen: !1,
    reason: "强吸电子（-I 诱导 + -C 共轭），使邻、对位电子云密度下降最多，间位相对最高，故定位于间位并强烈钝化苯环。"
  },
  {
    formula: "-COOH",
    name: "羧基",
    directing: "meta",
    activating: !1,
    isHalogen: !1,
    reason: "羰基吸电子（-I + -C），邻、对位缺电子更明显，亲电试剂主要进入间位，苯环被钝化。"
  },
  {
    formula: "-CHO",
    name: "醛基",
    directing: "meta",
    activating: !1,
    isHalogen: !1,
    reason: "醛基羰基吸电子（-I + -C），降低邻、对位电子云密度，定位于间位并钝化苯环。"
  },
  {
    formula: "-SO₃H",
    name: "磺酸基",
    directing: "meta",
    activating: !1,
    isHalogen: !1,
    reason: "磺酸基强吸电子（-I + -C），邻、对位电子云密度下降，亲电取代主要发生在间位，钝化苯环。"
  }
], l = [
  { x: 130, y: 40 },
  // 1：取代基所在位（顶部）
  { x: 208, y: 85 },
  // 2：邻位
  { x: 208, y: 175 },
  // 3：间位
  { x: 130, y: 220 },
  // 4：对位
  { x: 52, y: 175 },
  // 5：间位
  { x: 52, y: 85 }
  // 6：邻位
], p = [1, 3, 5], v = [2, 4], i = "var(--accent)";
function b() {
  const [o, f] = u(0), r = m[o], g = r.directing === "ortho-para" ? p : v, x = l.map((t, n) => `${n === 0 ? "M" : "L"} ${t.x} ${t.y}`).join(
    " "
  ) + " Z", c = r.directing === "ortho-para" ? "邻位 + 对位" : "间位";
  return /* @__PURE__ */ a("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "text-lg font-semibold text-[var(--ink)]", children: "芳环定位效应预测" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "选择苯环上已有的取代基，判断它是「邻对位定位基」还是「间位定位基」， 并预测下一个亲电取代主要进入的位置（高亮显示）。" }),
    /* @__PURE__ */ a("div", { className: "mt-4 grid grid-cols-1 gap-4 md:grid-cols-2", children: [
      /* @__PURE__ */ a("div", { children: [
        /* @__PURE__ */ e("p", { className: "mb-2 text-xs font-medium text-[var(--ink-soft)]", children: "选择苯环上的取代基：" }),
        /* @__PURE__ */ e("div", { className: "flex flex-wrap gap-2", children: m.map((t, n) => {
          const s = n === o;
          return /* @__PURE__ */ e(
            "button",
            {
              type: "button",
              onClick: () => f(n),
              className: `rounded-lg border px-3 py-1.5 text-sm transition-colors ${s ? "border-transparent text-white" : "border-[var(--line)] bg-[var(--bg-muted)] text-[var(--ink)] hover:border-[var(--ink-soft)]"}`,
              style: s ? { backgroundColor: i } : void 0,
              children: t.formula
            },
            t.formula
          );
        }) }),
        /* @__PURE__ */ a("div", { className: "mt-4 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
          /* @__PURE__ */ a("div", { className: "flex flex-wrap items-center gap-2 text-sm", children: [
            /* @__PURE__ */ a("span", { className: "font-semibold text-[var(--ink)]", children: [
              r.formula,
              "（",
              r.name,
              "）"
            ] }),
            /* @__PURE__ */ e(
              "span",
              {
                className: "rounded-md px-2 py-0.5 text-xs font-medium text-white",
                style: { backgroundColor: i },
                children: r.directing === "ortho-para" ? "邻对位定位基" : "间位定位基"
              }
            ),
            /* @__PURE__ */ e(
              "span",
              {
                className: `rounded-md px-2 py-0.5 text-xs font-medium ${r.activating ? "bg-emerald-500/10 text-[var(--color-success)]" : "bg-rose-500/10 text-[var(--md-sys-color-error)]"}`,
                children: r.activating ? "致活（活化苯环）" : "致钝（钝化苯环）"
              }
            )
          ] }),
          r.isHalogen && /* @__PURE__ */ e("p", { className: "mt-2 rounded-md bg-amber-500/10 px-2 py-1 text-xs text-[var(--color-warning)]", children: "⚠ 特例：卤素是「致钝的邻对位定位基」——既钝化苯环，又把反应导向邻、对位。" }),
          /* @__PURE__ */ a("p", { className: "mt-2 text-sm leading-relaxed text-[var(--ink-soft)]", children: [
            /* @__PURE__ */ e("span", { className: "font-medium text-[var(--ink)]", children: "原因：" }),
            r.reason
          ] }),
          /* @__PURE__ */ a("p", { className: "mt-2 text-sm text-[var(--ink)]", children: [
            "下一个亲电取代主要进入：",
            /* @__PURE__ */ a("span", { className: "font-semibold", style: { color: i }, children: [
              " ",
              c
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ a("div", { className: "flex flex-col items-center justify-center", children: [
        /* @__PURE__ */ a(
          "svg",
          {
            viewBox: "0 0 260 260",
            className: "h-64 w-64",
            role: "img",
            "aria-label": `带 ${r.formula} 取代基的苯环，高亮 ${c}`,
            children: [
              /* @__PURE__ */ e(
                "path",
                {
                  d: x,
                  fill: "none",
                  stroke: "var(--ink)",
                  strokeWidth: 2.5,
                  strokeLinejoin: "round"
                }
              ),
              /* @__PURE__ */ e(
                "circle",
                {
                  cx: 130,
                  cy: 130,
                  r: 48,
                  fill: "none",
                  stroke: "var(--ink-soft)",
                  strokeWidth: 1.5,
                  strokeDasharray: "4 4"
                }
              ),
              l.map((t, n) => {
                const s = n === 0, d = g.includes(n);
                return /* @__PURE__ */ a("g", { children: [
                  d && /* @__PURE__ */ e(
                    "circle",
                    {
                      cx: t.x,
                      cy: t.y,
                      r: 16,
                      fill: i,
                      fillOpacity: 0.18,
                      stroke: i,
                      strokeWidth: 2
                    }
                  ),
                  /* @__PURE__ */ e(
                    "circle",
                    {
                      cx: t.x,
                      cy: t.y,
                      r: 5,
                      fill: s || d ? i : "var(--ink-soft)"
                    }
                  ),
                  /* @__PURE__ */ e(
                    "text",
                    {
                      x: t.x,
                      y: t.y - 22,
                      textAnchor: "middle",
                      fontSize: "11",
                      fill: "var(--ink-soft)",
                      children: n + 1
                    }
                  )
                ] }, `vertex-${n}`);
              }),
              /* @__PURE__ */ e(
                "text",
                {
                  x: l[0].x,
                  y: l[0].y - 6,
                  textAnchor: "middle",
                  fontSize: "14",
                  fontWeight: "600",
                  fill: i,
                  children: r.formula
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ a("div", { className: "mt-2 flex items-center gap-4 text-xs text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ a("span", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ e(
              "span",
              {
                className: "inline-block h-3 w-3 rounded-full",
                style: { backgroundColor: i }
              }
            ),
            "取代基 / 主要进攻位"
          ] }),
          /* @__PURE__ */ a("span", { className: "flex items-center gap-1", children: [
            /* @__PURE__ */ e("span", { className: "inline-block h-3 w-3 rounded-full bg-[var(--ink-soft)]" }),
            "其它碳"
          ] })
        ] })
      ] })
    ] })
  ] });
}
const y = h(b);
export {
  y as default
};
