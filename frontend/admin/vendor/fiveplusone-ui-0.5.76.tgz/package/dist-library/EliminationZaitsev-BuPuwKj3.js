import { jsxs as a, jsx as e } from "react/jsx-runtime";
import { memo as f, useState as m } from "react";
const o = [
  {
    id: "2-bromobutane",
    name: "2-溴丁烷",
    formula: "CH3-CHBr-CH2-CH3",
    carbonClass: "2°",
    note: "两侧 β-碳上都有氢，消除方向不同得到不同取代度烯烃。",
    products: [
      {
        name: "2-丁烯 (但-2-烯)",
        substitution: 2,
        detail: "消除 C3 上的 β-氢，双键在 C2=C3，二取代烯烃，E2 主要给反式(E)。",
        isZaitsev: !0,
        hofmannRatio: 30,
        zaitsevRatio: 80
      },
      {
        name: "1-丁烯 (但-1-烯)",
        substitution: 1,
        detail: "消除 C1 上的 β-氢，双键在 C1=C2，端烯（一取代），霍夫曼产物。",
        isZaitsev: !1,
        hofmannRatio: 70,
        zaitsevRatio: 20
      }
    ]
  },
  {
    id: "2-bromo-2-methylbutane",
    name: "2-溴-2-甲基丁烷",
    formula: "(CH3)2CBr-CH2-CH3",
    carbonClass: "3°",
    note: "叔卤代烷，易走 E1（稳定叔碳正离子），也可 E2；存在两类 β-氢。",
    products: [
      {
        name: "2-甲基-2-丁烯",
        substitution: 3,
        detail: "消除 C3 的 β-氢，双键在 C2=C3，三取代烯烃，最稳定的扎伊采夫主产物。",
        isZaitsev: !0,
        hofmannRatio: 28,
        zaitsevRatio: 82
      },
      {
        name: "2-甲基-1-丁烯",
        substitution: 2,
        detail: "消除甲基上的 β-氢，双键在 C2=CH2，二取代端烯，霍夫曼（少取代）产物。",
        isZaitsev: !1,
        hofmannRatio: 72,
        zaitsevRatio: 18
      }
    ]
  },
  {
    id: "2-bromo-2-methylbutane-tBuOK",
    name: "2-溴-2,3-二甲基丁烷",
    formula: "(CH3)2CBr-CH(CH3)2",
    carbonClass: "3°",
    note: "叔卤代烷，β-碳上分别为甲基氢与次甲基氢，体现取向之争。",
    products: [
      {
        name: "2,3-二甲基-2-丁烯",
        substitution: 4,
        detail: "消除次甲基(C3-H)，双键在 C2=C3，四取代烯烃，高度稳定的扎伊采夫主产物。",
        isZaitsev: !0,
        hofmannRatio: 25,
        zaitsevRatio: 85
      },
      {
        name: "2,3-二甲基-1-丁烯",
        substitution: 2,
        detail: "消除一个甲基上的氢，得到端烯，二取代，霍夫曼产物。",
        isZaitsev: !1,
        hofmannRatio: 75,
        zaitsevRatio: 15
      }
    ]
  }
], x = {
  E2: {
    title: "E2 · 双分子消除（一步协同）",
    points: [
      "强碱进攻 β-氢、C–H 与 C–X 键同时断裂，一步完成。",
      "立体要求：β-H 与离去基团需反式共平面（anti-periplanar），即反式消除。",
      "速率 = k[底物][碱]，二级反应；过渡态部分双键性，倾向生成更稳定（多取代）烯烃。"
    ]
  },
  E1: {
    title: "E1 · 单分子消除（碳正离子分步）",
    points: [
      "先离去基团离去生成碳正离子（决速步），再失去 β-氢形成双键。",
      "速率 = k[底物]，与碱浓度无关；叔/烯丙位等稳定碳正离子最易走 E1。",
      "碳正离子平面构型，无严格反式要求；同样遵循扎伊采夫，主要给多取代烯烃。"
    ]
  }
};
function p(n, d) {
  return /* @__PURE__ */ e("div", { className: "h-3 w-full overflow-hidden rounded-full bg-[var(--bg-muted)]", children: /* @__PURE__ */ e(
    "div",
    {
      className: "h-full rounded-full transition-all duration-300",
      style: { width: `${n}%`, backgroundColor: d }
    }
  ) });
}
function k() {
  const [n, d] = m(o[0].id), [r, v] = m("E2"), [s, b] = m(!1), l = o.find((t) => t.id === n) ?? o[0], h = (t) => s ? t.hofmannRatio : t.zaitsevRatio, u = s ? "反扎伊采夫 · 霍夫曼取向（少取代烯烃为主）" : "扎伊采夫取向（多取代、更稳定烯烃为主）";
  return /* @__PURE__ */ a("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "mb-1 text-lg font-semibold text-[var(--ink)]", children: "E1 / E2 消除与扎伊采夫规则" }),
    /* @__PURE__ */ a("p", { className: "mb-4 text-sm text-[var(--ink-soft)]", children: [
      "卤代烷消除 HX 生成烯烃。同一底物的不同 β-氢被消除会得到不同取代度的烯烃：",
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "扎伊采夫规则" }),
      "指出主产物通常是双键上取代基更多、 更稳定的烯烃；而用",
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "强碱、大体积碱" }),
      "（如叔丁醇钾）时， 取向可逆转为少取代的",
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "霍夫曼产物" }),
      "（反扎伊采夫）。"
    ] }),
    /* @__PURE__ */ a("div", { className: "mb-4", children: [
      /* @__PURE__ */ e("div", { className: "mb-2 text-xs font-medium uppercase tracking-wide text-[var(--ink-soft)]", children: "选择卤代烷底物" }),
      /* @__PURE__ */ e("div", { className: "flex flex-wrap gap-2", children: o.map((t) => {
        const i = t.id === n;
        return /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => d(t.id),
            className: `rounded-lg border px-3 py-1.5 text-sm transition-colors ${i ? "border-indigo-500 bg-[var(--accent-weak)] text-[var(--accent)]" : "border-[var(--line)] bg-[var(--bg-elevated)] text-[var(--ink)] hover:bg-[var(--bg-muted)]"}`,
            children: t.name
          },
          t.id
        );
      }) }),
      /* @__PURE__ */ a("div", { className: "mt-2 rounded-lg bg-[var(--bg-muted)] p-3", children: [
        /* @__PURE__ */ e("div", { className: "font-mono text-sm text-[var(--ink)]", children: l.formula }),
        /* @__PURE__ */ a("div", { className: "mt-1 text-xs text-[var(--ink-soft)]", children: [
          "连碳类型：",
          /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: l.carbonClass }),
          " ·",
          " ",
          l.note
        ] })
      ] })
    ] }),
    /* @__PURE__ */ a("div", { className: "mb-4 flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ e("div", { className: "inline-flex overflow-hidden rounded-lg border border-[var(--line)]", children: ["E2", "E1"].map((t) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => v(t),
          className: `px-4 py-1.5 text-sm transition-colors ${r === t ? "bg-indigo-600 text-white" : "bg-[var(--bg-elevated)] text-[var(--ink)] hover:bg-[var(--bg-muted)]"}`,
          children: t
        },
        t
      )) }),
      /* @__PURE__ */ a("label", { className: "inline-flex cursor-pointer items-center gap-2 text-sm text-[var(--ink)]", children: [
        /* @__PURE__ */ e(
          "input",
          {
            type: "checkbox",
            checked: s,
            onChange: (t) => b(t.target.checked),
            className: "h-4 w-4 accent-indigo-600"
          }
        ),
        "强碱 / 大体积碱（叔丁醇钾，t-BuOK）"
      ] })
    ] }),
    /* @__PURE__ */ a("div", { className: "mb-4 rounded-lg border border-[var(--line)] p-3", children: [
      /* @__PURE__ */ e("div", { className: "mb-1 text-sm font-semibold text-[var(--ink)]", children: x[r].title }),
      /* @__PURE__ */ e("ul", { className: "list-disc space-y-1 pl-5 text-xs text-[var(--ink-soft)]", children: x[r].points.map((t) => /* @__PURE__ */ e("li", { children: t }, t)) }),
      r === "E2" ? /* @__PURE__ */ e(g, {}) : /* @__PURE__ */ a("div", { className: "mt-3 rounded bg-[var(--bg-muted)] p-2 text-xs text-[var(--ink-soft)]", children: [
        "E1 经平面碳正离子中间体（",
        /* @__PURE__ */ a("span", { className: "font-mono text-[var(--ink)]", children: [
          "R3C",
          /* @__PURE__ */ e("sup", { children: "+" })
        ] }),
        "），无反式共平面要求，主产物仍服从扎伊采夫。"
      ] })
    ] }),
    /* @__PURE__ */ a(
      "div",
      {
        className: `mb-3 rounded-lg px-3 py-2 text-sm font-medium ${s ? "bg-amber-500/10 text-[var(--color-warning)]" : "bg-emerald-500/10 text-[var(--color-success)]"}`,
        children: [
          "当前取向：",
          u
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "space-y-3", children: l.products.map((t) => {
      const i = h(t), c = i >= 50;
      return /* @__PURE__ */ a(
        "div",
        {
          className: "rounded-lg border border-[var(--line)] p-3",
          children: [
            /* @__PURE__ */ a("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
              /* @__PURE__ */ a("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: t.name }),
                /* @__PURE__ */ a("span", { className: "rounded bg-[var(--bg-muted)] px-1.5 py-0.5 text-[11px] text-[var(--ink-soft)]", children: [
                  t.substitution,
                  " 取代烯烃"
                ] }),
                t.isZaitsev ? /* @__PURE__ */ e("span", { className: "rounded bg-emerald-500/10 px-1.5 py-0.5 text-[11px] text-[var(--color-success)]", children: "扎伊采夫（更稳定）" }) : /* @__PURE__ */ e("span", { className: "rounded bg-amber-500/10 px-1.5 py-0.5 text-[11px] text-[var(--color-warning)]", children: "霍夫曼（少取代）" })
              ] }),
              /* @__PURE__ */ a(
                "span",
                {
                  className: `text-sm font-semibold ${c ? "text-[var(--accent)]" : "text-[var(--ink-soft)]"}`,
                  children: [
                    "~",
                    i,
                    "% · ",
                    c ? "主产物" : "次产物"
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ e("div", { className: "mt-2", children: p(i, c ? "var(--accent)" : "var(--line)") }),
            /* @__PURE__ */ e("p", { className: "mt-2 text-xs text-[var(--ink-soft)]", children: t.detail })
          ]
        },
        t.name
      );
    }) }),
    /* @__PURE__ */ e("p", { className: "mt-4 text-xs text-[var(--ink-soft)]", children: "提示：比例为教学示意值。普通碱（如乙醇钠）下多取代的扎伊采夫产物占主； 换用大体积强碱（t-BuOK）时，因难以接近内侧拥挤的 β-氢，转而消除位阻较小的端位 β-氢，少取代的霍夫曼产物上升为主，即反扎伊采夫取向。" })
  ] });
}
function g() {
  return /* @__PURE__ */ a("div", { className: "mt-3", children: [
    /* @__PURE__ */ a(
      "svg",
      {
        viewBox: "0 0 320 120",
        role: "img",
        "aria-label": "E2 反式共平面消除示意",
        className: "w-full max-w-md",
        children: [
          /* @__PURE__ */ e(
            "rect",
            {
              x: "0.5",
              y: "0.5",
              width: "319",
              height: "119",
              rx: "8",
              fill: "var(--bg-muted)",
              stroke: "var(--line)"
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: "120",
              y1: "60",
              x2: "200",
              y2: "60",
              stroke: "var(--ink)",
              strokeWidth: "2"
            }
          ),
          /* @__PURE__ */ e(
            "circle",
            {
              cx: "120",
              cy: "60",
              r: "14",
              fill: "#fff",
              stroke: "var(--ink)",
              strokeWidth: "1.5"
            }
          ),
          /* @__PURE__ */ e(
            "circle",
            {
              cx: "200",
              cy: "60",
              r: "14",
              fill: "#fff",
              stroke: "var(--ink)",
              strokeWidth: "1.5"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "120",
              y: "64",
              textAnchor: "middle",
              fontSize: "11",
              fill: "var(--ink)",
              children: "Cα"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "200",
              y: "64",
              textAnchor: "middle",
              fontSize: "11",
              fill: "var(--ink)",
              children: "Cβ"
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: "120",
              y1: "46",
              x2: "120",
              y2: "22",
              stroke: "#dc2626",
              strokeWidth: "2"
            }
          ),
          /* @__PURE__ */ e("text", { x: "120", y: "18", textAnchor: "middle", fontSize: "11", fill: "#dc2626", children: "X (离去)" }),
          /* @__PURE__ */ e(
            "line",
            {
              x1: "200",
              y1: "74",
              x2: "200",
              y2: "98",
              stroke: "#2563eb",
              strokeWidth: "2"
            }
          ),
          /* @__PURE__ */ e("text", { x: "200", y: "112", textAnchor: "middle", fontSize: "11", fill: "#2563eb", children: "β-H" }),
          /* @__PURE__ */ e(
            "text",
            {
              x: "255",
              y: "102",
              textAnchor: "middle",
              fontSize: "10",
              fill: "var(--ink-soft)",
              children: "B:⁻ →"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "160",
              y: "40",
              textAnchor: "middle",
              fontSize: "10",
              fill: "var(--ink-soft)",
              children: "反式共平面 (anti)"
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "mt-1 text-[11px] text-[var(--ink-soft)]", children: "X 与 β-H 处于反式共平面，碱夺 β-H、X 离去、Cα=Cβ 形成双键 —— E2 的反式消除。" })
  ] });
}
const y = f(k);
export {
  y as default
};
