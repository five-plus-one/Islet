import { jsxs as r, jsx as e } from "react/jsx-runtime";
import { memo as c, useState as x } from "react";
const h = {
  base: {
    label: "碱催化（亲核条件）",
    description: "强亲核试剂 CH₃O⁻ 在中性 / 碱性条件下直接进攻环氧三元环。",
    attackedCarbon: "C1",
    product: "CH₃O–CH₂–CH(OH)–CH₃",
    mechanism: "SN2 类（协同背面进攻）",
    reason: "碱性条件下没有质子化，环氧环的两个 C–O 键差别不大，反应受位阻控制。亲核试剂走 SN2 路径，从位阻较小的一端（端位 CH₂，即取代少的碳 C1）背面进攻，过渡态拥挤程度最低，因此优先在位阻小的碳上开环。"
  },
  acid: {
    label: "酸催化（质子化条件）",
    description: "先由 H⁺ 质子化环氧氧，弱亲核试剂 CH₃OH 再进攻被活化的环。",
    attackedCarbon: "C2",
    product: "CH₃O–CH(CH₃)–CH₂(OH)",
    mechanism: "碳正离子类（SN1 倾向 / 较松的过渡态）",
    reason: "质子化后 C–O 键拉长、断裂，部分正电荷分布到碳上。取代多、位阻大的碳（C2，连有甲基）能更好地稳定正电荷（更稳定的“类碳正离子”），故 C–O 键优先在该碳上断开，亲核试剂进攻位阻较大的取代多碳。区域选择性由电子效应（正电荷稳定性）主导，而非位阻。"
  }
}, a = "#2563eb", t = "#dc2626";
function m() {
  const [n, s] = x("base"), i = h[n], l = i.attackedCarbon === "C1";
  return /* @__PURE__ */ r("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "text-lg font-semibold", style: { color: "var(--ink)" }, children: "环氧乙烷开环：区域选择性（酸催化 vs 碱催化）" }),
    /* @__PURE__ */ r("p", { className: "mt-1 text-sm", style: { color: "var(--ink-soft)" }, children: [
      "以 1,2-环氧丙烷（2-甲基环氧乙烷）+ 甲氧基亲核试剂为例。切换催化条件，观察亲核试剂进攻",
      /* @__PURE__ */ e("strong", { children: "位阻小的端位碳" }),
      "（碱催化，SN2 类）还是",
      /* @__PURE__ */ e("strong", { children: "位阻大的取代多碳" }),
      "（酸催化，碳正离子类）。"
    ] }),
    /* @__PURE__ */ e("div", { className: "mt-4 flex gap-2", children: ["base", "acid"].map((o) => {
      const d = n === o;
      return /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => s(o),
          className: "rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors",
          style: {
            borderColor: d ? a : "var(--line)",
            backgroundColor: d ? a : "var(--bg-muted)",
            color: d ? "var(--fp-on-primary)" : "var(--ink)"
          },
          children: o === "base" ? "碱催化" : "酸催化"
        },
        o
      );
    }) }),
    /* @__PURE__ */ e("div", { className: "mt-4 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: /* @__PURE__ */ r(
      "svg",
      {
        viewBox: "0 0 520 240",
        className: "h-auto w-full",
        role: "img",
        "aria-label": "环氧三元环开环区域选择示意图",
        children: [
          /* @__PURE__ */ r("g", { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: "120",
                y1: "60",
                x2: "80",
                y2: "120",
                stroke: "var(--ink)",
                strokeWidth: 2
              }
            ),
            /* @__PURE__ */ e(
              "line",
              {
                x1: "120",
                y1: "60",
                x2: "160",
                y2: "120",
                stroke: "var(--ink)",
                strokeWidth: 2
              }
            ),
            /* @__PURE__ */ e(
              "line",
              {
                x1: "80",
                y1: "120",
                x2: "160",
                y2: "120",
                stroke: "var(--ink)",
                strokeWidth: 2
              }
            ),
            /* @__PURE__ */ e(
              "circle",
              {
                cx: "120",
                cy: "60",
                r: "13",
                fill: "#fff",
                stroke: "var(--ink)",
                strokeWidth: 1.5
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: "120",
                y: "65",
                textAnchor: "middle",
                fontSize: "13",
                fill: "var(--ink)",
                children: n === "acid" ? "O⁺" : "O"
              }
            ),
            n === "acid" && /* @__PURE__ */ e(
              "text",
              {
                x: "120",
                y: "38",
                textAnchor: "middle",
                fontSize: "12",
                fill: t,
                children: "H⁺"
              }
            ),
            /* @__PURE__ */ e(
              "circle",
              {
                cx: "80",
                cy: "120",
                r: "13",
                fill: "#fff",
                stroke: l ? "var(--ink)" : t,
                strokeWidth: l ? 1.5 : 2.5
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: "80",
                y: "125",
                textAnchor: "middle",
                fontSize: "12",
                fill: "var(--ink)",
                children: "C2"
              }
            ),
            /* @__PURE__ */ e(
              "line",
              {
                x1: "80",
                y1: "120",
                x2: "48",
                y2: "150",
                stroke: "var(--ink)",
                strokeWidth: 2
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: "36",
                y: "166",
                textAnchor: "middle",
                fontSize: "11",
                fill: "var(--ink-soft)",
                children: "CH₃"
              }
            ),
            /* @__PURE__ */ e(
              "circle",
              {
                cx: "160",
                cy: "120",
                r: "13",
                fill: "#fff",
                stroke: l ? t : "var(--ink)",
                strokeWidth: l ? 2.5 : 1.5
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: "160",
                y: "125",
                textAnchor: "middle",
                fontSize: "12",
                fill: "var(--ink)",
                children: "C1"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: "178",
                y: "150",
                textAnchor: "middle",
                fontSize: "11",
                fill: "var(--ink-soft)",
                children: "CH₂"
              }
            )
          ] }),
          l ? /* @__PURE__ */ r("g", { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: "240",
                y1: "120",
                x2: "176",
                y2: "120",
                stroke: t,
                strokeWidth: 2,
                markerEnd: "url(#arrow)"
              }
            ),
            /* @__PURE__ */ e("text", { x: "250", y: "124", fontSize: "12", fill: t, children: "CH₃O⁻ 背面进攻 C1" })
          ] }) : /* @__PURE__ */ r("g", { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: "20",
                y1: "120",
                x2: "64",
                y2: "120",
                stroke: t,
                strokeWidth: 2,
                markerEnd: "url(#arrow)"
              }
            ),
            /* @__PURE__ */ e("text", { x: "6", y: "104", fontSize: "12", fill: t, children: "CH₃OH 进攻 C2" })
          ] }),
          /* @__PURE__ */ e(
            "line",
            {
              x1: "270",
              y1: "200",
              x2: "330",
              y2: "200",
              stroke: "var(--ink)",
              strokeWidth: 2,
              markerEnd: "url(#arrow)"
            }
          ),
          /* @__PURE__ */ e(
            "text",
            {
              x: "300",
              y: "192",
              textAnchor: "middle",
              fontSize: "11",
              fill: "var(--ink-soft)",
              children: "开环"
            }
          ),
          /* @__PURE__ */ r("g", { children: [
            /* @__PURE__ */ e("text", { x: "360", y: "70", fontSize: "12", fill: a, children: n === "base" ? "碱催化产物：" : "酸催化产物：" }),
            /* @__PURE__ */ e("text", { x: "360", y: "96", fontSize: "13", fill: "var(--ink)", children: i.product }),
            /* @__PURE__ */ r("text", { x: "360", y: "126", fontSize: "11", fill: "var(--ink-soft)", children: [
              "进攻碳：",
              i.attackedCarbon
            ] }),
            /* @__PURE__ */ r("text", { x: "360", y: "146", fontSize: "11", fill: "var(--ink-soft)", children: [
              "(",
              l ? "位阻小 / 端位 CH₂" : "位阻大 / 取代多碳",
              ")"
            ] })
          ] }),
          /* @__PURE__ */ e("defs", { children: /* @__PURE__ */ e(
            "marker",
            {
              id: "arrow",
              markerWidth: "8",
              markerHeight: "8",
              refX: "6",
              refY: "3",
              orient: "auto",
              markerUnits: "strokeWidth",
              children: /* @__PURE__ */ e("path", { d: "M0,0 L6,3 L0,6 Z", fill: t })
            }
          ) })
        ]
      }
    ) }),
    /* @__PURE__ */ r("div", { className: "mt-4 space-y-2 text-sm", style: { color: "var(--ink)" }, children: [
      /* @__PURE__ */ e("p", { className: "font-semibold", style: { color: a }, children: i.label }),
      /* @__PURE__ */ e("p", { style: { color: "var(--ink-soft)" }, children: i.description }),
      /* @__PURE__ */ r("div", { className: "grid grid-cols-1 gap-2 sm:grid-cols-2", children: [
        /* @__PURE__ */ r("div", { className: "rounded-lg border border-[var(--line)] p-2", children: [
          /* @__PURE__ */ e("span", { className: "text-xs", style: { color: "var(--ink-soft)" }, children: "机理类型" }),
          /* @__PURE__ */ e("p", { className: "font-medium", children: i.mechanism })
        ] }),
        /* @__PURE__ */ r("div", { className: "rounded-lg border border-[var(--line)] p-2", children: [
          /* @__PURE__ */ e("span", { className: "text-xs", style: { color: "var(--ink-soft)" }, children: "进攻位点" }),
          /* @__PURE__ */ r("p", { className: "font-medium", style: { color: t }, children: [
            i.attackedCarbon,
            "（",
            l ? "位阻较小的端位碳" : "位阻较大的取代多碳",
            "）"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ r("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
        /* @__PURE__ */ e(
          "span",
          {
            className: "text-xs font-semibold",
            style: { color: "var(--ink-soft)" },
            children: "区域选择性原因"
          }
        ),
        /* @__PURE__ */ e("p", { className: "mt-1 leading-relaxed", children: i.reason })
      ] }),
      /* @__PURE__ */ r("p", { className: "text-xs", style: { color: "var(--ink-soft)" }, children: [
        "小结：碱催化由",
        /* @__PURE__ */ e("strong", { children: "位阻控制" }),
        "（SN2 类，进攻位阻小碳）；酸催化由",
        /* @__PURE__ */ e("strong", { children: "电子效应控制" }),
        "（碳正离子稳定性，进攻位阻大、取代多的碳）。两条件给出",
        /* @__PURE__ */ e("strong", { children: "相反" }),
        "的区域选择性，是环氧开环的经典对比。"
      ] })
    ] })
  ] });
}
const v = c(m);
export {
  v as default
};
