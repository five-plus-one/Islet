import { jsxs as r, jsx as e } from "react/jsx-runtime";
import { learningAlpha as ue } from "./index.js";
import { memo as pe, useState as M, useCallback as be } from "react";
const w = "#dc2626", ne = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))", C = "#ea580c", ie = "color-mix(in srgb, #ffedd5 24%, var(--fp-surface))", F = "#0f766e", le = "color-mix(in srgb, #ccfbf1 24%, var(--fp-surface))", D = "#5b46e5", S = "#0ea5e9", O = "var(--ink-soft)", ge = "var(--fp-primary)", G = 560, ce = 200, Q = 10, de = 10, A = 18, ve = 40, ye = G - Q - de, W = ce - A - ve;
function z(t, n, i) {
  const c = (t - n) / i;
  return Math.exp(-0.5 * c * c) / (i * Math.sqrt(2 * Math.PI));
}
function Fe(t) {
  const n = 1 / (1 + 0.2316419 * Math.abs(t)), i = n * (0.31938153 + n * (-0.356563782 + n * (1.781477937 + n * (-1.821255978 + n * 1.330274429)))), c = 1 - z(t, 0, 1) * i;
  return t >= 0 ? c : 1 - c;
}
function ae(t, n, i) {
  return Fe((t - n) / i);
}
function se(t) {
  if (t <= 0) return -8;
  if (t >= 1) return 8;
  const n = [2.50662823884, -18.61500062529, 41.39119773534, -25.44106049637], i = [-8.4735109309, 23.08336743743, -21.06224101826, 3.13082909833], c = [
    0.3374754822726147,
    0.9761690190917186,
    0.1607979714918209,
    0.0276438810333863,
    0.0038405729373609,
    3951896511349e-16,
    321767881768e-16,
    2888167364e-16,
    3960315187e-16
  ], a = t - 0.5;
  if (Math.abs(a) < 0.42) {
    const s = a * a;
    return a * (((n[3] * s + n[2]) * s + n[1]) * s + n[0]) / ((((i[3] * s + i[2]) * s + i[1]) * s + i[0]) * s + 1);
  }
  const f = a < 0 ? Math.log(-Math.log(t)) : Math.log(-Math.log(1 - t));
  let l = c[0];
  for (let s = 1; s < 9; s++) l += c[s] * Math.pow(f, s);
  return a < 0 ? -l : l;
}
const y = -4, v = 7;
function d(t) {
  return Q + (t - y) / (v - y) * ye;
}
function $(t, n) {
  return A + W - t / n * W;
}
function re(t, n, i, c = 300) {
  const a = [];
  for (let f = 0; f <= c; f++) {
    const l = y + f / c * (v - y), s = z(l, t, n), x = d(l), b = $(s, i);
    a.push(`${f === 0 ? "M" : "L"}${x.toFixed(2)},${b.toFixed(2)}`);
  }
  return a.join(" ");
}
function q(t, n, i, c, a, f = 100) {
  const l = [], s = Math.max(c, y), x = Math.min(a, v);
  if (s >= x) return "";
  for (let N = 0; N <= f; N++) {
    const k = s + N / f * (x - s), T = z(k, t, n), u = d(k).toFixed(2), m = $(T, i).toFixed(2);
    l.push(`${N === 0 ? "M" : "L"}${u},${m}`);
  }
  const b = $(0, i).toFixed(2);
  return l.push(`L${d(x).toFixed(2)},${b}`), l.push(`L${d(s).toFixed(2)},${b}`), l.push("Z"), l.join(" ");
}
function Y({
  label: t,
  value: n,
  min: i,
  max: c,
  step: a,
  display: f,
  color: l,
  onChange: s,
  hint: x
}) {
  return /* @__PURE__ */ r("div", { className: "space-y-0.5", children: [
    /* @__PURE__ */ r("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: t }),
      /* @__PURE__ */ e(
        "span",
        {
          className: "rounded px-2 py-0.5 text-[12px] font-mono font-bold",
          style: { background: ue(l, "22"), color: l },
          children: f
        }
      )
    ] }),
    x && /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--ink-soft)] leading-relaxed", children: x }),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: i,
        max: c,
        step: a,
        value: n,
        onChange: (b) => s(Number(b.target.value)),
        className: "w-full h-1.5 cursor-pointer",
        style: { accentColor: l }
      }
    )
  ] });
}
function P({ label: t, value: n, sub: i, color: c, bg: a }) {
  return /* @__PURE__ */ r("div", { className: "rounded-lg p-2.5 text-center", style: { background: a }, children: [
    /* @__PURE__ */ e("div", { className: "text-[10px] leading-snug text-[var(--ink-soft)]", children: t }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "mt-0.5 text-[18px] font-extrabold font-mono",
        style: { color: c },
        children: n
      }
    ),
    i && /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: i })
  ] });
}
function Ne() {
  const [t, n] = M(0.05), [i, c] = M(1.5), [a, f] = M(20), [l, s] = M(!1), [x, b] = M(null), N = be(
    (o) => 1 / Math.sqrt(o),
    []
  ), k = N(a), T = k, u = 0, m = i, Z = se(1 - t), E = u + Z * k, R = ae(E, m, T), J = 1 - R, j = N(a * 2), xe = j, B = u + Z * j, I = ae(B, m, xe), K = 1 - I, g = l ? j : k, _ = z(u, u, g) * 1.08, p = l ? B : E, he = re(u, g, _), me = re(m, g, _), U = q(u, g, _, p, v), ee = q(m, g, _, y, p), te = q(m, g, _, p, v), X = d(p), h = $(0, _), oe = [];
  for (let o = Math.ceil(y); o <= Math.floor(v); o++)
    o !== 0 && oe.push(o);
  return /* @__PURE__ */ r("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ r("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "两类错误权衡可视化" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "调整显著性水平 α、效应量 δ 或样本量 n，观察第一类错误（α）与第二类错误（β）的此消彼长。" })
    ] }),
    /* @__PURE__ */ r("div", { className: "relative select-none", children: [
      /* @__PURE__ */ r(
        "svg",
        {
          viewBox: `0 0 ${G} ${ce}`,
          className: "w-full rounded-lg border border-[var(--line)] bg-[var(--bg-muted)]",
          style: { maxHeight: 220 },
          children: [
            U && /* @__PURE__ */ e(
              "path",
              {
                d: U,
                fill: w,
                opacity: x === "alpha" ? 0.55 : 0.35,
                className: "transition-opacity duration-200"
              }
            ),
            ee && /* @__PURE__ */ e(
              "path",
              {
                d: ee,
                fill: C,
                opacity: x === "beta" ? 0.55 : 0.35,
                className: "transition-opacity duration-200"
              }
            ),
            te && /* @__PURE__ */ e(
              "path",
              {
                d: te,
                fill: F,
                opacity: x === "power" ? 0.55 : 0.25,
                className: "transition-opacity duration-200"
              }
            ),
            /* @__PURE__ */ e("path", { d: he, fill: "none", stroke: D, strokeWidth: "2" }),
            /* @__PURE__ */ e("path", { d: me, fill: "none", stroke: S, strokeWidth: "2" }),
            /* @__PURE__ */ e(
              "line",
              {
                x1: X.toFixed(2),
                y1: A,
                x2: X.toFixed(2),
                y2: h,
                stroke: O,
                strokeWidth: "1.5",
                strokeDasharray: "5 3"
              }
            ),
            /* @__PURE__ */ e(
              "line",
              {
                x1: d(u).toFixed(2),
                y1: (h - 4).toFixed(2),
                x2: d(u).toFixed(2),
                y2: (h + 2).toFixed(2),
                stroke: D,
                strokeWidth: "1.5"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: d(u).toFixed(2),
                y: (h + 12).toFixed(2),
                fontSize: "10",
                textAnchor: "middle",
                fill: D,
                fontWeight: "bold",
                children: "μ₀=0"
              }
            ),
            /* @__PURE__ */ e(
              "line",
              {
                x1: d(m).toFixed(2),
                y1: (h - 4).toFixed(2),
                x2: d(m).toFixed(2),
                y2: (h + 2).toFixed(2),
                stroke: S,
                strokeWidth: "1.5"
              }
            ),
            /* @__PURE__ */ r(
              "text",
              {
                x: d(m).toFixed(2),
                y: (h + 12).toFixed(2),
                fontSize: "10",
                textAnchor: "middle",
                fill: S,
                fontWeight: "bold",
                children: [
                  "μ₁=",
                  i.toFixed(1)
                ]
              }
            ),
            /* @__PURE__ */ r(
              "text",
              {
                x: (X + 3).toFixed(2),
                y: (A + 10).toFixed(2),
                fontSize: "9",
                fill: O,
                fontWeight: "600",
                children: [
                  "c=",
                  p.toFixed(2)
                ]
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: d(u - g * 1.2).toFixed(2),
                y: (A + 14).toFixed(2),
                fontSize: "10",
                textAnchor: "middle",
                fill: D,
                fontWeight: "bold",
                children: "H₀"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: d(m + g * 1.2).toFixed(2),
                y: (A + 14).toFixed(2),
                fontSize: "10",
                textAnchor: "middle",
                fill: S,
                fontWeight: "bold",
                children: "H₁"
              }
            ),
            /* @__PURE__ */ e(
              "line",
              {
                x1: Q,
                y1: h,
                x2: G - de,
                y2: h,
                stroke: "var(--line)",
                strokeWidth: "1"
              }
            ),
            oe.map((o) => /* @__PURE__ */ r("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: d(o),
                  y1: h,
                  x2: d(o),
                  y2: h + 3,
                  stroke: "var(--line)",
                  strokeWidth: "1"
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: d(o),
                  y: h + 12,
                  fontSize: "8",
                  textAnchor: "middle",
                  fill: "var(--ink-faint)",
                  children: o
                }
              )
            ] }, o)),
            p < v - 0.5 && /* @__PURE__ */ e(
              "text",
              {
                x: d((p + v) / 2).toFixed(2),
                y: (h - W * 0.12).toFixed(2),
                fontSize: "10",
                textAnchor: "middle",
                fill: w,
                fontWeight: "bold",
                children: "α"
              }
            ),
            p > y + 0.5 && p < m && /* @__PURE__ */ e(
              "text",
              {
                x: d((y + p) / 2 + 0.5).toFixed(2),
                y: (h - W * 0.08).toFixed(2),
                fontSize: "10",
                textAnchor: "middle",
                fill: C,
                fontWeight: "bold",
                children: "β"
              }
            ),
            p < m + g * 2 && /* @__PURE__ */ e(
              "text",
              {
                x: d(
                  Math.min((p + m + g * 2) / 2, v - 0.3)
                ).toFixed(2),
                y: (h - W * 0.15).toFixed(2),
                fontSize: "9",
                textAnchor: "middle",
                fill: F,
                fontWeight: "bold",
                children: "1-β"
              }
            )
          ]
        }
      ),
      l && /* @__PURE__ */ r(
        "div",
        {
          className: "mt-1 text-center text-[11px] font-semibold",
          style: { color: F },
          children: [
            "当前显示：n = ",
            a * 2,
            "（翻倍后），α 保持 ",
            (t * 100).toFixed(0),
            "%"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "flex flex-wrap gap-2", children: [
      {
        key: "alpha",
        color: w,
        bg: ne,
        label: "第一类错误 α（弃真）",
        desc: "H₀为真却拒绝 H₀"
      },
      {
        key: "beta",
        color: C,
        bg: ie,
        label: "第二类错误 β（取伪）",
        desc: "H₁为真却接受 H₀"
      },
      {
        key: "power",
        color: F,
        bg: le,
        label: "检验功效 1-β",
        desc: "正确拒绝 H₀ 的概率"
      }
    ].map(({ key: o, color: H, bg: V, label: L, desc: fe }) => /* @__PURE__ */ r(
      "button",
      {
        type: "button",
        onMouseEnter: () => b(o),
        onMouseLeave: () => b(null),
        onClick: () => b(x === o ? null : o),
        className: "flex items-center gap-1.5 rounded-lg px-2 py-1 text-[11px] border transition-all duration-150",
        style: {
          background: x === o ? V : "var(--bg-muted)",
          borderColor: x === o ? H : "var(--line)",
          color: x === o ? H : "var(--ink-soft)"
        },
        children: [
          /* @__PURE__ */ e(
            "span",
            {
              className: "h-2.5 w-2.5 rounded-sm flex-shrink-0",
              style: { background: H }
            }
          ),
          /* @__PURE__ */ e("span", { className: "font-medium", children: L }),
          /* @__PURE__ */ e("span", { className: "text-[10px] opacity-70", children: fe })
        ]
      },
      o
    )) }),
    /* @__PURE__ */ r("div", { className: "space-y-3 rounded-lg bg-[var(--bg-muted)] px-4 py-3", children: [
      /* @__PURE__ */ e(
        Y,
        {
          label: "显著性水平 α",
          value: t,
          min: 0.01,
          max: 0.2,
          step: 5e-3,
          display: (t * 100).toFixed(1) + "%",
          color: w,
          onChange: n,
          hint: "↑ α → 拒绝域扩大，β ↓，但误判 H₀ 的概率增加。"
        }
      ),
      /* @__PURE__ */ e(
        Y,
        {
          label: "效应量 δ = μ₁ − μ₀",
          value: i,
          min: 0.5,
          max: 3,
          step: 0.1,
          display: i.toFixed(1),
          color: S,
          onChange: c,
          hint: "两分布距离越远，β 越小，越易区分 H₀ 与 H₁。"
        }
      ),
      /* @__PURE__ */ e(
        Y,
        {
          label: "样本量 n",
          value: a,
          min: 5,
          max: 50,
          step: 1,
          display: String(a),
          color: ge,
          onChange: f,
          hint: "↑ n → 两分布变窄，重叠减少，β ↓，功效 ↑。"
        }
      )
    ] }),
    /* @__PURE__ */ r("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
      /* @__PURE__ */ e(
        P,
        {
          label: "第一类错误 α",
          value: (t * 100).toFixed(1) + "%",
          sub: "H₀为真时拒绝",
          color: w,
          bg: ne
        }
      ),
      /* @__PURE__ */ e(
        P,
        {
          label: "第二类错误 β",
          value: ((l ? I : R) * 100).toFixed(1) + "%",
          sub: "H₁为真时未拒绝",
          color: C,
          bg: ie
        }
      ),
      /* @__PURE__ */ e(
        P,
        {
          label: "检验功效 1−β",
          value: ((l ? K : J) * 100).toFixed(1) + "%",
          sub: "正确拒绝 H₀",
          color: F,
          bg: le
        }
      ),
      /* @__PURE__ */ e(
        P,
        {
          label: "临界值 c",
          value: (l ? B : E).toFixed(3),
          sub: `z_α = ${se(1 - t).toFixed(3)}`,
          color: O,
          bg: "var(--bg-muted)"
        }
      )
    ] }),
    /* @__PURE__ */ r("div", { className: "rounded-lg border border-[var(--line)] p-3 space-y-2", children: [
      /* @__PURE__ */ r("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ r("span", { className: "text-[13px] font-bold text-[var(--ink)]", children: [
          "若 n 翻倍（n = ",
          a,
          " → ",
          a * 2,
          "），α 不变时 β 如何变化？"
        ] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => s((o) => !o),
            className: "rounded-lg px-3 py-1 text-[12px] font-semibold transition-colors",
            style: {
              background: l ? F : "var(--bg-muted)",
              color: l ? "white" : "var(--ink-soft)"
            },
            children: l ? "恢复原始 n" : "展示 n×2"
          }
        )
      ] }),
      /* @__PURE__ */ e("div", { className: "grid grid-cols-3 gap-2 text-[11px]", children: [
        {
          label: "α（保持不变）",
          before: (t * 100).toFixed(1) + "%",
          after: (t * 100).toFixed(1) + "%",
          changed: !1
        },
        {
          label: "β（第二类错误）",
          before: (R * 100).toFixed(1) + "%",
          after: (I * 100).toFixed(1) + "%",
          changed: !0
        },
        {
          label: "功效 1−β",
          before: (J * 100).toFixed(1) + "%",
          after: (K * 100).toFixed(1) + "%",
          changed: !0
        }
      ].map(({ label: o, before: H, after: V, changed: L }) => /* @__PURE__ */ r(
        "div",
        {
          className: "rounded-lg bg-[var(--bg-muted)] px-2.5 py-2",
          children: [
            /* @__PURE__ */ e("div", { className: "font-medium text-[var(--ink-soft)] mb-1", children: o }),
            /* @__PURE__ */ r("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ e("span", { className: "font-mono font-semibold text-[var(--ink)]", children: H }),
              /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)]", children: "→" }),
              /* @__PURE__ */ e(
                "span",
                {
                  className: "font-mono font-bold",
                  style: {
                    color: L ? o.includes("β") ? C : F : "var(--ink-soft)"
                  },
                  children: V
                }
              )
            ] }),
            L && /* @__PURE__ */ e(
              "div",
              {
                className: "mt-0.5 text-[10px] font-medium",
                style: { color: o.includes("β") ? C : F },
                children: o.includes("β") ? "↓ 减小" : "↑ 提升"
              }
            )
          ]
        },
        o
      )) })
    ] }),
    /* @__PURE__ */ r("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ e("span", { className: "font-bold text-[var(--ink)]", children: "核心直觉：" }),
      'α 与 β 是一对"此消彼长"的矛盾—— 在',
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "固定 n 和 δ" }),
      " 时，缩小 α（拒绝域变窄）必然让 β 增大；扩大 α 则 β 减小。 唯有",
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "增大 n" }),
      "（样本量）或",
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "增大 δ" }),
      '（效应量）才能在 保持 α 的同时降低 β，提升检验功效。 这正是"检验功效分析"在实验设计中的核心价值。'
    ] })
  ] });
}
const Ae = pe(Ne);
export {
  Ae as default
};
