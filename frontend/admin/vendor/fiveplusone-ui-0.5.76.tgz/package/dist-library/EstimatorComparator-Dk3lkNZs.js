import { jsxs as e, jsx as t, Fragment as U } from "react/jsx-runtime";
import { learningAlpha as dt } from "./index.js";
import { memo as St, useState as X } from "react";
const b = "var(--fp-primary)", $t = "var(--fp-primary-soft)", N = "#0f766e", Wt = "color-mix(in srgb, #d1fae5 24%, var(--fp-surface))", m = "#dc2626", At = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))", W = "#d97706", at = "var(--line)", x = 0, q = 2;
function wt() {
  const n = Math.random(), c = Math.random();
  return Math.sqrt(-2 * Math.log(n + 1e-15)) * Math.cos(2 * Math.PI * c);
}
function Et(n) {
  let c = 0;
  const d = [];
  for (let i = 0; i < n; i++) {
    const l = x + q * wt();
    d.push(l), c += l;
  }
  const y = c / n;
  let p = 0;
  for (const i of d) p += (i - y) ** 2;
  return { xbar: y, s2: p / (n - 1), sn2: p / n };
}
function Y(n) {
  const c = [...n].sort((p, i) => p - i), d = c.length, y = (p) => {
    const i = p * (d - 1), l = Math.floor(i), g = Math.ceil(i);
    return c[l] + (c[g] - c[l]) * (i - l);
  };
  return [c[0], y(0.25), y(0.5), y(0.75), c[d - 1]];
}
const Z = 500, tt = 220, h = 42, Ft = 20, k = 18, Lt = 30, $ = Z - h - Ft, S = tt - k - Lt;
function B(n, c) {
  return {
    y: (d) => k + S - (d - n) / (c - n) * S,
    x: (d) => h + d * $
  };
}
function K({ data: n, vMin: c, vMax: d, cx: y, halfW: p }) {
  const i = B(c, d), l = i.x(y - p), g = i.x(y), f = i.x(y + p), [T, G, P, R, j] = n.q5, C = i.y(Math.max(T, c)), a = i.y(Math.min(Math.max(G, c), d)), D = i.y(Math.min(Math.max(P, c), d)), w = i.y(Math.min(Math.max(R, c), d)), M = i.y(Math.min(j, d)), u = i.y(Math.min(Math.max(n.mean, c), d)), v = i.y(Math.min(Math.max(n.trueVal, c), d));
  return /* @__PURE__ */ e("g", { children: [
    /* @__PURE__ */ t(
      "line",
      {
        x1: g,
        y1: C,
        x2: g,
        y2: a,
        stroke: n.color,
        strokeWidth: 1.5,
        strokeDasharray: "3 2"
      }
    ),
    /* @__PURE__ */ t(
      "line",
      {
        x1: g,
        y1: M,
        x2: g,
        y2: w,
        stroke: n.color,
        strokeWidth: 1.5,
        strokeDasharray: "3 2"
      }
    ),
    /* @__PURE__ */ t(
      "line",
      {
        x1: l + (f - l) * 0.3,
        y1: C,
        x2: f - (f - l) * 0.3,
        y2: C,
        stroke: n.color,
        strokeWidth: 1.2
      }
    ),
    /* @__PURE__ */ t(
      "line",
      {
        x1: l + (f - l) * 0.3,
        y1: M,
        x2: f - (f - l) * 0.3,
        y2: M,
        stroke: n.color,
        strokeWidth: 1.2
      }
    ),
    /* @__PURE__ */ t(
      "rect",
      {
        x: l,
        y: Math.min(a, w),
        width: f - l,
        height: Math.abs(a - w),
        fill: dt(n.color, "28"),
        stroke: n.color,
        strokeWidth: 1.8,
        rx: 3
      }
    ),
    /* @__PURE__ */ t(
      "line",
      {
        x1: l,
        y1: D,
        x2: f,
        y2: D,
        stroke: n.color,
        strokeWidth: 2.5
      }
    ),
    /* @__PURE__ */ t(
      "polygon",
      {
        points: `${g},${u - 5} ${g + 4},${u} ${g},${u + 5} ${g - 4},${u}`,
        fill: n.color,
        opacity: 0.85
      }
    ),
    /* @__PURE__ */ t(
      "line",
      {
        x1: l - 6,
        y1: v,
        x2: f + 6,
        y2: v,
        stroke: m,
        strokeWidth: 1.8,
        strokeDasharray: "5 3"
      }
    ),
    Math.abs(u - v) > 3 && /* @__PURE__ */ e("g", { children: [
      /* @__PURE__ */ t(
        "line",
        {
          x1: f + 4,
          y1: v,
          x2: f + 4,
          y2: u,
          stroke: W,
          strokeWidth: 1.5
        }
      ),
      /* @__PURE__ */ t(
        "line",
        {
          x1: f + 1,
          y1: v,
          x2: f + 7,
          y2: v,
          stroke: W,
          strokeWidth: 1.5
        }
      ),
      /* @__PURE__ */ t(
        "line",
        {
          x1: f + 1,
          y1: u,
          x2: f + 7,
          y2: u,
          stroke: W,
          strokeWidth: 1.5
        }
      )
    ] })
  ] });
}
function ct({
  vMin: n,
  vMax: c,
  ticks: d,
  label: y
}) {
  const p = B(n, c);
  return /* @__PURE__ */ e("g", { children: [
    /* @__PURE__ */ t(
      "line",
      {
        x1: h,
        y1: k,
        x2: h,
        y2: k + S,
        stroke: at,
        strokeWidth: 1
      }
    ),
    d.map((i) => {
      const l = p.y(i);
      return l < k - 2 || l > k + S + 2 ? null : /* @__PURE__ */ e("g", { children: [
        /* @__PURE__ */ t(
          "line",
          {
            x1: h - 4,
            y1: l,
            x2: h,
            y2: l,
            stroke: "var(--line)",
            strokeWidth: 1
          }
        ),
        /* @__PURE__ */ t(
          "line",
          {
            x1: h,
            y1: l,
            x2: h + $,
            y2: l,
            stroke: at,
            strokeWidth: 0.6
          }
        ),
        /* @__PURE__ */ t(
          "text",
          {
            x: h - 6,
            y: l + 3.5,
            fontSize: 10,
            textAnchor: "end",
            fill: "var(--ink-faint)",
            children: i % 1 === 0 ? i : i.toFixed(1)
          }
        )
      ] }, i);
    }),
    /* @__PURE__ */ t(
      "text",
      {
        x: 10,
        y: k + S / 2,
        fontSize: 10,
        textAnchor: "middle",
        fill: "var(--ink-faint)",
        transform: `rotate(-90, 10, ${k + S / 2})`,
        children: y
      }
    )
  ] });
}
function J({
  label: n,
  value: c,
  sub: d,
  color: y,
  bg: p,
  badge: i,
  badgeColor: l
}) {
  return /* @__PURE__ */ e(
    "div",
    {
      className: "rounded-lg p-3 flex flex-col gap-1",
      style: { background: p },
      children: [
        /* @__PURE__ */ e("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ t("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: n }),
          /* @__PURE__ */ t(
            "span",
            {
              className: "rounded-full px-2 py-0.5 text-[10px] font-bold",
              style: { background: l + "33", color: l },
              children: i
            }
          )
        ] }),
        /* @__PURE__ */ t("div", { className: "text-[18px] font-extrabold font-mono", style: { color: y }, children: c }),
        /* @__PURE__ */ t("div", { className: "text-[11px] text-[var(--ink-soft)]", children: d })
      ]
    }
  );
}
function Xt() {
  const [n, c] = X(10), [d] = X(2e3), [y, p] = X(!1), [i, l] = X([]), [g, f] = X([]), [T, G] = X([]), [P, R] = X(null);
  function j() {
    p(!0);
    const r = [], o = [], A = [];
    for (let L = 0; L < d; L++) {
      const { xbar: Q, s2: _, sn2: H } = Et(n);
      r.push(Q), o.push(_), A.push(H);
    }
    l(r), f(o), G(A), R(n), p(!1);
  }
  function C() {
    l([]), f([]), G([]), R(null);
  }
  const a = i.length > 0;
  function D(r) {
    return r.reduce((o, A) => o + A, 0) / r.length;
  }
  function w(r, o) {
    return Math.sqrt(r.reduce((A, L) => A + (L - o) ** 2, 0) / r.length);
  }
  const M = a ? D(i) : 0, u = a ? D(g) : 0, v = a ? D(T) : 0, et = a ? w(i, M) : 0, xt = a ? w(g, u) : 0, ht = a ? w(T, v) : 0, s = q * q, nt = a ? v - s : -(s / (P ?? n)), mt = a ? Math.abs(M - x) : 0, ft = a ? Math.abs(u - s) : 0, yt = a ? Math.abs(v - s) : 0, z = mt < 0.05 * (Math.abs(x) + 1), st = ft < 0.05 * s, ot = yt < 0.05 * s, pt = a ? Y(i) : [x - 2, x - 1, x, x + 1, x + 2], bt = a ? Y(g) : [0, s * 0.6, s, s * 1.4, s * 2.2], ut = a ? Y(T) : [0, s * 0.5, s * 0.9, s * 1.3, s * 2], rt = a ? et * 3.5 : q / Math.sqrt(n) * 3.5, V = x - Math.max(rt, 0.5), I = x + Math.max(rt, 0.5), gt = a ? Math.max(xt, ht) * 3.5 : s * 1.5, E = 0, F = s + Math.max(gt, s * 0.8);
  function it(r, o, A) {
    const L = o * 2 / A, Q = Math.pow(10, Math.floor(Math.log10(L))), _ = Math.ceil(L / Q) * Q, H = Math.ceil((r - o) / _) * _, lt = [];
    for (let O = H; O <= r + o + 1e-9; O += _)
      lt.push(parseFloat(O.toFixed(8)));
    return lt;
  }
  const vt = it(x, (I - V) / 2, 5), kt = it(
    (E + F) / 2,
    (F - E) / 2,
    5
  ).filter((r) => r >= 0), Nt = q / Math.sqrt(n), Mt = -s / n;
  return /* @__PURE__ */ e("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ e("div", { children: [
      /* @__PURE__ */ t("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "估计量性质比较器" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5 leading-relaxed", children: [
        "总体",
        " ",
        /* @__PURE__ */ e("span", { className: "font-mono font-semibold text-[var(--ink)]", children: [
          "N(μ=",
          x,
          ", σ²=",
          s,
          ")"
        ] }),
        "， 重复抽样 ",
        d,
        " 次，比较",
        " ",
        /* @__PURE__ */ t("span", { style: { color: b }, children: "X̄" }),
        "、",
        /* @__PURE__ */ t("span", { style: { color: N }, children: "S²（无偏）" }),
        "、",
        /* @__PURE__ */ t("span", { style: { color: m }, children: "Sn²（有偏）" }),
        " ",
        "的分布，验证无偏性与相合性。"
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3", children: [
      /* @__PURE__ */ e("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ e("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: [
            "样本量",
            " ",
            /* @__PURE__ */ e("span", { className: "font-mono", style: { color: b }, children: [
              "n = ",
              n
            ] })
          ] }),
          /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)]", children: [
            "理论 SE(X̄) = ",
            Nt.toFixed(4),
            "理论偏差(Sn²) = ",
            Mt.toFixed(4)
          ] })
        ] }),
        /* @__PURE__ */ t(
          "input",
          {
            type: "range",
            min: 5,
            max: 100,
            step: 1,
            value: n,
            onChange: (r) => {
              c(Number(r.target.value)), C();
            },
            className: "w-full h-1.5 cursor-pointer",
            style: { accentColor: b }
          }
        ),
        /* @__PURE__ */ e("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ t("span", { children: "n=5（偏差明显）" }),
          /* @__PURE__ */ t("span", { children: "n=100（偏差消失）" })
        ] })
      ] }),
      /* @__PURE__ */ e("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ t(
          "button",
          {
            type: "button",
            onClick: j,
            disabled: y,
            className: "rounded-lg px-4 py-1.5 text-[13px] font-semibold text-white transition-opacity hover:opacity-90 disabled:opacity-50",
            style: { background: b },
            children: y ? "模拟中…" : `▶ 模拟 ${d} 次`
          }
        ),
        /* @__PURE__ */ t(
          "button",
          {
            type: "button",
            onClick: C,
            disabled: !a,
            className: "rounded-lg px-4 py-1.5 text-[13px] font-medium text-[var(--ink-soft)] bg-[var(--bg-elevated)] border border-[var(--line)] hover:bg-[var(--bg-muted)] disabled:opacity-40",
            children: "重置"
          }
        )
      ] })
    ] }),
    a && /* @__PURE__ */ e("div", { className: "grid grid-cols-3 gap-2", children: [
      /* @__PURE__ */ t(
        J,
        {
          label: "X̄（样本均值）",
          value: M.toFixed(4),
          sub: `真值 μ=${x}　偏差 ${(M - x > 0 ? "+" : "") + (M - x).toFixed(4)}`,
          color: b,
          bg: $t,
          badge: z ? "无偏 [OK]" : "有偏 [X]",
          badgeColor: z ? N : m
        }
      ),
      /* @__PURE__ */ t(
        J,
        {
          label: "S²（无偏方差）",
          value: u.toFixed(4),
          sub: `真值 σ²=${s}　偏差 ${(u - s > 0 ? "+" : "") + (u - s).toFixed(4)}`,
          color: N,
          bg: Wt,
          badge: st ? "无偏 [OK]" : "有偏 [X]",
          badgeColor: st ? N : m
        }
      ),
      /* @__PURE__ */ t(
        J,
        {
          label: "Sn²（有偏方差）",
          value: v.toFixed(4),
          sub: `真值 σ²=${s}　偏差 ${(v - s > 0 ? "+" : "") + (v - s).toFixed(4)}`,
          color: m,
          bg: At,
          badge: ot ? "近似无偏" : `有偏 [X]（−${s}/n）`,
          badgeColor: ot ? N : W
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { children: [
      /* @__PURE__ */ e("div", { className: "flex items-center gap-2 mb-1", children: [
        /* @__PURE__ */ t("span", { className: "text-[13px] font-bold", style: { color: b }, children: "① X̄ 的抽样分布" }),
        /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)]", children: [
          "估计 μ=",
          x,
          a ? `实测均值 = ${M.toFixed(4)}，SE = ${et.toFixed(4)}` : "（点击「模拟」后显示）"
        ] })
      ] }),
      /* @__PURE__ */ e(
        "svg",
        {
          viewBox: `0 0 ${Z} ${tt}`,
          className: "w-full rounded-lg border border-[var(--line)]",
          children: [
            /* @__PURE__ */ t(
              "rect",
              {
                x: h,
                y: k,
                width: $,
                height: S,
                fill: "var(--bg-muted)"
              }
            ),
            /* @__PURE__ */ t(ct, { vMin: V, vMax: I, ticks: vt, label: "X̄" }),
            (() => {
              const o = B(V, I).y(x);
              return /* @__PURE__ */ e(U, { children: [
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: h,
                    y1: o,
                    x2: h + $,
                    y2: o,
                    stroke: m,
                    strokeWidth: 1.8,
                    strokeDasharray: "6 3"
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: h + $ - 2,
                    y: o - 4,
                    fontSize: 10,
                    textAnchor: "end",
                    fill: m,
                    children: [
                      "μ = ",
                      x
                    ]
                  }
                )
              ] });
            })(),
            a && /* @__PURE__ */ t(
              K,
              {
                data: {
                  label: "X̄",
                  color: b,
                  q5: pt,
                  mean: M,
                  trueVal: x,
                  biasLabel: z ? "无偏" : "有偏",
                  biasColor: z ? N : m
                },
                vMin: V,
                vMax: I,
                cx: 0.5,
                halfW: 0.18
              }
            ),
            !a && /* @__PURE__ */ e(
              "text",
              {
                x: h + $ / 2,
                y: k + S / 2 + 4,
                fontSize: 13,
                textAnchor: "middle",
                fill: "var(--ink-faint)",
                children: [
                  "点击「模拟 ",
                  d,
                  " 次」开始"
                ]
              }
            ),
            a && (() => {
              const r = h + 12, o = k + 12;
              return /* @__PURE__ */ e("g", { children: [
                /* @__PURE__ */ t(
                  "rect",
                  {
                    x: r,
                    y: o - 8,
                    width: 100,
                    height: 26,
                    rx: 4,
                    fill: "var(--bg-elevated)",
                    opacity: 0.85
                  }
                ),
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: r + 6,
                    y1: o,
                    x2: r + 22,
                    y2: o,
                    stroke: m,
                    strokeWidth: 1.8,
                    strokeDasharray: "5 3"
                  }
                ),
                /* @__PURE__ */ t("text", { x: r + 26, y: o + 3.5, fontSize: 10, fill: m, children: "真实 μ" }),
                /* @__PURE__ */ t(
                  "polygon",
                  {
                    points: `${r + 60},${o} ${r + 64},${o + 5} ${r + 60},${o + 10} ${r + 56},${o + 5}`,
                    fill: b,
                    opacity: 0.85
                  }
                ),
                /* @__PURE__ */ t("text", { x: r + 68, y: o + 3.5, fontSize: 10, fill: b, children: "均值" }),
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: r + 56,
                    y1: o + 14,
                    x2: r + 66,
                    y2: o + 14,
                    stroke: b,
                    strokeWidth: 2.5
                  }
                ),
                /* @__PURE__ */ t("text", { x: r + 68, y: o + 17.5, fontSize: 10, fill: b, children: "中位数" })
              ] });
            })()
          ]
        }
      ),
      a && /* @__PURE__ */ e("div", { className: "mt-1 px-1 text-[11px] text-[var(--ink-soft)]", children: [
        "X̄ 的期望 E[X̄] = μ，故 X̄ 是 μ 的",
        /* @__PURE__ */ t(
          "b",
          {
            className: "ml-0.5",
            style: { color: z ? N : m },
            children: z ? "无偏估计量" : "（本次偶然偏差过大）"
          }
        ),
        "。 方差 D[X̄] = σ²/n = ",
        (s / n).toFixed(4),
        "，n 越大分布越集中（相合性）。"
      ] })
    ] }),
    /* @__PURE__ */ e("div", { children: [
      /* @__PURE__ */ e("div", { className: "flex items-center gap-2 mb-1", children: [
        /* @__PURE__ */ t("span", { className: "text-[13px] font-bold", style: { color: N }, children: "② S²" }),
        /* @__PURE__ */ t("span", { className: "text-[13px] font-bold", style: { color: m }, children: "vs Sn²" }),
        /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)]", children: [
          "估计 σ²=",
          s,
          "　橙色括号 = 偏差大小"
        ] })
      ] }),
      /* @__PURE__ */ e(
        "svg",
        {
          viewBox: `0 0 ${Z} ${tt}`,
          className: "w-full rounded-lg border border-[var(--line)]",
          children: [
            /* @__PURE__ */ t(
              "rect",
              {
                x: h,
                y: k,
                width: $,
                height: S,
                fill: "var(--bg-muted)"
              }
            ),
            /* @__PURE__ */ t(ct, { vMin: E, vMax: F, ticks: kt, label: "方差" }),
            (() => {
              const o = B(E, F).y(s);
              return /* @__PURE__ */ e(U, { children: [
                /* @__PURE__ */ t(
                  "line",
                  {
                    x1: h,
                    y1: o,
                    x2: h + $,
                    y2: o,
                    stroke: m,
                    strokeWidth: 1.8,
                    strokeDasharray: "6 3"
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: h + $ - 2,
                    y: o - 4,
                    fontSize: 10,
                    textAnchor: "end",
                    fill: m,
                    children: [
                      "σ² = ",
                      s
                    ]
                  }
                )
              ] });
            })(),
            a && /* @__PURE__ */ e(U, { children: [
              /* @__PURE__ */ t(
                K,
                {
                  data: {
                    label: "S²",
                    color: N,
                    q5: bt,
                    mean: u,
                    trueVal: s,
                    biasLabel: "无偏",
                    biasColor: N
                  },
                  vMin: E,
                  vMax: F,
                  cx: 0.3,
                  halfW: 0.18
                }
              ),
              /* @__PURE__ */ t(
                K,
                {
                  data: {
                    label: "Sn²",
                    color: m,
                    q5: ut,
                    mean: v,
                    trueVal: s,
                    biasLabel: "有偏",
                    biasColor: m
                  },
                  vMin: E,
                  vMax: F,
                  cx: 0.72,
                  halfW: 0.18
                }
              ),
              (() => {
                const r = B(E, F), o = k + S + 16;
                return /* @__PURE__ */ e("g", { children: [
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: r.x(0.3),
                      y: o,
                      fontSize: 12,
                      textAnchor: "middle",
                      fontWeight: "700",
                      fill: N,
                      children: "S²"
                    }
                  ),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: r.x(0.3) + 2,
                      y: o + 11,
                      fontSize: 9,
                      textAnchor: "middle",
                      fill: "var(--ink-faint)",
                      children: "无偏方差"
                    }
                  ),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: r.x(0.72),
                      y: o,
                      fontSize: 12,
                      textAnchor: "middle",
                      fontWeight: "700",
                      fill: m,
                      children: "Sn²"
                    }
                  ),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: r.x(0.72),
                      y: o + 11,
                      fontSize: 9,
                      textAnchor: "middle",
                      fill: "var(--ink-faint)",
                      children: "有偏方差"
                    }
                  )
                ] });
              })()
            ] }),
            !a && /* @__PURE__ */ e(
              "text",
              {
                x: h + $ / 2,
                y: k + S / 2 + 4,
                fontSize: 13,
                textAnchor: "middle",
                fill: "var(--ink-faint)",
                children: [
                  "点击「模拟 ",
                  d,
                  " 次」开始"
                ]
              }
            )
          ]
        }
      )
    ] }),
    a && /* @__PURE__ */ e("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 text-[12px] leading-relaxed text-[var(--ink-soft)] space-y-2", children: [
      /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)]", children: [
        "核心结论（当前 n = ",
        P,
        "）"
      ] }),
      /* @__PURE__ */ e("div", { className: "grid grid-cols-1 gap-1 sm:grid-cols-2", children: [
        /* @__PURE__ */ e("div", { children: [
          /* @__PURE__ */ t("span", { className: "font-semibold", style: { color: b }, children: "X̄" }),
          "： E[X̄] = μ = ",
          x,
          "（无偏），D[X̄] = σ²/n =",
          " ",
          (s / n).toFixed(4),
          " → 0，",
          /* @__PURE__ */ t("b", { children: "相合" })
        ] }),
        /* @__PURE__ */ e("div", { children: [
          /* @__PURE__ */ t("span", { className: "font-semibold", style: { color: N }, children: "S²" }),
          "： E[S²] = σ² = ",
          s,
          "（无偏），",
          /* @__PURE__ */ t("b", { children: "相合" }),
          "； 分母 (n−1) 修正了自由度损失"
        ] }),
        /* @__PURE__ */ e("div", { children: [
          /* @__PURE__ */ t("span", { className: "font-semibold", style: { color: m }, children: "Sn²" }),
          "： E[Sn²] = (n−1)/n · σ² = ",
          ((n - 1) / n * s).toFixed(4),
          "，",
          /* @__PURE__ */ e("b", { style: { color: W }, children: [
            "系统低估 ",
            Math.abs(nt).toFixed(4)
          ] }),
          Math.abs(nt) < 0.05 * s ? "（n 已较大，偏差趋近消失 → 相合）" : `（偏差 = −σ²/n = −${(s / n).toFixed(4)}）`
        ] }),
        /* @__PURE__ */ e("div", { style: { borderLeft: `3px solid ${W}`, paddingLeft: 8 }, children: [
          /* @__PURE__ */ t("b", { children: "相合性：" }),
          "n↑ → 偏差 |σ²/n| → 0， 故 Sn² 仍是 σ² 的相合估计量，但不是无偏估计量。 拖动 n 滑块可直观观察 Sn² 箱体向 σ²=",
          s,
          " 靠拢的过程。"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "flex flex-wrap gap-x-5 gap-y-1.5 text-[11px] text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ e("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t("svg", { width: "28", height: "12", children: /* @__PURE__ */ t(
          "line",
          {
            x1: 0,
            y1: 6,
            x2: 28,
            y2: 6,
            stroke: m,
            strokeWidth: 1.8,
            strokeDasharray: "5 3"
          }
        ) }),
        /* @__PURE__ */ t("span", { children: "真实参数值" })
      ] }),
      /* @__PURE__ */ e("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t("svg", { width: "12", height: "12", children: /* @__PURE__ */ t("polygon", { points: "6,0 11,6 6,12 1,6", fill: b, opacity: 0.85 }) }),
        /* @__PURE__ */ t("span", { children: "样本均值" })
      ] }),
      /* @__PURE__ */ e("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t("svg", { width: "24", height: "12", children: /* @__PURE__ */ t(
          "line",
          {
            x1: 0,
            y1: 6,
            x2: 24,
            y2: 6,
            stroke: b,
            strokeWidth: 2.5
          }
        ) }),
        /* @__PURE__ */ t("span", { children: "中位数" })
      ] }),
      /* @__PURE__ */ e("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ e("svg", { width: "16", height: "12", children: [
          /* @__PURE__ */ t(
            "line",
            {
              x1: 8,
              y1: 0,
              x2: 8,
              y2: 12,
              stroke: W,
              strokeWidth: 1.5
            }
          ),
          /* @__PURE__ */ t(
            "line",
            {
              x1: 4,
              y1: 0,
              x2: 12,
              y2: 0,
              stroke: W,
              strokeWidth: 1.5
            }
          ),
          /* @__PURE__ */ t(
            "line",
            {
              x1: 4,
              y1: 12,
              x2: 12,
              y2: 12,
              stroke: W,
              strokeWidth: 1.5
            }
          )
        ] }),
        /* @__PURE__ */ t("span", { style: { color: W }, children: "偏差大小" })
      ] }),
      /* @__PURE__ */ e("div", { className: "flex items-center gap-1.5", children: [
        /* @__PURE__ */ t("svg", { width: "24", height: "12", children: /* @__PURE__ */ t(
          "rect",
          {
            x: 0,
            y: 2,
            width: 24,
            height: 8,
            fill: dt(b, "28"),
            stroke: b,
            strokeWidth: 1.5,
            rx: 2
          }
        ) }),
        /* @__PURE__ */ t("span", { children: "四分位箱（IQR）" })
      ] })
    ] })
  ] });
}
const Tt = St(Xt);
export {
  Tt as default
};
