import { jsxs as d, jsx as r, Fragment as k } from "react/jsx-runtime";
import { useState as m, useEffect as v } from "react";
function S(e, o, t) {
  if (e.length !== o.length || !e.length || new Set(e).size !== e.length) throw new Error("插值节点须互异并与函数值对应");
  return e.reduce((i, l, s) => i + o[s] * e.reduce((n, a, c) => s === c ? n : n * (t - a) / (l - a), 1), 0);
}
function C(e, o) {
  if (e.length !== o.length || e.length < 2) throw new Error("至少需要两组数据");
  const t = e.reduce((c, h) => c + h, 0) / e.length, i = o.reduce((c, h) => c + h, 0) / o.length, l = e.reduce((c, h) => c + (h - t) ** 2, 0);
  if (!l) throw new Error("横坐标不能全部相同");
  const s = e.reduce((c, h, p) => c + (h - t) * (o[p] - i), 0) / l, n = i - s * t, a = e.map((c, h) => o[h] - n - s * c);
  return { slope: s, intercept: n, residuals: a, sse: a.reduce((c, h) => c + h * h, 0) };
}
function w(e, o, t, i, l) {
  if (!Number.isInteger(i) || i < 1 || l === "simpson" && i % 2) throw new Error("分段数须为正整数，Simpson 需要偶数段");
  const s = (t - o) / i;
  let n = e(o) + e(t);
  for (let a = 1; a < i; a++) n += (l === "trapezoid" ? 2 : a % 2 ? 4 : 2) * e(o + a * s);
  return n * s / (l === "trapezoid" ? 2 : 3);
}
function E(e, o, t, i, l) {
  const s = [{ t: 0, y: o }];
  let n = o;
  for (let a = 0; a < i; a++) {
    const c = a * t, h = e(c, n);
    if (l === "euler") n += t * h;
    else if (l === "heun") n += t * (h + e(c + t, n + t * h)) / 2;
    else {
      const p = e(c + t / 2, n + t * h / 2), u = e(c + t / 2, n + t * p / 2), F = e(c + t, n + t * u);
      n += t * (h + 2 * p + 2 * u + F) / 6;
    }
    s.push({ t: (a + 1) * t, y: n });
  }
  return s;
}
function M(e, o) {
  const t = [{ x: 0, y: 0, residual: 2 }];
  let i = 0, l = 0;
  for (let s = 0; s < o; s++) {
    const n = (1 - l) / 4, a = (2 - (e === "seidel" ? n : i)) / 3;
    i = n, l = a, t.push({ x: i, y: l, residual: Math.max(Math.abs(1 - 4 * i - l), Math.abs(2 - i - 3 * l)) });
  }
  return t;
}
function L(e, o) {
  let t = 1, i = 1;
  const l = () => {
    const n = (3 * t * t + 3 * e * i * i) / (t * t + i * i);
    return { x: t, y: i, eigenvalue: n, residual: Math.hypot((3 - n) * t, (3 * e - n) * i) / Math.hypot(t, i) };
  }, s = [l()];
  for (let n = 0; n < o; n++) {
    t *= 3, i *= 3 * e;
    const a = Math.max(Math.abs(t), Math.abs(i));
    t /= a, i /= a, s.push(l());
  }
  return s;
}
const b = ["#bb6b32", "#287c80", "#8661a2"];
function x({ title: e, children: o }) {
  return /* @__PURE__ */ d(
    "section",
    {
      "aria-label": e,
      style: {
        margin: "24px 0",
        padding: 20,
        border: "1px solid var(--line)",
        borderRadius: 16
      },
      children: [
        /* @__PURE__ */ r("h3", { children: e }),
        o
      ]
    }
  );
}
function f({
  label: e,
  value: o,
  min: t,
  max: i,
  step: l = 1,
  change: s
}) {
  return /* @__PURE__ */ d("label", { style: { display: "block", margin: "16px 0" }, children: [
    e,
    "：",
    o,
    /* @__PURE__ */ r(
      "input",
      {
        "aria-label": e,
        type: "range",
        min: t,
        max: i,
        step: l,
        value: o,
        onChange: (n) => s(Number(n.target.value)),
        style: { width: "100%" }
      }
    )
  ] });
}
function y({
  series: e,
  xmin: o = 0,
  xmax: t = 1,
  ymin: i = 0,
  ymax: l = 1,
  dots: s = []
}) {
  const n = (c) => 36 + (c - o) / (t - o) * 450, a = (c) => 210 - (c - i) / (l - i) * 180;
  return /* @__PURE__ */ d(k, { children: [
    /* @__PURE__ */ d(
      "svg",
      {
        viewBox: "0 0 520 245",
        role: "img",
        "aria-label": e.map((c) => c.name).join("、") + "对照图",
        style: { width: "100%", height: "auto" },
        children: [
          /* @__PURE__ */ r(
            "path",
            {
              d: "M36 25V210H490",
              fill: "none",
              stroke: "currentColor",
              opacity: "0.4"
            }
          ),
          [o, t].map((c) => /* @__PURE__ */ r(
            "text",
            {
              x: n(c),
              y: "232",
              textAnchor: "middle",
              fill: "currentColor",
              fontSize: "12",
              children: c
            },
            c
          )),
          [i, l].map((c) => /* @__PURE__ */ r(
            "text",
            {
              x: "29",
              y: a(c) + 4,
              textAnchor: "end",
              fill: "currentColor",
              fontSize: "12",
              children: c
            },
            c
          )),
          e.map((c, h) => /* @__PURE__ */ r(
            "polyline",
            {
              points: c.points.map(([p, u]) => `${n(p)},${a(u)}`).join(" "),
              fill: "none",
              stroke: b[h % b.length],
              strokeWidth: "2.5"
            },
            c.name
          )),
          s.map(([c, h], p) => /* @__PURE__ */ r("circle", { cx: n(c), cy: a(h), r: "4", fill: "currentColor" }, p))
        ]
      }
    ),
    /* @__PURE__ */ r("p", { style: { display: "flex", gap: 16, flexWrap: "wrap", fontSize: 13 }, children: e.map((c, h) => /* @__PURE__ */ d("span", { style: { color: b[h % b.length] }, children: [
      "● ",
      c.name
    ] }, c.name)) })
  ] });
}
function g({
  count: e,
  change: o,
  max: t
}) {
  const [i, l] = m(!1), s = i && e < t;
  v(() => {
    if (!s) return;
    const a = setTimeout(() => o(e + 1), 600);
    return () => clearTimeout(a);
  }, [s, e, o]);
  const n = {
    border: "1px solid var(--line)",
    borderRadius: 8,
    padding: "6px 12px",
    cursor: "pointer"
  };
  return /* @__PURE__ */ d(
    "div",
    {
      style: {
        display: "flex",
        gap: 10,
        alignItems: "center",
        flexWrap: "wrap"
      },
      children: [
        /* @__PURE__ */ r(
          "button",
          {
            type: "button",
            style: n,
            onClick: () => {
              e === t && o(0), l(!s);
            },
            children: s ? "暂停" : "播放过程"
          }
        ),
        /* @__PURE__ */ r(
          "button",
          {
            type: "button",
            style: n,
            disabled: e === t,
            onClick: () => {
              l(!1), o(e + 1);
            },
            children: "下一步"
          }
        ),
        /* @__PURE__ */ r(
          "button",
          {
            type: "button",
            style: n,
            onClick: () => {
              l(!1), o(0);
            },
            children: "从头开始"
          }
        ),
        /* @__PURE__ */ d("span", { children: [
          "第 ",
          e,
          " 步"
        ] })
      ]
    }
  );
}
function A() {
  const [e, o] = m(0), t = M("jacobi", e).at(-1), i = M("seidel", e).at(-1);
  return /* @__PURE__ */ d(x, { title: "两种线性迭代的计算过程", children: [
    /* @__PURE__ */ r("p", { children: "求解 4x + y = 1，x + 3y = 2，从 (0, 0) 开始，观察每轮使用新旧值的差别。" }),
    /* @__PURE__ */ r(g, { count: e, change: o, max: 12 }),
    /* @__PURE__ */ r("div", { style: { overflowX: "auto" }, children: /* @__PURE__ */ d("table", { children: [
      /* @__PURE__ */ r("thead", { children: /* @__PURE__ */ d("tr", { children: [
        /* @__PURE__ */ r("th", { children: "方法" }),
        /* @__PURE__ */ r("th", { children: "x" }),
        /* @__PURE__ */ r("th", { children: "y" }),
        /* @__PURE__ */ r("th", { children: "最大残差" })
      ] }) }),
      /* @__PURE__ */ r("tbody", { children: [
        ["Jacobi", t],
        ["Gauss–Seidel", i]
      ].map(([l, s]) => {
        const n = s;
        return /* @__PURE__ */ d("tr", { children: [
          /* @__PURE__ */ r("td", { children: String(l) }),
          /* @__PURE__ */ r("td", { children: n.x.toFixed(8) }),
          /* @__PURE__ */ r("td", { children: n.y.toFixed(8) }),
          /* @__PURE__ */ r("td", { children: n.residual.toExponential(2) })
        ] }, String(l));
      }) })
    ] }) }),
    /* @__PURE__ */ r("p", { children: "精确解为 (1/11, 7/11)。本例严格对角占优，两种方法都收敛。" })
  ] });
}
function j() {
  const [e, o] = m(6), t = (p) => 1 / (1 + 25 * p * p), i = Array.from({ length: e + 1 }, (p, u) => -1 + 2 * u / e), l = i.map(t), s = Array.from({ length: 201 }, (p, u) => -1 + u / 100), n = s.map(
    (p) => [p, S(i, l, p)]
  ), a = Math.max(...n.map(([p, u]) => Math.abs(u - t(p)))), c = Math.min(-0.1, ...n.map((p) => p[1])), h = Math.max(1.1, ...n.map((p) => p[1]));
  return /* @__PURE__ */ d(x, { title: "等距高次插值会怎样变化", children: [
    /* @__PURE__ */ r("p", { children: "对 f(x) = 1/(1 + 25x²) 使用等距节点，观察端点附近的曲线。" }),
    /* @__PURE__ */ r(
      f,
      {
        label: "多项式最高次数",
        value: e,
        min: 2,
        max: 12,
        step: 2,
        change: o
      }
    ),
    /* @__PURE__ */ r(
      y,
      {
        xmin: -1,
        xmax: 1,
        ymin: Math.floor(c * 10) / 10,
        ymax: Math.ceil(h * 10) / 10,
        dots: i.map((p, u) => [p, l[u]]),
        series: [
          { name: "原函数", points: s.map((p) => [p, t(p)]) },
          { name: "插值多项式", points: n }
        ]
      }
    ),
    /* @__PURE__ */ d("p", { children: [
      "201 个观察点上的最大误差约 ",
      a.toFixed(5),
      "。这是采样比较，不能代替整个区间的严格误差界。"
    ] })
  ] });
}
function R() {
  const [e, o] = m(3), t = [0, 1, 2, 3], i = [1, 2, 2, e], l = C(t, i);
  return /* @__PURE__ */ d(x, { title: "一个观测点怎样影响拟合", children: [
    /* @__PURE__ */ r(
      f,
      {
        label: "最后一个点的纵坐标",
        value: e,
        min: 0,
        max: 6,
        step: 0.1,
        change: o
      }
    ),
    /* @__PURE__ */ r(
      y,
      {
        xmax: 3,
        ymin: -1,
        ymax: 6,
        dots: t.map((s, n) => [s, i[n]]),
        series: [
          {
            name: "最小二乘直线",
            points: [
              [0, l.intercept],
              [3, l.intercept + 3 * l.slope]
            ]
          }
        ]
      }
    ),
    /* @__PURE__ */ d("p", { children: [
      "拟合直线：y = ",
      l.intercept.toFixed(4),
      " ",
      l.slope < 0 ? "−" : "+",
      " ",
      Math.abs(l.slope).toFixed(4),
      "x"
    ] }),
    /* @__PURE__ */ d("p", { children: [
      "残差平方和：",
      l.sse.toFixed(5),
      "。移动一个点会改变整条直线，其他点的残差也随之改变。"
    ] })
  ] });
}
function _() {
  const [e, o] = m(1), t = 2 ** e, i = (n) => n ** 4, l = w(i, 0, 1, t, "trapezoid"), s = w(i, 0, 1, t, "simpson");
  return /* @__PURE__ */ d(x, { title: "加密网格与积分精度", children: [
    /* @__PURE__ */ r("p", { children: "计算从 0 到 1 的 x⁴ 积分，精确值为 0.2。" }),
    /* @__PURE__ */ r(f, { label: "加密层数", value: e, min: 1, max: 6, change: o }),
    /* @__PURE__ */ r(
      y,
      {
        series: [
          {
            name: "原函数",
            points: Array.from({ length: 101 }, (n, a) => [
              a / 100,
              i(a / 100)
            ])
          },
          {
            name: "梯形上边界",
            points: Array.from({ length: t + 1 }, (n, a) => [a / t, i(a / t)])
          }
        ]
      }
    ),
    /* @__PURE__ */ d("p", { children: [
      "分段数 ",
      t,
      "，步长 ",
      (1 / t).toFixed(6)
    ] }),
    /* @__PURE__ */ d("table", { children: [
      /* @__PURE__ */ r("thead", { children: /* @__PURE__ */ d("tr", { children: [
        /* @__PURE__ */ r("th", { children: "公式" }),
        /* @__PURE__ */ r("th", { children: "积分近似值" }),
        /* @__PURE__ */ r("th", { children: "绝对误差" })
      ] }) }),
      /* @__PURE__ */ r("tbody", { children: [
        ["复化梯形", l],
        ["复化 Simpson", s]
      ].map(([n, a]) => /* @__PURE__ */ d("tr", { children: [
        /* @__PURE__ */ r("td", { children: n }),
        /* @__PURE__ */ r("td", { children: Number(a).toFixed(10) }),
        /* @__PURE__ */ r("td", { children: Math.abs(Number(a) - 0.2).toExponential(3) })
      ] }, n)) })
    ] }),
    /* @__PURE__ */ r("p", { children: "步长减半后，可比较梯形误差约缩小 4 倍、Simpson 误差约缩小 16 倍的规律。" })
  ] });
}
function I() {
  const [e, o] = m(10), [t, i] = m(0), s = [
    ["euler", "Euler"],
    ["heun", "改进 Euler"],
    ["rk4", "RK4"]
  ].map(([n, a]) => ({
    name: a,
    rows: E((c, h) => h, 1, 1 / e, e, n)
  }));
  return /* @__PURE__ */ d(x, { title: "沿时间比较三种近似解", children: [
    /* @__PURE__ */ r("p", { children: "初值问题 y′ = y，y(0) = 1，精确解为 eᵗ。" }),
    /* @__PURE__ */ r(
      f,
      {
        label: "时间分段数",
        value: e,
        min: 4,
        max: 20,
        step: 2,
        change: (n) => {
          o(n), i(0);
        }
      }
    ),
    /* @__PURE__ */ r(g, { count: t, change: i, max: e }),
    /* @__PURE__ */ r(
      y,
      {
        ymin: 1,
        ymax: 3,
        series: s.map((n) => ({
          name: n.name,
          points: n.rows.slice(0, t + 1).map((a) => [a.t, a.y])
        }))
      }
    ),
    /* @__PURE__ */ d("p", { children: [
      "当前时间 ",
      (t / e).toFixed(3),
      "，精确值",
      " ",
      Math.exp(t / e).toFixed(9)
    ] }),
    /* @__PURE__ */ d("table", { children: [
      /* @__PURE__ */ r("thead", { children: /* @__PURE__ */ d("tr", { children: [
        /* @__PURE__ */ r("th", { children: "方法" }),
        /* @__PURE__ */ r("th", { children: "近似值" }),
        /* @__PURE__ */ r("th", { children: "绝对误差" })
      ] }) }),
      /* @__PURE__ */ r("tbody", { children: s.map((n) => /* @__PURE__ */ d("tr", { children: [
        /* @__PURE__ */ r("td", { children: n.name }),
        /* @__PURE__ */ r("td", { children: n.rows[t].y.toFixed(9) }),
        /* @__PURE__ */ r("td", { children: Math.abs(n.rows[t].y - Math.exp(t / e)).toExponential(
          3
        ) })
      ] }, n.name)) })
    ] })
  ] });
}
function P() {
  const [e, o] = m(0.5), [t, i] = m(0), l = L(e, 20), s = l[t];
  return /* @__PURE__ */ d(x, { title: "特征值接近时，幂法收敛多快", children: [
    /* @__PURE__ */ d("p", { children: [
      "矩阵为 diag(3, ",
      Number((3 * e).toFixed(2)),
      ")，初始向量为 (1, 1)。每步用最大绝对分量规范化。"
    ] }),
    /* @__PURE__ */ r(
      f,
      {
        label: "两个特征值的比值",
        value: e,
        min: 0.1,
        max: 0.95,
        step: 0.05,
        change: (n) => {
          o(n), i(0);
        }
      }
    ),
    /* @__PURE__ */ r(g, { count: t, change: i, max: 20 }),
    /* @__PURE__ */ r(
      y,
      {
        xmax: 20,
        series: [
          {
            name: "第二个分量",
            points: l.slice(0, t + 1).map((n, a) => [a, n.y])
          }
        ]
      }
    ),
    /* @__PURE__ */ d("p", { children: [
      "当前向量：(1, ",
      s.y.toFixed(7),
      ")；特征值近似：",
      s.eigenvalue.toFixed(7),
      "；规范化残差：",
      s.residual.toExponential(3),
      "。"
    ] }),
    /* @__PURE__ */ r("p", { children: "比值越接近 1，非主方向衰减越慢。" })
  ] });
}
export {
  R as FittingLab,
  j as InterpolationLab,
  A as LinearLab,
  I as OdeLab,
  P as PowerLab,
  _ as QuadratureLab
};
