import { jsxs as r, jsx as n, Fragment as b } from "react/jsx-runtime";
import { useState as h } from "react";
function x(e, s, i) {
  if (e * i - s * s <= 0) return null;
  const c = Math.sqrt(e), l = s / c, o = Math.sqrt(i - l * l);
  return { l11: c, l21: l, l22: o };
}
const a = (e) => Math.abs(e) < 1e-12 ? "0" : Number(e.toPrecision(6)).toString();
function m({
  label: e,
  value: s,
  min: i,
  max: c,
  step: l = 1,
  change: o
}) {
  return /* @__PURE__ */ r("label", { className: "block my-3", children: [
    e,
    "：",
    a(s),
    /* @__PURE__ */ n(
      "input",
      {
        "aria-label": e,
        className: "w-full",
        type: "range",
        min: i,
        max: c,
        step: l,
        value: s,
        onChange: (p) => o(Number(p.target.value))
      }
    )
  ] });
}
function f() {
  const [e, s] = h(5), [i, c] = h(2), l = x(4, i, e);
  return /* @__PURE__ */ r("section", { "aria-label": "平方根分解实验", className: "border rounded-xl p-4 my-6", children: [
    /* @__PURE__ */ n("h3", { children: "改变矩阵，逐步计算平方根分解" }),
    /* @__PURE__ */ n("p", { children: "A 的两行为 (4，b)、(b，c)。保持对称，观察正定条件如何限制参数。" }),
    /* @__PURE__ */ n(
      m,
      {
        label: "非对角元素 b",
        value: i,
        min: -4,
        max: 4,
        step: 0.5,
        change: c
      }
    ),
    /* @__PURE__ */ n(
      m,
      {
        label: "右下角元素 c",
        value: e,
        min: 0,
        max: 8,
        step: 0.5,
        change: s
      }
    ),
    /* @__PURE__ */ n("div", { "aria-live": "polite", children: l ? /* @__PURE__ */ r(b, { children: [
      /* @__PURE__ */ r("p", { children: [
        "① l₁₁=√4=2；② l₂₁=b/2=",
        a(l.l21),
        "；③ l₂₂=√(c−l₂₁²)=",
        a(l.l22),
        "。"
      ] }),
      /* @__PURE__ */ r("p", { children: [
        "乘回：第一行 (4，",
        a(l.l11 * l.l21),
        ")；第二行 (",
        a(l.l11 * l.l21),
        "，",
        a(l.l21 ** 2 + l.l22 ** 2),
        ")。"
      ] })
    ] }) : /* @__PURE__ */ r("p", { children: [
      "4c−b²=",
      a(4 * e - i * i),
      "，不满足正定条件，不能得到正对角的实数 Cholesky 分解。"
    ] }) })
  ] });
}
function g() {
  const [e, s] = h(2), [i, c] = h(0), l = e ? 3 / e : NaN, o = 4 - l;
  return /* @__PURE__ */ r("section", { "aria-label": "LU分解实验", className: "border rounded-xl p-4 my-6", children: [
    /* @__PURE__ */ n("h3", { children: "把消元乘子保存到 L" }),
    /* @__PURE__ */ n("p", { children: "A 的两行为 (a，1)、(3，4)。右端项为 (5，6)。" }),
    /* @__PURE__ */ n(
      m,
      {
        label: "首主元 a",
        value: e,
        min: 0,
        max: 4,
        step: 0.5,
        change: (p) => {
          s(p), c(0);
        }
      }
    ),
    /* @__PURE__ */ n(
      "button",
      {
        type: "button",
        onClick: () => c(Math.min(3, i + 1)),
        disabled: i === 3,
        children: "下一步"
      }
    ),
    /* @__PURE__ */ n("button", { type: "button", className: "ml-4", onClick: () => c(0), children: "从头计算" }),
    /* @__PURE__ */ n("div", { "aria-live": "polite", children: e === 0 ? /* @__PURE__ */ n("p", { children: "首主元为零，必须先换行，当前无主元 LU 流程不能继续。" }) : /* @__PURE__ */ r(b, { children: [
      /* @__PURE__ */ r("p", { children: [
        "第 ",
        i,
        " 步"
      ] }),
      i >= 1 && /* @__PURE__ */ r("p", { children: [
        "m₂₁=3/a=",
        a(l),
        "；R₂←R₂−m₂₁R₁。"
      ] }),
      i >= 2 && /* @__PURE__ */ r("p", { children: [
        "L 的两行为 (1，0)、(",
        a(l),
        "，1)；U 为 (",
        a(e),
        "，1)、(0，",
        a(o),
        ")。"
      ] }),
      i >= 3 && (Math.abs(o) < 1e-12 ? /* @__PURE__ */ n("p", { children: "第二主元为零：矩阵奇异。" }) : /* @__PURE__ */ r("p", { children: [
        "先解 Ly=b：y=(5，",
        a(6 - l * 5),
        ")；再解 Ux=y：x₂=",
        a((6 - l * 5) / o),
        "，x₁=",
        a((5 - (6 - l * 5) / o) / e),
        "。"
      ] }))
    ] }) })
  ] });
}
function N() {
  const [e, s] = h(2), [i, c] = h(0), l = [e], o = [1];
  for (let t = 1; t < 3; t++)
    l.push(e - 1 / l[t - 1]), o.push((t === 2 ? 1 : 0) + o[t - 1] / l[t - 1]);
  const p = l.every((t) => Number.isFinite(t) && Math.abs(t) > 1e-10), d = [0, 0, o[2] / l[2]];
  for (let t = 1; t >= 0; t--) d[t] = (o[t] + d[t + 1]) / l[t];
  return /* @__PURE__ */ r("section", { "aria-label": "追赶法实验", className: "border rounded-xl p-4 my-6", children: [
    /* @__PURE__ */ n("h3", { children: "三对角系统：前向递推与回代" }),
    /* @__PURE__ */ n("p", { children: "主对角均为 d，相邻副对角均为 −1，b=(1，0，1)。" }),
    /* @__PURE__ */ n(
      m,
      {
        label: "主对角 d",
        value: e,
        min: 1,
        max: 4,
        step: 0.25,
        change: (t) => {
          s(t), c(0);
        }
      }
    ),
    /* @__PURE__ */ n(
      "button",
      {
        type: "button",
        onClick: () => c(Math.min(4, i + 1)),
        disabled: i === 4,
        children: "下一步"
      }
    ),
    /* @__PURE__ */ n("button", { type: "button", className: "ml-4", onClick: () => c(0), children: "从头计算" }),
    /* @__PURE__ */ n("div", { "aria-live": "polite", children: p ? /* @__PURE__ */ r(b, { children: [
      l.slice(0, i).map((t, u) => /* @__PURE__ */ r("p", { children: [
        "第 ",
        u + 1,
        " 行：新主元 ",
        a(t),
        "，新右端 ",
        a(o[u]),
        "。"
      ] }, u)),
      i === 4 && /* @__PURE__ */ r("p", { children: [
        "从最后一行回代：x=(",
        d.map(a).join("，"),
        ")。代回右端为 (",
        a(e * d[0] - d[1]),
        "，",
        a(-d[0] + e * d[1] - d[2]),
        "，",
        a(-d[1] + e * d[2]),
        ")。"
      ] })
    ] }) : /* @__PURE__ */ n("p", { children: "递推中出现零主元，当前追赶流程失效，需改用选主元方法。" }) })
  ] });
}
function k() {
  const [e, s] = h(0.1), [i, c] = h(0.01);
  return /* @__PURE__ */ r(
    "section",
    {
      "aria-label": "条件数与扰动实验",
      className: "border rounded-xl p-4 my-6",
      children: [
        /* @__PURE__ */ n("h3", { children: "小扰动为何可能变成大误差" }),
        /* @__PURE__ */ n("p", { children: "A=diag(1，ε)，原 b=(1，0)，原解 x=(1，0)。把第二个右端分量改成 δ。" }),
        /* @__PURE__ */ n(
          m,
          {
            label: "较小对角元素 ε",
            value: e,
            min: 0.01,
            max: 1,
            step: 0.01,
            change: s
          }
        ),
        /* @__PURE__ */ n(
          m,
          {
            label: "右端扰动 δ",
            value: i,
            min: 0,
            max: 0.1,
            step: 1e-3,
            change: c
          }
        ),
        /* @__PURE__ */ r("p", { "aria-live": "polite", children: [
          "∞ 范数条件数 κ=1/ε=",
          a(1 / e),
          "；新解为 (1，",
          a(i / e),
          ")。右端相对扰动 ",
          a(i),
          "，解的相对变化 ",
          a(i / e),
          "，放大倍数为 ",
          a(1 / e),
          "。"
        ] }),
        /* @__PURE__ */ n("p", { children: "这是矩阵本身的敏感性。即使求解步骤稳定，输入中的误差也会被放大。" })
      ]
    }
  );
}
function L() {
  const [e, s] = h(5), [i, c] = h(1.5), l = (e - 3) / 2, o = 1 + i + l * i * (i - 1);
  return /* @__PURE__ */ r("section", { "aria-label": "差商插值实验", className: "border rounded-xl p-4 my-6", children: [
    /* @__PURE__ */ n("h3", { children: "新增节点只需追加一个差商项" }),
    /* @__PURE__ */ n("p", { children: "已有节点 (0，1)、(1，2)，追加节点 (2，y)。" }),
    /* @__PURE__ */ n(
      m,
      {
        label: "第三个函数值 y",
        value: e,
        min: 0,
        max: 8,
        step: 0.5,
        change: s
      }
    ),
    /* @__PURE__ */ n(
      m,
      {
        label: "求值位置 x",
        value: i,
        min: 0,
        max: 2,
        step: 0.05,
        change: c
      }
    ),
    /* @__PURE__ */ r("p", { children: [
      "一阶差商为 1、",
      a(e - 2),
      "；二阶差商为 (",
      a(e - 2),
      "−1)/2=",
      a(l),
      "。"
    ] }),
    /* @__PURE__ */ r("p", { "aria-live": "polite", children: [
      "p(x)=1+x+",
      a(l),
      "x(x−1)，p(",
      a(i),
      ")=",
      a(o),
      "。"
    ] }),
    /* @__PURE__ */ r(
      "svg",
      {
        viewBox: "0 0 400 220",
        role: "img",
        "aria-label": "插值多项式曲线",
        className: "w-full",
        style: { maxHeight: 260 },
        children: [
          /* @__PURE__ */ n("path", { d: "M30 15V195H375", stroke: "currentColor", fill: "none" }),
          /* @__PURE__ */ n(
            "polyline",
            {
              points: Array.from({ length: 81 }, (p, d) => {
                const t = d / 40;
                return `${30 + 170 * t},${195 - 20 * (1 + t + l * t * (t - 1))}`;
              }).join(" "),
              stroke: "#7650ae",
              strokeWidth: 3,
              fill: "none"
            }
          ),
          [
            [0, 1],
            [1, 2],
            [2, e],
            [i, o]
          ].map(([p, d], t) => /* @__PURE__ */ n(
            "circle",
            {
              cx: 30 + p * 170,
              cy: 195 - d * 20,
              r: 5,
              fill: t === 3 ? "#d87927" : "#7650ae"
            },
            t
          ))
        ]
      }
    ),
    /* @__PURE__ */ n("p", { children: "因子 x(x−1) 在旧节点为零，所以调整最后一个差商不会改变前两个节点的值。" })
  ] });
}
export {
  f as CholeskyLab,
  k as ConditionLab,
  L as DividedDifferenceLab,
  g as LULab,
  N as ThomasLab,
  x as cholesky2
};
