import { type ReactNode } from 'react';
export interface FeaturePreviewCard {
    id: string;
    label: string;
    title: string;
    description: string;
    children: ReactNode;
    motion?: 'writing' | 'files' | 'conversation' | 'connections' | 'sync';
}
export declare function FeatureCardStack({ cards, activeId, onSelect }: {
    cards: FeaturePreviewCard[];
    activeId: string;
    onSelect?: (id: string) => void;
}): import("react").JSX.Element | null;
