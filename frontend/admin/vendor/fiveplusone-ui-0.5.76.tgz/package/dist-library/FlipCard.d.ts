/** FlipCard - 从课栈 review/FlipCard 提取
 *
 * 复习闪卡：正面是问题，背面是答案。点击或按 Enter / 空格翻面。
 * 受控组件，翻面有 3D 过渡，尊重减少动态效果偏好。
 */
import { type ReactNode } from "react";
export type FlipCardKind = "excerpt" | "cloze" | "quiz" | "custom" | "qa";
export interface FlipCardProps {
    kind?: FlipCardKind;
    front: ReactNode;
    back: ReactNode;
    flipped: boolean;
    onFlip: () => void;
    /** 背面补充说明，例如评分依据 */
    explanation?: string;
    className?: string;
}
export declare function FlipCard({ kind, front, back, flipped, onFlip, explanation, className, }: FlipCardProps): import("react").JSX.Element;
