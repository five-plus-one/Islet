/** FormulaSteps - 从课栈 visualizations/primitives/FormulaSteps 提取
 *
 * 分步公式：展示推导的每一步，可切换为逐步浏览模式。
 * 与 Derivation 的区别是内容按步骤拆分，强调顺序与前后的衔接。
 */
import { type ReactNode } from "react";
export interface FormulaStepsProps {
    /** 每一步的内容，建议为普通文本或行内公式 */
    steps: ReactNode[];
    /** 交互模式：逐步显示，默认 false 全部展示 */
    interactive?: boolean;
    label?: string;
}
export declare function FormulaSteps({ steps, interactive, label, }: FormulaStepsProps): import("react").JSX.Element | null;
