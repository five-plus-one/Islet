import { jsxs as i, jsx as n } from "react/jsx-runtime";
import { memo as F, useState as f } from "react";
const c = 340, m = 160, t = 26, $ = 600;
function j() {
  const [o, p] = f(0), [d, v] = f(0), [l, g] = f([]);
  function N(e) {
    let a = d, h = o, s = l.slice();
    for (let x = 0; x < e; x++)
      h += 1, Math.random() < 0.5 && (a += 1), s.push(a / h);
    for (; s.length > $; )
      s = s.filter((x, w) => w % 2 === 0);
    v(a), p(h), g(s);
  }
  function k() {
    v(0), p(0), g([]);
  }
  const u = o ? d / o : 0, r = (e) => t + (1 - e) * (m - 2 * t), b = (e, a) => t + (a <= 1 ? 0 : e / (a - 1) * (c - 2 * t)), y = l.length > 1 ? l.map(
    (e, a) => `${a === 0 ? "M" : "L"}${b(a, l.length).toFixed(1)},${r(e).toFixed(1)}`
  ).join(" ") : "";
  return /* @__PURE__ */ i("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ i("svg", { viewBox: `0 0 ${c} ${m}`, className: "w-full", children: [
      /* @__PURE__ */ n(
        "rect",
        {
          x: t,
          y: t,
          width: c - 2 * t,
          height: m - 2 * t,
          fill: "var(--bg-muted)",
          stroke: "var(--line)"
        }
      ),
      [0, 0.5, 1].map((e) => /* @__PURE__ */ i("g", { children: [
        /* @__PURE__ */ n(
          "line",
          {
            x1: t,
            y1: r(e),
            x2: c - t,
            y2: r(e),
            stroke: e === 0.5 ? "#c4b5fd" : "var(--line)",
            strokeDasharray: e === 0.5 ? "4 3" : void 0
          }
        ),
        /* @__PURE__ */ n(
          "text",
          {
            x: t - 6,
            y: r(e) + 3,
            fontSize: "10",
            textAnchor: "end",
            fill: "var(--ink-faint)",
            children: e
          }
        )
      ] }, e)),
      /* @__PURE__ */ n(
        "text",
        {
          x: c - t,
          y: r(0.5) - 5,
          fontSize: "10",
          textAnchor: "end",
          fill: "var(--accent)",
          children: "理论概率 0.5"
        }
      ),
      y && /* @__PURE__ */ n("path", { d: y, fill: "none", stroke: "#5b46e5", strokeWidth: "1.8" }),
      l.length > 0 && /* @__PURE__ */ n(
        "circle",
        {
          cx: b(l.length - 1, l.length),
          cy: r(u),
          r: "3",
          fill: "#5b46e5"
        }
      )
    ] }),
    /* @__PURE__ */ n("div", { className: "mt-3 flex items-center justify-between text-[13px]", children: /* @__PURE__ */ i("div", { className: "flex gap-4", children: [
      /* @__PURE__ */ i("span", { className: "text-[var(--ink-faint)]", children: [
        "试验 ",
        /* @__PURE__ */ n("b", { className: "text-[var(--ink)]", children: o })
      ] }),
      /* @__PURE__ */ i("span", { className: "text-[var(--ink-faint)]", children: [
        "正面 ",
        /* @__PURE__ */ n("b", { className: "text-[var(--ink)]", children: d })
      ] }),
      /* @__PURE__ */ i("span", { className: "text-[var(--ink-faint)]", children: [
        "频率",
        " ",
        /* @__PURE__ */ n("b", { className: "font-mono text-[var(--accent-ink)]", children: u.toFixed(4) })
      ] })
    ] }) }),
    /* @__PURE__ */ i("div", { className: "mt-3 flex flex-wrap gap-1.5", children: [
      [1, 20, 500].map((e) => /* @__PURE__ */ i(
        "button",
        {
          type: "button",
          onClick: () => N(e),
          className: "rounded-lg bg-[var(--accent)] px-3 py-1 text-[13px] font-medium text-white hover:opacity-90",
          children: [
            "抛 ",
            e,
            " 次"
          ]
        },
        e
      )),
      /* @__PURE__ */ n(
        "button",
        {
          type: "button",
          onClick: k,
          className: "rounded-lg bg-[var(--bg-muted)] px-3 py-1 text-[13px] font-medium text-[var(--ink-soft)] hover:bg-[var(--line)]",
          children: "重置"
        }
      )
    ] })
  ] });
}
const q = F(j);
export {
  q as default
};
