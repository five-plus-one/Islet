import { jsxs as o, jsx as e, Fragment as J } from "react/jsx-runtime";
import { memo as K, useState as L, useCallback as Q } from "react";
const m = "var(--accent)", I = "var(--fp-primary-soft)", f = "#dc2626", R = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))", b = "#16a34a", j = "color-mix(in srgb, #dcfce7 24%, var(--fp-surface))", _ = "var(--line)", D = "var(--ink-faint)", G = 500, O = 180, W = 10, U = 10, w = 20, tt = 36;
function P(t) {
  const a = t < 0 ? -1 : 1, n = 1 / (1 + 0.2316419 * Math.abs(t)), r = n * (0.31938153 + n * (-0.356563782 + n * (1.781477937 + n * (-1.821255978 + n * 1.330274429))));
  return 0.5 + a * (0.5 - N(Math.abs(t)) * r);
}
function N(t) {
  return Math.exp(-0.5 * t * t) / Math.sqrt(2 * Math.PI);
}
function F(t, a) {
  const n = O - w - tt;
  return w + n * (1 - t / a);
}
const x = -3.8, u = 3.8;
function g(t) {
  const a = G - W - U;
  return W + (t - x) / (u - x) * a;
}
function et(t = 300) {
  const a = [];
  for (let n = 0; n <= t; n++) {
    const r = x + (u - x) * n / t, l = F(N(r), N(0));
    a.push(`${n === 0 ? "M" : "L"}${g(r).toFixed(2)},${l.toFixed(2)}`);
  }
  return a.join(" ");
}
function M(t, a, n = 120) {
  const r = F(0, N(0)), l = [];
  l.push(`M${g(t).toFixed(2)},${r.toFixed(2)}`);
  for (let y = 0; y <= n; y++) {
    const c = t + (a - t) * y / n, s = F(N(c), N(0));
    l.push(`L${g(c).toFixed(2)},${s.toFixed(2)}`);
  }
  return l.push(`L${g(a).toFixed(2)},${r.toFixed(2)}`), l.push("Z"), l.join(" ");
}
function nt(t, a) {
  return a === "left" ? { zLeft: C(t), zRight: null } : a === "right" ? { zLeft: null, zRight: C(1 - t) } : { zLeft: C(t / 2), zRight: C(1 - t / 2) };
}
function C(t) {
  if (t <= 0) return -1 / 0;
  if (t >= 1) return 1 / 0;
  const a = [
    -39.69683028665376,
    220.9460984245205,
    -275.9285104469687,
    138.357751867269,
    -30.66479806614716,
    2.506628277459239
  ], n = [
    -54.47609879822406,
    161.5858368580409,
    -155.6989798598866,
    66.80131188771972,
    -13.28068155288572
  ], r = [
    -0.007784894002430293,
    -0.3223964580411365,
    -2.400758277161838,
    -2.549732539343734,
    4.374664141464968,
    2.938163982698783
  ], l = [
    0.007784695709041462,
    0.3224671290700398,
    2.445134137142996,
    3.754408661907416
  ], y = 0.02425, c = 1 - y;
  let s = 0;
  if (t < y) {
    const i = Math.sqrt(-2 * Math.log(t));
    s = (((((r[0] * i + r[1]) * i + r[2]) * i + r[3]) * i + r[4]) * i + r[5]) / ((((l[0] * i + l[1]) * i + l[2]) * i + l[3]) * i + 1);
  } else if (t <= c) {
    const i = t - 0.5, h = i * i;
    s = (((((a[0] * h + a[1]) * h + a[2]) * h + a[3]) * h + a[4]) * h + a[5]) * i / (((((n[0] * h + n[1]) * h + n[2]) * h + n[3]) * h + n[4]) * h + 1);
  } else {
    const i = Math.sqrt(-2 * Math.log(1 - t));
    s = -((((((r[0] * i + r[1]) * i + r[2]) * i + r[3]) * i + r[4]) * i + r[5]) / ((((l[0] * i + l[1]) * i + l[2]) * i + l[3]) * i + 1));
  }
  return s;
}
function lt(t, a) {
  return a === "left" ? P(t) : a === "right" ? 1 - P(t) : 2 * (1 - P(Math.abs(t)));
}
const it = {
  left: "左尾检验",
  right: "右尾检验",
  two: "双尾检验"
}, ot = {
  left: "H₁: μ < μ₀，拒绝域在左侧",
  right: "H₁: μ > μ₀，拒绝域在右侧",
  two: "H₁: μ ≠ μ₀，拒绝域在两侧"
};
function A(t) {
  return t.toFixed(4);
}
function p(t) {
  return t.toFixed(2);
}
function at() {
  const [t, a] = L(0.05), [n, r] = L(1.8), [l, y] = L("two"), { zLeft: c, zRight: s } = nt(t, l), i = lt(n, l), h = i < t, v = l === "left" && c !== null && n <= c || l === "right" && s !== null && n >= s || l === "two" && c !== null && s !== null && (n <= c || n >= s), X = et(), $ = [];
  l === "left" && c !== null ? $.push(M(x, c)) : l === "right" && s !== null ? $.push(M(s, u)) : l === "two" && c !== null && s !== null && ($.push(M(x, c)), $.push(M(s, u)));
  const z = g(Math.max(x, Math.min(u, n))), k = F(0, N(0)), H = F(N(n), N(0)), T = c !== null ? g(Math.max(x, Math.min(u, c))) : null, S = s !== null ? g(Math.max(x, Math.min(u, s))) : null, q = Q(() => {
    const d = Math.random() * 6 - 3;
    r(parseFloat(d.toFixed(2)));
  }, []), Y = [-3, -2, -1, 0, 1, 2, 3];
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "假设检验直觉演示" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "调整显著性水平 α 和检验统计量 z，观察拒绝域变化与决策结果。" })
    ] }),
    /* @__PURE__ */ o("div", { className: "flex gap-1.5 flex-wrap", children: [
      ["left", "right", "two"].map((d) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => y(d),
          className: "rounded-lg px-3 py-1.5 text-[12px] font-semibold transition-colors " + (d === l ? "bg-[var(--accent)] text-white shadow-sm" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--accent-weak)]"),
          children: it[d]
        },
        d
      )),
      /* @__PURE__ */ e("span", { className: "ml-2 self-center text-[11px] text-[var(--ink-soft)]", children: ot[l] })
    ] }),
    /* @__PURE__ */ e("div", { className: "rounded-lg border border-[var(--line)] overflow-hidden bg-[var(--bg-muted)]", children: /* @__PURE__ */ o(
      "svg",
      {
        viewBox: `0 0 ${G} ${O}`,
        className: "w-full",
        style: { maxHeight: 200 },
        children: [
          $.map((d, E) => /* @__PURE__ */ e("path", { d, fill: m, fillOpacity: 0.25 }, E)),
          l === "left" && /* @__PURE__ */ e(
            "path",
            {
              d: M(
                x,
                Math.max(x, Math.min(u, n))
              ),
              fill: v ? f : "var(--ink-faint)",
              fillOpacity: 0.12
            }
          ),
          l === "right" && /* @__PURE__ */ e(
            "path",
            {
              d: M(
                Math.max(x, Math.min(u, n)),
                u
              ),
              fill: v ? f : "var(--ink-faint)",
              fillOpacity: 0.12
            }
          ),
          l === "two" && /* @__PURE__ */ o(J, { children: [
            /* @__PURE__ */ e(
              "path",
              {
                d: M(
                  x,
                  Math.max(
                    x,
                    Math.min(u, Math.min(n, -Math.abs(n)))
                  )
                ),
                fill: v ? f : "var(--ink-faint)",
                fillOpacity: 0.12
              }
            ),
            /* @__PURE__ */ e(
              "path",
              {
                d: M(
                  Math.max(x, Math.min(u, Math.abs(n))),
                  u
                ),
                fill: v ? f : "var(--ink-faint)",
                fillOpacity: 0.12
              }
            )
          ] }),
          /* @__PURE__ */ e("path", { d: X, fill: "none", stroke: m, strokeWidth: "2" }),
          /* @__PURE__ */ e(
            "line",
            {
              x1: g(x),
              y1: k,
              x2: g(u),
              y2: k,
              stroke: _,
              strokeWidth: "1"
            }
          ),
          Y.map((d) => /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: g(d),
                y1: k,
                x2: g(d),
                y2: k + 4,
                stroke: _,
                strokeWidth: "1"
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: g(d),
                y: k + 14,
                fontSize: "10",
                textAnchor: "middle",
                fill: D,
                children: d
              }
            )
          ] }, d)),
          T !== null && c !== null && /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: T,
                y1: w,
                x2: T,
                y2: k,
                stroke: m,
                strokeWidth: "1.5",
                strokeDasharray: "4 3"
              }
            ),
            /* @__PURE__ */ o(
              "text",
              {
                x: T,
                y: w - 6,
                fontSize: "9",
                textAnchor: "middle",
                fill: m,
                fontWeight: "600",
                children: [
                  "z=",
                  p(c)
                ]
              }
            )
          ] }),
          S !== null && s !== null && /* @__PURE__ */ o("g", { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: S,
                y1: w,
                x2: S,
                y2: k,
                stroke: m,
                strokeWidth: "1.5",
                strokeDasharray: "4 3"
              }
            ),
            /* @__PURE__ */ o(
              "text",
              {
                x: S,
                y: w - 6,
                fontSize: "9",
                textAnchor: "middle",
                fill: m,
                fontWeight: "600",
                children: [
                  "z=",
                  p(s)
                ]
              }
            )
          ] }),
          /* @__PURE__ */ e(
            "line",
            {
              x1: z,
              y1: H - 2,
              x2: z,
              y2: k,
              stroke: v ? f : b,
              strokeWidth: "2",
              strokeDasharray: "3 2"
            }
          ),
          /* @__PURE__ */ e(
            "polygon",
            {
              points: `${z},${H - 14} ${z - 6},${H - 24} ${z + 6},${H - 24}`,
              fill: v ? f : b
            }
          ),
          /* @__PURE__ */ o(
            "text",
            {
              x: z,
              y: H - 26,
              fontSize: "10",
              textAnchor: "middle",
              fill: v ? f : b,
              fontWeight: "700",
              children: [
                "z=",
                p(n)
              ]
            }
          ),
          /* @__PURE__ */ e(
            "rect",
            {
              x: W,
              y: w + 2,
              width: 10,
              height: 8,
              fill: m,
              fillOpacity: 0.35,
              rx: "1"
            }
          ),
          /* @__PURE__ */ o("text", { x: W + 13, y: w + 9, fontSize: "9", fill: D, children: [
            "拒绝域 α=",
            A(t)
          ] })
        ]
      }
    ) }),
    /* @__PURE__ */ o("div", { className: "space-y-3 rounded-lg bg-[var(--bg-muted)] px-4 py-3", children: [
      /* @__PURE__ */ o("div", { className: "space-y-1", children: [
        /* @__PURE__ */ o("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "显著性水平 α" }),
          /* @__PURE__ */ e(
            "span",
            {
              className: "rounded-md px-2 py-0.5 text-[13px] font-mono font-bold",
              style: { background: I, color: m },
              children: t.toFixed(2)
            }
          )
        ] }),
        /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--ink-soft)]", children: "α 越大，拒绝域越宽，越容易拒绝 H₀（但犯第一类错误概率越高）" }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0.01,
            max: 0.1,
            step: 0.01,
            value: t,
            onChange: (d) => a(Number(d.target.value)),
            className: "w-full h-1.5 cursor-pointer",
            style: { accentColor: m }
          }
        ),
        /* @__PURE__ */ o("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ e("span", { children: "0.01（严格）" }),
          /* @__PURE__ */ e("span", { children: "0.10（宽松）" })
        ] })
      ] }),
      /* @__PURE__ */ o("div", { className: "space-y-1", children: [
        /* @__PURE__ */ o("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "检验统计量 z" }),
          /* @__PURE__ */ e(
            "span",
            {
              className: "rounded-md px-2 py-0.5 text-[13px] font-mono font-bold",
              style: {
                background: v ? R : j,
                color: v ? f : b
              },
              children: p(n)
            }
          )
        ] }),
        /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--ink-soft)]", children: "样本数据折合成的标准化统计量（在 H₀ 下服从标准正态分布）" }),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: -3,
            max: 3,
            step: 0.05,
            value: n,
            onChange: (d) => r(Number(d.target.value)),
            className: "w-full h-1.5 cursor-pointer",
            style: { accentColor: v ? f : b }
          }
        ),
        /* @__PURE__ */ o("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ e("span", { children: "−3" }),
          /* @__PURE__ */ e("span", { children: "0" }),
          /* @__PURE__ */ e("span", { children: "+3" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg border-2 p-4 space-y-2 transition-all duration-300",
        style: {
          borderColor: h ? f : b,
          background: h ? R : j
        },
        children: [
          /* @__PURE__ */ o("div", { className: "flex items-center justify-between flex-wrap gap-2", children: [
            /* @__PURE__ */ e(
              "div",
              {
                className: "text-[15px] font-bold",
                style: { color: h ? f : b },
                children: h ? "拒绝 H₀（p < α）" : "不拒绝 H₀（p ≥ α）"
              }
            ),
            /* @__PURE__ */ e(
              "div",
              {
                className: "rounded-full px-3 py-0.5 text-[12px] font-semibold",
                style: {
                  background: h ? f : b,
                  color: "white"
                },
                children: h ? "差异显著" : "差异不显著"
              }
            )
          ] }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "text-[12px] leading-relaxed",
              style: { color: h ? "#991b1b" : "#166534" },
              children: h ? `检验统计量 z = ${p(n)} 落入拒绝域，说明在显著性水平 α = ${t.toFixed(2)} 下，有充分理由拒绝原假设 H₀。` : `检验统计量 z = ${p(n)} 未落入拒绝域，在显著性水平 α = ${t.toFixed(2)} 下，无充分理由拒绝原假设 H₀。`
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "grid grid-cols-3 gap-2", children: [
      {
        label: "p 值",
        val: A(i),
        sub: "P(观测 ≥ |z| | H₀成立)",
        bg: i < t ? R : j,
        col: i < t ? f : b
      },
      {
        label: "显著性水平 α",
        val: t.toFixed(2),
        sub: "第一类错误上限",
        bg: I,
        col: m
      },
      {
        label: "临界值 z_c",
        val: l === "two" && c !== null && s !== null ? `±${p(s)}` : l === "left" && c !== null ? p(c) : s !== null ? p(s) : "—",
        sub: l === "two" ? `双尾 α/2 = ${(t / 2).toFixed(3)}` : `单尾 α = ${t.toFixed(2)}`,
        bg: "var(--bg-muted)",
        col: m
      }
    ].map(({ label: d, val: E, sub: B, bg: Z, col: V }) => /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg p-2.5 text-center",
        style: { background: Z },
        children: [
          /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)] leading-snug", children: d }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "text-[17px] font-extrabold font-mono mt-0.5",
              style: { color: V },
              children: E
            }
          ),
          /* @__PURE__ */ e("div", { className: "text-[9px] text-[var(--ink-soft)] mt-0.5 leading-snug", children: B })
        ]
      },
      d
    )) }),
    /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 text-[12px] leading-loose text-[var(--ink-soft)] space-y-1.5", children: [
      /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "判决逻辑" }),
      /* @__PURE__ */ o("div", { className: "font-mono", children: [
        "p 值 = P(Z",
        " ",
        l === "left" ? "≤" : l === "right" ? "≥" : "满足 |Z| ≥",
        " ",
        p(Math.abs(n)),
        " | H₀) =",
        " ",
        /* @__PURE__ */ e(
          "span",
          {
            style: { color: i < t ? f : b, fontWeight: 700 },
            children: A(i)
          }
        )
      ] }),
      /* @__PURE__ */ o("div", { className: "font-mono", children: [
        "α =",
        " ",
        /* @__PURE__ */ e("span", { style: { color: m, fontWeight: 700 }, children: t.toFixed(2) }),
        "  →  ",
        i < t ? /* @__PURE__ */ e("span", { style: { color: f, fontWeight: 700 }, children: "p < α，拒绝 H₀" }) : /* @__PURE__ */ e("span", { style: { color: b, fontWeight: 700 }, children: "p ≥ α，不拒绝 H₀" })
      ] }),
      /* @__PURE__ */ o("div", { className: "text-[11px] mt-1", children: [
        /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "直觉：" }),
        "p 值是「如果 H₀ 为真，得到至少这么极端结果的概率」。 p 值越小，说明观测到的数据在 H₀ 下越罕见，越有理由怀疑 H₀。"
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "flex gap-2 flex-wrap", children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: q,
          className: "rounded-lg bg-[var(--accent)] px-4 py-1.5 text-[13px] font-medium text-white hover:opacity-90 transition-opacity",
          children: "随机生成 z 值"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => {
            a(0.05), r(1.8), y("two");
          },
          className: "rounded-lg bg-[var(--bg-muted)] px-4 py-1.5 text-[13px] font-medium text-[var(--ink-soft)] hover:bg-[var(--line)] transition-colors",
          children: "重置默认"
        }
      ),
      /* @__PURE__ */ o("span", { className: "self-center text-[11px] text-[var(--ink-soft)]", children: [
        l === "two" ? `两侧临界值 ±${s !== null ? p(s) : "—"}` : l === "left" ? `左侧临界值 ${c !== null ? p(c) : "—"}` : `右侧临界值 ${s !== null ? p(s) : "—"}`,
        "，z = ",
        p(n),
        v ? "（在拒绝域内）" : "（在接受域内）"
      ] })
    ] })
  ] });
}
const ct = K(at);
export {
  ct as default
};
