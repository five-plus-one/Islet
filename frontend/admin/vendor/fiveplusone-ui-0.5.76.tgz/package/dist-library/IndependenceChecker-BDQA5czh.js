import { jsxs as o, jsx as e } from "react/jsx-runtime";
import { learningAlpha as O } from "./index.js";
import { memo as J, useState as G, useCallback as Q } from "react";
const b = "var(--fp-primary)", H = "var(--fp-primary-soft)", y = "#0f766e", S = "color-mix(in srgb, #d1fae5 24%, var(--fp-surface))", g = "#dc2626", R = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))", X = "#b45309", T = "color-mix(in srgb, #fef3c7 24%, var(--fp-surface))", U = [
  [0.06, 0.08, 0.06],
  [0.15, 0.2, 0.15],
  [0.09, 0.12, 0.09]
], _ = [
  {
    label: "完全独立",
    description: "边缘分布乘积恰好等于联合概率，独立性指数 = 0",
    grid: [
      [0.06, 0.08, 0.06],
      [0.15, 0.2, 0.15],
      [0.09, 0.12, 0.09]
    ]
  },
  {
    label: "强相关",
    description: "概率集中在对角线，X 与 Y 高度正相关",
    grid: [
      [0.25, 0.05, 0],
      [0.05, 0.3, 0.05],
      [0, 0.05, 0.25]
    ]
  },
  {
    label: "负相关",
    description: "X 大时 Y 小，X 小时 Y 大，反对角线集中",
    grid: [
      [0.02, 0.06, 0.22],
      [0.06, 0.2, 0.04],
      [0.22, 0.04, 0.02]
    ]
  },
  {
    label: "边缘相同·不独立",
    description: "边缘分布均匀，但联合分布不是乘积",
    grid: [
      [0.02, 0.14, 0.17],
      [0.17, 0.08, 0.08],
      [0.14, 0.11, 0.09]
    ]
  }
];
function Z(n) {
  const r = [
    n[0][0] + n[0][1] + n[0][2],
    n[1][0] + n[1][1] + n[1][2],
    n[2][0] + n[2][1] + n[2][2]
  ], l = [
    n[0][0] + n[1][0] + n[2][0],
    n[0][1] + n[1][1] + n[2][1],
    n[0][2] + n[1][2] + n[2][2]
  ], t = r[0] + r[1] + r[2], d = [
    t > 0 ? r[0] / t : 0,
    t > 0 ? r[1] / t : 0,
    t > 0 ? r[2] / t : 0
  ], p = [
    t > 0 ? l[0] / t : 0,
    t > 0 ? l[1] / t : 0,
    t > 0 ? l[2] / t : 0
  ], i = [
    [d[0] * p[0], d[0] * p[1], d[0] * p[2]],
    [d[1] * p[0], d[1] * p[1], d[1] * p[2]],
    [d[2] * p[0], d[2] * p[1], d[2] * p[2]]
  ], f = [
    [
      t > 0 ? n[0][0] / t : 0,
      t > 0 ? n[0][1] / t : 0,
      t > 0 ? n[0][2] / t : 0
    ],
    [
      t > 0 ? n[1][0] / t : 0,
      t > 0 ? n[1][1] / t : 0,
      t > 0 ? n[1][2] / t : 0
    ],
    [
      t > 0 ? n[2][0] / t : 0,
      t > 0 ? n[2][1] / t : 0,
      t > 0 ? n[2][2] / t : 0
    ]
  ], k = [
    [
      f[0][0] - i[0][0],
      f[0][1] - i[0][1],
      f[0][2] - i[0][2]
    ],
    [
      f[1][0] - i[1][0],
      f[1][1] - i[1][1],
      f[1][2] - i[1][2]
    ],
    [
      f[2][0] - i[2][0],
      f[2][1] - i[2][1],
      f[2][2] - i[2][2]
    ]
  ], M = Math.max(...k.flat().map(Math.abs));
  return { rowMargins: r, colMargins: l, total: t, independent: i, deviations: k, maxDev: M };
}
function A(n, r) {
  if (r < 1e-9) return "#e8f5e9";
  const l = Math.min(Math.abs(n) / Math.max(r, 1e-3), 1), t = Math.round(15 + 205 * l), d = Math.round(118 - 80 * l), p = Math.round(110 - 110 * l);
  return `rgb(${t},${d},${p})`;
}
function W(n, r) {
  if (r < 1e-9) return "#f0fdf4";
  const l = Math.min(Math.abs(n) / Math.max(r, 1e-3), 1), t = Math.round(240 + 14 * l), d = Math.round(253 + -27 * l), p = Math.round(244 + -18 * l);
  return `rgb(${t},${d},${p})`;
}
function u(n) {
  return n.toFixed(4);
}
function $(n) {
  return n.toFixed(3);
}
function j({
  value: n,
  dev: r,
  maxDev: l,
  isSelected: t,
  onClick: d,
  onChange: p,
  row: i,
  col: f,
  independent: k
}) {
  const M = W(r, l), v = t ? b : A(r, l), w = A(r, l), c = Math.abs(r) < 2e-3, E = Q(
    (Y) => {
      p(Number(Y.target.value));
    },
    [p]
  );
  return /* @__PURE__ */ o(
    "div",
    {
      className: "relative flex flex-col items-center justify-center rounded-lg p-1.5 cursor-pointer transition-all duration-200",
      style: {
        background: M,
        border: `2px solid ${v}`,
        minHeight: 64,
        boxShadow: t ? `0 0 0 3px ${O(b, "44")}` : void 0
      },
      onClick: d,
      title: `X=${i + 1}, Y=${f + 1} | 实际: ${u(n)} | 独立参考: ${u(k)} | 偏差: ${r >= 0 ? "+" : ""}${u(r)}`,
      children: [
        /* @__PURE__ */ e(
          "div",
          {
            className: "text-[11px] font-bold leading-tight",
            style: { color: c ? y : w },
            children: c ? "OK" : r > 0 ? "↑" : "↓"
          }
        ),
        /* @__PURE__ */ e(
          "div",
          {
            className: "text-[13px] font-mono font-bold",
            style: { color: w },
            children: $(n)
          }
        ),
        t && /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0,
            max: 0.5,
            step: 1e-3,
            value: n,
            onChange: E,
            onClick: (Y) => Y.stopPropagation(),
            className: "w-full mt-1",
            style: { accentColor: b, height: 14 }
          }
        )
      ]
    }
  );
}
function D({ maxDev: n }) {
  const l = Math.min(n, 0.25) / 0.25, t = n < 0.01 ? y : n < 0.05 ? X : g, d = n < 5e-3 ? "几乎完全独立" : n < 0.02 ? "近似独立" : n < 0.07 ? "弱相关" : "强相关（不独立）";
  return /* @__PURE__ */ o("div", { className: "rounded-lg border border-[var(--line)] p-3 space-y-2", children: [
    /* @__PURE__ */ o("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ e("span", { className: "text-[13px] font-bold text-[var(--ink)]", children: "独立性指数" }),
      /* @__PURE__ */ e(
        "span",
        {
          className: "rounded-md px-2 py-0.5 text-[13px] font-mono font-bold",
          style: {
            background: n < 0.01 ? S : n < 0.05 ? T : R,
            color: t
          },
          children: u(n)
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "text-[11px] font-mono text-[var(--ink-soft)]", children: [
      "max |p(xᵢ,yⱼ) − pᵢ·qⱼ| = ",
      u(n)
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "relative h-4 w-full rounded-full overflow-hidden",
        style: { background: "var(--line)" },
        children: /* @__PURE__ */ e(
          "div",
          {
            className: "h-full rounded-full transition-all duration-300",
            style: { width: `${l * 100}%`, background: t }
          }
        )
      }
    ),
    /* @__PURE__ */ o("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ e("span", { style: { color: y }, children: "0 = 完全独立" }),
      /* @__PURE__ */ e("span", { style: { color: g }, children: "≥ 0.25 = 强相关" })
    ] }),
    /* @__PURE__ */ e(
      "div",
      {
        className: "text-center text-[12px] font-semibold rounded-md py-1",
        style: {
          background: n < 0.01 ? S : n < 0.05 ? T : R,
          color: t
        },
        children: d
      }
    )
  ] });
}
function F({
  value: n,
  label: r,
  color: l
}) {
  return /* @__PURE__ */ o(
    "div",
    {
      className: "rounded-md px-2 py-1 text-center",
      style: { background: O(l, "22"), minWidth: 54 },
      children: [
        /* @__PURE__ */ e("div", { className: "text-[9px] text-[var(--ink-soft)]", children: r }),
        /* @__PURE__ */ e("div", { className: "text-[12px] font-mono font-bold", style: { color: l }, children: $(n) })
      ]
    }
  );
}
function ee() {
  const [n, r] = G(
    () => U.map((s) => [...s])
  ), [l, t] = G([
    1,
    1
  ]), [d, p] = G(!1), [i, f] = G(0), { rowMargins: k, colMargins: M, total: v, independent: w, deviations: C, maxDev: c } = Z(n), E = n.map(
    (s) => s.map((a) => v > 0 ? a / v : 0)
  );
  function Y(s, a, m) {
    const N = n.map(
      (h, x) => h.map((q, L) => x === s && L === a ? m : q)
    );
    r(N);
  }
  function B(s) {
    f(s), r(_[s].grid.map((a) => [...a])), t(null);
  }
  function K() {
    const s = [
      Math.random(),
      Math.random(),
      Math.random()
    ], a = [
      Math.random(),
      Math.random(),
      Math.random()
    ], m = s[0] + s[1] + s[2], N = a[0] + a[1] + a[2], h = [
      s[0] / m,
      s[1] / m,
      s[2] / m
    ], x = [
      a[0] / N,
      a[1] / N,
      a[2] / N
    ], L = [
      [
        h[0] * x[0] + (Math.random() - 0.5) * 0.05,
        h[0] * x[1] + (Math.random() - 0.5) * 0.05,
        h[0] * x[2] + (Math.random() - 0.5) * 0.05
      ],
      [
        h[1] * x[0] + (Math.random() - 0.5) * 0.05,
        h[1] * x[1] + (Math.random() - 0.5) * 0.05,
        h[1] * x[2] + (Math.random() - 0.5) * 0.05
      ],
      [
        h[2] * x[0] + (Math.random() - 0.5) * 0.05,
        h[2] * x[1] + (Math.random() - 0.5) * 0.05,
        h[2] * x[2] + (Math.random() - 0.5) * 0.05
      ]
    ].map(
      (z) => z.map((V) => Math.max(V, 1e-3))
    );
    r(L), f(-1), t(null);
  }
  const P = ["X₁", "X₂", "X₃"], I = ["Y₁", "Y₂", "Y₃"];
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "随机变量独立性检验器" }),
      /* @__PURE__ */ o("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: [
        "编辑联合分布表，实时检验 p(xᵢ,yⱼ) = pᵢ·qⱼ 是否成立。",
        /* @__PURE__ */ o("span", { style: { color: y }, className: "font-semibold", children: [
          " ",
          "绿"
        ] }),
        "色表示接近独立，",
        /* @__PURE__ */ o("span", { style: { color: g }, className: "font-semibold", children: [
          " ",
          "红"
        ] }),
        "色表示偏离独立假设。"
      ] })
    ] }),
    /* @__PURE__ */ o("div", { className: "flex flex-wrap gap-1.5", children: [
      _.map((s, a) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => B(a),
          className: "rounded-lg px-2.5 py-1 text-[11px] font-medium transition-colors",
          style: {
            background: i === a ? b : "var(--bg-muted)",
            color: i === a ? "white" : "var(--ink-soft)",
            border: `1px solid ${i === a ? b : "var(--line)"}`
          },
          title: s.description,
          children: s.label
        },
        a
      )),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: K,
          className: "rounded-lg px-2.5 py-1 text-[11px] font-medium transition-colors",
          style: {
            background: i === -1 ? b : "var(--bg-muted)",
            color: i === -1 ? "white" : "var(--ink-soft)",
            border: `1px solid ${i === -1 ? b : "var(--line)"}`
          },
          children: "随机分布"
        }
      )
    ] }),
    /* @__PURE__ */ e("div", { className: "overflow-x-auto", children: /* @__PURE__ */ o("div", { className: "min-w-[340px]", children: [
      /* @__PURE__ */ o("div", { className: "flex items-end mb-1 ml-[64px] gap-1.5", children: [
        I.map((s, a) => /* @__PURE__ */ o("div", { className: "flex-1 text-center", children: [
          /* @__PURE__ */ e("div", { className: "text-[11px] font-semibold text-[var(--ink-soft)] mb-0.5", children: s }),
          /* @__PURE__ */ e(
            F,
            {
              value: v > 0 ? M[a] / v : 0,
              label: `q${a + 1}`,
              color: b
            }
          )
        ] }, a)),
        /* @__PURE__ */ e("div", { className: "w-[54px] text-center text-[9px] text-[var(--ink-soft)] self-end pb-1", children: "边缘分布" })
      ] }),
      P.map((s, a) => /* @__PURE__ */ o("div", { className: "flex items-center gap-1.5 mb-1.5", children: [
        /* @__PURE__ */ o("div", { className: "flex flex-col items-center w-[64px] shrink-0 gap-0.5", children: [
          /* @__PURE__ */ e("div", { className: "text-[11px] font-semibold text-[var(--ink-soft)]", children: s }),
          /* @__PURE__ */ e(
            F,
            {
              value: v > 0 ? k[a] / v : 0,
              label: `p${a + 1}`,
              color: "#7c3aed"
            }
          )
        ] }),
        [0, 1, 2].map((m) => {
          const N = l !== null && l[0] === a && l[1] === m;
          return /* @__PURE__ */ e("div", { className: "flex-1", children: /* @__PURE__ */ e(
            j,
            {
              value: n[a][m],
              dev: C[a][m],
              maxDev: c,
              isSelected: N,
              onClick: () => t(N ? null : [a, m]),
              onChange: (h) => Y(a, m, h),
              row: a,
              col: m,
              independent: w[a][m] * v
            }
          ) }, m);
        }),
        /* @__PURE__ */ o(
          "div",
          {
            className: "w-[54px] shrink-0 rounded-md px-1 py-1 text-center text-[11px] font-mono",
            style: {
              background: "var(--bg-muted)",
              color: "var(--ink-soft)"
            },
            children: [
              /* @__PURE__ */ e("div", { className: "text-[9px]", children: "行和" }),
              /* @__PURE__ */ e("div", { className: "font-bold text-[var(--ink)]", children: $(k[a]) })
            ]
          }
        )
      ] }, a)),
      /* @__PURE__ */ o("div", { className: "flex items-center gap-1.5 ml-[64px]", children: [
        [0, 1, 2].map((s) => /* @__PURE__ */ o(
          "div",
          {
            className: "flex-1 rounded-md px-1 py-1 text-center text-[11px] font-mono",
            style: {
              background: "var(--bg-muted)",
              color: "var(--ink-soft)"
            },
            children: [
              /* @__PURE__ */ e("div", { className: "text-[9px]", children: "列和" }),
              /* @__PURE__ */ e("div", { className: "font-bold text-[var(--ink)]", children: $(M[s]) })
            ]
          },
          s
        )),
        /* @__PURE__ */ o(
          "div",
          {
            className: "w-[54px] shrink-0 rounded-md px-1 py-1 text-center text-[11px] font-mono",
            style: { background: H, color: b },
            children: [
              /* @__PURE__ */ e("div", { className: "text-[9px]", children: "总和" }),
              /* @__PURE__ */ e("div", { className: "font-bold", children: $(v) })
            ]
          }
        )
      ] })
    ] }) }),
    l !== null && /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg px-3 py-2 text-[12px] leading-relaxed",
        style: { background: H, color: b },
        children: [
          /* @__PURE__ */ o("span", { className: "font-semibold", children: [
            "已选中 (",
            P[l[0]],
            ", ",
            I[l[1]],
            "):"
          ] }),
          " ",
          "拖动格子内的滑块调整概率值。当前值 =",
          " ",
          /* @__PURE__ */ e("span", { className: "font-mono font-bold", children: u(n[l[0]][l[1]]) }),
          "，独立参考值 =",
          " ",
          /* @__PURE__ */ e("span", { className: "font-mono font-bold", children: u(w[l[0]][l[1]]) }),
          "，偏差 =",
          " ",
          /* @__PURE__ */ o(
            "span",
            {
              className: "font-mono font-bold",
              style: {
                color: Math.abs(C[l[0]][l[1]]) < 2e-3 ? y : g
              },
              children: [
                C[l[0]][l[1]] >= 0 ? "+" : "",
                u(C[l[0]][l[1]])
              ]
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ e(D, { maxDev: c }),
    /* @__PURE__ */ o("div", { className: "rounded-lg border border-[var(--line)] p-3 space-y-2", children: [
      /* @__PURE__ */ o("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ e("span", { className: "text-[13px] font-bold text-[var(--ink)]", children: "独立参考分布 pᵢ·qⱼ" }),
        /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)]", children: "若 X⊥Y，则联合分布应等于此值" })
      ] }),
      /* @__PURE__ */ e("div", { className: "overflow-x-auto", children: /* @__PURE__ */ o("table", { className: "w-full border-collapse text-[11px] font-mono", children: [
        /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ o("tr", { children: [
          /* @__PURE__ */ e("th", { className: "text-[var(--ink-soft)] pb-1 pr-2 text-left font-normal", children: "pᵢ·qⱼ" }),
          I.map((s, a) => /* @__PURE__ */ e(
            "th",
            {
              className: "pb-1 text-center font-semibold",
              style: { color: b },
              children: s
            },
            a
          ))
        ] }) }),
        /* @__PURE__ */ e("tbody", { children: P.map((s, a) => /* @__PURE__ */ o("tr", { children: [
          /* @__PURE__ */ e(
            "td",
            {
              className: "pr-2 font-semibold",
              style: { color: "#7c3aed" },
              children: s
            }
          ),
          [0, 1, 2].map((m) => {
            const N = E[a][m], h = w[a][m], x = C[a][m], q = Math.abs(x) < 2e-3;
            return /* @__PURE__ */ o(
              "td",
              {
                className: "py-1 px-2 text-center rounded",
                style: {
                  background: W(x, c),
                  color: A(x, c),
                  fontWeight: 600
                },
                title: `独立参考: ${u(h)} | 实际: ${u(N)}`,
                children: [
                  $(h),
                  q ? " [OK]" : ""
                ]
              },
              m
            );
          })
        ] }, a)) })
      ] }) })
    ] }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          onClick: () => p(!d),
          className: "flex items-center gap-1.5 text-[12px] font-semibold text-[var(--ink-soft)] hover:text-[var(--ink)] transition-colors",
          style: { color: b },
          children: [
            /* @__PURE__ */ e(
              "span",
              {
                className: "inline-block transition-transform duration-200",
                style: {
                  transform: d ? "rotate(90deg)" : "rotate(0deg)"
                },
                children: "▶"
              }
            ),
            "独立性定义与检验方法"
          ]
        }
      ),
      d && /* @__PURE__ */ o("div", { className: "mt-2 rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3 text-[12px] leading-relaxed text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "独立性定义" }),
          /* @__PURE__ */ e("div", { className: "font-mono", children: "X ⊥ Y ⟺ P(X=xᵢ, Y=yⱼ) = P(X=xᵢ)·P(Y=yⱼ)" }),
          /* @__PURE__ */ e("div", { className: "font-mono mt-1", children: "即：p(xᵢ,yⱼ) = pᵢ·qⱼ  对所有 i,j 成立" })
        ] }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "边缘分布计算" }),
          /* @__PURE__ */ e("div", { className: "font-mono", children: "pᵢ = P(X=xᵢ) = Σⱼ P(xᵢ,yⱼ)（行求和）" }),
          /* @__PURE__ */ e("div", { className: "font-mono mt-0.5", children: "qⱼ = P(Y=yⱼ) = Σᵢ P(xᵢ,yⱼ)（列求和）" })
        ] }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "独立性指数" }),
          /* @__PURE__ */ e("div", { className: "font-mono", children: "δ = max{|p(xᵢ,yⱼ) − pᵢ·qⱼ|}" }),
          /* @__PURE__ */ o("div", { className: "mt-1", children: [
            "δ = 0 ⟹ 完全独立；δ 越大，X 与 Y 相关性越强。 本组件中当前 δ =",
            " ",
            /* @__PURE__ */ e(
              "span",
              {
                className: "font-mono font-bold",
                style: {
                  color: c < 0.01 ? y : c < 0.05 ? X : g
                },
                children: u(c)
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ e("div", { className: "font-semibold text-[13px] text-[var(--ink)] mb-1", children: "颜色含义" }),
          /* @__PURE__ */ o("div", { className: "flex gap-3 flex-wrap", children: [
            /* @__PURE__ */ o("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ e(
                "span",
                {
                  className: "inline-block w-3 h-3 rounded",
                  style: { background: y }
                }
              ),
              /* @__PURE__ */ e("span", { children: "绿 = p(xᵢ,yⱼ) ≈ pᵢ·qⱼ（独立）" })
            ] }),
            /* @__PURE__ */ o("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ e(
                "span",
                {
                  className: "inline-block w-3 h-3 rounded",
                  style: { background: X }
                }
              ),
              /* @__PURE__ */ e("span", { children: "黄 = 轻微偏差" })
            ] }),
            /* @__PURE__ */ o("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ e(
                "span",
                {
                  className: "inline-block w-3 h-3 rounded",
                  style: { background: g }
                }
              ),
              /* @__PURE__ */ e("span", { children: "红 = 显著违反独立性" })
            ] })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg border px-3 py-2.5 text-[12px] leading-relaxed",
        style: {
          borderColor: c < 0.01 ? y : c < 0.05 ? X : g,
          background: c < 0.01 ? S : c < 0.05 ? T : R,
          color: c < 0.01 ? y : c < 0.05 ? X : g
        },
        children: [
          c < 5e-3 && /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: "X 与 Y 相互独立！" }),
            " 每格实际概率几乎等于边缘乘积 pᵢ·qⱼ， 知道 X 的取值不改变 Y 的概率分布。"
          ] }),
          c >= 5e-3 && c < 0.05 && /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: "近似独立" }),
            "（δ = ",
            u(c),
            "）。存在轻微统计关联， 在实际问题中通常可视为独立处理。"
          ] }),
          c >= 0.05 && c < 0.12 && /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: "弱相关，不独立" }),
            "（δ = ",
            u(c),
            "）。红色格子的 p(xᵢ,yⱼ) 偏离 pᵢ·qⱼ 较多，X 与 Y 存在可观测的统计依赖关系。"
          ] }),
          c >= 0.12 && /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ e("strong", { children: "强相关，显著不独立" }),
            "（δ = ",
            u(c),
            "）。红色高亮格子 说明联合概率远超或远低于边缘乘积——X 的取值对 Y 的分布有显著影响。"
          ] })
        ]
      }
    )
  ] });
}
const ae = J(ee);
export {
  ae as default
};
