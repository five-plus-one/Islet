using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Script.Serialization;

namespace FivePlusOne.UI {
 public sealed class InstallerAppearance {
  public string Preference { get; private set; }
  public string Theme { get; private set; }
  static bool Valid(string value) { return value=="light" || value=="dark" || value=="system"; }
  public static InstallerAppearance Resolve(string file, bool systemDark, string handoffPreference) {
   string preference=Valid(handoffPreference)?handoffPreference:null;
   if(preference==null)try {
    var info=new FileInfo(file);
    if(info.Exists && info.Length<=4096) {
     var data=new JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(file));
     object version,stored;
     if(data!=null && data.TryGetValue("version",out version) && version is int && (int)version==1 && data.TryGetValue("preference",out stored) && stored is string && Valid((string)stored))preference=(string)stored;
    }
   } catch(IOException) {} catch(UnauthorizedAccessException) {} catch(ArgumentException) {} catch(InvalidOperationException) {}
   preference=preference??"system";
   return new InstallerAppearance {Preference=preference,Theme=preference=="system"?(systemDark?"dark":"light"):preference};
  }
 }
}
