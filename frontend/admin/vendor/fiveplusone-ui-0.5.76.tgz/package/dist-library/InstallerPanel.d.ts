import { type ReactNode } from 'react';
export interface InstallerPanelProps {
    brand: ReactNode;
    showStatusIcon?: boolean;
    preview?: ReactNode;
    productIcon?: ReactNode;
    headerActions?: ReactNode;
    onDrag?: () => void;
    phase: 'checking' | 'ready' | 'downloading' | 'verifying' | 'installing' | 'done' | 'error' | 'confirm';
    transitionKey?: string;
    title: string;
    description: string;
    version?: string;
    progress?: number;
    progressLabel?: string;
    detail?: string;
    children?: ReactNode;
    actions: ReactNode;
    footer?: ReactNode;
}
export declare function InstallerPanel({ brand, showStatusIcon, preview, productIcon, headerActions, onDrag, phase, transitionKey, title, description, version, progress, progressLabel: label, detail, children, actions, footer }: InstallerPanelProps): import("react").JSX.Element;
