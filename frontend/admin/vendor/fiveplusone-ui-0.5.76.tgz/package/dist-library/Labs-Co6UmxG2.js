import { jsxs as o, jsx as e } from "react/jsx-runtime";
import { L as m } from "./LearningSelect-DSx2ZDO6.js";
import { useState as h, useEffect as g } from "react";
function v(r, t, n, i) {
  if (![r, t, n, i].every(Number.isFinite) || n < 0 || i < 0 || r <= n || t <= i)
    throw new RangeError("边长应大于非负误差限");
  const l = r * t, c = t * n + r * i;
  return { nominal: l, linear: c, exact: c + n * i, low: (r - n) * (t - i), high: (r + n) * (t + i) };
}
const x = (r) => (r + 4) * r * r - 10;
function w(r) {
  if (!Number.isInteger(r) || r < 0 || r > 40) throw new RangeError("无效步数");
  let t = 1, n = 2;
  const i = [];
  for (let l = 0; l <= r; l++) {
    const c = (t + n) / 2, a = x(c);
    if (i.push({ k: l, a: t, b: n, mid: c, value: a, bound: (n - t) / 2 }), a === 0) break;
    x(t) * a < 0 ? n = c : t = c;
  }
  return i;
}
function k(r, t) {
  if (!Number.isInteger(t) || t < 1 || t > 2e3) throw new RangeError("无效步数");
  const n = r === "sqrt" ? 1 / Math.sqrt(7) : 0.99, i = r === "sqrt" ? 3 : 1;
  let l = r === "sqrt" ? 4 : 0;
  const c = [];
  for (let a = 1; a <= t; a++) {
    const s = r === "sqrt" ? Math.sqrt(2 * l + 3) : 0.99 * l + 0.01, y = Math.abs(s - l);
    c.push({ k: a, previous: l, x: s, step: y, bound: n / (1 - n) * y, error: Math.abs(i - s) }), l = s;
  }
  return { L: n, root: i, rows: c };
}
const b = {
  border: "1px solid var(--line)",
  borderRadius: 16,
  padding: 20,
  background: "var(--md-sys-color-surface-container-low)",
  color: "var(--ink)",
  margin: "20px 0"
}, p = {
  padding: "8px 14px",
  border: "1px solid var(--line)",
  borderRadius: 8,
  cursor: "pointer",
  background: "var(--bg-app)",
  color: "var(--ink)"
}, d = (r) => Number(r.toPrecision(8)).toString();
function u({
  label: r,
  value: t,
  max: n,
  step: i = 1,
  onChange: l
}) {
  return /* @__PURE__ */ o("label", { style: { display: "block", margin: "14px 0" }, children: [
    r,
    "：",
    t,
    /* @__PURE__ */ e(
      "input",
      {
        "aria-label": r,
        type: "range",
        min: 0,
        max: n,
        step: i,
        value: t,
        onChange: (c) => l(Number(c.target.value)),
        style: { display: "block", width: "100%", accentColor: "#b66b32" }
      }
    )
  ] });
}
function f(r) {
  const [t, n] = h(0), [i, l] = h(!1), c = i && t < r;
  return g(() => {
    if (!c) return;
    const a = setInterval(() => n((s) => Math.min(s + 1, r)), 900);
    return () => clearInterval(a);
  }, [c, r]), {
    step: t,
    setStep: n,
    active: c,
    pause: () => l(!1),
    controls: /* @__PURE__ */ o("div", { style: { display: "flex", gap: 8, flexWrap: "wrap" }, children: [
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          style: p,
          onClick: () => {
            t >= r && n(0), l(!c);
          },
          children: c ? "暂停" : "播放过程"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          style: p,
          disabled: t >= r,
          onClick: () => {
            l(!1), n((a) => Math.min(a + 1, r));
          },
          children: "下一步"
        }
      ),
      /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          style: p,
          onClick: () => {
            l(!1), n(0);
          },
          children: "从头开始"
        }
      )
    ] })
  };
}
function L() {
  const [r, t] = h(0.2), [n, i] = h(0.1), l = v(120, 60, r, n);
  return /* @__PURE__ */ o("section", { style: b, "aria-label": "面积误差实验", children: [
    /* @__PURE__ */ e("h3", { children: "边长的误差，怎样变成面积的误差？" }),
    /* @__PURE__ */ e("p", { children: "桌面长 120 cm、宽 60 cm。拖动误差限，比较一阶估计与完整乘积。" }),
    /* @__PURE__ */ e(
      u,
      {
        label: "长度误差限（cm）",
        value: r,
        max: 5,
        step: 0.1,
        onChange: t
      }
    ),
    /* @__PURE__ */ e(
      u,
      {
        label: "宽度误差限（cm）",
        value: n,
        max: 5,
        step: 0.1,
        onChange: i
      }
    ),
    /* @__PURE__ */ o(
      "svg",
      {
        viewBox: "0 0 440 175",
        role: "img",
        "aria-label": "面积由原矩形、两个一阶误差条带及角部乘积构成",
        style: { width: "100%", maxHeight: 210 },
        children: [
          /* @__PURE__ */ e(
            "rect",
            {
              x: "35",
              y: "15",
              width: "280",
              height: "120",
              fill: "#b66b3228",
              stroke: "#b66b32"
            }
          ),
          /* @__PURE__ */ e("rect", { x: "315", y: "15", width: r * 12, height: "120", fill: "#4e8fa6" }),
          /* @__PURE__ */ e("rect", { x: "35", y: "135", width: "280", height: n * 6, fill: "#c58f37" }),
          /* @__PURE__ */ e("rect", { x: "315", y: "135", width: r * 12, height: n * 6, fill: "#b15b79" }),
          /* @__PURE__ */ e("text", { x: "175", y: "80", textAnchor: "middle", fill: "currentColor", children: "7200 cm²" })
        ]
      }
    ),
    /* @__PURE__ */ e("p", { style: { fontSize: 12 }, children: "图中误差条带放大展示。蓝色：宽 × 长度误差；金色：长 × 宽度误差；粉色：误差乘积。" }),
    /* @__PURE__ */ o("dl", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }, children: [
      /* @__PURE__ */ e("dt", { children: "一阶误差限" }),
      /* @__PURE__ */ o("dd", { children: [
        d(l.linear),
        " cm²"
      ] }),
      /* @__PURE__ */ e("dt", { children: "包含乘积项的误差限" }),
      /* @__PURE__ */ o("dd", { children: [
        d(l.exact),
        " cm²"
      ] }),
      /* @__PURE__ */ e("dt", { children: "面积可能范围" }),
      /* @__PURE__ */ o("dd", { children: [
        d(l.low),
        "～",
        d(l.high),
        " cm²"
      ] }),
      /* @__PURE__ */ e("dt", { children: "一阶相对误差限" }),
      /* @__PURE__ */ o("dd", { children: [
        d(l.linear / l.nominal * 100),
        "%"
      ] })
    ] }),
    /* @__PURE__ */ e("p", { children: "误差越小，乘积项通常越不显著；放大误差后，可以看见一阶估计与完整范围逐渐拉开。" })
  ] });
}
function E() {
  const r = f(12), t = w(r.step).at(-1), n = (i) => 40 + (i - 1) * 440;
  return /* @__PURE__ */ o("section", { style: b, "aria-label": "二分法实验", children: [
    /* @__PURE__ */ e("h3", { children: "每次留下根所在的半个区间" }),
    /* @__PURE__ */ e("p", { children: "求 x³ + 4x² − 10 = 0 在 [1, 2] 内的根。当前中点是近似值，半区间长是误差界。" }),
    r.controls,
    /* @__PURE__ */ e(
      u,
      {
        label: "已完成的区间更新次数",
        value: r.step,
        max: 12,
        onChange: (i) => {
          r.pause(), r.setStep(i);
        }
      }
    ),
    /* @__PURE__ */ o(
      "svg",
      {
        viewBox: "0 0 520 95",
        role: "img",
        "aria-label": `当前区间从 ${t.a} 到 ${t.b}，中点 ${t.mid}`,
        style: { width: "100%" },
        children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: "40",
              x2: "480",
              y1: "45",
              y2: "45",
              stroke: "currentColor",
              opacity: ".25"
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: n(t.a),
              x2: n(t.b),
              y1: "45",
              y2: "45",
              stroke: "#b66b32",
              strokeWidth: "8"
            }
          ),
          /* @__PURE__ */ e("circle", { cx: n(t.mid), cy: "45", r: "6", fill: "#4e8fa6" }),
          /* @__PURE__ */ e("text", { x: "40", y: "80", fill: "currentColor", children: "1" }),
          /* @__PURE__ */ e("text", { x: "475", y: "80", fill: "currentColor", children: "2" })
        ]
      }
    ),
    /* @__PURE__ */ o("p", { children: [
      "当前区间：[",
      d(t.a),
      ", ",
      d(t.b),
      "]"
    ] }),
    /* @__PURE__ */ o("p", { children: [
      "中点：",
      /* @__PURE__ */ e("strong", { children: d(t.mid) }),
      "；函数值：",
      d(t.value)
    ] }),
    /* @__PURE__ */ o("p", { children: [
      "误差界：",
      /* @__PURE__ */ e("strong", { children: d(t.bound) }),
      " ",
      t.bound <= 5e-3 ? "≤ 0.005，已满足示例精度" : "> 0.005，继续缩小区间"
    ] }),
    /* @__PURE__ */ o("p", { children: [
      "下一次保留",
      t.value > 0 ? "左" : "右",
      "半区间。此处“第 0 步”是尚未更新的 [1, 2]，避免把中点编号与更新次数混淆。"
    ] })
  ] });
}
function M() {
  const [r, t] = h("sqrt"), n = f(30), { L: i, root: l, rows: c } = k(r, n.step + 1), a = c.at(-1);
  return /* @__PURE__ */ o("section", { style: b, "aria-label": "不动点迭代实验", children: [
    /* @__PURE__ */ e("h3", { children: "步长小，离根就近了吗？" }),
    /* @__PURE__ */ o("label", { children: [
      "迭代格式",
      " ",
      /* @__PURE__ */ o(
        m,
        {
          value: r,
          onChange: (s) => {
            t(s.target.value), n.pause(), n.setStep(0);
          },
          style: p,
          children: [
            /* @__PURE__ */ e("option", { value: "sqrt", children: "√(2x + 3)，初值 4" }),
            /* @__PURE__ */ e("option", { value: "slow", children: "0.99x + 0.01，初值 0" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ e("p", { children: r === "sqrt" ? "在 [2, 4] 上自映射，L = 1/√7，根为 3。" : "在 [0, 1] 上自映射，L = 0.99，根为 1。" }),
    n.controls,
    /* @__PURE__ */ e(
      u,
      {
        label: "查看的迭代步骤",
        value: n.step + 1,
        max: 31,
        onChange: (s) => {
          n.pause(), n.setStep(Math.max(0, s - 1));
        }
      }
    ),
    /* @__PURE__ */ e("div", { style: { overflowX: "auto" }, children: /* @__PURE__ */ o("table", { style: { width: "100%", fontVariantNumeric: "tabular-nums" }, children: [
      /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ o("tr", { children: [
        /* @__PURE__ */ e("th", { children: "步骤" }),
        /* @__PURE__ */ e("th", { children: "近似值" }),
        /* @__PURE__ */ e("th", { children: "步长" }),
        /* @__PURE__ */ e("th", { children: "后验界" }),
        /* @__PURE__ */ e("th", { children: "真实误差" })
      ] }) }),
      /* @__PURE__ */ e("tbody", { children: c.slice(-6).map((s) => /* @__PURE__ */ o("tr", { children: [
        /* @__PURE__ */ e("td", { children: s.k }),
        /* @__PURE__ */ e("td", { children: d(s.x) }),
        /* @__PURE__ */ e("td", { children: d(s.step) }),
        /* @__PURE__ */ e("td", { children: d(s.bound) }),
        /* @__PURE__ */ e("td", { children: d(s.error) })
      ] }, s.k)) })
    ] }) }),
    /* @__PURE__ */ o("p", { children: [
      "后验界 = ",
      d(i / (1 - i)),
      " × 步长。当前",
      a.bound <= 0.01 ? "已保证" : "尚不能保证",
      "误差 ≤ 0.01。"
    ] }),
    /* @__PURE__ */ o("p", { children: [
      "蓝点是当前近似值，竖线是根 ",
      l,
      "。"
    ] }),
    /* @__PURE__ */ o(
      "svg",
      {
        viewBox: "0 0 500 55",
        role: "img",
        "aria-label": `近似值 ${a.x}，根 ${l}`,
        style: { width: "100%" },
        children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: "25",
              x2: "475",
              y1: "25",
              y2: "25",
              stroke: "currentColor",
              opacity: ".3"
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: r === "sqrt" ? 175 : 475,
              x2: r === "sqrt" ? 175 : 475,
              y1: "8",
              y2: "42",
              stroke: "#b66b32",
              strokeWidth: "3"
            }
          ),
          /* @__PURE__ */ e(
            "circle",
            {
              cx: r === "sqrt" ? 25 + (a.x - 2) * 150 : 25 + a.x * 450,
              cy: "25",
              r: "7",
              fill: "#4e8fa6"
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ e("p", { children: "这里已知根，才能展示真实误差作比较；一般求根时应使用可计算的误差界判断停止。" })
  ] });
}
export {
  E as BisectionLab,
  L as ErrorLab,
  M as IterationLab
};
