import { type ReactNode } from "react";
import { learningExperiments, getInteractive } from "./learning/registry";
import { type LearningSourceResource } from "./LearningSourceView";
export { learningExperiments };
export { getInteractive as getLearningExperiment };
export type { InteractiveMeta as LearningExperimentMeta } from "./learning/registry";
export interface LearningExperimentProps {
    id: string;
    sources?: Record<string, LearningSourceResource>;
    renderSource?: (id: string, kind: "audio" | "document" | "transcript") => ReactNode;
}
export declare function LearningExperiment({ id, renderSource, sources, }: LearningExperimentProps): import("react").JSX.Element;
export declare function ExperimentLibrary({ value, onSelect, onSave, renderSource, sources, }: {
    value?: string;
    onSelect?: (id: string) => void;
    onSave?: (id: string) => Promise<void> | void;
    renderSource?: LearningExperimentProps["renderSource"];
    sources?: LearningExperimentProps["sources"];
}): import("react").JSX.Element;
