import { type PreviewResource } from "./workspace/ResourcePreview";
import { type LectureUtterance, type LectureSection } from "./LectureWorkspace";
import type { AudioPlayerProps } from "./AudioPlayer";
export interface LearningSourceResource {
    title: string;
    resource?: PreviewResource;
    audio?: AudioPlayerProps;
    transcript?: LectureUtterance[];
    chapters?: LectureSection[];
    markdown?: string;
}
export declare function LearningSourceView({ source, }: {
    source: LearningSourceResource;
}): import("react").JSX.Element;
