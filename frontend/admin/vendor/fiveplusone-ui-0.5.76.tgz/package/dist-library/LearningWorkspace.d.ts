import { type ReactNode } from "react";
export * from "./GraphView";
export interface CanvasWorkbenchProps {
    title: string;
    children: ReactNode;
    tools?: ReactNode;
    inspector?: ReactNode;
    source?: string;
    onSourceChange?: (source: string) => void;
    onRun?: () => Promise<void> | void;
    onReset?: () => void;
    onSave?: () => Promise<void> | void;
    loading?: boolean;
    error?: string;
}
/** Rendering engines stay with the host; the workspace owns the shared tools and panels. */
export declare function CanvasWorkbench({ title, children, tools, inspector, source, onSourceChange, onRun, onReset, onSave, loading, error, }: CanvasWorkbenchProps): import("react").JSX.Element;
export interface LectureChapter {
    id: string;
    title: string;
    time: number;
    detail?: string;
}
export declare function ClassroomTimeline({ chapters, currentTime, onSeek, onAddNote, }: {
    chapters: LectureChapter[];
    currentTime: number;
    onSeek: (time: number) => void;
    onAddNote?: (time: number) => void;
}): import("react").JSX.Element;
export declare function LectureDock({ title, children, collapsed, onCollapsedChange, onClose, }: {
    title: string;
    children: ReactNode;
    collapsed: boolean;
    onCollapsedChange: (collapsed: boolean) => void;
    onClose?: () => void;
}): import("react").JSX.Element;
export interface ScoreItem {
    id: string;
    title: string;
    maximum: number;
    awarded: number;
    subjective?: boolean;
    detail?: ReactNode;
}
export declare function QuizScoring({ items, onScoreChange, onComplete, }: {
    items: ScoreItem[];
    onScoreChange: (id: string, value: number) => void;
    onComplete?: () => Promise<void> | void;
}): import("react").JSX.Element;
export declare function QuizSummary({ correct, total, score, maximum, onReview, onRetry, }: {
    correct: number;
    total: number;
    score: number;
    maximum: number;
    onReview: () => void;
    onRetry?: () => void;
}): import("react").JSX.Element;
