import { jsxs as c, jsx as e } from "react/jsx-runtime";
import { L as v } from "./LearningSelect-DSx2ZDO6.js";
import { useState as g, useMemo as f } from "react";
const h = "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", u = "rounded-md border border-[var(--line)] px-2.5 py-1.5 text-sm hover:border-[var(--accent)]";
function b({
  label: t,
  value: o,
  onChange: s
}) {
  return /* @__PURE__ */ c(
    "button",
    {
      type: "button",
      className: u,
      onClick: s,
      "aria-pressed": o,
      children: [
        t,
        " = ",
        o ? "真" : "假"
      ]
    }
  );
}
function q() {
  const [t, o] = g(!0), [s, m] = g(!1), [r, a] = g("imp"), n = r === "imp" ? !t || s : r === "iff" ? t === s : !(t && s) == (!t || !s);
  return /* @__PURE__ */ c("section", { className: h, "aria-label": "真值表实验台", children: [
    /* @__PURE__ */ e("h3", { className: "text-base font-semibold", children: "真值表实验台" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "切换公式和赋值，观察蕴含、等价与德摩根律。" }),
    /* @__PURE__ */ c("div", { className: "mt-3 flex flex-wrap gap-2", children: [
      /* @__PURE__ */ c(
        v,
        {
          className: u,
          value: r,
          onChange: (i) => a(i.target.value),
          "aria-label": "选择公式",
          children: [
            /* @__PURE__ */ e("option", { value: "imp", children: "蕴含" }),
            /* @__PURE__ */ e("option", { value: "iff", children: "双条件" }),
            /* @__PURE__ */ e("option", { value: "demorgan", children: "德摩根律" })
          ]
        }
      ),
      /* @__PURE__ */ e(b, { label: "p", value: t, onChange: () => o((i) => !i) }),
      /* @__PURE__ */ e(b, { label: "q", value: s, onChange: () => m((i) => !i) })
    ] }),
    /* @__PURE__ */ c("div", { className: "mt-4 rounded-lg bg-[var(--bg-muted)] p-4 text-center", children: [
      /* @__PURE__ */ e("div", { className: "font-mono text-lg", children: r === "imp" ? "p → q" : r === "iff" ? "p ↔ q" : "¬(p ∧ q) ↔ (¬p ∨ ¬q)" }),
      /* @__PURE__ */ c("div", { className: "mt-2 text-sm", children: [
        "当前结果：",
        /* @__PURE__ */ e("strong", { className: n ? "text-emerald-600" : "text-rose-600", children: n ? "真" : "假" })
      ] }),
      r === "imp" && /* @__PURE__ */ e("p", { className: "mt-2 text-xs text-[var(--ink-soft)]", children: "蕴含只在前件真、后件假时为假。" })
    ] })
  ] });
}
function L() {
  const [t, o] = g(4), [s, m] = g(3), r = f(
    () => Array.from({ length: t }, (n, l) => l + 1),
    [t]
  ), a = r.filter((n) => n >= s);
  return /* @__PURE__ */ c("section", { className: h, "aria-label": "量词作用域实验台", children: [
    /* @__PURE__ */ e("h3", { className: "text-base font-semibold", children: "量词作用域实验台" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "论域为 1 到 n，谓词 P(x) 表示 x ≥ k。" }),
    /* @__PURE__ */ c("label", { className: "mt-3 block text-sm", children: [
      "论域上界 n：",
      t,
      /* @__PURE__ */ e(
        "input",
        {
          className: "ml-3 align-middle",
          type: "range",
          min: "1",
          max: "8",
          value: t,
          onChange: (n) => o(Number(n.target.value))
        }
      )
    ] }),
    /* @__PURE__ */ c("label", { className: "mt-2 block text-sm", children: [
      "阈值 k：",
      s,
      /* @__PURE__ */ e(
        "input",
        {
          className: "ml-3 align-middle",
          type: "range",
          min: "1",
          max: "9",
          value: s,
          onChange: (n) => m(Number(n.target.value))
        }
      )
    ] }),
    /* @__PURE__ */ c("div", { className: "mt-4 grid gap-2 sm:grid-cols-2", children: [
      /* @__PURE__ */ c("div", { className: "rounded-lg bg-[var(--bg-muted)] p-3 text-sm", children: [
        "满足 P 的元素：{",
        a.join(", ") || "空",
        "}"
      ] }),
      /* @__PURE__ */ c("div", { className: "rounded-lg bg-[var(--bg-muted)] p-3 text-sm", children: [
        "∀xP(x)：",
        /* @__PURE__ */ e("strong", { children: a.length === r.length ? "真" : "假" }),
        /* @__PURE__ */ e("br", {}),
        "∃xP(x)：",
        /* @__PURE__ */ e("strong", { children: a.length > 0 ? "真" : "假" })
      ] })
    ] })
  ] });
}
function N(t) {
  const o = t.every((a, n) => a[n]), s = t.every(
    (a, n) => a.every((l, i) => !l || t[i][n])
  ), m = t.every(
    (a, n) => a.every((l, i) => n === i || !l || !t[i][n])
  ), r = t.every(
    (a, n) => a.every((l, i) => !l || t[i].every((d, p) => !d || t[n][p]))
  );
  return { reflexive: o, symmetric: s, antisymmetric: m, transitive: r };
}
function P() {
  const [t, o] = g([
    [!0, !0, !1],
    [!1, !0, !0],
    [!1, !1, !0]
  ]), s = N(t), m = (r, a) => o(
    (n) => n.map((l, i) => l.map((d, p) => i === r && p === a ? !d : d))
  );
  return /* @__PURE__ */ c("section", { className: h, "aria-label": "关系性质实验台", children: [
    /* @__PURE__ */ e("h3", { className: "text-base font-semibold", children: "关系性质实验台" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "点击关系矩阵中的格子，立即重新判断四种性质。" }),
    /* @__PURE__ */ e("div", { className: "mt-4 grid grid-cols-3 gap-1", style: { maxWidth: 210 }, children: t.flatMap(
      (r, a) => r.map((n, l) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          className: `${u} font-mono ${n ? "bg-[var(--accent-weak)] text-[var(--accent)]" : ""}`,
          onClick: () => m(a, l),
          "aria-label": `关系 ${a + 1} 到 ${l + 1}`,
          children: n ? "1" : "0"
        },
        `${a}-${l}`
      ))
    ) }),
    /* @__PURE__ */ e("div", { className: "mt-4 grid grid-cols-2 gap-2 text-sm sm:grid-cols-4", children: [
      ["自反", s.reflexive],
      ["对称", s.symmetric],
      ["反对称", s.antisymmetric],
      ["传递", s.transitive]
    ].map(([r, a]) => /* @__PURE__ */ c(
      "div",
      {
        className: "rounded-lg bg-[var(--bg-muted)] p-2 text-center",
        children: [
          r,
          /* @__PURE__ */ e("br", {}),
          /* @__PURE__ */ e("strong", { className: a ? "text-emerald-600" : "text-rose-600", children: a ? "满足" : "不满足" })
        ]
      },
      r
    )) })
  ] });
}
function S() {
  const [t, o] = g([0, 1, 1]), s = ["a", "b", "c"], m = new Set(t), r = m.size === t.length, a = m.size === s.length, n = (l, i) => o((d) => d.map((p, x) => x === l ? i : p));
  return /* @__PURE__ */ c("section", { className: h, "aria-label": "函数映射实验台", children: [
    /* @__PURE__ */ e("h3", { className: "text-base font-semibold", children: "函数映射实验台" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "设置 f: {1,2,3} → {a,b,c}，观察单射、满射与双射。" }),
    /* @__PURE__ */ e("div", { className: "mt-4 space-y-2", children: t.map((l, i) => /* @__PURE__ */ c("label", { className: "flex items-center gap-3 text-sm", children: [
      /* @__PURE__ */ c("span", { className: "w-10 font-mono", children: [
        "f(",
        i + 1,
        ")"
      ] }),
      /* @__PURE__ */ e(
        v,
        {
          className: u,
          value: l,
          onChange: (d) => n(i, Number(d.target.value)),
          children: s.map((d, p) => /* @__PURE__ */ e("option", { value: p, children: d }, d))
        }
      )
    ] }, i)) }),
    /* @__PURE__ */ c("div", { className: "mt-4 rounded-lg bg-[var(--bg-muted)] p-3 text-sm", children: [
      "像集：{",
      [...m].sort().map((l) => s[l]).join(", "),
      "}",
      /* @__PURE__ */ e("br", {}),
      "单射：",
      /* @__PURE__ */ e("strong", { children: r ? "是" : "否" }),
      "　满射：",
      /* @__PURE__ */ e("strong", { children: a ? "是" : "否" }),
      "　双射：",
      /* @__PURE__ */ e("strong", { children: r && a ? "是" : "否" })
    ] })
  ] });
}
export {
  S as FunctionMappingLab,
  L as QuantifierScopeLab,
  P as RelationPropertyLab,
  q as TruthTableLab
};
