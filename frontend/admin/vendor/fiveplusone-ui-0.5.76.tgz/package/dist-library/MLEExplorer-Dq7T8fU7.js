import { jsxs as o, jsx as e, Fragment as W } from "react/jsx-runtime";
import { learningAlpha as se } from "./index.js";
import { memo as ce, useState as _, useRef as ae, useCallback as de } from "react";
const j = "var(--fp-primary)", Q = "var(--fp-primary-soft)", v = "#0f766e", J = "#0f766e22", L = "#f59e0b", H = "#5b46e5", V = 520, B = 220, x = 52, xe = 20, s = 18, he = 36, C = V - x - xe, k = B - s - he;
function S(n, i = 4) {
  return n.toFixed(i);
}
function I(n, i, l) {
  if (l.length === 0) return -1 / 0;
  if (n === "exponential") {
    if (i <= 0) return -1 / 0;
    const c = l.length, r = l.reduce((d, f) => d + f, 0);
    return c * Math.log(i) - i * r;
  } else {
    if (i <= 0 || i >= 1) return -1 / 0;
    const c = l.length, r = l.reduce((p, N) => p + (N > 0.5 ? 1 : 0), 0), d = r > 0 ? r * Math.log(i) : 0, f = c - r > 0 ? (c - r) * Math.log(1 - i) : 0;
    return d + f;
  }
}
function fe(n, i) {
  if (i.length === 0) return NaN;
  if (n === "exponential") {
    const l = i.reduce((c, r) => c + r, 0) / i.length;
    return l > 0 ? 1 / l : NaN;
  } else
    return i.reduce((c, r) => c + (r > 0.5 ? 1 : 0), 0) / i.length;
}
function K(n) {
  return n === "exponential" ? { min: 0.05, max: 5, label: "λ（率参数）", unit: "" } : { min: 0.01, max: 0.99, label: "p（成功概率）", unit: "" };
}
function ue(n) {
  return n === "exponential" ? [0.5, 1.2, 0.8, 2.1, 0.3, 1.5, 0.9, 0.4, 1.8, 0.6] : [1, 0, 1, 1, 0, 1, 0, 1, 1, 0];
}
function z(n, i, l) {
  return x + (n - i) / (l - i) * C;
}
function X(n, i, l) {
  if (!isFinite(n)) return s + k;
  const c = (n - i) / (l - i);
  return s + k * (1 - Math.max(0, Math.min(1, c)));
}
function pe(n, i, l, c, r, d, f = 200) {
  const p = [];
  for (let h = 0; h <= f; h++) {
    const m = l + h / f * (c - l), y = I(n, m, i);
    p.push({ theta: m, ll: y });
  }
  if (p.filter((h) => isFinite(h.ll)).length < 2) return { path: "", points: p };
  const a = [];
  let b = !1;
  for (const { theta: h, ll: m } of p) {
    if (!isFinite(m)) {
      b = !1;
      continue;
    }
    const y = z(h, l, c), $ = X(m, r, d);
    b ? a.push(`L${y.toFixed(2)},${$.toFixed(2)}`) : (a.push(`M${y.toFixed(2)},${$.toFixed(2)}`), b = !0);
  }
  return { path: a.join(" "), points: p };
}
function me(n) {
  return n.split(/[\s,;，；]+/).map((i) => parseFloat(i.trim())).filter((i) => isFinite(i));
}
function ge(n, i, l) {
  if (n === "exponential") {
    const c = i.length, r = i.reduce((f, p) => f + p, 0).toFixed(4), d = (parseFloat(r) / c).toFixed(4);
    return `θ̂ = λ̂ = n / Σxᵢ = ${c} / ${r} = 1 / x̄ = 1 / ${d} = ${S(l)}`;
  } else {
    const c = i.length;
    return `θ̂ = p̂ = k / n = ${i.reduce((d, f) => d + (f > 0.5 ? 1 : 0), 0)} / ${c} = ${S(l)}`;
  }
}
function ve(n, i, l, c, r = 200) {
  let d = 1 / 0, f = -1 / 0;
  for (let N = 0; N <= r; N++) {
    const a = l + N / r * (c - l), b = I(n, a, i);
    isFinite(b) && (b < d && (d = b), b > f && (f = b));
  }
  if (!isFinite(d) || !isFinite(f)) return { llMin: -10, llMax: 0 };
  const p = f - d || 1;
  return { llMin: d - p * 0.1, llMax: f + p * 0.15 };
}
function be({
  label: n,
  value: i,
  min: l,
  max: c,
  step: r,
  fmt_fn: d,
  onChange: f,
  color: p
}) {
  return /* @__PURE__ */ o("div", { className: "flex items-center gap-3", children: [
    /* @__PURE__ */ e("span", { className: "w-28 shrink-0 text-[12px] font-semibold text-[var(--ink)]", children: n }),
    /* @__PURE__ */ e(
      "input",
      {
        type: "range",
        min: l,
        max: c,
        step: r,
        value: i,
        onChange: (N) => f(Number(N.target.value)),
        className: "flex-1 h-1.5 cursor-pointer",
        style: { accentColor: p ?? j }
      }
    ),
    /* @__PURE__ */ e(
      "span",
      {
        className: "w-16 shrink-0 rounded-md px-2 py-0.5 text-center text-[12px] font-mono font-bold",
        style: { background: Q, color: p ?? j },
        children: d(i)
      }
    )
  ] });
}
function ye() {
  const [n, i] = _("exponential"), [l, c] = _(
    "0.5, 1.2, 0.8, 2.1, 0.3, 1.5, 0.9, 0.4, 1.8, 0.6"
  ), [r, d] = _(1), [f, p] = _(!1), N = ae(null), a = me(l), b = K(n), h = b.min, m = b.max, y = fe(n, a), { llMin: $, llMax: T } = ve(n, a, h, m), M = a.length > 0 ? I(n, r, a) : NaN, w = a.length > 0 ? I(n, y, a) : NaN, { path: G } = pe(
    n,
    a,
    h,
    m,
    $,
    T
  ), R = de(
    (t) => {
      if (!N.current) return r;
      const u = N.current.getBoundingClientRect(), g = (t - u.left) / u.width * V, F = h + (g - x) / C * (m - h);
      return Math.max(h, Math.min(m, F));
    },
    [h, m, r]
  );
  function Z(t) {
    f && d(R(t.clientX));
  }
  function ee(t) {
    p(!0), d(R(t.clientX));
  }
  function U() {
    p(!1);
  }
  function te(t) {
    d(R(t.clientX));
  }
  function ne(t) {
    t.preventDefault(), t.touches.length > 0 && d(R(t.touches[0].clientX));
  }
  function ie(t) {
    i(t);
    const u = ue(t);
    c(u.join(", "));
    const g = K(t);
    d((g.min + g.max) / 2);
  }
  function oe() {
    if (n === "exponential") {
      const g = [];
      for (let F = 0; F < 10; F++)
        g.push(
          parseFloat((-Math.log(1 - Math.random()) / 1.5).toFixed(3))
        );
      c(g.join(", "));
    } else {
      const u = 0.3 + Math.random() * 0.4, g = [];
      for (let F = 0; F < 10; F++)
        g.push(Math.random() < u ? 1 : 0);
      c(g.join(", "));
    }
  }
  const A = z(
    Math.max(h, Math.min(m, r)),
    h,
    m
  ), P = isFinite(M) ? X(M, $, T) : s + k, E = isFinite(y) ? z(Math.max(h, Math.min(m, y)), h, m) : -999, D = isFinite(w) ? X(w, $, T) : s + k, Y = [];
  {
    const u = (T - $) / 4, g = Math.pow(10, Math.floor(Math.log10(Math.abs(u)))), F = Math.ceil(u / g) * g, re = Math.ceil($ / F) * F;
    for (let O = re; O <= T + 1e-9; O += F)
      Y.push(O);
  }
  const q = [];
  for (let t = 0; t <= 4; t++)
    q.push(h + t / 4 * (m - h));
  const le = a.length > 0 && isFinite(y) ? ge(n, a, y) : "请输入有效样本数据";
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "极大似然估计可视化" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "输入样本，观察对数似然函数曲线；拖动蓝色竖线探索不同 θ 值， 感受 MLE 峰值处恰好是最优估计。" })
    ] }),
    /* @__PURE__ */ o("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3", children: [
      /* @__PURE__ */ o("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ e("span", { className: "w-28 shrink-0 text-[12px] font-semibold text-[var(--ink)]", children: "选分布" }),
        /* @__PURE__ */ e("div", { className: "flex gap-1.5", children: ["exponential", "bernoulli"].map((t) => /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => ie(t),
            className: "rounded-lg px-3 py-1 text-[12px] font-medium transition-colors " + (t === n ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-elevated)] border border-[var(--line)] text-[var(--ink-soft)] hover:border-[var(--accent)]"),
            children: t === "exponential" ? "指数分布 Exp(λ)" : "伯努利分布 B(p)"
          },
          t
        )) })
      ] }),
      /* @__PURE__ */ e(
        be,
        {
          label: `当前 θ（${b.label}）`,
          value: parseFloat(r.toFixed(4)),
          min: h,
          max: m,
          step: n === "exponential" ? 0.01 : 5e-3,
          fmt_fn: (t) => t.toFixed(3),
          onChange: d,
          color: L
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ o("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ o("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: [
          "样本数据",
          a.length > 0 && /* @__PURE__ */ o("span", { className: "ml-2 font-normal text-[var(--ink-soft)]", children: [
            "（n = ",
            a.length,
            "，",
            n === "exponential" ? `x̄ = ${(a.reduce((t, u) => t + u, 0) / a.length).toFixed(4)}` : `k = ${a.filter((t) => t > 0.5).length}`,
            "）"
          ] })
        ] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: oe,
            className: "rounded-lg bg-[var(--bg-elevated)] border border-[var(--line)] px-2.5 py-0.5 text-[11px] text-[var(--ink-soft)] hover:border-[var(--accent)] hover:text-[var(--accent)] transition-colors",
            children: "随机生成"
          }
        )
      ] }),
      /* @__PURE__ */ e(
        "textarea",
        {
          value: l,
          onChange: (t) => c(t.target.value),
          rows: 2,
          className: "w-full rounded-lg border border-[var(--line)] bg-[var(--bg-elevated)] px-3 py-2 text-[12px] font-mono text-[var(--ink)] placeholder-[var(--ink-soft)] focus:outline-none focus:border-[var(--accent)] resize-none",
          placeholder: n === "exponential" ? "输入正实数，逗号/空格分隔，如: 0.5, 1.2, 0.8, 2.1, 0.3" : "输入 0/1 序列，逗号/空格分隔，如: 1, 0, 1, 1, 0, 1",
          spellCheck: !1
        }
      ),
      a.length === 0 && l.trim() !== "" && /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--md-sys-color-error)]", children: "无法解析数据，请检查格式" })
    ] }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ o("div", { className: "mb-1.5 flex items-center justify-between", children: [
        /* @__PURE__ */ e("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "对数似然函数 logL(θ | x₁,…,xₙ)" }),
        /* @__PURE__ */ e("span", { className: "text-[11px] text-[var(--ink-soft)]", children: "点击 / 拖动图表探索 θ" })
      ] }),
      /* @__PURE__ */ o(
        "svg",
        {
          ref: N,
          viewBox: `0 0 ${V} ${B}`,
          className: "w-full rounded-lg border border-[var(--line)] cursor-crosshair select-none",
          style: { background: "var(--bg-muted)", touchAction: "none" },
          onMouseDown: ee,
          onMouseMove: Z,
          onMouseUp: U,
          onMouseLeave: U,
          onClick: te,
          onTouchMove: ne,
          onTouchStart: (t) => {
            t.touches.length > 0 && d(R(t.touches[0].clientX));
          },
          children: [
            /* @__PURE__ */ e(
              "rect",
              {
                x,
                y: s,
                width: C,
                height: k,
                fill: "var(--bg-muted)"
              }
            ),
            Y.map((t) => {
              const u = X(t, $, T);
              return u < s || u > s + k + 1 ? null : /* @__PURE__ */ o("g", { children: [
                /* @__PURE__ */ e(
                  "line",
                  {
                    x1: x,
                    y1: u,
                    x2: x + C,
                    y2: u,
                    stroke: "var(--line)",
                    strokeWidth: 1
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: x - 5,
                    y: u + 3.5,
                    fontSize: "9",
                    textAnchor: "end",
                    fill: "var(--ink-faint)",
                    children: t >= -100 && t <= 100 ? t.toFixed(1) : t.toExponential(1)
                  }
                )
              ] }, t);
            }),
            q.map((t, u) => {
              const g = z(t, h, m);
              return /* @__PURE__ */ o("g", { children: [
                /* @__PURE__ */ e(
                  "line",
                  {
                    x1: g,
                    y1: s,
                    x2: g,
                    y2: s + k,
                    stroke: "var(--line)",
                    strokeWidth: 1
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: g,
                    y: s + k + 14,
                    fontSize: "9",
                    textAnchor: "middle",
                    fill: "var(--ink-faint)",
                    children: t.toFixed(2)
                  }
                )
              ] }, u);
            }),
            /* @__PURE__ */ e(
              "line",
              {
                x1: x,
                y1: s,
                x2: x,
                y2: s + k,
                stroke: "var(--line)"
              }
            ),
            /* @__PURE__ */ e(
              "line",
              {
                x1: x,
                y1: s + k,
                x2: x + C,
                y2: s + k,
                stroke: "var(--line)"
              }
            ),
            /* @__PURE__ */ o(
              "text",
              {
                x: x + C / 2,
                y: B - 4,
                fontSize: "10",
                textAnchor: "middle",
                fill: "var(--ink-faint)",
                children: [
                  "θ（",
                  b.label,
                  b.unit,
                  "）"
                ]
              }
            ),
            G && /* @__PURE__ */ e(
              "path",
              {
                d: G,
                fill: "none",
                stroke: H,
                strokeWidth: 2.2,
                opacity: 0.85
              }
            ),
            a.length === 0 && /* @__PURE__ */ e(
              "text",
              {
                x: x + C / 2,
                y: s + k / 2,
                textAnchor: "middle",
                fontSize: "13",
                fill: "var(--ink-faint)",
                children: "请输入样本数据"
              }
            ),
            a.length > 0 && isFinite(y) && /* @__PURE__ */ o("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: E,
                  y1: s,
                  x2: E,
                  y2: s + k,
                  stroke: v,
                  strokeWidth: 1.8,
                  strokeDasharray: "5 3"
                }
              ),
              /* @__PURE__ */ e(
                "polygon",
                {
                  points: `${E},${D + 10} ${E - 5},${D + 18} ${E + 5},${D + 18}`,
                  fill: v
                }
              ),
              /* @__PURE__ */ e(
                "circle",
                {
                  cx: E,
                  cy: D,
                  r: 5,
                  fill: v,
                  stroke: "white",
                  strokeWidth: 1.5
                }
              ),
              /* @__PURE__ */ o(
                "text",
                {
                  x: E + 7,
                  y: s + 12,
                  fontSize: "10",
                  fill: v,
                  fontWeight: "bold",
                  children: [
                    "θ̂ = ",
                    S(y, 3)
                  ]
                }
              )
            ] }),
            a.length > 0 && /* @__PURE__ */ o("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: A,
                  y1: s,
                  x2: A,
                  y2: s + k,
                  stroke: L,
                  strokeWidth: 2,
                  opacity: 0.9
                }
              ),
              isFinite(M) && /* @__PURE__ */ o(W, { children: [
                /* @__PURE__ */ e(
                  "circle",
                  {
                    cx: A,
                    cy: P,
                    r: 5,
                    fill: L,
                    stroke: "white",
                    strokeWidth: 1.5
                  }
                ),
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: Math.min(A + 8, x + C - 68),
                    y: P - 9,
                    width: 66,
                    height: 16,
                    rx: 4,
                    fill: L,
                    opacity: 0.92
                  }
                ),
                /* @__PURE__ */ o(
                  "text",
                  {
                    x: Math.min(A + 8 + 33, x + C - 35),
                    y: P + 3,
                    fontSize: "10",
                    textAnchor: "middle",
                    fill: "white",
                    fontWeight: "bold",
                    children: [
                      "logL=",
                      M.toFixed(2)
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ o(
                "text",
                {
                  x: Math.min(A + 4, x + C - 54),
                  y: s + k + 14,
                  fontSize: "9",
                  fill: L,
                  fontWeight: "bold",
                  children: [
                    "θ=",
                    r.toFixed(3)
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ o("g", { children: [
              /* @__PURE__ */ e(
                "line",
                {
                  x1: x + 4,
                  y1: s + 8,
                  x2: x + 20,
                  y2: s + 8,
                  stroke: H,
                  strokeWidth: 2
                }
              ),
              /* @__PURE__ */ e("text", { x: x + 23, y: s + 11, fontSize: "9", fill: H, children: "logL(θ)" }),
              a.length > 0 && isFinite(y) && /* @__PURE__ */ o(W, { children: [
                /* @__PURE__ */ e("circle", { cx: x + 70, cy: s + 8, r: 4, fill: v }),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: x + 77,
                    y: s + 11,
                    fontSize: "9",
                    fill: v,
                    fontWeight: "bold",
                    children: "MLE θ̂"
                  }
                )
              ] }),
              /* @__PURE__ */ e("circle", { cx: x + 115, cy: s + 8, r: 4, fill: L }),
              /* @__PURE__ */ e(
                "text",
                {
                  x: x + 122,
                  y: s + 11,
                  fontSize: "9",
                  fill: L,
                  children: "当前 θ（可拖动）"
                }
              )
            ] })
          ]
        }
      )
    ] }),
    a.length > 0 && isFinite(y) && /* @__PURE__ */ o("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-3", children: [
      /* @__PURE__ */ o(
        "div",
        {
          className: "rounded-lg p-3 text-center",
          style: {
            background: J,
            border: `1.5px solid ${v}30`
          },
          children: [
            /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)] mb-0.5", children: "MLE 估计量 θ̂" }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "text-[22px] font-extrabold font-mono",
                style: { color: v },
                children: S(y)
              }
            ),
            /* @__PURE__ */ o("div", { className: "text-[10px] mt-0.5", style: { color: v }, children: [
              "logL(θ̂) = ",
              S(w, 2)
            ] })
          ]
        }
      ),
      /* @__PURE__ */ o(
        "div",
        {
          className: "rounded-lg p-3 text-center",
          style: {
            background: "#f59e0b1f",
            border: `1.5px solid ${L}40`
          },
          children: [
            /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)] mb-0.5", children: "当前游标 θ" }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "text-[22px] font-extrabold font-mono",
                style: { color: L },
                children: S(r)
              }
            ),
            /* @__PURE__ */ o("div", { className: "text-[10px] mt-0.5", style: { color: L }, children: [
              "logL(θ) = ",
              isFinite(M) ? S(M, 2) : "−∞"
            ] })
          ]
        }
      ),
      /* @__PURE__ */ o(
        "div",
        {
          className: "rounded-lg p-3 text-center",
          style: {
            background: Q,
            border: `1.5px solid ${se(j, "30")}`
          },
          children: [
            /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)] mb-0.5", children: "与 MLE 的 logL 差值" }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "text-[22px] font-extrabold font-mono",
                style: {
                  color: isFinite(M) && Math.abs(M - w) < 0.01 ? v : j
                },
                children: isFinite(M) ? (M - w >= 0 ? "+" : "") + S(M - w, 2) : "−∞"
              }
            ),
            /* @__PURE__ */ e("div", { className: "text-[10px] mt-0.5 text-[var(--ink-soft)]", children: isFinite(M) && Math.abs(M - w) < 0.05 ? "近似最优！" : "向左/右移动减小差值" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-lg px-4 py-3 space-y-2",
        style: {
          background: `${v}08`,
          border: `1px solid ${v}30`
        },
        children: [
          /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: n === "exponential" ? "指数分布 MLE 解析解" : "伯努利分布 MLE 解析解" }),
          /* @__PURE__ */ e("div", { className: "font-mono text-[11px] text-[var(--ink-soft)] leading-loose", children: n === "exponential" ? /* @__PURE__ */ o(W, { children: [
            /* @__PURE__ */ e("div", { children: "logL(λ) = n·ln λ − λ·Σxᵢ" }),
            /* @__PURE__ */ o("div", { children: [
              "d logL / dλ = n/λ − Σxᵢ = 0 →",
              " ",
              /* @__PURE__ */ e("strong", { style: { color: v }, children: "λ̂ = n / Σxᵢ = 1 / x̄" })
            ] })
          ] }) : /* @__PURE__ */ o(W, { children: [
            /* @__PURE__ */ e("div", { children: "logL(p) = k·ln p + (n−k)·ln(1−p)" }),
            /* @__PURE__ */ o("div", { children: [
              "d logL / dp = k/p − (n−k)/(1−p) = 0 →",
              " ",
              /* @__PURE__ */ e("strong", { style: { color: v }, children: "p̂ = k / n" })
            ] })
          ] }) }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "rounded-md px-3 py-2 font-mono text-[12px] font-bold",
              style: { background: J, color: v },
              children: le
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ o("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "直觉：" }),
      '极大似然估计寻找"使当前样本出现概率最大"的参数 θ̂。 对数似然曲线的',
      /* @__PURE__ */ e("strong", { style: { color: v }, children: "峰值" }),
      '就是该最优点—— 拖动黄色游标线，你会发现越靠近 θ̂，对数似然越高； 偏离时似然值迅速下降，这正是 MLE 的"几何直觉"。'
    ] })
  ] });
}
const Fe = ce(ye);
export {
  Fe as default
};
