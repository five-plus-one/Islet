import { type ReactNode } from "react";
export declare function AsyncAction({ children, onAction, disabled, confirm, }: {
    children: ReactNode;
    onAction: () => Promise<void> | void;
    disabled?: boolean;
    confirm?: string;
}): import("react").JSX.Element;
export interface ManagementColumn<T> {
    id: string;
    label: string;
    render: (item: T) => ReactNode;
}
export interface ManagementAction<T> {
    id: string;
    label: string;
    run: (item: T) => Promise<void> | void;
    disabled?: (item: T) => boolean;
    confirm?: (item: T) => string;
}
export declare function ManagementTable<T extends {
    id: string;
}>({ title, items, columns, actions, loading, error, toolbar, onLoadMore, hasMore, }: {
    title: string;
    items: T[];
    columns: ManagementColumn<T>[];
    actions?: ManagementAction<T>[];
    loading?: boolean;
    error?: string;
    toolbar?: ReactNode;
    onLoadMore?: () => void;
    hasMore?: boolean;
}): import("react").JSX.Element;
export interface LedgerEntry {
    id: string;
    title: string;
    date: string;
    amount: number;
    balance?: number;
    status?: string;
}
export declare function LedgerView({ entries, loading, error, }: {
    entries: LedgerEntry[];
    loading?: boolean;
    error?: string;
}): import("react").JSX.Element;
export declare function CreditsOverview({ balance, reserved, children, onTopUp, }: {
    balance: number;
    reserved?: number;
    children?: ReactNode;
    onTopUp?: () => void;
}): import("react").JSX.Element;
export interface CapacityItem {
    id: string;
    label: string;
    used: number;
    limit: number;
    unit: string;
}
export declare function CapacityOverview({ items, onManage, }: {
    items: CapacityItem[];
    onManage?: (id: string) => void;
}): import("react").JSX.Element;
export interface AccessInheritance {
    source: string;
    role: string;
    inherited: boolean;
}
export declare function PermissionSummary({ items, canManage, onManage, }: {
    items: AccessInheritance[];
    canManage?: boolean;
    onManage?: () => void;
}): import("react").JSX.Element;
export interface SettingsField {
    id: string;
    label: string;
    description?: string;
    value: string;
    options?: {
        value: string;
        label: string;
    }[];
    secret?: boolean;
    disabled?: boolean;
}
export declare function SettingsForm({ title, fields, onChange, onSave, }: {
    title: string;
    fields: SettingsField[];
    onChange: (id: string, value: string) => void;
    onSave: () => Promise<void> | void;
}): import("react").JSX.Element;
export interface SetupStep {
    id: string;
    title: string;
    description?: string;
    content: ReactNode;
    canContinue?: boolean;
}
export declare function SetupWizard({ steps, step, onStepChange, onComplete, }: {
    steps: SetupStep[];
    step: number;
    onStepChange: (step: number) => void;
    onComplete: () => Promise<void> | void;
}): import("react").JSX.Element;
