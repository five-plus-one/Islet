import { jsxs as t, jsx as e } from "react/jsx-runtime";
import { learningAlpha as I } from "./index.js";
import { memo as ue, useState as E, Fragment as ve } from "react";
const h = "var(--fp-primary)", _ = "var(--fp-primary-soft)", J = "var(--fp-primary)", b = "#0d9488", z = "color-mix(in srgb, #ccfbf1 24%, var(--fp-surface))", L = "#ea580c", ne = "color-mix(in srgb, #ffedd5 24%, var(--fp-surface))", K = "var(--bg-muted)";
function oe(o) {
  return `color-mix(in srgb, var(--fp-primary) ${Math.round(12 + Math.max(0, Math.min(1, o)) * 88)}%, var(--fp-surface))`;
}
const le = [
  [0.1, 0.08, 0.06],
  [0.12, 0.18, 0.1],
  [0.08, 0.14, 0.14]
], ge = [
  [0.2, 0.1, 0.1],
  [0.1, 0.2, 0.1],
  [0.1, 0.1, 0]
], be = [
  [0.15, 0.15, 0.1],
  [0.15, 0.1, 0.15],
  [0.1, 0.05, 0.05]
], S = ["x₁", "x₂", "x₃"], C = ["y₁", "y₂", "y₃"];
function Q(o) {
  let f = 0;
  for (const c of o) for (const d of c) f += Math.max(0, d);
  return f === 0 ? o.map((c) => c.map(() => 1 / 9)) : o.map((c) => c.map((d) => Math.max(0, d) / f));
}
function U(o) {
  return o.map((f) => f.reduce((c, d) => c + d, 0));
}
function Z(o) {
  const f = o[0].length;
  return Array.from(
    { length: f },
    (c, d) => o.reduce((a, y) => a + y[d], 0)
  );
}
function u(o) {
  return o.toFixed(4);
}
function ye(o) {
  return Array.from(
    { length: o },
    () => Array.from({ length: o }, () => Math.random())
  );
}
const p = 56, M = 30, A = 24;
function ae({
  values: o,
  labels: f,
  color: c,
  lightColor: d,
  highlightIdx: a,
  direction: y
}) {
  const s = Math.max(...o, 1e-3);
  if (y === "horizontal")
    return /* @__PURE__ */ e("div", { className: "flex flex-col gap-1.5", children: o.map((m, x) => {
      const i = m / s, r = a === x;
      return /* @__PURE__ */ t(
        "div",
        {
          className: "flex items-center gap-2",
          style: {
            opacity: a === null || r ? 1 : 0.3,
            transition: "opacity 0.25s"
          },
          children: [
            /* @__PURE__ */ e(
              "span",
              {
                className: "text-[12px] font-semibold w-6 text-right flex-shrink-0",
                style: { color: r ? c : "var(--ink-faint)" },
                children: f[x]
              }
            ),
            /* @__PURE__ */ t(
              "div",
              {
                className: "relative h-7 rounded-md overflow-hidden flex-1",
                style: { background: d, minWidth: 60 },
                children: [
                  /* @__PURE__ */ e(
                    "div",
                    {
                      className: "absolute inset-y-0 left-0 rounded-md",
                      style: {
                        width: `${i * 100}%`,
                        background: r ? c : `${I(c, "80")}`,
                        transition: "width 0.35s cubic-bezier(0.4,0,0.2,1)"
                      }
                    }
                  ),
                  /* @__PURE__ */ e(
                    "span",
                    {
                      className: "absolute inset-0 flex items-center justify-end pr-2 text-[11px] font-mono font-bold",
                      style: { color: i > 0.5 ? "#fff" : c },
                      children: u(m)
                    }
                  )
                ]
              }
            )
          ]
        },
        x
      );
    }) });
  const g = 80;
  return /* @__PURE__ */ e(
    "div",
    {
      className: "flex gap-3 items-end justify-center",
      style: { height: g + 36 },
      children: o.map((m, x) => {
        const i = m / s, r = a === x, v = Math.round(i * g);
        return /* @__PURE__ */ t(
          "div",
          {
            className: "flex flex-col items-center gap-1",
            style: {
              opacity: a === null || r ? 1 : 0.3,
              transition: "opacity 0.25s"
            },
            children: [
              /* @__PURE__ */ e(
                "span",
                {
                  className: "text-[10px] font-mono font-bold",
                  style: { color: r ? c : "var(--ink-faint)" },
                  children: u(m)
                }
              ),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "w-8 rounded-t-md",
                  style: {
                    height: v,
                    background: r ? c : `${I(c, "80")}`,
                    minHeight: 2,
                    transition: "height 0.35s cubic-bezier(0.4,0,0.2,1)"
                  }
                }
              ),
              /* @__PURE__ */ e(
                "span",
                {
                  className: "text-[12px] font-semibold",
                  style: { color: r ? c : "var(--ink-faint)" },
                  children: f[x]
                }
              )
            ]
          },
          x
        );
      })
    }
  );
}
function Ne({
  p: o,
  selectedRow: f,
  selectedCol: c,
  mode: d,
  onRowClick: a,
  onColClick: y
}) {
  const s = Math.max(...o.flatMap((i) => i), 1e-3), g = o.length, m = M + g * p + 4, x = A + g * p + 4;
  return /* @__PURE__ */ t(
    "svg",
    {
      viewBox: `0 0 ${m} ${x}`,
      className: "w-full",
      style: { maxWidth: 240, userSelect: "none" },
      children: [
        C.map((i, r) => {
          const v = d === "colSelect" && c === r;
          return /* @__PURE__ */ t(
            "g",
            {
              style: { cursor: "pointer" },
              onClick: () => y(r),
              children: [
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: M + r * p,
                    y: 0,
                    width: p,
                    height: A,
                    fill: v ? _ : "transparent",
                    rx: 4
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: M + r * p + p / 2,
                    y: A - 6,
                    textAnchor: "middle",
                    fontSize: "12",
                    fontWeight: v ? "800" : "600",
                    fill: v ? h : "var(--ink-soft)",
                    children: i
                  }
                )
              ]
            },
            r
          );
        }),
        S.map((i, r) => {
          const v = d === "rowSelect" && f === r;
          return /* @__PURE__ */ t(
            "g",
            {
              style: { cursor: "pointer" },
              onClick: () => a(r),
              children: [
                /* @__PURE__ */ e(
                  "rect",
                  {
                    x: 0,
                    y: A + r * p,
                    width: M,
                    height: p,
                    fill: v ? _ : "transparent",
                    rx: 4
                  }
                ),
                /* @__PURE__ */ e(
                  "text",
                  {
                    x: M - 5,
                    y: A + r * p + p / 2 + 4,
                    textAnchor: "end",
                    fontSize: "12",
                    fontWeight: v ? "800" : "600",
                    fill: v ? h : "var(--ink-soft)",
                    children: i
                  }
                )
              ]
            },
            r
          );
        }),
        o.map(
          (i, r) => i.map((v, N) => {
            const w = M + N * p, $ = A + r * p, X = v / s, B = d === "rowSelect" && f === r, P = d === "colSelect" && c === N, T = d === "rowSelect" && f !== null && f !== r || d === "colSelect" && c !== null && c !== N, R = oe(X), W = X > 0.55 ? "var(--fp-on-primary)" : h;
            return /* @__PURE__ */ t("g", { children: [
              /* @__PURE__ */ e(
                "rect",
                {
                  x: w + 1,
                  y: $ + 1,
                  width: p - 2,
                  height: p - 2,
                  rx: 6,
                  fill: R,
                  opacity: T ? 0.2 : 1,
                  stroke: B || P ? h : "transparent",
                  strokeWidth: B || P ? 2.5 : 0,
                  style: { transition: "opacity 0.25s" }
                }
              ),
              /* @__PURE__ */ e(
                "text",
                {
                  x: w + p / 2,
                  y: $ + p / 2 + 4,
                  textAnchor: "middle",
                  fontSize: "11",
                  fontWeight: "700",
                  fill: W,
                  opacity: T ? 0.3 : 1,
                  style: { pointerEvents: "none", transition: "opacity 0.25s" },
                  children: u(v)
                }
              )
            ] }, `${r}-${N}`);
          })
        ),
        d === "rowSelect" && f !== null && /* @__PURE__ */ e(
          "rect",
          {
            x: M + 1,
            y: A + f * p + 1,
            width: g * p - 2,
            height: p - 2,
            rx: 6,
            fill: "none",
            stroke: h,
            strokeWidth: 2.5,
            strokeDasharray: "5 3",
            opacity: 0.6,
            style: { pointerEvents: "none" }
          }
        ),
        d === "colSelect" && c !== null && /* @__PURE__ */ e(
          "rect",
          {
            x: M + c * p + 1,
            y: A + 1,
            width: p - 2,
            height: g * p - 2,
            rx: 6,
            fill: "none",
            stroke: b,
            strokeWidth: 2.5,
            strokeDasharray: "5 3",
            opacity: 0.6,
            style: { pointerEvents: "none" }
          }
        )
      ]
    }
  );
}
function re({ p: o, label: f }) {
  const c = Math.max(...o.flatMap((x) => x), 1e-3), d = o.length, a = 44, y = 24, s = 18, g = y + d * a + 4, m = s + d * a + 4;
  return /* @__PURE__ */ t("div", { className: "flex flex-col items-center gap-1", children: [
    /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: f }),
    /* @__PURE__ */ t("svg", { viewBox: `0 0 ${g} ${m}`, style: { width: g, userSelect: "none" }, children: [
      C.map((x, i) => /* @__PURE__ */ e(
        "text",
        {
          x: y + i * a + a / 2,
          y: s - 4,
          textAnchor: "middle",
          fontSize: "10",
          fill: "var(--ink-faint)",
          children: x
        },
        i
      )),
      S.map((x, i) => /* @__PURE__ */ e(
        "text",
        {
          x: y - 4,
          y: s + i * a + a / 2 + 4,
          textAnchor: "end",
          fontSize: "10",
          fill: "var(--ink-faint)",
          children: x
        },
        i
      )),
      o.map(
        (x, i) => x.map((r, v) => {
          const N = r / c, w = N > 0.55 ? "var(--fp-on-primary)" : h;
          return /* @__PURE__ */ t("g", { children: [
            /* @__PURE__ */ e(
              "rect",
              {
                x: y + v * a + 1,
                y: s + i * a + 1,
                width: a - 2,
                height: a - 2,
                rx: 5,
                fill: oe(N)
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: y + v * a + a / 2,
                y: s + i * a + a / 2 + 4,
                textAnchor: "middle",
                fontSize: "9",
                fontWeight: "700",
                fill: w,
                style: { pointerEvents: "none" },
                children: r.toFixed(2)
              }
            )
          ] }, `${i}-${v}`);
        })
      )
    ] })
  ] });
}
function ke() {
  const [o, f] = E("main"), [c, d] = E(le.map((l) => [...l])), [a, y] = E("rowSelect"), [s, g] = E(null), [m, x] = E(null), [i, r] = E(null), [v, N] = E(""), w = Q(c), $ = U(w), X = Z(w), B = a === "rowSelect" && s !== null ? w[s] : null, P = a === "colSelect" && m !== null ? w.map((l) => l[m]) : null, T = a === "rowSelect" && s !== null ? $[s] : a === "colSelect" && m !== null ? X[m] : null, R = a === "rowSelect" && s !== null ? `P(X=x${s + 1}) = Σⱼ p(x${s + 1},yⱼ)` : a === "colSelect" && m !== null ? `P(Y=y${m + 1}) = Σᵢ p(xᵢ,y${m + 1})` : "";
  function W(l, n, Y) {
    N(Y), r([l, n]);
    const k = parseFloat(Y);
    !isNaN(k) && k >= 0 && d(
      (V) => V.map(
        (q, pe) => q.map((fe, he) => pe === l && he === n ? k : fe)
      )
    );
  }
  function ce(l, n) {
    r([l, n]), N(c[l][n].toString());
  }
  function se() {
    r(null), N("");
  }
  function ie() {
    d(ye(3)), g(null), x(null);
  }
  function de() {
    d(le.map((l) => [...l])), g(null), x(null);
  }
  function me(l) {
    a === "rowSelect" && (g((n) => n === l ? null : l), x(null));
  }
  function xe(l) {
    a === "colSelect" && (x((n) => n === l ? null : l), g(null));
  }
  function j(l) {
    y(l), g(null), x(null);
  }
  const G = Q(ge), F = Q(be), D = U(G), ee = Z(G), O = U(F), te = Z(F), H = D.every((l, n) => Math.abs(l - O[n]) < 1e-3) && ee.every((l, n) => Math.abs(l - te[n]) < 1e-3);
  return /* @__PURE__ */ t("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ t("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "边缘分布提取演示" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "点击行号提取 X 的边缘分布（对 Y 求和），点击列号提取 Y 的边缘分布（对 X 求和）——直观体会「投影」的含义。" })
    ] }),
    /* @__PURE__ */ e("div", { className: "flex gap-1 rounded-lg bg-[var(--bg-muted)] p-1", children: [
      { key: "main", label: "主探索器" },
      { key: "counterexample", label: "反例：同边缘，异联合" }
    ].map(({ key: l, label: n }) => /* @__PURE__ */ e(
      "button",
      {
        type: "button",
        onClick: () => f(l),
        className: "flex-1 rounded-md py-1.5 text-[12px] font-medium transition-colors " + (o === l ? "bg-[var(--bg-elevated)] shadow-sm text-[var(--ink)]" : "text-[var(--ink-soft)] hover:text-[var(--ink)]"),
        children: n
      },
      l
    )) }),
    o === "main" && /* @__PURE__ */ t("div", { className: "space-y-4", children: [
      /* @__PURE__ */ t("div", { className: "flex flex-wrap gap-2 items-center", children: [
        /* @__PURE__ */ e("span", { className: "text-[12px] text-[var(--ink-soft)]", children: "投影方向：" }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => j("rowSelect"),
            className: "rounded-lg px-3 py-1 text-[12px] font-medium transition-colors " + (a === "rowSelect" ? "text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)]"),
            style: { background: a === "rowSelect" ? h : void 0 },
            children: "固定 X → 对 Y 求和"
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: () => j("colSelect"),
            className: "rounded-lg px-3 py-1 text-[12px] font-medium transition-colors " + (a === "colSelect" ? "text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)]"),
            style: { background: a === "colSelect" ? b : void 0 },
            children: "固定 Y → 对 X 求和"
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: ie,
            className: "ml-auto rounded-lg px-2.5 py-1 text-[12px] font-medium bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--accent-weak,#ede9fe)] transition-colors",
            children: "随机"
          }
        ),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: de,
            className: "rounded-lg px-2.5 py-1 text-[12px] font-medium bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--line,#e9ebf2)] transition-colors",
            children: "重置"
          }
        )
      ] }),
      /* @__PURE__ */ e(
        "div",
        {
          className: "rounded-lg px-3 py-2 text-[12px] font-medium border",
          style: {
            borderColor: a === "rowSelect" ? `${I(h, "40")}` : `${b}40`,
            background: a === "rowSelect" ? _ : z,
            color: a === "rowSelect" ? h : b
          },
          children: a === "rowSelect" ? "点击左侧行标签（x₁/x₂/x₃）高亮整行，右侧条形图即为 P(X=xᵢ) = Σⱼ p(xᵢ,yⱼ)" : "点击顶部列标签（y₁/y₂/y₃）高亮整列，下方条形图即为 P(Y=yⱼ) = Σᵢ p(xᵢ,yⱼ)"
        }
      ),
      /* @__PURE__ */ t("div", { className: "flex flex-col gap-4 lg:flex-row lg:gap-6", children: [
        /* @__PURE__ */ t("div", { className: "flex-shrink-0", children: [
          /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--ink-soft)] mb-1.5", children: "输入任意正数（自动归一化）" }),
          /* @__PURE__ */ t(
            "div",
            {
              className: "grid gap-1",
              style: { gridTemplateColumns: "auto repeat(3, 68px)" },
              children: [
                /* @__PURE__ */ e("div", { className: "text-[11px] text-[var(--ink-soft)] flex items-end justify-center pb-1", children: "X↓ Y→" }),
                C.map((l) => /* @__PURE__ */ e(
                  "div",
                  {
                    className: "text-center text-[12px] font-semibold text-[var(--ink)]",
                    children: l
                  },
                  l
                )),
                c.map((l, n) => /* @__PURE__ */ t(ve, { children: [
                  /* @__PURE__ */ e("div", { className: "flex items-center justify-center text-[12px] font-semibold text-[var(--ink)]", children: S[n] }),
                  l.map((Y, k) => {
                    const V = i !== null && i[0] === n && i[1] === k;
                    return /* @__PURE__ */ e(
                      "input",
                      {
                        type: "number",
                        min: "0",
                        step: "0.01",
                        value: V ? v : Y.toFixed(2),
                        onChange: (q) => W(n, k, q.target.value),
                        onFocus: () => ce(n, k),
                        onBlur: se,
                        className: "w-full rounded-md border border-[var(--line)] bg-[var(--bg-muted)] px-1 py-1.5 text-center text-[12px] font-mono text-[var(--ink)] focus:border-[var(--accent)] focus:outline-none focus:ring-1 focus:ring-[var(--accent)]"
                      },
                      `inp-${n}-${k}`
                    );
                  })
                ] }, `row-${n}`))
              ]
            }
          ),
          /* @__PURE__ */ t("div", { className: "mt-1.5 text-[11px] text-[var(--ink-soft)]", children: [
            "合计：",
            /* @__PURE__ */ e("span", { className: "font-mono font-semibold text-[var(--ink)]", children: c.flatMap((l) => l).reduce((l, n) => l + Math.max(0, n), 0).toFixed(4) }),
            "（归一化后 = 1）"
          ] })
        ] }),
        /* @__PURE__ */ t("div", { className: "flex-shrink-0 flex flex-col gap-1", children: [
          /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--ink-soft)]", children: "联合分布热力图（可点击行/列标签）" }),
          /* @__PURE__ */ e(
            Ne,
            {
              p: w,
              selectedRow: s,
              selectedCol: m,
              mode: a,
              onRowClick: me,
              onColClick: xe
            }
          )
        ] }),
        /* @__PURE__ */ e("div", { className: "flex-1 min-w-0", children: a === "rowSelect" ? /* @__PURE__ */ t("div", { className: "space-y-3", children: [
          /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--ink-soft)]", children: "X 的边缘分布 P(X=xᵢ) ← 对该行所有 y 值求和" }),
          /* @__PURE__ */ e(
            ae,
            {
              values: $,
              labels: S,
              color: h,
              lightColor: _,
              highlightIdx: s,
              direction: "horizontal"
            }
          ),
          s !== null && B !== null && /* @__PURE__ */ t(
            "div",
            {
              className: "rounded-lg p-3 space-y-2",
              style: {
                background: _,
                border: `1px solid ${I(h, "40")}`
              },
              children: [
                /* @__PURE__ */ t(
                  "div",
                  {
                    className: "text-[12px] font-semibold",
                    style: { color: h },
                    children: [
                      S[s],
                      " 这一行的分解"
                    ]
                  }
                ),
                /* @__PURE__ */ t("div", { className: "flex gap-2 flex-wrap", children: [
                  B.map((l, n) => /* @__PURE__ */ t("div", { className: "text-center", children: [
                    /* @__PURE__ */ t("div", { className: "text-[10px] text-[var(--ink-soft)]", children: [
                      "p(x",
                      s + 1,
                      ",",
                      C[n],
                      ")"
                    ] }),
                    /* @__PURE__ */ e(
                      "div",
                      {
                        className: "rounded-md px-2 py-1 text-[12px] font-mono font-bold",
                        style: {
                          background: "var(--bg-elevated)",
                          color: h
                        },
                        children: u(l)
                      }
                    )
                  ] }, n)),
                  /* @__PURE__ */ t(
                    "div",
                    {
                      className: "flex items-center text-[12px] font-semibold",
                      style: { color: h },
                      children: [
                        "= ",
                        u($[s])
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ t(
                  "div",
                  {
                    className: "text-[11px] font-mono",
                    style: { color: `${I(h, "cc")}` },
                    children: [
                      R,
                      " =",
                      " ",
                      B.map(u).join(" + "),
                      " =",
                      " ",
                      u(T)
                    ]
                  }
                )
              ]
            }
          )
        ] }) : /* @__PURE__ */ t("div", { className: "space-y-3", children: [
          /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--ink-soft)]", children: "Y 的边缘分布 P(Y=yⱼ) ← 对该列所有 x 值求和" }),
          /* @__PURE__ */ e(
            ae,
            {
              values: X,
              labels: C,
              color: b,
              lightColor: z,
              highlightIdx: m,
              direction: "horizontal"
            }
          ),
          m !== null && P !== null && /* @__PURE__ */ t(
            "div",
            {
              className: "rounded-lg p-3 space-y-2",
              style: {
                background: z,
                border: `1px solid ${b}40`
              },
              children: [
                /* @__PURE__ */ t(
                  "div",
                  {
                    className: "text-[12px] font-semibold",
                    style: { color: b },
                    children: [
                      C[m],
                      " 这一列的分解"
                    ]
                  }
                ),
                /* @__PURE__ */ t("div", { className: "flex gap-2 flex-wrap", children: [
                  P.map((l, n) => /* @__PURE__ */ t("div", { className: "text-center", children: [
                    /* @__PURE__ */ t("div", { className: "text-[10px] text-[var(--ink-soft)]", children: [
                      "p(",
                      S[n],
                      ",y",
                      m + 1,
                      ")"
                    ] }),
                    /* @__PURE__ */ e(
                      "div",
                      {
                        className: "rounded-md px-2 py-1 text-[12px] font-mono font-bold",
                        style: {
                          background: "var(--bg-elevated)",
                          color: b
                        },
                        children: u(l)
                      }
                    )
                  ] }, n)),
                  /* @__PURE__ */ t(
                    "div",
                    {
                      className: "flex items-center text-[12px] font-semibold",
                      style: { color: b },
                      children: [
                        "= ",
                        u(X[m])
                      ]
                    }
                  )
                ] }),
                /* @__PURE__ */ t(
                  "div",
                  {
                    className: "text-[11px] font-mono",
                    style: { color: `${b}cc` },
                    children: [
                      R,
                      " =",
                      " ",
                      P.map(u).join(" + "),
                      " =",
                      " ",
                      u(T)
                    ]
                  }
                )
              ]
            }
          )
        ] }) })
      ] }),
      /* @__PURE__ */ t("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ t("div", { className: "rounded-lg p-3", style: { background: K }, children: [
          /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)] mb-2", children: "X 的边缘分布" }),
          /* @__PURE__ */ e("div", { className: "flex gap-2", children: $.map((l, n) => /* @__PURE__ */ t("div", { className: "flex-1 text-center", children: [
            /* @__PURE__ */ e("div", { className: "text-[11px] text-[var(--ink-soft)]", children: S[n] }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "mt-1 rounded-md py-1 text-[12px] font-mono font-bold",
                style: {
                  background: a === "rowSelect" && s === n ? h : _,
                  color: a === "rowSelect" && s === n ? "#fff" : h,
                  transition: "background 0.2s"
                },
                children: u(l)
              }
            )
          ] }, n)) })
        ] }),
        /* @__PURE__ */ t("div", { className: "rounded-lg p-3", style: { background: K }, children: [
          /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)] mb-2", children: "Y 的边缘分布" }),
          /* @__PURE__ */ e("div", { className: "flex gap-2", children: X.map((l, n) => /* @__PURE__ */ t("div", { className: "flex-1 text-center", children: [
            /* @__PURE__ */ e("div", { className: "text-[11px] text-[var(--ink-soft)]", children: C[n] }),
            /* @__PURE__ */ e(
              "div",
              {
                className: "mt-1 rounded-md py-1 text-[12px] font-mono font-bold",
                style: {
                  background: a === "colSelect" && m === n ? b : z,
                  color: a === "colSelect" && m === n ? "#fff" : b,
                  transition: "background 0.2s"
                },
                children: u(l)
              }
            )
          ] }, n)) })
        ] })
      ] }),
      /* @__PURE__ */ t("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
        /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "边缘分布定义：" }),
        /* @__PURE__ */ e("span", { className: "font-mono ml-1", children: "P(X=xᵢ) = Σⱼ p(xᵢ,yⱼ)" }),
        " ",
        "即把联合分布表按行求和（对 Y「积分」掉）；",
        /* @__PURE__ */ e("span", { className: "font-mono ml-1", children: "P(Y=yⱼ) = Σᵢ p(xᵢ,yⱼ)" }),
        " ",
        "即按列求和（对 X「积分」掉）。边缘分布是联合分布在某一维度的「投影」。"
      ] })
    ] }),
    o === "counterexample" && /* @__PURE__ */ t("div", { className: "space-y-4", children: [
      /* @__PURE__ */ t(
        "div",
        {
          className: "rounded-lg border px-3 py-2.5 text-[13px] leading-relaxed",
          style: {
            borderColor: `${L}40`,
            background: ne,
            color: L
          },
          children: [
            /* @__PURE__ */ e("span", { className: "font-bold", children: "关键洞察：" }),
            "知道边缘分布 P(X) 和 P(Y)，",
            /* @__PURE__ */ e("b", { children: "不能" }),
            "唯一确定联合分布 P(X,Y)！ 下面两个联合分布完全不同，但它们的边缘分布却完全一致。"
          ]
        }
      ),
      /* @__PURE__ */ t("div", { className: "flex flex-col gap-4 sm:flex-row sm:gap-6 justify-center", children: [
        /* @__PURE__ */ t("div", { className: "flex flex-col items-center gap-3", children: [
          /* @__PURE__ */ e(re, { p: G, label: "联合分布 A" }),
          /* @__PURE__ */ t("div", { className: "text-[11px] text-[var(--ink-soft)] text-center", children: [
            /* @__PURE__ */ e("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "边缘分布（A）" }),
            /* @__PURE__ */ e("div", { className: "flex gap-2 mb-1", children: D.map((l, n) => /* @__PURE__ */ t("div", { className: "text-center", children: [
              /* @__PURE__ */ e("div", { className: "text-[10px]", children: S[n] }),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "font-mono font-bold",
                  style: { color: h },
                  children: u(l)
                }
              )
            ] }, n)) }),
            /* @__PURE__ */ e("div", { className: "flex gap-2", children: ee.map((l, n) => /* @__PURE__ */ t("div", { className: "text-center", children: [
              /* @__PURE__ */ e("div", { className: "text-[10px]", children: C[n] }),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "font-mono font-bold",
                  style: { color: J },
                  children: u(l)
                }
              )
            ] }, n)) })
          ] })
        ] }),
        /* @__PURE__ */ e("div", { className: "flex items-center justify-center", children: /* @__PURE__ */ t("div", { className: "flex flex-col items-center gap-1", children: [
          /* @__PURE__ */ e("div", { className: "text-2xl font-bold", style: { color: L }, children: "≠" }),
          /* @__PURE__ */ t("div", { className: "text-[11px] text-[var(--ink-soft)] text-center", children: [
            "联合",
            /* @__PURE__ */ e("br", {}),
            "不同"
          ] })
        ] }) }),
        /* @__PURE__ */ t("div", { className: "flex flex-col items-center gap-3", children: [
          /* @__PURE__ */ e(re, { p: F, label: "联合分布 B" }),
          /* @__PURE__ */ t("div", { className: "text-[11px] text-[var(--ink-soft)] text-center", children: [
            /* @__PURE__ */ e("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "边缘分布（B）" }),
            /* @__PURE__ */ e("div", { className: "flex gap-2 mb-1", children: O.map((l, n) => /* @__PURE__ */ t("div", { className: "text-center", children: [
              /* @__PURE__ */ e("div", { className: "text-[10px]", children: S[n] }),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "font-mono font-bold",
                  style: { color: h },
                  children: u(l)
                }
              )
            ] }, n)) }),
            /* @__PURE__ */ e("div", { className: "flex gap-2", children: te.map((l, n) => /* @__PURE__ */ t("div", { className: "text-center", children: [
              /* @__PURE__ */ e("div", { className: "text-[10px]", children: C[n] }),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "font-mono font-bold",
                  style: { color: J },
                  children: u(l)
                }
              )
            ] }, n)) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ t(
        "div",
        {
          className: "rounded-lg border px-4 py-3 text-center",
          style: {
            borderColor: H ? `${b}40` : `${L}40`,
            background: H ? z : ne
          },
          children: [
            /* @__PURE__ */ e(
              "div",
              {
                className: "text-[14px] font-bold",
                style: { color: H ? b : L },
                children: H ? "边缘分布完全相同" : "边缘分布有差异"
              }
            ),
            /* @__PURE__ */ e(
              "div",
              {
                className: "text-[12px] mt-1",
                style: { color: H ? b : L },
                children: H ? "两个截然不同的联合分布，投影到 X 轴或 Y 轴后得到的边缘分布一模一样！" : "（请检查反例数据设置）"
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ t("div", { className: "rounded-lg p-3", style: { background: K }, children: [
        /* @__PURE__ */ e("div", { className: "text-[12px] font-semibold text-[var(--ink)] mb-2", children: "X 边缘分布对比（A vs B）" }),
        /* @__PURE__ */ e("div", { className: "space-y-1.5", children: D.map((l, n) => {
          const Y = O[n], k = Math.abs(l - Y) < 1e-3;
          return /* @__PURE__ */ t("div", { className: "flex items-center gap-2 text-[12px]", children: [
            /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)] w-4", children: S[n] }),
            /* @__PURE__ */ e("span", { className: "font-mono", style: { color: h }, children: u(l) }),
            /* @__PURE__ */ e("span", { className: "text-[var(--ink-soft)]", children: "vs" }),
            /* @__PURE__ */ e("span", { className: "font-mono", style: { color: J }, children: u(Y) }),
            /* @__PURE__ */ e(
              "span",
              {
                className: "ml-1 text-[11px] font-bold",
                style: { color: k ? b : L },
                children: k ? "相同" : "不同"
              }
            )
          ] }, n);
        }) })
      ] }),
      /* @__PURE__ */ t("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
        /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "结论：" }),
        '边缘分布是联合分布的"影子"——它丢失了 X 与 Y 之间的',
        /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "相关结构" }),
        "（协方差、独立性信息等）。 只有当 X 与 Y",
        " ",
        /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "相互独立" }),
        "时，边缘分布才能完全恢复联合分布（此时",
        /* @__PURE__ */ e("span", { className: "font-mono ml-1", children: "p(xᵢ,yⱼ) = P(X=xᵢ)·P(Y=yⱼ)" }),
        "）。"
      ] })
    ] })
  ] });
}
const Me = ue(ke);
export {
  Me as default
};
