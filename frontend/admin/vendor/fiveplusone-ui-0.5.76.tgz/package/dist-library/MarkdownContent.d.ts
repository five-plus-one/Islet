import { type ReactNode } from "react";
import type { PluggableList } from "unified";
import { type Components } from "react-markdown";
import "katex/dist/katex.min.css";
import "katex/contrib/mhchem";
export interface RenderDirectiveProps {
    name: string;
    attributes: Record<string, string>;
    children: ReactNode;
    source?: string;
}
export interface MarkdownContentProps {
    components?: Components;
    remarkPlugins?: PluggableList;
    rehypePlugins?: PluggableList;
    markdown: string;
    resolveResourceUrl?: (url: string) => string;
    renderDirective?: (props: RenderDirectiveProps) => ReactNode;
    onOpenResource?: (attributes: Record<string, string>, kind: string) => void;
    onOpenLink?: (href: string) => void;
}
/** Markdown reading and editing share named directives; host renderers supply specialist engines. */
export declare function MarkdownContent({ markdown, resolveResourceUrl, renderDirective, onOpenResource, onOpenLink, components: hostComponents, remarkPlugins: hostRemarkPlugins, rehypePlugins: hostRehypePlugins, }: MarkdownContentProps): import("react").JSX.Element;
