import { jsxs as d, jsx as n, Fragment as V } from "react/jsx-runtime";
import { memo as Q, useState as F } from "react";
const w = "var(--accent)", B = "var(--fp-primary-soft)", v = "#dc2626", O = "color-mix(in srgb, #fee2e2 24%, var(--fp-surface))", C = "#0f766e", G = "color-mix(in srgb, #ccfbf1 24%, var(--fp-surface))", J = "var(--line)", Y = 480, j = 180, k = 40, N = 20, $ = Y - 2 * k, z = j - 2 * N;
function W(t) {
  return Math.exp(-0.5 * t * t) / Math.sqrt(2 * Math.PI);
}
function K(t) {
  const e = t >= 0 ? 1 : -1, s = 1 / (1 + 0.3275911 * Math.abs(t)), a = s * (0.254829592 + s * (-0.284496736 + s * (1.421413741 + s * (-1.453152027 + s * 1.061405429))));
  return e * (1 - a * Math.exp(-t * t));
}
function E(t) {
  return 0.5 * (1 + K(t / Math.SQRT2));
}
function T(t) {
  const s = [
    0.9999999999998099,
    676.5203681218851,
    -1259.1392167224028,
    771.3234287776531,
    -176.6150291621406,
    12.507343278686905,
    -0.13857109526572012,
    9984369578019572e-21,
    15056327351493116e-23
  ];
  if (t < 0.5) return Math.PI / (Math.sin(Math.PI * t) * T(1 - t));
  t -= 1;
  let a = s[0];
  for (let l = 1; l < 9; l++) a += s[l] / (t + l);
  const c = t + 7 + 0.5;
  return Math.sqrt(2 * Math.PI) * Math.pow(c, t + 0.5) * Math.exp(-c) * a;
}
function U(t, e, s) {
  if (s <= 0) return 0;
  if (s >= 1) return 1;
  const a = Math.log(T(t)) + Math.log(T(e)) - Math.log(T(t + e)), c = Math.exp(Math.log(s) * t + Math.log(1 - s) * e - a) / t;
  let l = 1, r = 1, o = 1 - (t + e) * s / (t + 1);
  Math.abs(o) < 1e-30 && (o = 1e-30), o = 1 / o, l = o;
  for (let i = 1; i <= 200; i++) {
    const h = 2 * i;
    let x = i * (e - i) * s / ((t + h - 1) * (t + h));
    o = 1 + x * o, r = 1 + x / r, Math.abs(o) < 1e-30 && (o = 1e-30), Math.abs(r) < 1e-30 && (r = 1e-30), o = 1 / o, l *= o * r, x = -((t + i) * (t + e + i) * s) / ((t + h) * (t + h + 1)), o = 1 + x * o, r = 1 + x / r, Math.abs(o) < 1e-30 && (o = 1e-30), Math.abs(r) < 1e-30 && (r = 1e-30), o = 1 / o;
    const b = o * r;
    if (l *= b, Math.abs(b - 1) < 1e-10) break;
  }
  return c * l;
}
function I(t, e) {
  const s = e / (e + t * t), a = U(e / 2, 0.5, s);
  return t >= 0 ? 1 - 0.5 * a : 0.5 * a;
}
function _(t, e) {
  const s = Math.log(T((e + 1) / 2)) - Math.log(T(e / 2)) - 0.5 * Math.log(e * Math.PI);
  return Math.exp(s - (e + 1) / 2 * Math.log(1 + t * t / e));
}
function A(t) {
  if (t <= 0) return -1 / 0;
  if (t >= 1) return 1 / 0;
  const e = [
    -39.69683028665376,
    220.9460984245205,
    -275.9285104469687,
    138.357751867269,
    -30.66479806614716,
    2.506628277459239
  ], s = [
    -54.47609879822406,
    161.5858368580409,
    -155.6989798598866,
    66.80131188771972,
    -13.28068155288572
  ], a = [
    -0.007784894002430293,
    -0.3223964580411365,
    -2.400758277161838,
    -2.549732539343734,
    4.374664141464968,
    2.938163982698783
  ], c = [
    0.007784695709041462,
    0.3224671290700398,
    2.445134137142996,
    3.754408661907416
  ], l = 0.02425, r = 1 - l;
  if (t < l) {
    const i = Math.sqrt(-2 * Math.log(t));
    return (((((a[0] * i + a[1]) * i + a[2]) * i + a[3]) * i + a[4]) * i + a[5]) / ((((c[0] * i + c[1]) * i + c[2]) * i + c[3]) * i + 1);
  }
  if (t <= r) {
    const i = t - 0.5, h = i * i;
    return (((((e[0] * h + e[1]) * h + e[2]) * h + e[3]) * h + e[4]) * h + e[5]) * i / (((((s[0] * h + s[1]) * h + s[2]) * h + s[3]) * h + s[4]) * h + 1);
  }
  const o = Math.sqrt(-2 * Math.log(1 - t));
  return -(((((a[0] * o + a[1]) * o + a[2]) * o + a[3]) * o + a[4]) * o + a[5]) / ((((c[0] * o + c[1]) * o + c[2]) * o + c[3]) * o + 1);
}
function q(t, e) {
  if (t <= 0) return 1 / 0;
  if (t >= 1) return -1 / 0;
  let s = -10, a = 10;
  for (; I(a, e) < t; ) a *= 2;
  for (; I(s, e) > t; ) s *= 2;
  for (let c = 0; c < 80; c++) {
    const l = (s + a) / 2;
    I(l, e) < t ? s = l : a = l;
  }
  return (s + a) / 2;
}
function tt(t, e, s, a, c, l, r) {
  const o = s / Math.sqrt(a), i = (t - e) / o, h = a - 1;
  let x, b, f;
  r === "z" ? c === "left" ? (x = E(i), b = -1 / 0, f = A(l)) : c === "right" ? (x = 1 - E(i), b = A(1 - l), f = 1 / 0) : (x = 2 * Math.min(E(i), 1 - E(i)), b = A(l / 2), f = A(1 - l / 2)) : c === "left" ? (x = I(i, h), b = -1 / 0, f = q(l, h)) : c === "right" ? (x = 1 - I(i, h), b = q(1 - l, h), f = 1 / 0) : (x = 2 * Math.min(I(i, h), 1 - I(i, h)), b = q(l / 2, h), f = q(1 - l / 2, h));
  const y = c === "left" ? i < f : c === "right" ? i > b : i < b || i > f;
  return {
    statistic: i,
    pValue: Math.max(0, Math.min(1, x)),
    criticalLow: b,
    criticalHigh: f,
    reject: y
  };
}
function et(t, e, s, a = 200) {
  const c = [];
  for (let l = 0; l <= a; l++) {
    const r = t + l / a * (e - t), o = s(r), i = k + (r - t) / (e - t) * $, h = s(0), x = j - N - o / h * z * 0.85;
    c.push(`${l === 0 ? "M" : "L"}${i.toFixed(2)},${x.toFixed(2)}`);
  }
  return c.join(" ");
}
function R(t, e, s, a, c, l = 200) {
  const r = Math.max(s, t), o = Math.min(a, e);
  if (r >= o) return "";
  const i = c(0), h = (y) => k + (y - t) / (e - t) * $, x = (y) => j - N - y / i * z * 0.85, b = j - N, f = [`M${h(r).toFixed(2)},${b}`];
  for (let y = 0; y <= l; y++) {
    const u = r + y / l * (o - r), H = c(u);
    f.push(`L${h(u).toFixed(2)},${x(H).toFixed(2)}`);
  }
  return f.push(`L${h(o).toFixed(2)},${b}`, "Z"), f.join(" ");
}
function P({
  label: t,
  value: e,
  min: s,
  max: a,
  step: c,
  onChange: l,
  unit: r
}) {
  return /* @__PURE__ */ d("div", { className: "space-y-0.5", children: [
    /* @__PURE__ */ n("label", { className: "block text-[12px] font-semibold text-[var(--ink)]", children: t }),
    /* @__PURE__ */ d("div", { className: "flex items-center gap-1", children: [
      /* @__PURE__ */ n(
        "input",
        {
          type: "number",
          value: e,
          min: s,
          max: a,
          step: c,
          onChange: (o) => {
            const i = parseFloat(o.target.value);
            isNaN(i) || l(Math.min(a, Math.max(s, i)));
          },
          className: "w-full rounded-md border border-[var(--line)] bg-[var(--bg-elevated)] px-2 py-1 text-[13px] font-mono text-[var(--ink)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:border-transparent"
        }
      ),
      r && /* @__PURE__ */ n("span", { className: "text-[11px] text-[var(--ink-soft)] whitespace-nowrap", children: r })
    ] })
  ] });
}
function nt({ label: t, value: e, min: s, max: a, step: c, onChange: l, fmt: r }) {
  const o = r ? r(e) : String(e);
  return /* @__PURE__ */ d("div", { className: "space-y-1", children: [
    /* @__PURE__ */ d("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ n("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: t }),
      /* @__PURE__ */ n(
        "span",
        {
          className: "rounded px-2 py-0.5 text-[12px] font-mono font-bold",
          style: { background: B, color: w },
          children: o
        }
      )
    ] }),
    /* @__PURE__ */ n(
      "input",
      {
        type: "range",
        min: s,
        max: a,
        step: c,
        value: e,
        onChange: (i) => l(Number(i.target.value)),
        className: "w-full h-1.5 cursor-pointer",
        style: { accentColor: w }
      }
    )
  ] });
}
function it({ result: t, tail: e, type: s, df: a }) {
  const { statistic: c, criticalLow: l, criticalHigh: r } = t, o = -4.5, i = 4.5, h = s === "z" ? W : (g) => _(g, a), x = et(o, i, h), b = s === "z" ? W(0) : _(0, a), f = (g) => k + (Math.max(o, Math.min(i, g)) - o) / (i - o) * $, y = (g) => j - N - g / b * z * 0.85, u = j - N, H = e === "left" || e === "two" ? R(o, i, o, Math.min(r, i), h) : "", S = e === "right" || e === "two" ? R(o, i, Math.max(l, o), i, h) : "", M = f(c), X = y(h(Math.max(o, Math.min(i, c)))), m = t.reject ? v : w, L = [];
  return (e === "left" || e === "two") && L.push({
    x: r,
    label: "-z/t"
  }), (e === "right" || e === "two") && L.push({ x: l, label: "z/t" }), /* @__PURE__ */ d(
    "svg",
    {
      viewBox: `0 0 ${Y} ${j}`,
      className: "w-full rounded-lg border border-[var(--line)]",
      children: [
        /* @__PURE__ */ n(
          "rect",
          {
            x: k,
            y: N,
            width: $,
            height: z,
            fill: "var(--bg-muted)",
            stroke: J
          }
        ),
        [-4, -3, -2, -1, 0, 1, 2, 3, 4].map((g) => {
          const p = f(g);
          return /* @__PURE__ */ d("g", { children: [
            /* @__PURE__ */ n(
              "line",
              {
                x1: p,
                y1: u,
                x2: p,
                y2: u + 3,
                stroke: "var(--ink-faint)"
              }
            ),
            /* @__PURE__ */ n(
              "text",
              {
                x: p,
                y: u + 11,
                fontSize: "8",
                textAnchor: "middle",
                fill: "var(--ink-faint)",
                children: g
              }
            )
          ] }, g);
        }),
        H && /* @__PURE__ */ n("path", { d: H, fill: v, opacity: 0.18 }),
        S && /* @__PURE__ */ n("path", { d: S, fill: v, opacity: 0.18 }),
        /* @__PURE__ */ n("path", { d: x, fill: "none", stroke: w, strokeWidth: "2" }),
        L.map(({ x: g }) => {
          if (g === 1 / 0 || g === -1 / 0 || isNaN(g)) return null;
          const p = f(g);
          return /* @__PURE__ */ n(
            "line",
            {
              x1: p,
              y1: N,
              x2: p,
              y2: u,
              stroke: v,
              strokeDasharray: "4 3",
              strokeWidth: "1.2"
            },
            g
          );
        }),
        !isNaN(M) && isFinite(M) && /* @__PURE__ */ d(V, { children: [
          /* @__PURE__ */ n(
            "line",
            {
              x1: M,
              y1: N,
              x2: M,
              y2: u,
              stroke: m,
              strokeWidth: "2"
            }
          ),
          M >= k && M <= k + $ && /* @__PURE__ */ n("circle", { cx: M, cy: X, r: "4", fill: m }),
          /* @__PURE__ */ d(
            "text",
            {
              x: Math.min(Math.max(M, k + 16), k + $ - 16),
              y: N + 12,
              fontSize: "9",
              textAnchor: "middle",
              fill: m,
              fontWeight: "bold",
              children: [
                s === "z" ? "Z" : "T",
                "=",
                c.toFixed(3)
              ]
            }
          )
        ] }),
        e !== "right" && isFinite(r) && /* @__PURE__ */ n(
          "text",
          {
            x: f(r) - 4,
            y: N + 22,
            fontSize: "8",
            textAnchor: "end",
            fill: v,
            children: r.toFixed(3)
          }
        ),
        e !== "left" && isFinite(l) && /* @__PURE__ */ n(
          "text",
          {
            x: f(l) + 4,
            y: N + 22,
            fontSize: "8",
            textAnchor: "start",
            fill: v,
            children: l.toFixed(3)
          }
        ),
        /* @__PURE__ */ n(
          "text",
          {
            x: k + $ / 2,
            y: j - 1,
            fontSize: "9",
            textAnchor: "middle",
            fill: "var(--ink-faint)",
            children: s === "z" ? "Z 统计量" : `T 统计量 (df=${a})`
          }
        ),
        (e === "left" || e === "two") && /* @__PURE__ */ n(
          "text",
          {
            x: k + 12,
            y: N + z * 0.5,
            fontSize: "8",
            fill: v,
            opacity: 0.8,
            children: "拒绝域"
          }
        ),
        (e === "right" || e === "two") && /* @__PURE__ */ n(
          "text",
          {
            x: k + $ - 6,
            y: N + z * 0.5,
            fontSize: "8",
            textAnchor: "end",
            fill: v,
            opacity: 0.8,
            children: "拒绝域"
          }
        )
      ]
    }
  );
}
function ot({
  testType: t,
  tail: e,
  xbar: s,
  mu0: a,
  spread: c,
  n: l,
  result: r,
  alpha: o
}) {
  const [i, h] = F(!1), x = l - 1, b = c / Math.sqrt(l), f = r.statistic, y = t === "z" ? "σ" : "S", u = t === "z" ? "Z" : "T";
  return /* @__PURE__ */ d("div", { className: "rounded-lg border border-[var(--line)] overflow-hidden", children: [
    /* @__PURE__ */ d(
      "button",
      {
        type: "button",
        onClick: () => h((S) => !S),
        className: "flex w-full items-center justify-between px-4 py-2.5 bg-[var(--bg-muted)] text-left",
        children: [
          /* @__PURE__ */ n("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "推导步骤展开" }),
          /* @__PURE__ */ n("span", { className: "text-[16px] text-[var(--ink-soft)]", children: i ? "▲" : "▼" })
        ]
      }
    ),
    i && /* @__PURE__ */ d("div", { className: "px-4 py-3 space-y-3 text-[12px] leading-relaxed text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ d("div", { children: [
        /* @__PURE__ */ n("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 1：建立假设" }),
        /* @__PURE__ */ d("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          "H₀: μ = ",
          a,
          "　",
          "|",
          "　",
          e === "left" ? "左尾检验 H₁: μ < μ₀" : e === "right" ? "右尾检验 H₁: μ > μ₀" : "双尾检验 H₁: μ ≠ μ₀"
        ] })
      ] }),
      /* @__PURE__ */ d("div", { children: [
        /* @__PURE__ */ n("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 2：计算标准误" }),
        /* @__PURE__ */ d("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          "SE = ",
          y,
          "/√n = ",
          c,
          "/",
          Math.sqrt(l).toFixed(4),
          " =",
          " ",
          b.toFixed(4)
        ] })
      ] }),
      /* @__PURE__ */ d("div", { children: [
        /* @__PURE__ */ d("div", { className: "font-semibold text-[var(--ink)] mb-1", children: [
          "Step 3：计算检验统计量",
          t === "t" && `（t 分布，df = n−1 = ${x}）`
        ] }),
        /* @__PURE__ */ d("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          u,
          " = (X̄ − μ₀) / SE",
          `
`,
          "　　",
          "= (",
          s,
          " − ",
          a,
          ") / ",
          b.toFixed(4),
          `
`,
          "　　",
          "= ",
          (s - a).toFixed(4),
          " / ",
          b.toFixed(4),
          `
`,
          "　　",
          "=",
          " ",
          /* @__PURE__ */ n("span", { style: { color: w, fontWeight: 700 }, children: f.toFixed(4) })
        ] })
      ] }),
      /* @__PURE__ */ d("div", { children: [
        /* @__PURE__ */ n("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 4：确定临界值与拒绝域" }),
        /* @__PURE__ */ d("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          "显著性水平 α = ",
          o,
          "　",
          e === "left" && `临界值 = ${r.criticalHigh.toFixed(4)}（左尾）`,
          e === "right" && `临界值 = ${r.criticalLow.toFixed(4)}（右尾）`,
          e === "two" && `临界值 = ±${Math.abs(r.criticalHigh).toFixed(4)}（双尾）`
        ] })
      ] }),
      /* @__PURE__ */ d("div", { children: [
        /* @__PURE__ */ n("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 5：计算 p 值" }),
        /* @__PURE__ */ d("div", { className: "font-mono bg-[var(--bg-muted)] rounded px-3 py-2", children: [
          e === "left" && `p = P(${u} ≤ ${f.toFixed(4)}) = `,
          e === "right" && `p = P(${u} ≥ ${f.toFixed(4)}) = `,
          e === "two" && `p = 2 × P(${u} ≥ |${f.toFixed(4)}|) = `,
          /* @__PURE__ */ n("span", { style: { color: w, fontWeight: 700 }, children: r.pValue.toFixed(4) })
        ] })
      ] }),
      /* @__PURE__ */ d("div", { children: [
        /* @__PURE__ */ n("div", { className: "font-semibold text-[var(--ink)] mb-1", children: "Step 6：作出结论" }),
        /* @__PURE__ */ n(
          "div",
          {
            className: "rounded px-3 py-2 font-semibold",
            style: {
              background: r.reject ? O : G,
              color: r.reject ? v : C
            },
            children: r.reject ? `p = ${r.pValue.toFixed(4)} < α = ${o}，拒绝 H₀` : `p = ${r.pValue.toFixed(4)} ≥ α = ${o}，不拒绝 H₀`
          }
        )
      ] })
    ] })
  ] });
}
function st() {
  const [t, e] = F("z"), [s, a] = F(102.5), [c, l] = F(100), [r, o] = F(10), [i, h] = F(10), [x, b] = F(25), [f, y] = F("two"), [u, H] = F(0.05), S = t === "z" ? r : i, M = x - 1, m = x >= 2 && S > 0 ? tt(s, c, S, x, f, u, t) : null, L = [
    { key: "left", label: "左尾", symbol: "H₁: μ < μ₀" },
    { key: "two", label: "双尾", symbol: "H₁: μ ≠ μ₀" },
    { key: "right", label: "右尾", symbol: "H₁: μ > μ₀" }
  ], g = [0.01, 0.05, 0.1];
  return /* @__PURE__ */ d("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ d("div", { children: [
      /* @__PURE__ */ n("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "正态总体均值假设检验" }),
      /* @__PURE__ */ n("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "输入样本统计量，选择检验方向与显著性水平，实时计算统计量、p 值与结论。" })
    ] }),
    /* @__PURE__ */ n("div", { className: "flex gap-1 rounded-lg bg-[var(--bg-muted)] p-1", children: ["z", "t"].map((p) => /* @__PURE__ */ n(
      "button",
      {
        type: "button",
        onClick: () => e(p),
        className: `flex-1 rounded-md py-1.5 text-[13px] font-semibold transition-colors ${t === p ? "bg-[var(--bg-elevated)] shadow text-[var(--ink)]" : "text-[var(--ink-soft)] hover:text-[var(--ink)]"}`,
        children: p === "z" ? "Z 检验（σ 已知）" : "t 检验（σ 未知）"
      },
      p
    )) }),
    /* @__PURE__ */ d("div", { className: "grid grid-cols-2 gap-3 sm:grid-cols-3 rounded-lg bg-[var(--bg-muted)] p-3", children: [
      /* @__PURE__ */ n(
        P,
        {
          label: "样本均值 X̄",
          value: s,
          min: -1e3,
          max: 1e3,
          step: 0.1,
          onChange: a
        }
      ),
      /* @__PURE__ */ n(
        P,
        {
          label: "原假设均值 μ₀",
          value: c,
          min: -1e3,
          max: 1e3,
          step: 0.1,
          onChange: l
        }
      ),
      /* @__PURE__ */ n(
        P,
        {
          label: "样本量 n",
          value: x,
          min: 2,
          max: 1e4,
          step: 1,
          onChange: b
        }
      ),
      t === "z" ? /* @__PURE__ */ n(
        P,
        {
          label: "总体标准差 σ（已知）",
          value: r,
          min: 1e-3,
          max: 1e3,
          step: 0.1,
          onChange: o
        }
      ) : /* @__PURE__ */ n(
        P,
        {
          label: "样本标准差 S",
          value: i,
          min: 1e-3,
          max: 1e3,
          step: 0.1,
          onChange: h
        }
      ),
      /* @__PURE__ */ n("div", { className: "col-span-2 sm:col-span-2", children: /* @__PURE__ */ n(
        nt,
        {
          label: "样本量 n（快速调整）",
          value: x,
          min: 2,
          max: 200,
          step: 1,
          onChange: b,
          fmt: (p) => `n = ${p}`
        }
      ) })
    ] }),
    /* @__PURE__ */ d("div", { className: "grid grid-cols-2 gap-3", children: [
      /* @__PURE__ */ d("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ n("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "检验方向" }),
        /* @__PURE__ */ n("div", { className: "flex flex-col gap-1", children: L.map(({ key: p, label: Z, symbol: D }) => /* @__PURE__ */ d(
          "button",
          {
            type: "button",
            onClick: () => y(p),
            className: `rounded-lg px-3 py-1.5 text-left text-[12px] font-medium transition-colors ${f === p ? "text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--line)]"}`,
            style: f === p ? { background: w } : {},
            children: [
              /* @__PURE__ */ n("span", { className: "font-semibold", children: Z }),
              /* @__PURE__ */ n("span", { className: "ml-2 font-mono text-[11px] opacity-80", children: D })
            ]
          },
          p
        )) })
      ] }),
      /* @__PURE__ */ d("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ n("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "显著性水平 α" }),
        /* @__PURE__ */ n("div", { className: "flex flex-col gap-1", children: g.map((p) => /* @__PURE__ */ d(
          "button",
          {
            type: "button",
            onClick: () => H(p),
            className: `rounded-lg px-3 py-1.5 text-[12px] font-mono font-semibold transition-colors ${u === p ? "text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--line)]"}`,
            style: u === p ? { background: w } : {},
            children: [
              "α = ",
              p
            ]
          },
          p
        )) }),
        /* @__PURE__ */ n("div", { className: "mt-2 rounded-md bg-[var(--bg-muted)] px-2 py-1.5 text-[11px] leading-snug text-[var(--ink-soft)]", children: t === "z" ? /* @__PURE__ */ d(V, { children: [
          /* @__PURE__ */ n("span", { className: "font-semibold text-[var(--ink)]", children: "Z 统计量" }),
          /* @__PURE__ */ n("br", {}),
          "Z = (X̄ − μ₀) / (σ / √n)",
          /* @__PURE__ */ n("br", {}),
          "服从 N(0,1)"
        ] }) : /* @__PURE__ */ d(V, { children: [
          /* @__PURE__ */ n("span", { className: "font-semibold text-[var(--ink)]", children: "T 统计量" }),
          /* @__PURE__ */ n("br", {}),
          "T = (X̄ − μ₀) / (S / √n)",
          /* @__PURE__ */ n("br", {}),
          "服从 t(n−1) = t(",
          M,
          ")"
        ] }) })
      ] })
    ] }),
    m && /* @__PURE__ */ n(it, { result: m, tail: f, type: t, df: M }),
    m && /* @__PURE__ */ d(
      "div",
      {
        className: "rounded-lg border-2 p-4 space-y-3",
        style: {
          borderColor: m.reject ? v : C,
          background: m.reject ? O : G
        },
        children: [
          /* @__PURE__ */ d("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ n(
              "span",
              {
                className: "text-[14px] font-bold",
                style: { color: m.reject ? v : C },
                children: m.reject ? "拒绝 H₀" : "不拒绝 H₀"
              }
            ),
            /* @__PURE__ */ n(
              "span",
              {
                className: "rounded-full px-3 py-0.5 text-[12px] font-bold text-white",
                style: { background: m.reject ? v : C },
                children: m.reject ? "显著" : "不显著"
              }
            )
          ] }),
          /* @__PURE__ */ n("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
            {
              label: t === "z" ? "Z 值" : "T 值",
              val: m.statistic.toFixed(4),
              color: m.reject ? v : w
            },
            {
              label: "p 值",
              val: m.pValue < 1e-4 ? "< 0.0001" : m.pValue.toFixed(4),
              color: m.pValue < u ? v : C
            },
            {
              label: f === "left" ? "左临界值" : f === "right" ? "右临界值" : "临界值 ±",
              val: f === "two" ? Math.abs(m.criticalHigh).toFixed(4) : f === "left" ? m.criticalHigh.toFixed(4) : m.criticalLow.toFixed(4),
              color: v
            },
            {
              label: "df",
              val: t === "t" ? String(M) : "∞（Z）",
              color: w
            }
          ].map(({ label: p, val: Z, color: D }) => /* @__PURE__ */ d(
            "div",
            {
              className: "rounded-lg bg-[var(--fp-surface)] bg-opacity-70 p-2 text-center",
              children: [
                /* @__PURE__ */ n("div", { className: "text-[10px] text-[var(--ink-soft)]", children: p }),
                /* @__PURE__ */ n(
                  "div",
                  {
                    className: "text-[15px] font-extrabold font-mono mt-0.5",
                    style: { color: D },
                    children: Z
                  }
                )
              ]
            },
            p
          )) }),
          /* @__PURE__ */ n(
            "div",
            {
              className: "text-[12px] leading-relaxed",
              style: { color: m.reject ? v : C },
              children: m.reject ? /* @__PURE__ */ d(V, { children: [
                "在 α = ",
                u,
                " 水平下，p = ",
                m.pValue.toFixed(4),
                " ",
                "<",
                " ",
                u,
                "，有统计上的显著差异， 有足够证据拒绝 H₀，认为总体均值与 μ₀ = ",
                c,
                " 有显著差异。"
              ] }) : /* @__PURE__ */ d(V, { children: [
                "在 α = ",
                u,
                " 水平下，p = ",
                m.pValue.toFixed(4),
                " ",
                "≥",
                " ",
                u,
                "， 没有足够证据拒绝 H₀，无法认为总体均值与 μ₀ = ",
                c,
                " ",
                "有显著差异。"
              ] })
            }
          )
        ]
      }
    ),
    m && /* @__PURE__ */ d("div", { className: "space-y-1", children: [
      /* @__PURE__ */ d("div", { className: "flex items-center justify-between text-[11px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ n("span", { children: "p 值直观位置" }),
        /* @__PURE__ */ d("span", { children: [
          "α = ",
          u
        ] })
      ] }),
      /* @__PURE__ */ d(
        "div",
        {
          className: "relative h-5 w-full rounded-full overflow-hidden",
          style: { background: G },
          children: [
            /* @__PURE__ */ n(
              "div",
              {
                className: "absolute top-0 h-full w-0.5",
                style: { left: `${u * 100}%`, background: v }
              }
            ),
            /* @__PURE__ */ n(
              "div",
              {
                className: "h-full rounded-full transition-all duration-300",
                style: {
                  width: `${Math.min(m.pValue, 1) * 100}%`,
                  background: m.reject ? v : C,
                  opacity: 0.5
                }
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ d("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ n("span", { children: "0" }),
        /* @__PURE__ */ d("span", { style: { color: v }, children: [
          "α = ",
          u
        ] }),
        /* @__PURE__ */ n("span", { children: "1" })
      ] })
    ] }),
    m && /* @__PURE__ */ n(
      ot,
      {
        testType: t,
        tail: f,
        xbar: s,
        mu0: c,
        spread: S,
        n: x,
        result: m,
        alpha: u
      }
    ),
    /* @__PURE__ */ d("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ n("span", { className: "font-semibold text-[var(--ink)]", children: "核心思想：" }),
      "假设检验问题的本质是「若 H₀ 为真，观察到当前或更极端数据的概率（p 值）有多小？」。 p 值越小，越有证据反对 H₀。Z 检验需要已知 σ；当 σ 未知且用样本 S 估计时， 统计量服从 t 分布——样本量越小（df 越小），t 分布尾部越重，临界值越大。"
    ] })
  ] });
}
const rt = Q(st);
export {
  rt as default
};
