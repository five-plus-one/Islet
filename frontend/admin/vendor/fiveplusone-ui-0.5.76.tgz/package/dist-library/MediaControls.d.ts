import type { HTMLAttributes, InputHTMLAttributes, ReactNode } from "react";
/** Controls retain a dark media palette, including menus rendered in a portal. */
export declare function MediaControls({ progress, children, className, ...props }: HTMLAttributes<HTMLDivElement> & {
    progress?: ReactNode;
}): import("react").JSX.Element;
/** A styled range keeps native keyboard and assistive technology behavior. */
export declare function MediaSlider({ className, style, min, max, value, ...props }: InputHTMLAttributes<HTMLInputElement>): import("react").JSX.Element;
