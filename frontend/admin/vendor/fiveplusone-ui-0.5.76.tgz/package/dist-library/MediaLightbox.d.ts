/** MediaLightbox - 从课栈 shared/ImageLightbox 提取
 *
 * 全屏图片查看：缩放、拖动平移、双击复位、键盘 Esc 关闭。
 * 适合笔记图片、课件截图等需要细看的内容。
 */
export interface MediaLightboxProps {
    /** 图片地址；为 null 时关闭 */
    src: string | null;
    alt?: string;
    onClose: () => void;
}
export declare function MediaLightbox({ src, alt, onClose }: MediaLightboxProps): import("react").ReactPortal | null;
