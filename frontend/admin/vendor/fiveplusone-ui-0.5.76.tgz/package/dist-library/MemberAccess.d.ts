export interface AccessMember {
    id: string;
    name: string;
    detail?: string;
    role: string;
    editable?: boolean;
}
export interface AccessRole {
    value: string;
    label: string;
    description?: string;
}
export interface MemberAccessProps {
    members: AccessMember[];
    roles: AccessRole[];
    canManage?: boolean;
    busyIds?: string[];
    onRoleChange?: (memberId: string, role: string) => void;
    onRemove?: (memberId: string) => void;
    onInvite?: (address: string, role: string) => Promise<void> | void;
    defaultInviteRole?: string;
    error?: string;
}
/** Controlled access view. The host authorizes every role change, removal and invitation. */
export declare function MemberAccess({ members, roles, canManage, busyIds, onRoleChange, onRemove, onInvite, defaultInviteRole, error }: MemberAccessProps): import("react").JSX.Element;
