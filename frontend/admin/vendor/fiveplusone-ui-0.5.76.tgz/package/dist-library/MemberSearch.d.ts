export interface MemberSearchResult {
    id: string;
    name: string;
    detail?: string;
    avatarUrl?: string;
    disabled?: boolean;
}
export type MemberSearchKind = 'user' | 'group';
export interface MemberSearchProps {
    onSearch: (query: string, kind: MemberSearchKind, signal: AbortSignal) => Promise<MemberSearchResult[]>;
    onPick: (member: MemberSearchResult, kind: MemberSearchKind) => void;
    disabled?: boolean;
    excludedIds?: string[];
    debounceMs?: number;
    onQueryChange?: (query: string, kind: MemberSearchKind) => void;
}
/** Search transport, authorization and result privacy are owned by the host. */
export declare function MemberSearch({ onSearch, onPick, disabled, excludedIds, debounceMs, onQueryChange }: MemberSearchProps): import("react").JSX.Element;
