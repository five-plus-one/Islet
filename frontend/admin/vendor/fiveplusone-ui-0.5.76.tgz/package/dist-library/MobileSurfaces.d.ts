import type { ReactNode } from 'react';
import './mobile-surfaces.css';
export declare function MobileHeader({ title, subtitle, leading, actions, onBack }: {
    title: ReactNode;
    subtitle?: ReactNode;
    leading?: ReactNode;
    actions?: ReactNode;
    onBack?: () => void;
}): import("react").JSX.Element;
export declare function MobileSection({ title, description, action, children }: {
    title: string;
    description?: string;
    action?: ReactNode;
    children: ReactNode;
}): import("react").JSX.Element;
export type MobileAction = {
    id: string;
    label: string;
    icon: ReactNode;
    description?: string;
    disabled?: boolean;
    onClick: () => void;
};
export declare function MobileActionGrid({ items, label }: {
    items: MobileAction[];
    label?: string;
}): import("react").JSX.Element;
export declare function MobileCollectionRow({ title, description, icon, trailing, onClick }: {
    title: string;
    description?: string;
    icon?: ReactNode;
    trailing?: ReactNode;
    onClick: () => void;
}): import("react").JSX.Element;
export declare function MobileNotebookGrid({ children }: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function MobileNotebookCard({ title, description, icon, onClick }: {
    title: string;
    description: string;
    icon: ReactNode;
    onClick: () => void;
}): import("react").JSX.Element;
export declare function MobileWelcome({ mark, title, description, children, footer }: {
    mark: ReactNode;
    title: string;
    description: string;
    children: ReactNode;
    footer?: ReactNode;
}): import("react").JSX.Element;
export declare function MobileRecorder({ state, time, busy, onStart, onPause, onFinish, onUpload, onAgain }: {
    state: 'idle' | 'recording' | 'paused' | 'saved';
    time: string;
    busy?: boolean;
    onStart: () => void;
    onPause: () => void;
    onFinish: () => void;
    onUpload: () => void;
    onAgain: () => void;
}): import("react").JSX.Element;
