import { jsxs as i, jsx as t } from "react/jsx-runtime";
import { learningAlpha as _ } from "./index.js";
import { memo as se, useState as E } from "react";
const y = "var(--fp-primary)", Y = "var(--fp-primary-soft)", $ = "#0f766e", G = "#c2410c", J = "var(--line)", K = 500, H = 200, v = 48, oe = 20, k = 18, ie = 36, B = K - v - oe, L = H - k - ie;
function h(e, a = 4) {
  return isFinite(e) ? e.toFixed(a) : "—";
}
function ce(e) {
  return isFinite(e) ? e.toFixed(3) : "—";
}
function me(e) {
  return e.split(/[\s,;，；]+/).map((a) => parseFloat(a.trim())).filter((a) => isFinite(a));
}
function I(e) {
  return e.length === 0 ? NaN : e.reduce((a, l) => a + l, 0) / e.length;
}
function q(e) {
  return e.length === 0 ? NaN : e.reduce((a, l) => a + l * l, 0) / e.length;
}
function Q(e, a) {
  if (a.length === 0) return { params: {} };
  const l = I(a), m = q(a) - l * l;
  if (e === "exponential")
    return { params: { lambda: 1 / l } };
  if (e === "normal")
    return {
      params: { mu: l, sigma2: m, sigma: Math.sqrt(Math.max(0, m)) }
    };
  {
    const x = Math.sqrt(Math.max(0, 3 * m));
    return { params: { a: l - x, b: l + x } };
  }
}
const R = {
  exponential: {
    label: "指数分布 Exp(λ)",
    shortLabel: "Exp(λ)",
    paramNames: ["lambda"],
    trueParamLabels: ["真实 λ"],
    trueParamDefaults: [1.5],
    trueParamMin: [0.1],
    trueParamMax: [5],
    trueParamStep: [0.1],
    generateSample: ([e], a) => {
      const l = [];
      for (let s = 0; s < a; s++)
        l.push(-Math.log(1 - Math.random()) / e);
      return l;
    }
  },
  normal: {
    label: "正态分布 N(μ, σ²)",
    shortLabel: "N(μ,σ²)",
    paramNames: ["mu", "sigma2", "sigma"],
    trueParamLabels: ["真实 μ", "真实 σ"],
    trueParamDefaults: [2, 1.5],
    trueParamMin: [-5, 0.1],
    trueParamMax: [5, 5],
    trueParamStep: [0.1, 0.1],
    generateSample: ([e, a], l) => {
      const s = [];
      for (let m = 0; m < l; m++) {
        const x = Math.random(), c = Math.random(), f = Math.sqrt(-2 * Math.log(Math.max(x, 1e-12))) * Math.cos(2 * Math.PI * c);
        s.push(e + a * f);
      }
      return s;
    }
  },
  uniform: {
    label: "均匀分布 U(a, b)",
    shortLabel: "U(a,b)",
    paramNames: ["a", "b"],
    trueParamLabels: ["真实 a", "真实 b"],
    trueParamDefaults: [1, 5],
    trueParamMin: [-5, 0],
    trueParamMax: [0, 10],
    trueParamStep: [0.1, 0.1],
    generateSample: ([e, a], l) => {
      const s = [];
      for (let m = 0; m < l; m++)
        s.push(e + Math.random() * (a - e));
      return s;
    }
  }
};
function de(e, a, l) {
  if (a.length === 0) return [];
  const s = I(a), m = q(a), x = m - s * s;
  if (e === "exponential") {
    const c = l.params.lambda;
    return [
      {
        label: "① 总体一阶矩",
        math: "E[X] = ∫₀^∞ x·λe^{-λx} dx = 1/λ"
      },
      {
        label: "② 令总体矩 = 样本矩",
        math: "E[X] = x̄   →   1/λ = x̄"
      },
      {
        label: "③ 解出矩估计量",
        math: "λ̂ = 1 / x̄",
        color: y
      },
      {
        label: "④ 代入样本数值",
        math: `x̄ = ${h(s)}   →   λ̂ = 1 / ${h(s)} = ${h(c)}`,
        color: $
      }
    ];
  } else if (e === "normal") {
    const { mu: c, sigma2: f, sigma: M } = l.params;
    return [
      {
        label: "① 总体一、二阶矩",
        math: "E[X] = μ,   E[X²] = D(X) + (E[X])² = σ² + μ²"
      },
      {
        label: "② 令总体矩 = 样本矩",
        math: "μ = x̄,   σ² + μ² = B₂ = (1/n)·Σxᵢ²"
      },
      {
        label: "③ 解出矩估计量",
        math: "μ̂ = x̄,   σ̂² = B₂ − x̄² = (1/n)·Σxᵢ² − x̄²",
        color: y
      },
      {
        label: "④ 代入数值（n=" + a.length + "）",
        math: `x̄ = ${h(s)},  B₂ = ${h(m)},  σ̂² = ${h(f)},  σ̂ = ${h(M)}`,
        color: $
      },
      {
        label: "⑤ 矩估计结果",
        math: `μ̂ = ${h(c, 3)},   σ̂ = ${h(M, 3)}`,
        color: $
      }
    ];
  } else {
    const { a: c, b: f } = l.params;
    return [
      {
        label: "① 总体一、二阶矩",
        math: "E[X] = (a+b)/2,   D(X) = (b−a)²/12"
      },
      {
        label: "② 总体二阶矩",
        math: "E[X²] = D(X)+(E[X])² = (b−a)²/12 + (a+b)²/4"
      },
      {
        label: "③ 令总体矩 = 样本矩",
        math: "(a+b)/2 = x̄,   (b−a)²/12 = B₂−x̄²"
      },
      {
        label: "④ 解方程组",
        math: "b−a = √(12·(B₂−x̄²)),   a+b = 2x̄",
        color: y
      },
      {
        label: "⑤ 矩估计量",
        math: "â = x̄ − √(3·(B₂−x̄²)),   b̂ = x̄ + √(3·(B₂−x̄²))",
        color: y
      },
      {
        label: "⑥ 代入数值",
        math: `x̄=${h(s)}, B₂−x̄²=${h(x)}, √(3·${h(x)})=${h(Math.sqrt(Math.max(0, 3 * x)))}`,
        color: $
      },
      {
        label: "⑦ 结果",
        math: `â = ${h(c, 3)},   b̂ = ${h(f, 3)}`,
        color: $
      }
    ];
  }
}
function xe(e, a, l) {
  const s = [], m = l.length, x = [5, 8, 12, 18, 25, 35, 50, 70, 100, 140, 200];
  for (const P of x)
    P <= m && s.push(P);
  s[s.length - 1] !== m && s.push(m);
  let c, f, M;
  e === "exponential" ? (c = ["λ̂（矩估计）"], f = [y], M = [[a[0]]]) : e === "normal" ? (c = ["μ̂（矩估计）", "σ̂（矩估计）"], f = [y, $], M = [[a[0]], [a[1]]]) : (c = ["â（矩估计）", "b̂（矩估计）"], f = [y, G], M = [[a[0]], [a[1]]]);
  const F = c.map(() => []);
  for (const P of s) {
    const D = l.slice(0, P), b = Q(e, D);
    e === "exponential" ? F[0].push(isFinite(b.params.lambda) ? b.params.lambda : NaN) : e === "normal" ? (F[0].push(isFinite(b.params.mu) ? b.params.mu : NaN), F[1].push(isFinite(b.params.sigma) ? b.params.sigma : NaN)) : (F[0].push(isFinite(b.params.a) ? b.params.a : NaN), F[1].push(isFinite(b.params.b) ? b.params.b : NaN));
  }
  return {
    ns: s,
    trueVals: M,
    estVals: F,
    paramLabels: c,
    colors: f
  };
}
function pe({ series: e }) {
  const { ns: a, trueVals: l, estVals: s, paramLabels: m, colors: x } = e;
  if (a.length < 2) return null;
  const c = [];
  for (const o of s)
    for (const r of o) isFinite(r) && c.push(r);
  for (const o of l)
    for (const r of o) isFinite(r) && c.push(r);
  if (c.length === 0) return null;
  const f = Math.min(...c), M = Math.max(...c), P = (M - f || 1) * 0.2, D = f - P, b = M + P, z = a[0], j = a[a.length - 1];
  function T(o) {
    return v + (o - z) / (j - z) * B;
  }
  function w(o) {
    return k + L * (1 - (o - D) / (b - D));
  }
  const X = [];
  for (let o = 0; o <= 4; o++)
    X.push(D + o / 4 * (b - D));
  const V = [
    a[0],
    ...a.filter((o, r) => r > 0 && r < a.length - 1 && r % 3 === 0),
    a[a.length - 1]
  ];
  return /* @__PURE__ */ i(
    "svg",
    {
      viewBox: `0 0 ${K} ${H}`,
      className: "w-full rounded-lg border border-[var(--line)]",
      style: { background: "var(--bg-muted)" },
      children: [
        X.map((o, r) => /* @__PURE__ */ i("g", { children: [
          /* @__PURE__ */ t(
            "line",
            {
              x1: v,
              y1: w(o),
              x2: v + B,
              y2: w(o),
              stroke: J,
              strokeWidth: 1
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: v - 5,
              y: w(o) + 3.5,
              fontSize: "9",
              textAnchor: "end",
              fill: "var(--ink-faint)",
              children: Math.abs(o) < 100 ? o.toFixed(2) : o.toFixed(0)
            }
          )
        ] }, r)),
        V.map((o, r) => /* @__PURE__ */ i("g", { children: [
          /* @__PURE__ */ t(
            "line",
            {
              x1: T(o),
              y1: k,
              x2: T(o),
              y2: k + L,
              stroke: J,
              strokeWidth: 1
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: T(o),
              y: k + L + 14,
              fontSize: "9",
              textAnchor: "middle",
              fill: "var(--ink-faint)",
              children: o
            }
          )
        ] }, r)),
        /* @__PURE__ */ t(
          "line",
          {
            x1: v,
            y1: k,
            x2: v,
            y2: k + L,
            stroke: "var(--line)"
          }
        ),
        /* @__PURE__ */ t(
          "line",
          {
            x1: v,
            y1: k + L,
            x2: v + B,
            y2: k + L,
            stroke: "var(--line)"
          }
        ),
        l.map((o, r) => {
          const g = o[0];
          if (!isFinite(g)) return null;
          const p = w(g);
          return p < k - 2 || p > k + L + 2 ? null : /* @__PURE__ */ i("g", { children: [
            /* @__PURE__ */ t(
              "line",
              {
                x1: v,
                y1: p,
                x2: v + B,
                y2: p,
                stroke: x[r],
                strokeWidth: 1.5,
                strokeDasharray: "6 3",
                opacity: 0.5
              }
            ),
            /* @__PURE__ */ t(
              "text",
              {
                x: v + B - 2,
                y: p - 3,
                fontSize: "9",
                textAnchor: "end",
                fill: x[r],
                opacity: 0.7,
                children: "真值"
              }
            )
          ] }, r);
        }),
        s.map((o, r) => {
          const g = o.map((S, A) => ({
            x: T(a[A]),
            y: isFinite(S) ? w(S) : null
          })), p = [];
          let C = "M";
          for (const S of g) {
            if (S.y === null) {
              C = "M";
              continue;
            }
            p.push(`${C}${S.x.toFixed(2)},${S.y.toFixed(2)}`), C = "L";
          }
          return /* @__PURE__ */ i("g", { children: [
            /* @__PURE__ */ t(
              "path",
              {
                d: p.join(" "),
                fill: "none",
                stroke: x[r],
                strokeWidth: 2
              }
            ),
            g.map(
              (S, A) => S.y !== null ? /* @__PURE__ */ t(
                "circle",
                {
                  cx: S.x,
                  cy: S.y,
                  r: 3,
                  fill: x[r],
                  stroke: "white",
                  strokeWidth: 1
                },
                A
              ) : null
            )
          ] }, r);
        }),
        /* @__PURE__ */ t(
          "text",
          {
            x: v + B / 2,
            y: H - 4,
            fontSize: "10",
            textAnchor: "middle",
            fill: "var(--ink-faint)",
            children: "样本量 n"
          }
        ),
        m.map((o, r) => /* @__PURE__ */ i("g", { children: [
          /* @__PURE__ */ t(
            "line",
            {
              x1: v + 4 + r * 110,
              y1: k + 8,
              x2: v + 20 + r * 110,
              y2: k + 8,
              stroke: x[r],
              strokeWidth: 2
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: v + 23 + r * 110,
              y: k + 11,
              fontSize: "9",
              fill: x[r],
              children: o
            }
          )
        ] }, r))
      ]
    }
  );
}
function ue({
  label: e,
  value: a,
  min: l,
  max: s,
  step: m,
  onChange: x,
  color: c
}) {
  return /* @__PURE__ */ i("div", { className: "flex items-center gap-3", children: [
    /* @__PURE__ */ t("span", { className: "w-20 shrink-0 text-[12px] font-semibold text-[var(--ink)]", children: e }),
    /* @__PURE__ */ t(
      "input",
      {
        type: "range",
        min: l,
        max: s,
        step: m,
        value: a,
        onChange: (f) => x(Number(f.target.value)),
        className: "flex-1 h-1.5 cursor-pointer",
        style: { accentColor: c }
      }
    ),
    /* @__PURE__ */ t(
      "span",
      {
        className: "w-14 shrink-0 rounded-md px-2 py-0.5 text-center text-[12px] font-mono font-bold",
        style: { background: _(c, "22"), color: c },
        children: a.toFixed(2)
      }
    )
  ] });
}
function he() {
  const [e, a] = E("exponential"), [l, s] = E(
    "2.1, 0.8, 1.5, 0.4, 3.2, 0.6, 1.9, 2.7, 0.3, 1.1"
  ), [m, x] = E(30), [c, f] = E(!0), [M, F] = E([1.5]), [P, D] = E([2, 1.5]), [b, z] = E([1, 5]), [j, T] = E([]), [w, X] = E(!1);
  function V() {
    return e === "exponential" ? M : e === "normal" ? P : b;
  }
  function o(n) {
    e === "exponential" ? F(n) : e === "normal" ? D(n) : z(n);
  }
  const r = R[e], g = V(), p = me(l), C = Q(e, p), S = de(e, p, C), A = I(p), U = q(p), Z = U - A * A;
  function ee() {
    const n = r.generateSample(g, m);
    s(n.map((d) => d.toFixed(3)).join(", "));
  }
  function te(n) {
    a(n), X(!1), T([]);
    const d = R[n];
    let u;
    n === "exponential" ? u = M : n === "normal" ? u = P : u = b;
    const N = d.generateSample(u, 20);
    s(N.map((le) => le.toFixed(3)).join(", "));
  }
  function ae() {
    const d = r.generateSample(g, 200);
    T(d), X(!0);
  }
  const O = w && j.length >= 5 ? xe(e, g, j) : null;
  function ne() {
    return p.length ? e === "exponential" ? [
      {
        label: "λ",
        est: C.params.lambda,
        true_: g[0],
        color: y
      }
    ] : e === "normal" ? [
      {
        label: "μ",
        est: C.params.mu,
        true_: g[0],
        color: y
      },
      {
        label: "σ",
        est: C.params.sigma,
        true_: g[1],
        color: $
      }
    ] : [
      {
        label: "a",
        est: C.params.a,
        true_: g[0],
        color: y
      },
      {
        label: "b",
        est: C.params.b,
        true_: g[1],
        color: G
      }
    ] : [];
  }
  const W = ne(), re = [y, $, G];
  return /* @__PURE__ */ i("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ i("div", { children: [
      /* @__PURE__ */ t("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "矩估计量计算器" }),
      /* @__PURE__ */ t("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "选择总体分布，输入样本数据，自动推导矩估计量公式并给出数值估计； 观察样本量 n 增大时估计量向真实参数收敛的过程。" })
    ] }),
    /* @__PURE__ */ t("div", { className: "flex gap-1.5 flex-wrap", children: ["exponential", "normal", "uniform"].map((n) => /* @__PURE__ */ t(
      "button",
      {
        type: "button",
        onClick: () => te(n),
        className: "rounded-lg px-3 py-1.5 text-[12px] font-medium transition-colors " + (n === e ? "bg-[var(--accent)] text-white" : "border border-[var(--line)] bg-[var(--bg-elevated)] text-[var(--ink-soft)] hover:border-[var(--accent)] hover:text-[var(--accent)]"),
        children: R[n].label
      },
      n
    )) }),
    /* @__PURE__ */ i("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3", children: [
      /* @__PURE__ */ t("div", { className: "text-[12px] font-semibold text-[var(--ink)]", children: "设定真实参数（用于随机生成样本）" }),
      r.trueParamLabels.map((n, d) => /* @__PURE__ */ t(
        ue,
        {
          label: n,
          value: g[d],
          min: r.trueParamMin[d],
          max: r.trueParamMax[d],
          step: r.trueParamStep[d],
          onChange: (u) => {
            const N = [...g];
            N[d] = u, e === "uniform" && (d === 0 && u >= N[1] && (N[1] = u + 0.5), d === 1 && u <= N[0] && (N[0] = u - 0.5)), o(N);
          },
          color: re[d]
        },
        n
      )),
      /* @__PURE__ */ i("div", { className: "flex items-center gap-3 pt-1", children: [
        /* @__PURE__ */ t("span", { className: "w-20 shrink-0 text-[12px] font-semibold text-[var(--ink)]", children: "样本量 n" }),
        /* @__PURE__ */ t(
          "input",
          {
            type: "range",
            min: 5,
            max: 100,
            step: 1,
            value: m,
            onChange: (n) => x(Number(n.target.value)),
            className: "flex-1 h-1.5 cursor-pointer",
            style: { accentColor: y }
          }
        ),
        /* @__PURE__ */ t(
          "span",
          {
            className: "w-14 shrink-0 rounded-md px-2 py-0.5 text-center text-[12px] font-mono font-bold",
            style: { background: Y, color: y },
            children: m
          }
        )
      ] }),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: ee,
          className: "rounded-lg bg-[var(--accent)] px-4 py-1.5 text-[12px] font-medium text-white hover:opacity-90 transition-opacity",
          children: "随机生成样本"
        }
      )
    ] }),
    /* @__PURE__ */ i("div", { className: "space-y-1.5", children: [
      /* @__PURE__ */ i("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ i("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: [
          "样本数据（逗号分隔）",
          p.length > 0 && /* @__PURE__ */ i("span", { className: "ml-2 font-normal text-[var(--ink-soft)]", children: [
            "n = ",
            p.length
          ] })
        ] }),
        p.length === 0 && l.trim() !== "" && /* @__PURE__ */ t("span", { className: "text-[11px] text-red-500", children: "格式有误，请检查" })
      ] }),
      /* @__PURE__ */ t(
        "textarea",
        {
          value: l,
          onChange: (n) => s(n.target.value),
          rows: 3,
          className: "w-full rounded-lg border border-[var(--line)] bg-[var(--bg-elevated)] px-3 py-2 text-[12px] font-mono text-[var(--ink)] placeholder-[var(--ink-soft)] focus:outline-none focus:border-[var(--accent)] resize-none",
          placeholder: "输入样本值，逗号/空格分隔",
          spellCheck: !1
        }
      )
    ] }),
    p.length > 0 && /* @__PURE__ */ t("div", { className: "grid grid-cols-3 gap-2", children: [
      {
        label: "一阶样本矩 x̄",
        val: h(A),
        sub: "(1/n)·Σxᵢ",
        color: y
      },
      {
        label: "二阶样本矩 B₂",
        val: h(U),
        sub: "(1/n)·Σxᵢ²",
        color: $
      },
      {
        label: "样本方差 B₂−x̄²",
        val: h(Z),
        sub: "= σ̂² (矩估计)",
        color: G
      }
    ].map(({ label: n, val: d, sub: u, color: N }) => /* @__PURE__ */ i(
      "div",
      {
        className: "rounded-lg p-2.5 text-center",
        style: {
          background: _(N, "15"),
          border: `1px solid ${_(N, "30")}`
        },
        children: [
          /* @__PURE__ */ t("div", { className: "text-[10px] text-[var(--ink-soft)] leading-snug", children: n }),
          /* @__PURE__ */ t(
            "div",
            {
              className: "text-[15px] font-extrabold font-mono mt-0.5",
              style: { color: N },
              children: d
            }
          ),
          /* @__PURE__ */ t("div", { className: "text-[10px] text-[var(--ink-soft)]", children: u })
        ]
      },
      n
    )) }),
    p.length > 0 && /* @__PURE__ */ i("div", { className: "rounded-lg border border-[var(--line)] overflow-hidden", children: [
      /* @__PURE__ */ i(
        "button",
        {
          type: "button",
          onClick: () => f((n) => !n),
          className: "w-full flex items-center justify-between px-4 py-2.5 bg-[var(--bg-muted)] text-[13px] font-semibold text-[var(--ink)] hover:bg-[var(--line)] transition-colors",
          children: [
            /* @__PURE__ */ t("span", { children: "矩估计推导过程" }),
            /* @__PURE__ */ t("span", { className: "text-[var(--ink-soft)] text-[11px]", children: c ? "收起 ▲" : "展开 ▼" })
          ]
        }
      ),
      c && /* @__PURE__ */ t("div", { className: "divide-y divide-[var(--line)]", children: S.map((n, d) => /* @__PURE__ */ i(
        "div",
        {
          className: "flex gap-3 px-4 py-3 items-start",
          style: {
            background: n.color ? _(n.color, "08") : void 0
          },
          children: [
            /* @__PURE__ */ t(
              "span",
              {
                className: "shrink-0 text-[11px] font-semibold mt-0.5",
                style: { color: n.color ?? "var(--ink-soft)" },
                children: n.label
              }
            ),
            /* @__PURE__ */ t(
              "span",
              {
                className: "font-mono text-[12px] leading-relaxed break-all",
                style: { color: n.color ?? "var(--ink)" },
                children: n.math
              }
            )
          ]
        },
        d
      )) })
    ] }),
    p.length > 0 && W.length > 0 && /* @__PURE__ */ i(
      "div",
      {
        className: "rounded-lg border-2 p-4 space-y-3",
        style: { borderColor: y, background: Y },
        children: [
          /* @__PURE__ */ t("div", { className: "text-[13px] font-bold text-[var(--ink)]", children: "矩估计结果对比" }),
          /* @__PURE__ */ t(
            "div",
            {
              className: "grid gap-2",
              style: { gridTemplateColumns: `repeat(${W.length}, 1fr)` },
              children: W.map(({ label: n, est: d, true_: u, color: N }) => /* @__PURE__ */ i(
                "div",
                {
                  className: "rounded-lg p-3 text-center",
                  style: {
                    background: "var(--bg-elevated)",
                    border: `1.5px solid ${_(N, "40")}`
                  },
                  children: [
                    /* @__PURE__ */ i("div", { className: "text-[10px] text-[var(--ink-soft)]", children: [
                      "参数 ",
                      n
                    ] }),
                    /* @__PURE__ */ t(
                      "div",
                      {
                        className: "text-[20px] font-extrabold font-mono mt-0.5",
                        style: { color: N },
                        children: ce(d)
                      }
                    ),
                    /* @__PURE__ */ i("div", { className: "text-[10px] text-[var(--ink-soft)] mt-0.5", children: [
                      "矩估计 ",
                      n,
                      "̂"
                    ] }),
                    isFinite(u) && /* @__PURE__ */ i(
                      "div",
                      {
                        className: "mt-1 text-[10px] font-mono rounded px-1.5 py-0.5",
                        style: {
                          background: Math.abs(d - u) < 0.1 ? "rgb(16 185 129 / 0.12)" : "rgb(245 158 11 / 0.14)",
                          color: Math.abs(d - u) < 0.1 ? "var(--color-success)" : "var(--color-warning)"
                        },
                        children: [
                          "真值 ",
                          u.toFixed(3),
                          "｜误差",
                          " ",
                          Math.abs(d - u).toFixed(3)
                        ]
                      }
                    )
                  ]
                },
                n
              ))
            }
          ),
          /* @__PURE__ */ t("p", { className: "text-[11px] text-[var(--ink-soft)] leading-relaxed", children: "矩估计的理论保证：当样本量 n → ∞ 时，由大数定律，样本矩依概率收敛于总体矩，从而矩估计量也收敛于真实参数（一致估计量）。" })
        ]
      }
    ),
    /* @__PURE__ */ i("div", { className: "rounded-lg border border-[var(--line)] overflow-hidden", children: [
      /* @__PURE__ */ i("div", { className: "flex items-center justify-between px-4 py-2.5 bg-[var(--bg-muted)]", children: [
        /* @__PURE__ */ i("div", { children: [
          /* @__PURE__ */ t("span", { className: "text-[13px] font-semibold text-[var(--ink)]", children: "收敛性演示" }),
          /* @__PURE__ */ t("span", { className: "ml-2 text-[11px] text-[var(--ink-soft)]", children: "n 增大时矩估计量趋近真实参数" })
        ] }),
        /* @__PURE__ */ t(
          "button",
          {
            type: "button",
            onClick: ae,
            className: "rounded-lg bg-[var(--accent)] px-3 py-1 text-[12px] font-medium text-white hover:opacity-90 transition-opacity",
            children: w ? "重新模拟" : "开始模拟"
          }
        )
      ] }),
      w && O ? /* @__PURE__ */ i("div", { className: "p-3 space-y-2", children: [
        /* @__PURE__ */ t(pe, { series: O }),
        /* @__PURE__ */ t("p", { className: "text-[11px] text-[var(--ink-soft)] leading-relaxed px-1", children: "虚线为真实参数值，实线为矩估计量随 n 的变化。随着样本量增大， 矩估计量的波动越来越小并趋近于真值——这正是矩估计一致性的直观体现。" })
      ] }) : /* @__PURE__ */ t("div", { className: "px-4 py-6 text-center text-[12px] text-[var(--ink-soft)]", children: "点击「开始模拟」生成 200 个样本，观察矩估计量随 n 变化的收敛过程" })
    ] }),
    /* @__PURE__ */ i("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ t("span", { className: "font-semibold text-[var(--ink)]", children: "矩估计核心思想：" }),
      "用",
      /* @__PURE__ */ t("strong", { className: "text-[var(--ink)]", children: "样本矩" }),
      "替换",
      /* @__PURE__ */ t("strong", { className: "text-[var(--ink)]", children: "总体矩" }),
      "。 总体 k 阶矩 μₖ = E[Xᵏ] 是参数 θ 的函数；将其替换为样本 k 阶矩 Bₖ = (1/n)·Σxᵢᵏ，反解出参数即为矩估计量 θ̂。 方法简单、直观，但当总体分布的高阶矩需要用时，估计精度可能不如极大似然估计。"
    ] })
  ] });
}
const ve = se(he);
export {
  ve as default
};
