import type { ButtonHTMLAttributes, ReactNode } from "react";
export interface NavigationCardProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "title"> {
    title: string;
    description?: string;
    icon?: ReactNode;
}
export declare function NavigationCard({ title, description, icon, className, ...props }: NavigationCardProps): import("react").JSX.Element;
export declare function PreviewCard({ title, description, eyebrow, art, footer, className, ...props }: NavigationCardProps & {
    eyebrow: string;
    art?: ReactNode;
    footer?: ReactNode;
}): import("react").JSX.Element;
