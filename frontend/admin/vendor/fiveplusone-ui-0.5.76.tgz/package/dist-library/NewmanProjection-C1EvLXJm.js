import { jsxs as o, jsx as t } from "react/jsx-runtime";
import { memo as K, useState as z, useMemo as H } from "react";
const d = "#6d28d9";
function g(n) {
  const s = n % 360;
  return s < 0 ? s + 360 : s;
}
function b(n) {
  return n * Math.PI / 180;
}
function O(n) {
  const l = b(n);
  return 12 / 2 * (1 + Math.cos(3 * l));
}
function Q(n) {
  const s = b(n), l = 8 + 8 * Math.cos(s) + 1 * Math.cos(2 * s) + 3 * Math.cos(3 * s);
  return l < 0 ? 0 : l;
}
function j(n, s) {
  return n === "ethane" ? O(s) : Q(s);
}
function U(n, s) {
  const l = g(s), c = (y) => {
    const p = Math.abs(g(l - y));
    return Math.min(p, 360 - p) <= 12;
  };
  return n === "ethane" ? c(0) || c(120) || c(240) ? {
    name: "重叠式 (Eclipsed)",
    description: "前后碳上的氢正对重叠，电子云排斥最大，能量最高（峰）。"
  } : c(60) || c(180) || c(300) ? {
    name: "交叉式 (Staggered)",
    description: "前后氢错开 60°，排斥最小，最稳定（谷）。"
  } : {
    name: "扭转中间构象",
    description: "介于交叉式与重叠式之间，能量处于上升或下降的斜坡上。"
  } : c(180) ? {
    name: "对位交叉式 (Anti)",
    description: "两个甲基相距最远（180°），空间位阻最小，全局最稳定（最低谷）。"
  } : c(60) || c(300) ? {
    name: "邻位交叉式 (Gauche)",
    description: "两个甲基相隔 60°，比对位稍高，为局部次低谷。"
  } : c(120) || c(240) ? {
    name: "部分重叠式",
    description: "甲基与氢重叠，能量较高（次高峰）。"
  } : c(0) ? {
    name: "全重叠式 (Syn / Eclipsed)",
    description: "两个甲基正对重叠，位阻最大，能量最高（最高峰）。"
  } : {
    name: "扭转中间构象",
    description: "介于稳定与不稳定构象之间的过渡区域。"
  };
}
function V() {
  const [n, s] = z("ethane"), [l, c] = z(60), y = H(() => {
    const e = [];
    for (let r = 0; r <= 360; r += 2)
      e.push({ theta: r, energy: j(n, r) });
    return e;
  }, [n]), p = H(() => {
    let e = 0;
    for (const r of y)
      r.energy > e && (e = r.energy);
    return e === 0 ? 1 : e;
  }, [y]), N = j(n, l), w = U(n, l), h = 110, u = 110, M = 70, W = 62, A = 70, B = [90, 210, 330], P = [270, 30, 150];
  function R(e) {
    const r = b(e);
    return { x: h + W * Math.cos(r), y: u - W * Math.sin(r) };
  }
  function Y(e) {
    const r = b(e);
    return { x: h + A * Math.cos(r), y: u - A * Math.sin(r) };
  }
  const I = n === "ethane" ? ["H", "H", "H"] : ["CH₃", "H", "H"], T = n === "ethane" ? ["H", "H", "H"] : ["CH₃", "H", "H"], $ = 340, E = 180, f = 44, D = 14, i = 16, J = 34, S = $ - f - D, x = E - i - J;
  function k(e) {
    return f + e / 360 * S;
  }
  function F(e) {
    return i + x - e / p * x;
  }
  const G = H(() => {
    let e = "";
    return y.forEach((r, a) => {
      const m = k(r.theta), v = F(r.energy);
      e += a === 0 ? `M ${m.toFixed(2)} ${v.toFixed(2)}` : ` L ${m.toFixed(2)} ${v.toFixed(2)}`;
    }), e;
  }, [y, p]), C = k(g(l)), L = F(N), X = [0, 60, 120, 180, 240, 300, 360];
  return /* @__PURE__ */ o("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ t("h3", { className: "text-lg font-semibold", style: { color: "var(--ink)" }, children: "纽曼投影构象能量" }),
    /* @__PURE__ */ t("p", { className: "mt-1 text-sm", style: { color: "var(--ink-soft)" }, children: "拖动滑块调节二面角 θ，左侧纽曼投影中后面原子的键随 θ 旋转，右侧势能曲线显示对应的相对能量。 交叉式稳定（谷）、重叠式高能（峰）；丁烷以对位交叉式最稳定。" }),
    /* @__PURE__ */ o("div", { className: "mt-3 flex gap-2", children: [
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => s("ethane"),
          className: "rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors",
          style: {
            borderColor: n === "ethane" ? d : "var(--line)",
            backgroundColor: n === "ethane" ? d : "var(--bg-elevated)",
            color: n === "ethane" ? "white" : "var(--ink)"
          },
          children: "乙烷 (C₂H₆)"
        }
      ),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => s("butane"),
          className: "rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors",
          style: {
            borderColor: n === "butane" ? d : "var(--line)",
            backgroundColor: n === "butane" ? d : "var(--bg-elevated)",
            color: n === "butane" ? "white" : "var(--ink)"
          },
          children: "丁烷 (绕 C2–C3)"
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "mt-4 grid grid-cols-1 gap-4 md:grid-cols-2", children: [
      /* @__PURE__ */ o(
        "div",
        {
          className: "rounded-lg border p-2",
          style: {
            borderColor: "var(--line)",
            backgroundColor: "var(--bg-muted)"
          },
          children: [
            /* @__PURE__ */ o(
              "svg",
              {
                viewBox: "0 0 220 220",
                className: "mx-auto block h-auto w-full max-w-[260px]",
                children: [
                  /* @__PURE__ */ t(
                    "circle",
                    {
                      cx: h,
                      cy: u,
                      r: M,
                      fill: "var(--bg-muted)",
                      stroke: "var(--line)",
                      strokeWidth: 2
                    }
                  ),
                  P.map((e, r) => {
                    const a = e + l, m = Y(a), v = {
                      x: h + M * Math.cos(b(a)),
                      y: u - M * Math.sin(b(a))
                    }, q = n === "butane" && r === 0;
                    return /* @__PURE__ */ o("g", { children: [
                      /* @__PURE__ */ t(
                        "line",
                        {
                          x1: v.x,
                          y1: v.y,
                          x2: m.x,
                          y2: m.y,
                          stroke: "var(--ink-soft)",
                          strokeWidth: q ? 5 : 4,
                          strokeLinecap: "round"
                        }
                      ),
                      /* @__PURE__ */ t(
                        "text",
                        {
                          x: m.x,
                          y: m.y,
                          dx: m.x >= h ? 4 : -4,
                          dy: m.y >= u ? 12 : -4,
                          fontSize: 11,
                          textAnchor: m.x >= h ? "start" : "end",
                          fill: "var(--ink-soft)",
                          children: T[r]
                        }
                      )
                    ] }, `back-${r}`);
                  }),
                  B.map((e, r) => {
                    const a = R(e), m = n === "butane" && r === 0;
                    return /* @__PURE__ */ o("g", { children: [
                      /* @__PURE__ */ t(
                        "line",
                        {
                          x1: h,
                          y1: u,
                          x2: a.x,
                          y2: a.y,
                          stroke: d,
                          strokeWidth: m ? 6 : 5,
                          strokeLinecap: "round"
                        }
                      ),
                      /* @__PURE__ */ t(
                        "text",
                        {
                          x: a.x,
                          y: a.y,
                          dx: Math.abs(a.x - h) < 6 ? 0 : a.x > h ? 6 : -6,
                          dy: a.y > u ? 14 : -6,
                          fontSize: 12,
                          fontWeight: 600,
                          textAnchor: Math.abs(a.x - h) < 6 ? "middle" : a.x > h ? "start" : "end",
                          fill: d,
                          children: I[r]
                        }
                      )
                    ] }, `front-${r}`);
                  }),
                  /* @__PURE__ */ t("circle", { cx: h, cy: u, r: 4, fill: d })
                ]
              }
            ),
            /* @__PURE__ */ t(
              "p",
              {
                className: "mt-1 text-center text-xs",
                style: { color: "var(--ink-soft)" },
                children: "紫色 = 前碳（圆心 Y 形）；灰色 = 后碳（圆周倒 Y，随 θ 旋转）"
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ o(
        "div",
        {
          className: "rounded-lg border p-2",
          style: {
            borderColor: "var(--line)",
            backgroundColor: "var(--bg-muted)"
          },
          children: [
            /* @__PURE__ */ o(
              "svg",
              {
                viewBox: `0 0 ${$} ${E}`,
                className: "block h-auto w-full",
                children: [
                  /* @__PURE__ */ t(
                    "line",
                    {
                      x1: f,
                      y1: i,
                      x2: f,
                      y2: i + x,
                      stroke: "var(--line)",
                      strokeWidth: 1.5
                    }
                  ),
                  /* @__PURE__ */ t(
                    "line",
                    {
                      x1: f,
                      y1: i + x,
                      x2: f + S,
                      y2: i + x,
                      stroke: "var(--line)",
                      strokeWidth: 1.5
                    }
                  ),
                  X.map((e) => /* @__PURE__ */ o("g", { children: [
                    /* @__PURE__ */ t(
                      "line",
                      {
                        x1: k(e),
                        y1: i + x,
                        x2: k(e),
                        y2: i + x + 4,
                        stroke: "var(--line)",
                        strokeWidth: 1
                      }
                    ),
                    /* @__PURE__ */ o(
                      "text",
                      {
                        x: k(e),
                        y: i + x + 16,
                        fontSize: 9,
                        textAnchor: "middle",
                        fill: "var(--ink-soft)",
                        children: [
                          e,
                          "°"
                        ]
                      }
                    )
                  ] }, `xt-${e}`)),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: 6,
                      y: i + x / 2,
                      fontSize: 9,
                      textAnchor: "middle",
                      fill: "var(--ink-soft)",
                      transform: `rotate(-90 6 ${i + x / 2})`,
                      children: "相对能量 (kJ/mol)"
                    }
                  ),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: f - 6,
                      y: i + 4,
                      fontSize: 9,
                      textAnchor: "end",
                      fill: "var(--ink-soft)",
                      children: p.toFixed(0)
                    }
                  ),
                  /* @__PURE__ */ t(
                    "text",
                    {
                      x: f - 6,
                      y: i + x,
                      fontSize: 9,
                      textAnchor: "end",
                      fill: "var(--ink-soft)",
                      children: "0"
                    }
                  ),
                  /* @__PURE__ */ t("path", { d: G, fill: "none", stroke: d, strokeWidth: 2 }),
                  /* @__PURE__ */ t(
                    "line",
                    {
                      x1: C,
                      y1: L,
                      x2: C,
                      y2: i + x,
                      stroke: d,
                      strokeWidth: 1,
                      strokeDasharray: "3 3",
                      opacity: 0.5
                    }
                  ),
                  /* @__PURE__ */ t(
                    "circle",
                    {
                      cx: C,
                      cy: L,
                      r: 5,
                      fill: "#f59e0b",
                      stroke: "white",
                      strokeWidth: 1.5
                    }
                  )
                ]
              }
            ),
            /* @__PURE__ */ t(
              "p",
              {
                className: "mt-1 text-center text-xs",
                style: { color: "var(--ink-soft)" },
                children: "橙色点 = 当前 θ 对应能量"
              }
            )
          ]
        }
      )
    ] }),
    /* @__PURE__ */ o("div", { className: "mt-4", children: [
      /* @__PURE__ */ o("div", { className: "mb-1 flex items-center justify-between text-sm", children: [
        /* @__PURE__ */ t("label", { htmlFor: "theta-slider", style: { color: "var(--ink)" }, children: "二面角 θ" }),
        /* @__PURE__ */ o("span", { className: "font-mono font-semibold", style: { color: d }, children: [
          g(l).toFixed(0),
          "°"
        ] })
      ] }),
      /* @__PURE__ */ t(
        "input",
        {
          id: "theta-slider",
          type: "range",
          min: 0,
          max: 360,
          step: 1,
          value: l,
          onChange: (e) => c(Number(e.target.value)),
          className: "w-full cursor-pointer",
          style: { accentColor: d }
        }
      ),
      /* @__PURE__ */ o(
        "div",
        {
          className: "mt-1 flex justify-between text-xs",
          style: { color: "var(--ink-soft)" },
          children: [
            /* @__PURE__ */ t("span", { children: "0°" }),
            /* @__PURE__ */ t("span", { children: "180°" }),
            /* @__PURE__ */ t("span", { children: "360°" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ o(
      "div",
      {
        className: "mt-4 rounded-lg border p-3",
        style: { borderColor: d, backgroundColor: "var(--bg-muted)" },
        children: [
          /* @__PURE__ */ o("div", { className: "flex flex-wrap items-baseline gap-x-3 gap-y-1", children: [
            /* @__PURE__ */ t("span", { className: "text-base font-semibold", style: { color: d }, children: w.name }),
            /* @__PURE__ */ o("span", { className: "text-sm", style: { color: "var(--ink-soft)" }, children: [
              "相对能量 ≈ ",
              N.toFixed(1),
              " kJ/mol"
            ] })
          ] }),
          /* @__PURE__ */ t("p", { className: "mt-1 text-sm", style: { color: "var(--ink)" }, children: w.description })
        ]
      }
    )
  ] });
}
const ee = K(V);
export {
  ee as default
};
