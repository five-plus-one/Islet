import { jsxs as d, jsx as a } from "react/jsx-runtime";
import { learningAlpha as U } from "./index.js";
import { memo as it, useState as M } from "react";
const P = "var(--fp-primary)", Q = "var(--fp-primary-soft)", C = "#0f766e", Z = "#0f766e33", G = "#c2410c", ct = "#c2410c2e", V = "#be123c", dt = "#be123c2e", tt = "var(--line)", y = 5e3;
function ht() {
  let t = 0, e = 0;
  for (; t === 0; ) t = Math.random();
  for (; e === 0; ) e = Math.random();
  return Math.sqrt(-2 * Math.log(t)) * Math.cos(2 * Math.PI * e);
}
function mt(t, e, n) {
  let r = 0, o = 0;
  for (let h = 0; h < n; h++) {
    const c = t + e * ht();
    r += c, o += c * c;
  }
  const l = r / n, i = n > 1 ? (o - n * l * l) / (n - 1) : 0;
  return [l, i];
}
function et(t, e, n) {
  if (n <= 0) return 0;
  const r = (t - e) / n;
  return Math.exp(-0.5 * r * r) / (n * Math.sqrt(2 * Math.PI));
}
function pt(t, e) {
  if (t <= 0 || e <= 0) return 0;
  const n = e / 2;
  return Math.pow(t, n - 1) * Math.exp(-t / 2) / (Math.pow(2, n) * F(n));
}
function ft(t, e) {
  if (e <= 0) return 0;
  const n = (e + 1) / 2, r = e / 2;
  return F(n) / (Math.sqrt(e * Math.PI) * F(r)) * Math.pow(1 + t * t / e, -n);
}
function F(t) {
  if (t < 0.5)
    return Math.PI / (Math.sin(Math.PI * t) * F(1 - t));
  const e = 7, n = [
    0.9999999999998099,
    676.5203681218851,
    -1259.1392167224028,
    771.3234287776531,
    -176.6150291621406,
    12.507343278686905,
    -0.13857109526572012,
    9984369578019572e-21,
    15056327351493116e-23
  ], r = t - 1;
  let o = n[0];
  for (let i = 1; i < e + 2; i++)
    o += n[i] / (r + i);
  const l = r + e + 0.5;
  return Math.sqrt(2 * Math.PI) * Math.pow(l, r + 0.5) * Math.exp(-l) * o;
}
function ut(t) {
  const e = 1 / (1 + 0.2316419 * Math.abs(t)), n = e * (0.31938153 + e * (-0.356563782 + e * (1.781477937 + e * (-1.821255978 + e * 1.330274429)))), r = 1 - et(t, 0, 1) * n;
  return t >= 0 ? r : 1 - r;
}
function xt(t, e) {
  return t <= 0 ? 0 : bt(e / 2, t / 2) / F(e / 2);
}
function bt(t, e) {
  if (e <= 0) return 0;
  let n = 0, r = 1 / t;
  n = r;
  for (let o = 1; o < 200 && (r *= e / (t + o), n += r, !(Math.abs(r) < 1e-10)); o++)
    ;
  return Math.exp(-e + t * Math.log(e)) * n;
}
function gt(t, e) {
  const n = t * t, o = vt(e / (e + n), e / 2, 0.5) / 2;
  return t >= 0 ? 1 - o : o;
}
function vt(t, e, n) {
  if (t <= 0) return 0;
  if (t >= 1) return 1;
  const r = F(e) * F(n) / F(e + n), o = Math.pow(t, e) * Math.pow(1 - t, n) / (e * r);
  let l = 1, i = 1, h = 1, c = 1 - (e + n) * t / (e + 1);
  Math.abs(c) < 1e-30 && (c = 1e-30), c = 1 / c, i = c;
  for (let u = 1; u <= 100; u++) {
    const b = 2 * u;
    let v = u * (n - u) * t / ((e + b - 1) * (e + b));
    if (c = 1 + v * c, Math.abs(c) < 1e-30 && (c = 1e-30), h = 1 + v / h, Math.abs(h) < 1e-30 && (h = 1e-30), c = 1 / c, l = c * h, i *= l, v = -(e + u) * (e + n + u) * t / ((e + b) * (e + b + 1)), c = 1 + v * c, Math.abs(c) < 1e-30 && (c = 1e-30), h = 1 + v / h, Math.abs(h) < 1e-30 && (h = 1e-30), c = 1 / c, l = c * h, i *= l, Math.abs(l - 1) < 1e-7) break;
  }
  return o * i;
}
function B(t, e) {
  const n = t * Math.sqrt(e);
  if (n < 0.27) return 1;
  let r = 0;
  for (let l = 1; l <= 50; l++)
    r += Math.pow(-1, l + 1) * Math.exp(-2 * l * l * n * n);
  const o = 2 * r;
  return Math.max(0, Math.min(1, o));
}
function z(t, e) {
  const n = t.length;
  let r = 0;
  for (let o = 0; o < n; o++) {
    const l = (o + 1) / n, i = e(t[o]);
    r = Math.max(r, Math.abs(l - i));
  }
  return r;
}
function Nt(t, e, n, r) {
  const o = [], l = (r - n) / e;
  for (let i = 0; i < e; i++)
    o.push({ lo: n + i * l, hi: n + (i + 1) * l, count: 0 });
  for (const i of t) {
    const h = Math.min(e - 1, Math.max(0, Math.floor((i - n) / l)));
    o[h].count++;
  }
  return o;
}
function Y({
  title: t,
  subtitle: e,
  data: n,
  nBins: r,
  xMin: o,
  xMax: l,
  color: i,
  colorLight: h,
  pdfFn: c,
  ksPValue: u,
  nSamples: b,
  xLabel: v
}) {
  const m = { top: 8, right: 8, bottom: 28, left: 30 }, X = 280 - m.left - m.right, N = 140 - m.top - m.bottom, H = Nt(n, r, o, l), E = (l - o) / r, T = H.map(
    (s) => b > 0 ? s.count / (b * E) : 0
  ), I = 80, k = [];
  for (let s = 0; s <= I; s++) {
    const f = o + s / I * (l - o);
    k.push([f, c(f)]);
  }
  const D = Math.max(
    ...T,
    ...k.map(([, s]) => s),
    0.01
  ), p = (s) => m.left + (s - o) / (l - o) * X, L = (s) => m.top + (1 - s / D) * N, j = [], O = (l - o) / 4;
  for (let s = 0; s <= 4; s++)
    j.push(o + s * O);
  const R = k.map(
    ([s, f], g) => `${g === 0 ? "M" : "L"}${p(s).toFixed(1)},${L(f).toFixed(1)}`
  ).join(" "), K = u >= 0.05 ? C : V;
  return /* @__PURE__ */ d("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-elevated)] p-2", children: [
    /* @__PURE__ */ d("div", { className: "mb-1 px-1", children: [
      /* @__PURE__ */ a("div", { className: "text-[12px] font-bold", style: { color: i }, children: t }),
      /* @__PURE__ */ a("div", { className: "text-[10px] text-[var(--ink-soft)]", children: e })
    ] }),
    /* @__PURE__ */ d(
      "svg",
      {
        viewBox: "0 0 280 140",
        className: "w-full",
        style: { maxHeight: 150 },
        children: [
          /* @__PURE__ */ a(
            "rect",
            {
              x: m.left,
              y: m.top,
              width: X,
              height: N,
              fill: "var(--bg-muted)",
              stroke: tt
            }
          ),
          H.map((s, f) => {
            const g = p(s.lo), S = Math.max(1, p(s.hi) - p(s.lo) - 1), q = L(T[f]), _ = L(0) - q;
            return /* @__PURE__ */ a(
              "rect",
              {
                x: g,
                y: q,
                width: S,
                height: Math.max(0, _),
                fill: h,
                stroke: i,
                strokeWidth: "0.5",
                opacity: "0.8"
              },
              f
            );
          }),
          b > 0 && /* @__PURE__ */ a(
            "path",
            {
              d: R,
              fill: "none",
              stroke: i,
              strokeWidth: "1.8",
              strokeLinejoin: "round"
            }
          ),
          /* @__PURE__ */ a(
            "line",
            {
              x1: m.left,
              y1: m.top + N,
              x2: m.left + X,
              y2: m.top + N,
              stroke: "var(--line)",
              strokeWidth: "1"
            }
          ),
          j.map((s) => /* @__PURE__ */ d("g", { children: [
            /* @__PURE__ */ a(
              "line",
              {
                x1: p(s),
                y1: m.top + N,
                x2: p(s),
                y2: m.top + N + 3,
                stroke: "var(--line)"
              }
            ),
            /* @__PURE__ */ a(
              "text",
              {
                x: p(s),
                y: m.top + N + 10,
                textAnchor: "middle",
                fontSize: "8",
                fill: "var(--ink-faint)",
                children: Math.abs(s) < 0.01 ? "0" : s.toFixed(1)
              }
            )
          ] }, s)),
          v && /* @__PURE__ */ a(
            "text",
            {
              x: m.left + X / 2,
              y: 138,
              textAnchor: "middle",
              fontSize: "8",
              fill: "var(--ink-faint)",
              fontStyle: "italic",
              children: v
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ d(
      "div",
      {
        className: "mt-1 rounded px-2 py-0.5 text-[10px] font-mono text-center",
        style: {
          background: u >= 0.05 ? Z : dt,
          color: K
        },
        children: [
          "K-S p值 = ",
          b > 0 ? u.toFixed(4) : "—",
          b > 0 && /* @__PURE__ */ a("span", { className: "ml-1", children: u >= 0.05 ? "[OK] 符合理论" : "[X] 偏离理论" })
        ]
      }
    )
  ] });
}
function J({
  label: t,
  value: e,
  min: n,
  max: r,
  step: o,
  display: l,
  color: i,
  onChange: h
}) {
  return /* @__PURE__ */ d("div", { className: "flex items-center gap-3", children: [
    /* @__PURE__ */ a("span", { className: "w-24 text-[12px] font-semibold text-[var(--ink)] shrink-0", children: t }),
    /* @__PURE__ */ a(
      "input",
      {
        type: "range",
        min: n,
        max: r,
        step: o,
        value: e,
        onChange: (c) => h(Number(c.target.value)),
        className: "flex-1 h-1.5 cursor-pointer",
        style: { accentColor: i }
      }
    ),
    /* @__PURE__ */ a(
      "span",
      {
        className: "w-12 rounded-md px-1.5 py-0.5 text-center text-[12px] font-mono font-bold shrink-0",
        style: { background: U(i, "22"), color: i },
        children: l
      }
    )
  ] });
}
function Mt() {
  const [t, e] = M(0), [n, r] = M(1), [o, l] = M(10), [i, h] = M([]), [c, u] = M([]), [b, v] = M([]), [$, W] = M(!1), [m, X] = M(0), [N, H] = M(0), [E, T] = M(0);
  function I() {
    W(!0), setTimeout(() => {
      const s = [], f = [], g = [];
      for (let x = 0; x < y; x++) {
        const [w, A] = mt(t, n, o);
        s.push(w);
        const rt = A > 0 ? (o - 1) * A / (n * n) : 0;
        f.push(rt);
        const lt = A > 0 ? (w - t) / (Math.sqrt(A) / Math.sqrt(o)) : 0;
        g.push(lt);
      }
      const S = [...s].sort((x, w) => x - w), q = [...f].sort((x, w) => x - w), _ = [...g].sort((x, w) => x - w), nt = n / Math.sqrt(o), ot = z(
        S,
        (x) => ut((x - t) / nt)
      ), st = z(q, (x) => xt(x, o - 1)), at = z(_, (x) => gt(x, o - 1));
      h(s), u(f), v(g), X(B(ot, y)), H(B(st, y)), T(B(at, y)), W(!1);
    }, 0);
  }
  function k() {
    h([]), u([]), v([]), X(0), H(0), T(0);
  }
  const D = n / Math.sqrt(o), p = o - 1, L = [t - 4 * D, t + 4 * D], O = [0, Math.max(p + 5 * Math.sqrt(2 * p), p * 3)], R = [-5, 5], K = i.length > 0;
  return /* @__PURE__ */ d("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-4", children: [
    /* @__PURE__ */ d("div", { children: [
      /* @__PURE__ */ a("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "正态总体抽样分布仿真" }),
      /* @__PURE__ */ d("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5 leading-relaxed", children: [
        "设定正态总体参数与样本量，重复抽样 ",
        y.toLocaleString(),
        " ",
        "次，实证验证四大抽样定理。 蓝色柱 = 模拟经验分布；曲线 = 理论概率密度；K-S 检验 p 值衡量吻合度。"
      ] })
    ] }),
    /* @__PURE__ */ d("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3", children: [
      /* @__PURE__ */ a("div", { className: "text-[12px] font-semibold text-[var(--ink)] mb-2", children: "总体设定：X ~ N(μ, σ²)" }),
      /* @__PURE__ */ a(
        J,
        {
          label: "均值 μ",
          value: t,
          min: -2,
          max: 2,
          step: 0.1,
          display: t.toFixed(1),
          color: P,
          onChange: (s) => {
            e(s), k();
          }
        }
      ),
      /* @__PURE__ */ a(
        J,
        {
          label: "标准差 σ",
          value: n,
          min: 0.5,
          max: 3,
          step: 0.1,
          display: n.toFixed(1),
          color: G,
          onChange: (s) => {
            r(s), k();
          }
        }
      ),
      /* @__PURE__ */ a(
        J,
        {
          label: "样本量 n",
          value: o,
          min: 2,
          max: 30,
          step: 1,
          display: String(o),
          color: C,
          onChange: (s) => {
            l(s), k();
          }
        }
      ),
      /* @__PURE__ */ a("div", { className: "mt-2 grid grid-cols-3 gap-2 text-center", children: [
        {
          label: "X̄ ~ N(μ, σ²/n)",
          val: `N(${t.toFixed(1)}, ${(n * n / o).toFixed(3)})`,
          color: P
        },
        {
          label: "(n−1)S²/σ² ~ χ²(n−1)",
          val: `χ²(${p})`,
          color: G
        },
        {
          label: "t = (X̄−μ)/(S/√n)",
          val: `t(${p})`,
          color: C
        }
      ].map(({ label: s, val: f, color: g }) => /* @__PURE__ */ d(
        "div",
        {
          className: "rounded-md p-2",
          style: { background: U(g, "18") },
          children: [
            /* @__PURE__ */ a("div", { className: "text-[9px] text-[var(--ink-soft)] leading-tight", children: s }),
            /* @__PURE__ */ a(
              "div",
              {
                className: "text-[11px] font-bold font-mono mt-0.5",
                style: { color: g },
                children: f
              }
            )
          ]
        },
        s
      )) })
    ] }),
    /* @__PURE__ */ d("div", { className: "flex flex-wrap gap-2 items-center", children: [
      /* @__PURE__ */ a(
        "button",
        {
          type: "button",
          onClick: I,
          disabled: $,
          className: "rounded-lg px-4 py-2 text-[13px] font-semibold text-white transition-opacity",
          style: {
            background: P,
            opacity: $ ? 0.6 : 1,
            cursor: $ ? "not-allowed" : "pointer"
          },
          children: $ ? "仿真中…" : `▶ 重复抽样 ${y.toLocaleString()} 次`
        }
      ),
      /* @__PURE__ */ a(
        "button",
        {
          type: "button",
          onClick: k,
          className: "rounded-lg bg-[var(--bg-muted)] px-3 py-2 text-[13px] font-medium text-[var(--ink-soft)] hover:bg-[var(--line)]",
          children: "重置"
        }
      ),
      K && /* @__PURE__ */ d("span", { className: "text-[12px] text-[var(--ink-soft)] ml-auto", children: [
        "已完成 ",
        y.toLocaleString(),
        " 次抽样，每次 n = ",
        o,
        " 个观测"
      ] })
    ] }),
    K ? /* @__PURE__ */ d("div", { className: "space-y-3", children: [
      /* @__PURE__ */ d("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2", children: [
        /* @__PURE__ */ a(
          Y,
          {
            title: "样本均值 X̄",
            subtitle: `理论分布：N(μ, σ²/n) = N(${t.toFixed(2)}, ${(n * n / o).toFixed(3)})`,
            data: i,
            nBins: 40,
            xMin: L[0],
            xMax: L[1],
            color: P,
            colorLight: Q,
            pdfFn: (s) => et(s, t, D),
            ksPValue: m,
            nSamples: y,
            xLabel: "x̄"
          }
        ),
        /* @__PURE__ */ a(
          Y,
          {
            title: "卡方统计量 (n−1)S²/σ²",
            subtitle: `理论分布：χ²(n−1) = χ²(${p})`,
            data: c,
            nBins: 40,
            xMin: 0,
            xMax: O[1],
            color: G,
            colorLight: ct,
            pdfFn: (s) => pt(s, p),
            ksPValue: N,
            nSamples: y,
            xLabel: "(n−1)S²/σ²"
          }
        )
      ] }),
      /* @__PURE__ */ d("div", { className: "grid grid-cols-1 gap-3 sm:grid-cols-2", children: [
        /* @__PURE__ */ a(
          Y,
          {
            title: "t 统计量  (X̄ − μ) / (S/√n)",
            subtitle: `理论分布：t(n−1) = t(${p})（厚尾，比正态宽）`,
            data: b,
            nBins: 40,
            xMin: R[0],
            xMax: R[1],
            color: C,
            colorLight: Z,
            pdfFn: (s) => ft(s, p),
            ksPValue: E,
            nSamples: y,
            xLabel: "t"
          }
        ),
        /* @__PURE__ */ d("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3 flex flex-col justify-between", children: [
          /* @__PURE__ */ d("div", { children: [
            /* @__PURE__ */ a("div", { className: "text-[13px] font-bold text-[var(--ink)] mb-1", children: "K-S 检验汇总" }),
            /* @__PURE__ */ d("p", { className: "text-[11px] text-[var(--ink-soft)] leading-relaxed mb-3", children: [
              "K-S 检验零假设：样本来自指定理论分布。 p值 > 0.05 表示无统计显著偏差，即",
              /* @__PURE__ */ a("b", { className: "text-[var(--ink)]", children: "实证与理论高度吻合" }),
              "。"
            ] }),
            /* @__PURE__ */ a("div", { className: "space-y-2", children: [
              { label: "X̄ vs N(μ, σ²/n)", p: m, color: P },
              {
                label: "(n−1)S²/σ² vs χ²(n−1)",
                p: N,
                color: G
              },
              { label: "t vs t(n−1)", p: E, color: C }
            ].map(({ label: s, p: f, color: g }) => {
              const S = f >= 0.05;
              return /* @__PURE__ */ d(
                "div",
                {
                  className: "rounded-md bg-[var(--bg-elevated)] border border-[var(--line)] px-3 py-2",
                  children: [
                    /* @__PURE__ */ d("div", { className: "flex items-center justify-between", children: [
                      /* @__PURE__ */ a(
                        "span",
                        {
                          className: "text-[11px] font-semibold",
                          style: { color: g },
                          children: s
                        }
                      ),
                      /* @__PURE__ */ d(
                        "span",
                        {
                          className: "text-[11px] font-mono font-bold",
                          style: { color: S ? C : V },
                          children: [
                            "p = ",
                            f.toFixed(4)
                          ]
                        }
                      )
                    ] }),
                    /* @__PURE__ */ a("div", { className: "mt-1 h-1.5 rounded-full overflow-hidden bg-[var(--bg-muted)]", children: /* @__PURE__ */ a(
                      "div",
                      {
                        className: "h-full rounded-full transition-all duration-500",
                        style: {
                          width: `${Math.min(100, f * 100 / 0.1)}%`,
                          background: S ? C : V
                        }
                      }
                    ) }),
                    /* @__PURE__ */ a(
                      "div",
                      {
                        className: "mt-0.5 text-[9px]",
                        style: { color: S ? C : V },
                        children: S ? "[OK] 不拒绝 H₀（吻合理论）" : "[X] 拒绝 H₀（n 太小时属正常）"
                      }
                    )
                  ]
                },
                s
              );
            }) })
          ] }),
          /* @__PURE__ */ d(
            "div",
            {
              className: "mt-3 rounded-lg p-2.5 text-[11px] leading-relaxed",
              style: { background: Q, color: P },
              children: [
                /* @__PURE__ */ a("div", { className: "font-bold mb-1", children: "三大定理验证结论" }),
                /* @__PURE__ */ a("div", { children: "① X̄ 服从正态分布 N(μ, σ²/n)—— 期望/方差缩放 √n 倍" }),
                /* @__PURE__ */ a("div", { children: "② (n−1)S²/σ² 独立于 X̄，服从 χ²(n−1)" }),
                /* @__PURE__ */ a("div", { children: "③ t 统计量服从 t(n−1)，比标准正态有更厚的尾部" })
              ]
            }
          )
        ] })
      ] })
    ] }) : /* @__PURE__ */ a(
      "div",
      {
        className: "rounded-lg border-2 border-dashed py-12 text-center text-[13px] text-[var(--ink-soft)]",
        style: { borderColor: tt },
        children: "点击「重复抽样」按钮，开始仿真验证四大抽样定理"
      }
    ),
    /* @__PURE__ */ d("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[11px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ a("span", { className: "font-semibold text-[var(--ink)]", children: "教学要点：" }),
      "增大 n 时，X̄ 的分布向均值 μ 收缩（方差 σ²/n → 0），t 分布趋近于标准正态； σ 越大，所有统计量的离散程度越大，但 K-S 检验仍验证理论形状正确。 这三个统计量是区间估计与假设检验的基础构建块。"
    ] })
  ] });
}
const wt = it(Mt);
export {
  wt as default
};
