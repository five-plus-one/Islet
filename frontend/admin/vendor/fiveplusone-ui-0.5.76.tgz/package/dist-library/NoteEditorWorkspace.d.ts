import { type MarkdownEditorProps } from "./editor/MarkdownEditor";
import { type NoteVersion } from "./editor/EditorPanels";
export interface EditableNote {
    id: string;
    title: string;
    markdown: string;
    revision: string;
}
export interface NoteEditorWorkspaceProps {
    document: EditableNote;
    onSave: (note: EditableNote, signal: AbortSignal) => Promise<EditableNote>;
    autosaveDelay?: number;
    readOnly?: boolean;
    editorProps?: Omit<MarkdownEditorProps, "markdown" | "documentKey" | "onChange" | "editable">;
    versions?: NoteVersion[];
    onRestore?: (id: string, expectedRevision: string, signal: AbortSignal) => Promise<EditableNote>;
    onExportDraft?: (note: EditableNote) => void;
    registerNavigationGuard?: (guard: () => Promise<boolean>) => () => void;
    onDirtyChange?: (dirty: boolean) => void;
}
/** A document boundary keeps asynchronous saves and pending text attached to their note. */
export declare function NoteEditorWorkspace(props: NoteEditorWorkspaceProps): import("react").JSX.Element;
