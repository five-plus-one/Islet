/** QuizQuestion - 从课栈 quiz/QuizQuestion 提取
 *
 * 答题卡：题号、题型与难度、题干、选项；作答与复盘两种模式。
 * 复盘模式显示正误与解析，选项用状态色区分。
 */
import { type ReactNode } from "react";
export type QuizDifficulty = "basic" | "medium" | "hard";
export interface QuizOption {
    id: string;
    text: ReactNode;
    correct?: boolean;
}
export interface QuizQuestionProps {
    index: number;
    total: number;
    kind?: string;
    difficulty?: QuizDifficulty;
    prompt: ReactNode;
    options: QuizOption[];
    /** 已选选项 id；多选用数组 */
    selected?: string | string[] | null;
    onSelect?: (id: string) => void;
    /** answer：作答中；review：显示答案与解析 */
    mode?: "answer" | "review";
    /** 解析文本，复盘时显示 */
    explanation?: ReactNode;
    /** 用掉提示时显示提示内容 */
    hint?: ReactNode;
}
export declare function QuizQuestion({ index, total, kind, difficulty, prompt, options, selected, onSelect, mode, explanation, hint, }: QuizQuestionProps): import("react").JSX.Element;
