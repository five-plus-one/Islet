import { jsxs as l, jsx as o } from "react/jsx-runtime";
import { learningAlpha as F } from "./index.js";
import { memo as I, useState as P, useCallback as _ } from "react";
const r = "var(--fp-primary)", N = "var(--fp-primary-soft)", i = "var(--ink)", m = "var(--ink-soft)", u = "var(--line)", v = "var(--bg-muted)", L = [
  "#5b46e5",
  "#7c3aed",
  "#0ea5e9",
  "#059669",
  "#d97706",
  "#dc2626"
], B = [
  {
    key: "identity",
    label: "X = 点数",
    fn: (n) => n,
    description: "最简单：X 直接等于骰子点数，六个样本点映射到六个不同实数值。"
  },
  {
    key: "oddEven",
    label: "X = 奇偶",
    fn: (n) => n % 2 === 1 ? 1 : 0,
    description: "X=1 表示奇数（1,3,5），X=0 表示偶数（2,4,6）。多对一映射，P(X=1)=P(X=0)=1/2。"
  },
  {
    key: "square",
    label: "X = 点数²",
    fn: (n) => n * n,
    description: "X = 点数的平方：1,4,9,16,25,36。每个值概率仍为 1/6，但值域分布极不均匀。"
  },
  {
    key: "sign",
    label: "X = ⌊点数/2⌋",
    fn: (n) => Math.floor(n / 2),
    description: "X 将 6 个点数压缩为 3 个值：0(点数1),1(点数2,3),2(点数4,5),3(点数6)。"
  },
  {
    key: "custom",
    label: "自定义",
    fn: (n) => n,
    description: "点击各样本点的数字输入框，自由设定 X 值，观察分布律变化。"
  }
];
function W(n) {
  return [1, 2, 3, 4, 5, 6].map((s) => ({
    face: s,
    xValue: n(s)
  }));
}
const z = {
  1: [[50, 50]],
  2: [
    [28, 28],
    [72, 72]
  ],
  3: [
    [28, 28],
    [50, 50],
    [72, 72]
  ],
  4: [
    [28, 28],
    [72, 28],
    [28, 72],
    [72, 72]
  ],
  5: [
    [28, 28],
    [72, 28],
    [50, 50],
    [28, 72],
    [72, 72]
  ],
  6: [
    [28, 25],
    [72, 25],
    [28, 50],
    [72, 50],
    [28, 75],
    [72, 75]
  ]
};
function D({ face: n, selected: s, onClick: c }) {
  const a = z[n] ?? [];
  return /* @__PURE__ */ o(
    "button",
    {
      type: "button",
      onClick: c,
      className: "rounded-xl border-2 transition-all duration-200 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-1",
      style: {
        borderColor: s ? r : u,
        background: s ? N : "var(--bg-elevated)",
        boxShadow: s ? `0 0 0 2px ${F(r, "44")}` : "0 1px 3px rgba(0,0,0,0.08)",
        padding: 0,
        width: 52,
        height: 52,
        flexShrink: 0
      },
      "aria-label": `骰子点数 ${n}`,
      children: /* @__PURE__ */ o(
        "svg",
        {
          viewBox: "0 0 100 100",
          width: 44,
          height: 44,
          style: { display: "block", margin: "auto" },
          children: a.map(([x, y], d) => /* @__PURE__ */ o(
            "circle",
            {
              cx: x,
              cy: y,
              r: 9,
              fill: s ? r : i
            },
            d
          ))
        }
      )
    }
  );
}
function j(n) {
  const s = /* @__PURE__ */ new Map();
  for (const { face: c, xValue: a } of n) {
    const x = s.get(a);
    x ? x.push(c) : s.set(a, [c]);
  }
  return Array.from(s.entries()).map(([c, a]) => ({ xVal: c, faces: a, prob: a.length / 6 })).sort((c, a) => c.xVal - a.xVal);
}
const S = 420, $ = 160, X = 44, E = 12, V = 16, R = 36;
function Y({ dist: n, hoveredX: s, onHover: c }) {
  const a = S - X - E, x = $ - V - R, y = Math.max(...n.map((t) => t.prob), 1 / 6), d = (t) => x - t / y * x, p = (t) => V + d(t), w = [], A = y <= 1 / 6 || y <= 3 / 6 ? 1 / 6 : 2 / 6;
  for (let t = 0; t <= y + 1e-3; t += A)
    w.push(Math.round(t * 6) / 6);
  const h = n.length, C = a, k = Math.min(48, C / Math.max(h, 1) * 0.6), e = h > 1 ? C / (h - 1) : 0, g = (t) => h === 1 ? X + a / 2 : X + t * e;
  return /* @__PURE__ */ l(
    "svg",
    {
      viewBox: `0 0 ${S} ${$}`,
      className: "w-full rounded-lg border",
      style: { borderColor: u, background: v, maxHeight: 180 },
      onMouseLeave: () => c(null),
      children: [
        w.map((t) => /* @__PURE__ */ l("g", { children: [
          /* @__PURE__ */ o(
            "line",
            {
              x1: X,
              y1: p(t),
              x2: S - E,
              y2: p(t),
              stroke: "var(--line)",
              strokeWidth: t === 0 ? 1.5 : 1
            }
          ),
          /* @__PURE__ */ o(
            "text",
            {
              x: X - 6,
              y: p(t) + 4,
              fontSize: 9,
              textAnchor: "end",
              fill: m,
              children: t === 0 ? "0" : `${Math.round(t * 6)}/6`
            }
          )
        ] }, t)),
        /* @__PURE__ */ o(
          "text",
          {
            x: 8,
            y: V + x / 2,
            fontSize: 9,
            fill: m,
            textAnchor: "middle",
            transform: `rotate(-90, 8, ${V + x / 2})`,
            children: "P(X=x)"
          }
        ),
        n.map((t, f) => {
          const b = g(f), T = p(t.prob), O = p(0) - T, M = s === t.xVal, H = L[f % L.length];
          return /* @__PURE__ */ l(
            "g",
            {
              onMouseEnter: () => c(t.xVal),
              style: { cursor: "pointer" },
              children: [
                /* @__PURE__ */ o(
                  "rect",
                  {
                    x: b - k / 2,
                    y: T,
                    width: k,
                    height: Math.max(O, 0),
                    fill: H,
                    opacity: M ? 1 : 0.78,
                    rx: 3
                  }
                ),
                M && /* @__PURE__ */ o(
                  "rect",
                  {
                    x: b - k / 2 - 4,
                    y: V,
                    width: k + 8,
                    height: x,
                    fill: H,
                    opacity: 0.08,
                    rx: 4
                  }
                ),
                /* @__PURE__ */ l(
                  "text",
                  {
                    x: b,
                    y: T - 4,
                    fontSize: 9,
                    textAnchor: "middle",
                    fill: H,
                    fontWeight: 700,
                    children: [
                      t.faces.length,
                      "/6"
                    ]
                  }
                ),
                /* @__PURE__ */ o(
                  "text",
                  {
                    x: b,
                    y: $ - R + 14,
                    fontSize: 10,
                    textAnchor: "middle",
                    fill: M ? r : m,
                    fontWeight: M ? 700 : 400,
                    children: t.xVal
                  }
                )
              ]
            },
            t.xVal
          );
        }),
        /* @__PURE__ */ o(
          "text",
          {
            x: S - E,
            y: $ - R + 14,
            fontSize: 10,
            textAnchor: "end",
            fill: m,
            fontStyle: "italic",
            children: "x"
          }
        )
      ]
    }
  );
}
function G() {
  const [n, s] = P("identity"), [c, a] = P(
    () => W(B.find((e) => e.key === "identity").fn)
  ), [x, y] = P(null), [d, p] = P(null), w = _((e) => {
    s(e.key), e.key !== "custom" && a(W(e.fn)), y(null);
  }, []), A = _((e, g) => {
    const t = parseFloat(g);
    isNaN(t) || (a(
      (f) => f.map((b) => b.face === e ? { ...b, xValue: t } : b)
    ), s("custom"));
  }, []), h = j(c), C = B.find((e) => e.key === n), k = d !== null ? h.find((e) => e.xVal === d)?.faces ?? [] : [];
  return /* @__PURE__ */ l("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ l("div", { children: [
      /* @__PURE__ */ o("h3", { className: "text-[15px] font-bold", style: { color: i }, children: "随机变量映射器" }),
      /* @__PURE__ */ l(
        "p",
        {
          className: "mt-0.5 text-[12px] leading-relaxed",
          style: { color: m },
          children: [
            "掷一颗骰子，样本空间 Ω = {1, 2, 3, 4, 5, 6}。为每个样本点 ω 指定实数值 X(ω)， 即定义了一个",
            /* @__PURE__ */ o("b", { style: { color: i }, children: "随机变量" }),
            "。底部实时展示 X 的分布律 P(X=x)。"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ l("div", { children: [
      /* @__PURE__ */ o("div", { className: "mb-2 text-[12px] font-semibold", style: { color: i }, children: "选择变换预设" }),
      /* @__PURE__ */ o("div", { className: "flex flex-wrap gap-1.5", children: B.map((e) => /* @__PURE__ */ o(
        "button",
        {
          type: "button",
          onClick: () => w(e),
          className: "rounded-lg px-2.5 py-1 text-[12px] font-medium transition-all duration-150",
          style: {
            background: n === e.key ? r : v,
            color: n === e.key ? "white" : m,
            border: `1px solid ${n === e.key ? r : u}`
          },
          children: e.label
        },
        e.key
      )) }),
      /* @__PURE__ */ o(
        "p",
        {
          className: "mt-2 text-[11px] leading-relaxed rounded-lg px-3 py-2",
          style: { background: N, color: r },
          children: C.description
        }
      )
    ] }),
    /* @__PURE__ */ l(
      "div",
      {
        className: "rounded-xl p-4",
        style: { background: v, border: `1px solid ${u}` },
        children: [
          /* @__PURE__ */ o("div", { className: "mb-3 text-[12px] font-semibold", style: { color: i }, children: "定义映射 X : Ω → ℝ" }),
          /* @__PURE__ */ o("div", { className: "flex flex-col gap-2.5", children: c.map(({ face: e, xValue: g }) => {
            const t = k.includes(e), f = x === e;
            return /* @__PURE__ */ l(
              "div",
              {
                className: "flex items-center gap-3 rounded-lg px-3 py-2 transition-colors duration-150",
                style: {
                  background: t ? N : f ? "var(--accent-weak)" : "var(--bg-elevated)",
                  border: `1px solid ${t ? r : f ? "#c4b5fd" : u}`
                },
                children: [
                  /* @__PURE__ */ o(
                    D,
                    {
                      face: e,
                      selected: t || f,
                      onClick: () => y(x === e ? null : e)
                    }
                  ),
                  /* @__PURE__ */ l("div", { className: "flex items-center gap-1.5 flex-1", children: [
                    /* @__PURE__ */ l("span", { className: "text-[13px]", style: { color: m }, children: [
                      "ω = ",
                      e
                    ] }),
                    /* @__PURE__ */ l("svg", { width: 28, height: 14, className: "flex-shrink-0", children: [
                      /* @__PURE__ */ o("defs", { children: /* @__PURE__ */ o(
                        "marker",
                        {
                          id: `arrow-${e}`,
                          markerWidth: 6,
                          markerHeight: 6,
                          refX: 3,
                          refY: 3,
                          orient: "auto",
                          children: /* @__PURE__ */ o(
                            "path",
                            {
                              d: "M0,0 L0,6 L6,3 z",
                              fill: t ? r : "var(--ink-faint)"
                            }
                          )
                        }
                      ) }),
                      /* @__PURE__ */ o(
                        "line",
                        {
                          x1: 2,
                          y1: 7,
                          x2: 20,
                          y2: 7,
                          stroke: t ? r : "var(--ink-faint)",
                          strokeWidth: 1.5,
                          markerEnd: `url(#arrow-${e})`
                        }
                      )
                    ] }),
                    /* @__PURE__ */ o(
                      "span",
                      {
                        className: "text-[13px] font-semibold",
                        style: { color: t ? r : i },
                        children: "X ="
                      }
                    )
                  ] }),
                  /* @__PURE__ */ l("div", { className: "flex items-center gap-1", children: [
                    /* @__PURE__ */ o(
                      "input",
                      {
                        type: "number",
                        value: g,
                        onChange: (b) => A(e, b.target.value),
                        onFocus: () => y(e),
                        onBlur: () => y(null),
                        className: "w-[70px] rounded-lg border px-2 py-1 text-[13px] font-mono font-bold text-center transition-all focus:outline-none focus:ring-2",
                        style: {
                          borderColor: t ? r : u,
                          background: t ? "var(--bg-elevated)" : v,
                          color: t ? r : i,
                          boxShadow: t ? `0 0 0 2px ${F(r, "33")}` : "none"
                        },
                        step: "1"
                      }
                    ),
                    /* @__PURE__ */ o("span", { className: "text-[11px]", style: { color: m }, children: "P = 1/6" })
                  ] })
                ]
              },
              e
            );
          }) })
        ]
      }
    ),
    /* @__PURE__ */ l("div", { children: [
      /* @__PURE__ */ l("div", { className: "mb-2 flex items-center justify-between", children: [
        /* @__PURE__ */ o("div", { className: "text-[12px] font-semibold", style: { color: i }, children: "分布律 P(X = x)" }),
        /* @__PURE__ */ l("div", { className: "text-[11px]", style: { color: m }, children: [
          "共 ",
          /* @__PURE__ */ o("b", { style: { color: i }, children: h.length }),
          " 个不同取值， 概率之和 =",
          " ",
          /* @__PURE__ */ o("b", { style: { color: r }, children: h.reduce((e, g) => e + g.prob, 0).toFixed(4) })
        ] })
      ] }),
      /* @__PURE__ */ o(Y, { dist: h, hoveredX: d, onHover: p })
    ] }),
    /* @__PURE__ */ o(
      "div",
      {
        className: "rounded-xl overflow-hidden",
        style: { border: `1px solid ${u}` },
        children: /* @__PURE__ */ l("table", { className: "w-full text-[12px]", children: [
          /* @__PURE__ */ o("thead", { children: /* @__PURE__ */ l("tr", { style: { background: v }, children: [
            /* @__PURE__ */ o(
              "th",
              {
                className: "px-3 py-2 text-left font-semibold",
                style: { color: i, borderBottom: `1px solid ${u}` },
                children: "x（取值）"
              }
            ),
            h.map((e) => /* @__PURE__ */ o(
              "th",
              {
                className: "px-3 py-2 text-center font-mono font-bold transition-colors",
                style: {
                  color: d === e.xVal ? r : i,
                  background: d === e.xVal ? N : "transparent",
                  borderBottom: `1px solid ${u}`
                },
                onMouseEnter: () => p(e.xVal),
                onMouseLeave: () => p(null),
                children: e.xVal
              },
              e.xVal
            ))
          ] }) }),
          /* @__PURE__ */ l("tbody", { children: [
            /* @__PURE__ */ l("tr", { children: [
              /* @__PURE__ */ o(
                "td",
                {
                  className: "px-3 py-2 font-semibold",
                  style: { color: m, borderBottom: `1px solid ${u}` },
                  children: "P(X = x)"
                }
              ),
              h.map((e) => /* @__PURE__ */ l(
                "td",
                {
                  className: "px-3 py-2 text-center font-mono transition-colors",
                  style: {
                    color: d === e.xVal ? r : i,
                    fontWeight: d === e.xVal ? 700 : 400,
                    background: d === e.xVal ? N : "transparent",
                    borderBottom: `1px solid ${u}`
                  },
                  onMouseEnter: () => p(e.xVal),
                  onMouseLeave: () => p(null),
                  children: [
                    e.faces.length,
                    "/6"
                  ]
                },
                e.xVal
              ))
            ] }),
            /* @__PURE__ */ l("tr", { style: { background: v }, children: [
              /* @__PURE__ */ o("td", { className: "px-3 py-2 text-[11px]", style: { color: m }, children: "对应样本点" }),
              h.map((e) => /* @__PURE__ */ l(
                "td",
                {
                  className: "px-3 py-2 text-center text-[11px] transition-colors",
                  style: {
                    color: d === e.xVal ? r : m,
                    background: d === e.xVal ? N : "transparent"
                  },
                  onMouseEnter: () => p(e.xVal),
                  onMouseLeave: () => p(null),
                  children: [
                    "{",
                    e.faces.join(", "),
                    "}"
                  ]
                },
                e.xVal
              ))
            ] })
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ l(
      "div",
      {
        className: "rounded-lg px-3 py-2.5 text-[12px] leading-relaxed space-y-2",
        style: {
          background: v,
          border: `1px solid ${u}`,
          color: m
        },
        children: [
          /* @__PURE__ */ l("div", { children: [
            /* @__PURE__ */ o("span", { className: "font-semibold", style: { color: i }, children: "核心概念：" }),
            "随机变量 X 是从样本空间 Ω 到实数 ℝ 的",
            /* @__PURE__ */ o("b", { style: { color: i }, children: "函数" }),
            '。 它把随机试验的结果"数值化"，使我们能用数学工具分析概率。'
          ] }),
          /* @__PURE__ */ l("div", { children: [
            /* @__PURE__ */ o("span", { className: "font-semibold", style: { color: i }, children: "分布律归一：" }),
            "不论如何设置 X 值，所有概率之和始终等于 1。 这是因为骰子 6 个等可能结果的概率之和 = 6 × (1/6) = 1。"
          ] }),
          h.length < 6 && /* @__PURE__ */ l("div", { children: [
            /* @__PURE__ */ o("span", { className: "font-semibold", style: { color: r }, children: "多对一映射：" }),
            '当前有多个样本点映射到相同 X 值，形成"合并"效果，该取值的概率变大—— 这正是随机变量强大之处：通过变换揭示概率的结构。'
          ] })
        ]
      }
    )
  ] });
}
const Q = I(G);
export {
  Q as default
};
