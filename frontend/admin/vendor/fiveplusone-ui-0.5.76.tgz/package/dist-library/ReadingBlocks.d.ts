import { type ReactNode } from "react";
export declare function EventCard({ title, date, children, defaultOpen, fields, }: {
    title: string;
    date?: string;
    children: ReactNode;
    defaultOpen?: boolean;
    fields?: {
        label: string;
        value: string;
    }[];
}): import("react").JSX.Element;
export declare function Figure({ src, alt, caption, credit, onOpen, }: {
    src: string;
    alt: string;
    caption?: ReactNode;
    credit?: ReactNode;
    onOpen?: () => void;
}): import("react").JSX.Element;
export declare function MemoryCard({ question, answer, revealed, onReveal, onGrade, }: {
    question: ReactNode;
    answer: ReactNode;
    revealed: boolean;
    onReveal: () => void;
    onGrade?: (grade: "again" | "hard" | "good" | "easy") => void;
}): import("react").JSX.Element;
export interface HistoryEvent {
    id: string;
    title: string;
    date: string;
    description?: ReactNode;
    relatedIds?: string[];
}
export declare function HistoryMap({ events, selectedId, onSelect, }: {
    events: HistoryEvent[];
    selectedId?: string;
    onSelect: (id: string) => void;
}): import("react").JSX.Element;
export declare function LearningAnimation({ title, children, sourceUrl, caption, }: {
    title: string;
    children: ReactNode;
    sourceUrl?: string;
    caption?: ReactNode;
}): import("react").JSX.Element;
export declare function NoteLink({ title, detail, onOpen, }: {
    title: string;
    detail?: string;
    onOpen: () => void;
}): import("react").JSX.Element;
export declare function VennDiagram({ leftLabel, rightLabel, leftCount, rightCount, intersection, total, }: {
    leftLabel: string;
    rightLabel: string;
    leftCount: number;
    rightCount: number;
    intersection: number;
    total?: number;
}): import("react").JSX.Element;
/** Reveals marked words and checklist items without flattening Markdown formatting. */
export declare function RecallContent({ children, mode, }: {
    children: ReactNode;
    mode?: string;
}): import("react").JSX.Element;
export interface MapLocation {
    name: string;
    x: number;
    y: number;
}
export declare function HistoryLocationMap({ title, points, caption, onSelect, }: {
    title?: string;
    points: MapLocation[];
    caption?: ReactNode;
    onSelect?: (point: MapLocation) => void;
}): import("react").JSX.Element;
export declare function ReadingTimeline({ title, children, }: {
    title?: string;
    children: ReactNode;
}): import("react").JSX.Element;
