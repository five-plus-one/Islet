import { jsxs as n, jsx as e, Fragment as M } from "react/jsx-runtime";
import { memo as L, useState as F } from "react";
const _ = "var(--accent)", S = "#22c55e", w = "#ef4444", B = "#6b7280", j = S, z = "#fca5a5", E = [
  { id: 1, label: "A", p: 0.9 },
  { id: 2, label: "B", p: 0.8 },
  { id: 3, label: "C", p: 0.75 }
];
function I(s) {
  return s.reduce((x, o) => x * o, 1);
}
function K(s) {
  return 1 - s.reduce((x, o) => x * (1 - o), 1);
}
const g = 340, A = 130;
function P({
  components: s,
  sysOk: x,
  compOk: o
}) {
  const b = s.length, l = 52, m = 34, r = A / 2, O = b * l + (b - 1) * 20, u = (g - O) / 2, h = (f) => f === null ? B : f ? j : z, k = h(x);
  return /* @__PURE__ */ n(
    "svg",
    {
      viewBox: `0 0 ${g} ${A}`,
      className: "w-full",
      style: { maxHeight: 130 },
      children: [
        /* @__PURE__ */ e(
          "line",
          {
            x1: 8,
            y1: r,
            x2: u,
            y2: r,
            stroke: k,
            strokeWidth: 2.4
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: 8,
            cy: r,
            r: 5,
            fill: x === !1 ? w : _
          }
        ),
        s.map((f, d) => {
          const p = u + d * (l + 20), v = o ? o[d] : null, N = v === null ? "var(--bg-elevated)" : v ? "#dcfce7" : "#fee2e2", c = v === null ? "var(--line)" : v ? S : w, C = v === null ? "var(--ink-soft)" : v ? "#15803d" : "#b91c1c", t = d === 0 ? u : u + d * (l + 20), i = d === 0 ? x : o ? o[d - 1] : null;
          return /* @__PURE__ */ n("g", { children: [
            d > 0 && /* @__PURE__ */ e(
              "line",
              {
                x1: u + (d - 1) * (l + 20) + l,
                y1: r,
                x2: t,
                y2: r,
                stroke: h(i),
                strokeWidth: 2.4
              }
            ),
            /* @__PURE__ */ e(
              "rect",
              {
                x: p,
                y: r - m / 2,
                width: l,
                height: m,
                rx: 6,
                fill: N,
                stroke: c,
                strokeWidth: 1.8
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: p + l / 2,
                y: r - 4,
                textAnchor: "middle",
                fontSize: 13,
                fontWeight: 700,
                fill: C,
                children: f.label
              }
            ),
            /* @__PURE__ */ n(
              "text",
              {
                x: p + l / 2,
                y: r + 11,
                textAnchor: "middle",
                fontSize: 10,
                fill: C,
                children: [
                  (f.p * 100).toFixed(0),
                  "%"
                ]
              }
            ),
            v !== null && /* @__PURE__ */ e(
              "text",
              {
                x: p + l - 6,
                y: r - m / 2 + 12,
                textAnchor: "middle",
                fontSize: 10,
                fill: c,
                children: v ? "OK" : "X"
              }
            )
          ] }, f.id);
        }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: u + (b - 1) * (l + 20) + l,
            y1: r,
            x2: g - 8,
            y2: r,
            stroke: h(x),
            strokeWidth: 2.4
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: g - 8,
            cy: r,
            r: 5,
            fill: x === !1 ? w : _
          }
        ),
        /* @__PURE__ */ e(
          "text",
          {
            x: g / 2,
            y: A - 8,
            textAnchor: "middle",
            fontSize: 11,
            fill: "var(--ink-faint)",
            children: "← 串联：全部正常系统才正常 →"
          }
        )
      ]
    }
  );
}
function G({
  components: s,
  sysOk: x,
  compOk: o
}) {
  const b = s.length, l = 52, m = 28, r = 36, u = b * m + (b - 1) * r + 40, h = u / 2, k = (c) => c === null ? B : c ? j : z, f = k(x), d = (c) => h - (b - 1) / 2 * (m + r) + c * (m + r), p = g / 2 - l / 2, v = p - 28, N = p + l + 28;
  return /* @__PURE__ */ n(
    "svg",
    {
      viewBox: `0 0 ${g} ${u}`,
      className: "w-full",
      style: { maxHeight: u },
      children: [
        /* @__PURE__ */ e(
          "line",
          {
            x1: 8,
            y1: h,
            x2: v,
            y2: h,
            stroke: f,
            strokeWidth: 2.4
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: 8,
            cy: h,
            r: 5,
            fill: x === !1 ? w : _
          }
        ),
        /* @__PURE__ */ e(
          "line",
          {
            x1: N,
            y1: h,
            x2: g - 8,
            y2: h,
            stroke: f,
            strokeWidth: 2.4
          }
        ),
        /* @__PURE__ */ e(
          "circle",
          {
            cx: g - 8,
            cy: h,
            r: 5,
            fill: x === !1 ? w : _
          }
        ),
        b > 1 && /* @__PURE__ */ n(M, { children: [
          /* @__PURE__ */ e(
            "line",
            {
              x1: v,
              y1: d(0),
              x2: v,
              y2: d(b - 1),
              stroke: B,
              strokeWidth: 2
            }
          ),
          /* @__PURE__ */ e(
            "line",
            {
              x1: N,
              y1: d(0),
              x2: N,
              y2: d(b - 1),
              stroke: B,
              strokeWidth: 2
            }
          )
        ] }),
        s.map((c, C) => {
          const t = d(C), i = o ? o[C] : null, a = i === null ? "var(--bg-elevated)" : i ? "#dcfce7" : "#fee2e2", y = i === null ? "var(--line)" : i ? S : w, R = i === null ? "var(--ink-soft)" : i ? "#15803d" : "#b91c1c", W = k(i);
          return /* @__PURE__ */ n("g", { children: [
            /* @__PURE__ */ e(
              "line",
              {
                x1: v,
                y1: t,
                x2: p,
                y2: t,
                stroke: W,
                strokeWidth: 2.2
              }
            ),
            /* @__PURE__ */ e(
              "line",
              {
                x1: p + l,
                y1: t,
                x2: N,
                y2: t,
                stroke: W,
                strokeWidth: 2.2
              }
            ),
            /* @__PURE__ */ e(
              "rect",
              {
                x: p,
                y: t - m / 2,
                width: l,
                height: m,
                rx: 6,
                fill: a,
                stroke: y,
                strokeWidth: 1.8
              }
            ),
            /* @__PURE__ */ e(
              "text",
              {
                x: p + l / 2,
                y: t - 2,
                textAnchor: "middle",
                fontSize: 13,
                fontWeight: 700,
                fill: R,
                children: c.label
              }
            ),
            /* @__PURE__ */ n(
              "text",
              {
                x: p + l / 2,
                y: t + 11,
                textAnchor: "middle",
                fontSize: 10,
                fill: R,
                children: [
                  (c.p * 100).toFixed(0),
                  "%"
                ]
              }
            ),
            i !== null && /* @__PURE__ */ e(
              "text",
              {
                x: p + l - 4,
                y: t - m / 2 + 11,
                textAnchor: "middle",
                fontSize: 10,
                fill: y,
                children: i ? "OK" : "X"
              }
            )
          ] }, c.id);
        }),
        /* @__PURE__ */ e(
          "text",
          {
            x: g / 2,
            y: u - 6,
            textAnchor: "middle",
            fontSize: 11,
            fill: "var(--ink-faint)",
            children: "← 并联：任一正常系统即正常 →"
          }
        )
      ]
    }
  );
}
function $(s) {
  return s >= 0.9 ? S : s >= 0.6 ? "#f59e0b" : w;
}
function T() {
  const [s, x] = F("series"), [o, b] = F(E), [l, m] = F(null), [r, O] = F(0), [u, h] = F(0), k = o.map((t) => t.p), f = s === "series" ? I(k) : K(k);
  function d(t, i) {
    b(
      (a) => a.map(
        (y) => y.id === t ? { ...y, p: Math.round(i * 100) / 100 } : y
      )
    ), m(null);
  }
  function p() {
    const t = o.map((a) => Math.random() < a.p), i = s === "series" ? t.every(Boolean) : t.some(Boolean);
    m({ compOk: t, sysOk: i }), O((a) => a + 1), h((a) => a + (i ? 1 : 0));
  }
  function v(t) {
    let i = r, a = u, y = null;
    for (let R = 0; R < t; R++) {
      const W = o.map((H) => Math.random() < H.p), X = s === "series" ? W.every(Boolean) : W.some(Boolean);
      i++, X && a++, y = { compOk: W, sysOk: X };
    }
    m(y), O(i), h(a);
  }
  function N() {
    m(null), O(0), h(0);
  }
  const c = r > 0 ? u / r : null, C = $(f);
  return /* @__PURE__ */ n("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ n("div", { className: "flex items-center justify-between mb-3 flex-wrap gap-2", children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-semibold text-[var(--ink)]", children: "可靠性系统探索" }),
      /* @__PURE__ */ e("div", { className: "flex gap-1.5", children: ["series", "parallel"].map((t) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => {
            x(t), N();
          },
          className: "rounded-lg px-3 py-1 text-[13px] font-medium transition-colors " + (s === t ? "bg-[var(--accent)] text-white" : "bg-[var(--bg-muted)] text-[var(--ink-soft)] hover:bg-[var(--accent-weak)]"),
          children: t === "series" ? "串联" : "并联"
        },
        t
      )) })
    ] }),
    /* @__PURE__ */ e("div", { className: "rounded-lg bg-[var(--bg-muted)] p-2 mb-3", children: s === "series" ? /* @__PURE__ */ e(
      P,
      {
        components: o,
        sysOk: l ? l.sysOk : null,
        compOk: l ? l.compOk : null
      }
    ) : /* @__PURE__ */ e(
      G,
      {
        components: o,
        sysOk: l ? l.sysOk : null,
        compOk: l ? l.compOk : null
      }
    ) }),
    /* @__PURE__ */ e("div", { className: "space-y-2.5 mb-3", children: o.map((t, i) => {
      const a = l ? l.compOk[i] : null;
      return /* @__PURE__ */ n("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ e(
          "div",
          {
            className: "w-6 h-6 rounded-md flex items-center justify-center text-[13px] font-bold flex-shrink-0",
            style: {
              background: a === null ? "var(--bg-muted)" : a ? "#dcfce7" : "#fee2e2",
              color: a === null ? "var(--ink-soft)" : a ? "#15803d" : "#b91c1c",
              border: `1.5px solid ${a === null ? "var(--line)" : a ? S : w}`
            },
            children: t.label
          }
        ),
        /* @__PURE__ */ e(
          "input",
          {
            type: "range",
            min: 0,
            max: 100,
            step: 1,
            value: Math.round(t.p * 100),
            onChange: (y) => d(t.id, Number(y.target.value) / 100),
            className: "flex-1 h-1.5 rounded-full appearance-none cursor-pointer",
            style: { accentColor: _ }
          }
        ),
        /* @__PURE__ */ n("span", { className: "w-10 text-right font-mono text-[13px] font-semibold text-[var(--ink)]", children: [
          (t.p * 100).toFixed(0),
          "%"
        ] })
      ] }, t.id);
    }) }),
    /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] px-3 py-2.5 mb-3", children: [
      /* @__PURE__ */ n("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ n("div", { children: [
          /* @__PURE__ */ n("p", { className: "text-[11px] text-[var(--ink-soft)] mb-0.5", children: [
            "系统可靠度",
            /* @__PURE__ */ e("span", { className: "ml-1.5 font-mono text-[10px] bg-[var(--bg-muted)] px-1.5 py-0.5 rounded text-[var(--ink-soft)]", children: s === "series" ? `R = ${o.map((t) => `${(t.p * 100).toFixed(0)}%`).join(" × ")}` : `R = 1 − ${o.map((t) => `(1−${(t.p * 100).toFixed(0)}%)`).join("×")}` })
          ] }),
          /* @__PURE__ */ n(
            "p",
            {
              className: "text-[22px] font-bold font-mono",
              style: { color: C },
              children: [
                (f * 100).toFixed(2),
                "%"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ e("div", { className: "w-28 h-3 rounded-full bg-[var(--bg-muted)] overflow-hidden", children: /* @__PURE__ */ e(
          "div",
          {
            className: "h-full rounded-full transition-all duration-300",
            style: { width: `${f * 100}%`, background: C }
          }
        ) })
      ] }),
      /* @__PURE__ */ e("div", { className: "mt-1.5 text-[11px] text-[var(--ink-soft)]", children: s === "series" ? /* @__PURE__ */ n("span", { children: [
        "串联：系统可靠度 ",
        /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "低于" }),
        " ",
        "最弱元件（",
        Math.min(...k.map((t) => t * 100)).toFixed(0),
        "%），元件越多越脆弱。"
      ] }) : /* @__PURE__ */ n("span", { children: [
        "并联：系统可靠度 ",
        /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "高于" }),
        " ",
        "最强元件（",
        Math.max(...k.map((t) => t * 100)).toFixed(0),
        "%），冗余提升可靠性。"
      ] }) })
    ] }),
    /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-3 py-2.5", children: [
      /* @__PURE__ */ e("p", { className: "text-[12px] font-semibold text-[var(--ink-soft)] mb-2", children: "Monte Carlo 模拟（验证理论值）" }),
      /* @__PURE__ */ n("div", { className: "flex flex-wrap gap-1.5 mb-2", children: [
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: p,
            className: "rounded-lg bg-[var(--accent)] px-2.5 py-1 text-[12px] font-medium text-white hover:opacity-90",
            children: "运行 1 次"
          }
        ),
        [100, 1e3].map((t) => /* @__PURE__ */ n(
          "button",
          {
            type: "button",
            onClick: () => v(t),
            className: "rounded-lg bg-[var(--accent)] px-2.5 py-1 text-[12px] font-medium text-white hover:opacity-90",
            children: [
              "运行 ",
              t,
              " 次"
            ]
          },
          t
        )),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: N,
            className: "rounded-lg bg-[var(--bg-elevated)] border border-[var(--line)] px-2.5 py-1 text-[12px] font-medium text-[var(--ink-soft)] hover:bg-[var(--line)]",
            children: "重置"
          }
        )
      ] }),
      r > 0 ? /* @__PURE__ */ n("div", { className: "flex flex-wrap gap-x-5 gap-y-1 text-[12px]", children: [
        /* @__PURE__ */ n("span", { className: "text-[var(--ink-soft)]", children: [
          "已运行 ",
          /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: r }),
          " 次"
        ] }),
        /* @__PURE__ */ n("span", { className: "text-[var(--ink-soft)]", children: [
          "成功 ",
          /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: u }),
          " 次"
        ] }),
        /* @__PURE__ */ n("span", { className: "text-[var(--ink-soft)]", children: [
          "频率",
          " ",
          /* @__PURE__ */ n(
            "b",
            {
              className: "font-mono",
              style: { color: $(c) },
              children: [
                ((c ?? 0) * 100).toFixed(2),
                "%"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ n("span", { className: "text-[var(--ink-soft)]", children: [
          "理论",
          " ",
          /* @__PURE__ */ n("b", { className: "font-mono text-[var(--ink)]", children: [
            (f * 100).toFixed(2),
            "%"
          ] })
        ] }),
        l && /* @__PURE__ */ n(
          "span",
          {
            className: "font-semibold",
            style: { color: l.sysOk ? S : w },
            children: [
              "最近一次：",
              l.sysOk ? "[OK] 系统正常" : "[X] 系统失效"
            ]
          }
        )
      ] }) : /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] italic", children: "点击按钮随机模拟各元件工作/失效，观察频率收敛到理论值。" }),
      r >= 10 && c !== null && /* @__PURE__ */ n("div", { className: "mt-2 flex items-center gap-2 text-[11px] text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ e("span", { className: "w-8", children: "模拟" }),
        /* @__PURE__ */ e("div", { className: "flex-1 h-2 rounded-full bg-[var(--bg-elevated)] border border-[var(--line)] overflow-hidden", children: /* @__PURE__ */ e(
          "div",
          {
            className: "h-full rounded-full transition-all duration-200",
            style: {
              width: `${c * 100}%`,
              background: $(c)
            }
          }
        ) }),
        /* @__PURE__ */ e("span", { className: "w-8", children: "理论" }),
        /* @__PURE__ */ e("div", { className: "flex-1 h-2 rounded-full bg-[var(--bg-elevated)] border border-[var(--line)] overflow-hidden", children: /* @__PURE__ */ e(
          "div",
          {
            className: "h-full rounded-full",
            style: { width: `${f * 100}%`, background: C }
          }
        ) })
      ] })
    ] }),
    /* @__PURE__ */ e("div", { className: "mt-3 rounded-lg border border-[var(--line)] px-3 py-2 text-[12px] leading-relaxed text-[var(--ink-soft)]", children: s === "series" ? /* @__PURE__ */ n(M, { children: [
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "串联系统" }),
      "：各元件独立，系统正常当且仅当所有元件均正常。 由独立事件乘法定理：",
      " ",
      /* @__PURE__ */ e("code", { className: "bg-[var(--bg-muted)] px-1 rounded text-[var(--accent)]", children: "R = p₁ × p₂ × … × pₙ" }),
      "，可靠度严格低于最小分量。"
    ] }) : /* @__PURE__ */ n(M, { children: [
      /* @__PURE__ */ e("b", { className: "text-[var(--ink)]", children: "并联系统" }),
      "：至少一个元件正常即可。系统失效概率 = 所有元件同时失效，故",
      " ",
      /* @__PURE__ */ e("code", { className: "bg-[var(--bg-muted)] px-1 rounded text-[var(--accent)]", children: "R = 1 − (1−p₁)(1−p₂)…(1−pₙ)" }),
      "，冗余显著提升可靠性。"
    ] }) })
  ] });
}
const q = L(T);
export {
  q as default
};
