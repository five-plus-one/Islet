export interface ExplorerResource {
    id: string;
    parentId?: string | null;
    name: string;
    kind: "folder" | "file";
    size?: number;
    modifiedAt?: string;
    thumbnailUrl?: string;
}
export interface ResourceExplorerProps {
    media?: boolean;
    defaultView?: 'grid' | 'list';
    showSearch?: boolean;
    availableActions?: ("download" | "share" | "rename" | "delete" | "move" | "restore")[];
    query?: string;
    onQueryChange?: (query: string) => void;
    items: ExplorerResource[];
    folderId?: string | null;
    onFolderChange: (id: string | null) => void;
    selectedIds: string[];
    onSelectionChange: (ids: string[]) => void;
    onOpen: (item: ExplorerResource) => void;
    onAction?: (action: "download" | "share" | "rename" | "delete" | "move" | "restore", items: ExplorerResource[]) => void;
    onCreateFolder?: () => void;
    onUpload?: (files: File[], folderId: string | null) => void;
    onMove?: (ids: string[], folderId: string | null) => void;
    loading?: boolean;
    error?: string;
}
/** Controlled resource navigation and selection; storage and permissions belong to the host. */
export declare function ResourceExplorer({ media, defaultView, showSearch, availableActions, query: controlledQuery, onQueryChange, items, folderId, onFolderChange, selectedIds, onSelectionChange, onOpen, onAction, onCreateFolder, onUpload, onMove, loading, error, }: ResourceExplorerProps): import("react").JSX.Element;
