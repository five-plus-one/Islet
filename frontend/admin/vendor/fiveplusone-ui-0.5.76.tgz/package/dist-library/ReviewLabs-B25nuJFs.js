import { jsxs as n, jsx as l, Fragment as x } from "react/jsx-runtime";
import { useState as h, useMemo as p } from "react";
function g(a) {
  const t = Math.max(-0.99, Math.min(0.99, a)), e = Math.sqrt(1 - t * t);
  return {
    x: t,
    halfLength: e,
    length: 2 * e,
    marginal: 2 * e / Math.PI,
    density: 1 / (2 * e)
  };
}
function b(a, t) {
  if (t < 0 || t > a) return 0;
  let e = 1;
  for (let c = 1; c <= t; c++) e = e * (a - c + 1) / c;
  return Math.round(e);
}
function d(a, t) {
  if (t === 0) return a === 0 ? 1 : 0;
  if (a < t || a < 0) return 0;
  let e = Array(t + 1).fill(0);
  e[0] = 1;
  for (let c = 1; c <= a; c++) {
    const r = Array(t + 1).fill(0);
    for (let i = 1; i <= t; i++)
      r[i] = i * (e[i] + e[i - 1]);
    e = r;
  }
  return e[t];
}
function N(a, t) {
  const e = d(a, t), c = d(a - 1, t), r = Array.from({ length: Math.max(0, a - t + 1) }, (i, s) => ({
    people: s + 1,
    count: b(a, s + 1) * d(a - s - 1, t - 1)
  }));
  return {
    total: e,
    same: c,
    different: e ? (e - c) / e : null,
    counts: r
  };
}
function u(a, t) {
  return t ? u(t, a % t) : a;
}
function m(a, t) {
  if (!t) return "—";
  const e = u(a, t);
  return `${a / e}/${t / e}`;
}
const f = "rounded-xl border border-[var(--line)] bg-[var(--surface)] p-4 space-y-4", o = "var(--accent, #7555b5)";
function k() {
  const [a, t] = h(0), e = g(a), c = 150 + e.x * 105;
  return /* @__PURE__ */ n("section", { "aria-label": "圆盘条件密度实验", className: f, children: [
    /* @__PURE__ */ n("div", { children: [
      /* @__PURE__ */ l("h3", { className: "font-semibold text-lg", children: "沿圆盘切一条弦" }),
      /* @__PURE__ */ l("p", { className: "text-sm text-[var(--muted)]", children: "圆盘内均匀取点。拖动横坐标，比较切片长度与归一后的条件密度。" })
    ] }),
    /* @__PURE__ */ n("label", { className: "block", children: [
      "横坐标 x = ",
      e.x.toFixed(2),
      /* @__PURE__ */ l(
        "input",
        {
          className: "block w-full",
          "aria-label": "横坐标",
          type: "range",
          min: "-0.99",
          max: "0.99",
          step: "0.01",
          value: a,
          onChange: (r) => t(Number(r.target.value))
        }
      )
    ] }),
    /* @__PURE__ */ n("div", { className: "grid gap-4 sm:grid-cols-2", children: [
      /* @__PURE__ */ n(
        "svg",
        {
          role: "img",
          "aria-label": "单位圆与当前竖直弦",
          viewBox: "0 0 300 280",
          className: "w-full max-h-72",
          children: [
            /* @__PURE__ */ l(
              "circle",
              {
                cx: "150",
                cy: "135",
                r: "105",
                fill: "var(--accent-soft, #eee6ff)",
                stroke: o,
                strokeWidth: "2"
              }
            ),
            /* @__PURE__ */ l(
              "path",
              {
                d: "M20 135H280M150 15V255",
                stroke: "var(--muted, #777)",
                fill: "none"
              }
            ),
            /* @__PURE__ */ l(
              "line",
              {
                x1: c,
                x2: c,
                y1: 135 - 105 * e.halfLength,
                y2: 135 + 105 * e.halfLength,
                stroke: o,
                strokeWidth: "6"
              }
            ),
            /* @__PURE__ */ l("circle", { cx: c, cy: "135", r: "4", fill: "var(--text, #222)" }),
            /* @__PURE__ */ l("text", { x: "282", y: "151", fontSize: "13", fill: "currentColor", children: "x" }),
            /* @__PURE__ */ l("text", { x: "158", y: "17", fontSize: "13", fill: "currentColor", children: "y" }),
            /* @__PURE__ */ n(
              "text",
              {
                x: "150",
                y: "275",
                textAnchor: "middle",
                fontSize: "13",
                fill: "currentColor",
                children: [
                  "紫色弦长 = ",
                  e.length.toFixed(4)
                ]
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ n("div", { className: "space-y-3", children: [
        /* @__PURE__ */ n("p", { children: [
          "允许范围：−",
          e.halfLength.toFixed(4),
          " ≤ y ≤",
          " ",
          e.halfLength.toFixed(4)
        ] }),
        /* @__PURE__ */ n("p", { children: [
          "边缘密度 fₓ(x) = ",
          e.marginal.toFixed(4)
        ] }),
        /* @__PURE__ */ n("p", { className: "font-semibold", style: { color: o }, children: [
          "条件密度 = ",
          e.density.toFixed(4)
        ] }),
        /* @__PURE__ */ n(
          "svg",
          {
            role: "img",
            "aria-label": "归一后的条件密度图",
            viewBox: "0 0 300 155",
            className: "w-full",
            children: [
              /* @__PURE__ */ l(
                "path",
                {
                  d: "M20 125H280M150 15V135",
                  stroke: "var(--muted, #777)",
                  fill: "none"
                }
              ),
              /* @__PURE__ */ l(
                "rect",
                {
                  x: 150 - e.halfLength * 105,
                  y: 125 - e.density * 25,
                  width: e.length * 105,
                  height: e.density * 25,
                  fill: "var(--accent-soft, #eee6ff)",
                  stroke: o
                }
              ),
              /* @__PURE__ */ l(
                "text",
                {
                  x: "150",
                  y: "150",
                  textAnchor: "middle",
                  fontSize: "12",
                  fill: "currentColor",
                  children: "矩形面积：弦长 × 密度 = 1"
                }
              )
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ l("p", { className: "text-sm", children: "弦长 = 2√(1−x²)，条件密度为弦长的倒数。越靠近圆边，允许区间越窄、密度越高，但总概率始终为一。端点处边缘密度为零，所以只考察 −1 < x < 1。" }),
    /* @__PURE__ */ l(
      "button",
      {
        type: "button",
        className: "rounded-lg border border-[var(--line)] px-3 py-1.5",
        onClick: () => t(0),
        children: "回到圆心"
      }
    )
  ] });
}
function M() {
  const [a, t] = h(6), [e, c] = h(4), r = p(
    () => N(a, e),
    [a, e]
  );
  return /* @__PURE__ */ n("section", { "aria-label": "非空窗口分配实验", className: f, children: [
    /* @__PURE__ */ n("div", { children: [
      /* @__PURE__ */ l("h3", { className: "font-semibold text-lg", children: "每个窗口都有人" }),
      /* @__PURE__ */ l("p", { className: "text-sm text-[var(--muted)]", children: "人员与窗口分别有区别；只记录谁去哪个窗口，不区分队内顺序。所有满足每窗非空的分配等可能。" })
    ] }),
    /* @__PURE__ */ n("div", { className: "grid gap-3 sm:grid-cols-2", children: [
      /* @__PURE__ */ n("label", { children: [
        "人数：",
        a,
        /* @__PURE__ */ l(
          "input",
          {
            className: "block w-full",
            "aria-label": "人数",
            type: "range",
            min: "2",
            max: "8",
            step: "1",
            value: a,
            onChange: (i) => t(Number(i.target.value))
          }
        )
      ] }),
      /* @__PURE__ */ n("label", { children: [
        "窗口数：",
        e,
        /* @__PURE__ */ l(
          "input",
          {
            className: "block w-full",
            "aria-label": "窗口数",
            type: "range",
            min: "2",
            max: "4",
            step: "1",
            value: e,
            onChange: (i) => c(Number(i.target.value))
          }
        )
      ] })
    ] }),
    r.total === 0 ? /* @__PURE__ */ l("p", { role: "status", children: "人数少于窗口数，无法满足每个窗口都有人。增加人数或减少窗口数后继续。" }) : /* @__PURE__ */ n(x, { children: [
      /* @__PURE__ */ n(
        "div",
        {
          className: "rounded-lg p-3",
          style: { background: "var(--accent-soft, #eee6ff)" },
          children: [
            /* @__PURE__ */ n("p", { children: [
              "有效分配共 ",
              /* @__PURE__ */ l("strong", { children: r.total }),
              " 种"
            ] }),
            /* @__PURE__ */ n("p", { children: [
              "指定两人同窗：",
              r.same,
              " 种；不同窗：",
              r.total - r.same,
              " ",
              "种。"
            ] }),
            /* @__PURE__ */ n("p", { className: "font-semibold", children: [
              "指定两人不同窗的概率：",
              m(r.total - r.same, r.total),
              " ≈",
              " ",
              r.different.toFixed(6)
            ] })
          ]
        }
      ),
      /* @__PURE__ */ l("div", { className: "overflow-x-auto", children: /* @__PURE__ */ n("table", { className: "w-full text-sm", children: [
        /* @__PURE__ */ l("caption", { className: "text-left font-semibold mb-2", children: "指定窗口人数的分布" }),
        /* @__PURE__ */ l("thead", { children: /* @__PURE__ */ n("tr", { children: [
          /* @__PURE__ */ l("th", { className: "p-2 text-left", children: "人数" }),
          /* @__PURE__ */ l("th", { className: "p-2 text-left", children: "分配数" }),
          /* @__PURE__ */ l("th", { className: "p-2 text-left", children: "概率" })
        ] }) }),
        /* @__PURE__ */ l("tbody", { children: r.counts.map((i) => /* @__PURE__ */ n(
          "tr",
          {
            className: "border-t border-[var(--line)]",
            children: [
              /* @__PURE__ */ l("td", { className: "p-2", children: i.people }),
              /* @__PURE__ */ l("td", { className: "p-2", children: i.count }),
              /* @__PURE__ */ n("td", { className: "p-2", children: [
                m(i.count, r.total),
                " ",
                /* @__PURE__ */ n("span", { className: "text-[var(--muted)]", children: [
                  "≈ ",
                  (i.count / r.total).toFixed(4)
                ] })
              ] })
            ]
          },
          i.people
        )) })
      ] }) }),
      /* @__PURE__ */ l("p", { className: "text-sm", children: "先只保留每窗非空的分配。指定两人同窗时，把二人看作一个整体，人数减少一而仍需占满全部窗口；指定窗口恰有 k 人时，先选出这 k 人，再让剩余人员占满其余窗口。" })
    ] }),
    /* @__PURE__ */ l(
      "button",
      {
        type: "button",
        className: "rounded-lg border border-[var(--line)] px-3 py-1.5",
        onClick: () => {
          t(6), c(4);
        },
        children: "恢复初始参数"
      }
    )
  ] });
}
export {
  k as DiskConditionalLab,
  M as OccupancyLab,
  g as diskSlice,
  m as fraction,
  N as occupancyModel,
  d as ontoCount
};
