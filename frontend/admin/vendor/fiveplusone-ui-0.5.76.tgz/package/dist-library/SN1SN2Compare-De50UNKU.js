import { jsxs as l, jsx as e } from "react/jsx-runtime";
import { memo as v, useState as d, useMemo as N } from "react";
const b = [
  {
    value: "methyl",
    label: "甲基卤代烷 CH₃X",
    note: "无空间位阻，碳正离子最不稳定"
  },
  {
    value: "primary",
    label: "伯卤代烷 RCH₂X",
    note: "空间位阻小，碳正离子不稳定"
  },
  {
    value: "secondary",
    label: "仲卤代烷 R₂CHX",
    note: "介于两者之间，机理取决于条件"
  },
  {
    value: "tertiary",
    label: "叔卤代烷 R₃CX",
    note: "空间位阻大，碳正离子最稳定"
  }
], u = [
  { value: "strong", label: "强亲核试剂", note: "如 OH⁻、RO⁻、CN⁻、I⁻" },
  { value: "weak", label: "弱亲核试剂", note: "如 H₂O、ROH 等中性分子" }
], p = [
  {
    value: "aprotic",
    label: "极性非质子溶剂",
    note: "如 DMSO、DMF、丙酮，不形成氢键"
  },
  {
    value: "protic",
    label: "极性质子溶剂",
    note: "如 H₂O、ROH，可氢键溶剂化稳定碳正离子"
  }
];
function S(s, c, o) {
  let i = 0, a = 0;
  const n = [];
  switch (s) {
    case "methyl":
      i += 3, a -= 3, n.push(
        "甲基卤代烷无空间位阻、且无法生成稳定碳正离子，强烈偏向 SN2。"
      );
      break;
    case "primary":
      i += 2, a -= 2, n.push("伯卤代烷位阻小、伯碳正离子极不稳定，倾向 SN2。");
      break;
    case "secondary":
      i += 1, a += 1, n.push(
        "仲卤代烷处于边界，SN1 与 SN2 均可能，由亲核试剂与溶剂决定。"
      );
      break;
    case "tertiary":
      i -= 3, a += 3, n.push(
        "叔卤代烷位阻大、叔碳正离子稳定，背面进攻受阻，强烈偏向 SN1。"
      );
      break;
  }
  c === "strong" ? (i += 2, n.push("强亲核试剂主动进攻、参与 SN2 决速步，加速双分子取代。")) : (a += 2, n.push(
    "弱亲核试剂难以发动背面进攻，反应更依赖先生成碳正离子的 SN1 路径。"
  )), o === "aprotic" ? (i += 2, n.push(
    "极性非质子溶剂不与亲核试剂形成氢键，裸露的亲核试剂活性更高，利于 SN2。"
  )) : (a += 2, n.push(
    "极性质子溶剂通过氢键溶剂化稳定碳正离子和离去基团，利于 SN1 的电离步。"
  ));
  let r;
  return i - a >= 2 ? r = "SN2" : a - i >= 2 ? r = "SN1" : r = "mixed", { mechanism: r, sn2Score: i, sn1Score: a, reasons: n };
}
function m({
  active: s,
  label: c,
  note: o,
  onClick: i
}) {
  return /* @__PURE__ */ l(
    "button",
    {
      type: "button",
      onClick: i,
      className: [
        "w-full rounded-lg border px-3 py-2 text-left transition-colors",
        s ? "border-indigo-500 bg-[var(--accent-weak)]" : "border-[var(--line)] bg-[var(--bg-muted)] hover:border-indigo-300"
      ].join(" "),
      children: [
        /* @__PURE__ */ e("span", { className: "block text-sm font-medium text-[var(--ink)]", children: c }),
        /* @__PURE__ */ e("span", { className: "block text-xs text-[var(--ink-soft)]", children: o })
      ]
    }
  );
}
function y() {
  return /* @__PURE__ */ l(
    "svg",
    {
      viewBox: "0 0 320 160",
      className: "w-full",
      role: "img",
      "aria-label": "SN2 背面进攻与构型翻转示意",
      children: [
        /* @__PURE__ */ e("circle", { cx: "160", cy: "80", r: "14", fill: "#6366f1" }),
        /* @__PURE__ */ e("text", { x: "160", y: "85", textAnchor: "middle", fontSize: "11", fill: "#fff", children: "C" }),
        /* @__PURE__ */ e("circle", { cx: "245", cy: "80", r: "12", fill: "#f87171" }),
        /* @__PURE__ */ e("text", { x: "245", y: "84", textAnchor: "middle", fontSize: "10", fill: "#fff", children: "X" }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "174",
            y1: "80",
            x2: "231",
            y2: "80",
            stroke: "#cbd5e1",
            strokeWidth: "2",
            strokeDasharray: "4 3"
          }
        ),
        /* @__PURE__ */ e("circle", { cx: "55", cy: "80", r: "12", fill: "#10b981" }),
        /* @__PURE__ */ e("text", { x: "55", y: "84", textAnchor: "middle", fontSize: "9", fill: "#fff", children: "Nu" }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "67",
            y1: "80",
            x2: "146",
            y2: "80",
            stroke: "#10b981",
            strokeWidth: "2",
            strokeDasharray: "4 3"
          }
        ),
        /* @__PURE__ */ e("polygon", { points: "146,80 138,75 138,85", fill: "#10b981" }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "160",
            y1: "80",
            x2: "190",
            y2: "40",
            stroke: "var(--ink-soft)",
            strokeWidth: "1.5"
          }
        ),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "160",
            y1: "80",
            x2: "190",
            y2: "120",
            stroke: "var(--ink-soft)",
            strokeWidth: "1.5"
          }
        ),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "160",
            y1: "80",
            x2: "200",
            y2: "80",
            stroke: "var(--ink-soft)",
            strokeWidth: "1.5"
          }
        ),
        /* @__PURE__ */ e("text", { x: "160", y: "148", textAnchor: "middle", fontSize: "11", fill: "var(--ink)", children: "一步协同：背面进攻 → 瓦尔登翻转（构型翻转）" })
      ]
    }
  );
}
function k() {
  return /* @__PURE__ */ l(
    "svg",
    {
      viewBox: "0 0 320 160",
      className: "w-full",
      role: "img",
      "aria-label": "SN1 碳正离子平面中间体与两面进攻示意",
      children: [
        /* @__PURE__ */ e("circle", { cx: "160", cy: "80", r: "14", fill: "#6366f1" }),
        /* @__PURE__ */ e("text", { x: "160", y: "78", textAnchor: "middle", fontSize: "11", fill: "#fff", children: "C" }),
        /* @__PURE__ */ e("text", { x: "160", y: "89", textAnchor: "middle", fontSize: "8", fill: "#fff", children: "+" }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "160",
            y1: "80",
            x2: "160",
            y2: "40",
            stroke: "var(--ink-soft)",
            strokeWidth: "1.5"
          }
        ),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "160",
            y1: "80",
            x2: "125",
            y2: "100",
            stroke: "var(--ink-soft)",
            strokeWidth: "1.5"
          }
        ),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "160",
            y1: "80",
            x2: "195",
            y2: "100",
            stroke: "var(--ink-soft)",
            strokeWidth: "1.5"
          }
        ),
        /* @__PURE__ */ e("circle", { cx: "80", cy: "80", r: "12", fill: "#10b981" }),
        /* @__PURE__ */ e("text", { x: "80", y: "84", textAnchor: "middle", fontSize: "9", fill: "#fff", children: "Nu" }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "92",
            y1: "80",
            x2: "146",
            y2: "80",
            stroke: "#10b981",
            strokeWidth: "2",
            strokeDasharray: "4 3"
          }
        ),
        /* @__PURE__ */ e("polygon", { points: "146,80 138,75 138,85", fill: "#10b981" }),
        /* @__PURE__ */ e("circle", { cx: "240", cy: "80", r: "12", fill: "#10b981" }),
        /* @__PURE__ */ e("text", { x: "240", y: "84", textAnchor: "middle", fontSize: "9", fill: "#fff", children: "Nu" }),
        /* @__PURE__ */ e(
          "line",
          {
            x1: "228",
            y1: "80",
            x2: "174",
            y2: "80",
            stroke: "#10b981",
            strokeWidth: "2",
            strokeDasharray: "4 3"
          }
        ),
        /* @__PURE__ */ e("polygon", { points: "174,80 182,75 182,85", fill: "#10b981" }),
        /* @__PURE__ */ e("text", { x: "160", y: "148", textAnchor: "middle", fontSize: "11", fill: "var(--ink)", children: "两步：电离生成平面碳正离子 → 两面进攻 → 外消旋化" })
      ]
    }
  );
}
function g() {
  const [s, c] = d("primary"), [o, i] = d("strong"), [a, n] = d("aprotic"), r = N(
    () => S(s, o, a),
    [s, o, a]
  ), x = r.mechanism === "SN2" ? "倾向 SN2（双分子亲核取代）" : r.mechanism === "SN1" ? "倾向 SN1（单分子亲核取代）" : "竞争状态：SN1 与 SN2 势均力敌", h = r.mechanism === "SN2" ? "text-[var(--color-success)]" : r.mechanism === "SN1" ? "text-[var(--md-sys-color-error)]" : "text-[var(--color-warning)]";
  return /* @__PURE__ */ l("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ e("h3", { className: "text-lg font-semibold text-[var(--ink)]", children: "SN1 / SN2 机理对比" }),
    /* @__PURE__ */ e("p", { className: "mt-1 text-sm text-[var(--ink-soft)]", children: "选择底物级数、亲核试剂强弱与溶剂极性，综合判定卤代烷亲核取代是走 SN2（一步背面进攻、构型翻转） 还是 SN1（两步经碳正离子、外消旋化）。" }),
    /* @__PURE__ */ l("div", { className: "mt-4 grid gap-4 md:grid-cols-3", children: [
      /* @__PURE__ */ l("div", { children: [
        /* @__PURE__ */ e("p", { className: "mb-2 text-sm font-medium text-[var(--ink)]", children: "底物（卤代烷级数）" }),
        /* @__PURE__ */ e("div", { className: "space-y-2", children: b.map((t) => /* @__PURE__ */ e(
          m,
          {
            active: s === t.value,
            label: t.label,
            note: t.note,
            onClick: () => c(t.value)
          },
          t.value
        )) })
      ] }),
      /* @__PURE__ */ l("div", { children: [
        /* @__PURE__ */ e("p", { className: "mb-2 text-sm font-medium text-[var(--ink)]", children: "亲核试剂强弱" }),
        /* @__PURE__ */ e("div", { className: "space-y-2", children: u.map((t) => /* @__PURE__ */ e(
          m,
          {
            active: o === t.value,
            label: t.label,
            note: t.note,
            onClick: () => i(t.value)
          },
          t.value
        )) })
      ] }),
      /* @__PURE__ */ l("div", { children: [
        /* @__PURE__ */ e("p", { className: "mb-2 text-sm font-medium text-[var(--ink)]", children: "溶剂极性" }),
        /* @__PURE__ */ e("div", { className: "space-y-2", children: p.map((t) => /* @__PURE__ */ e(
          m,
          {
            active: a === t.value,
            label: t.label,
            note: t.note,
            onClick: () => n(t.value)
          },
          t.value
        )) })
      ] })
    ] }),
    /* @__PURE__ */ l("div", { className: "mt-4 rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3", children: [
      /* @__PURE__ */ e("p", { className: ["text-base font-semibold", h].join(" "), children: x }),
      /* @__PURE__ */ l("div", { className: "mt-1 flex gap-4 text-xs text-[var(--ink-soft)]", children: [
        /* @__PURE__ */ l("span", { children: [
          "SN2 有利度评分：",
          r.sn2Score
        ] }),
        /* @__PURE__ */ l("span", { children: [
          "SN1 有利度评分：",
          r.sn1Score
        ] })
      ] }),
      /* @__PURE__ */ e("ul", { className: "mt-2 list-disc space-y-1 pl-5 text-sm text-[var(--ink)]", children: r.reasons.map((t, f) => /* @__PURE__ */ e("li", { children: t }, f)) })
    ] }),
    /* @__PURE__ */ l("div", { className: "mt-4 grid gap-4 md:grid-cols-2", children: [
      /* @__PURE__ */ l(
        "div",
        {
          className: [
            "rounded-lg border p-3",
            r.mechanism === "SN2" ? "border-emerald-400 bg-emerald-500/10" : "border-[var(--line)] bg-[var(--bg-muted)]"
          ].join(" "),
          children: [
            /* @__PURE__ */ e("p", { className: "mb-2 text-sm font-semibold text-[var(--color-success)]", children: "SN2 机理" }),
            /* @__PURE__ */ e(y, {}),
            /* @__PURE__ */ l("p", { className: "mt-2 text-xs text-[var(--ink-soft)]", children: [
              "速率 = k[底物][Nu]，双分子决速步。亲核试剂从离去基团背面进攻，过渡态为五配位， 产物立体构型发生",
              /* @__PURE__ */ e("strong", { children: "翻转（瓦尔登翻转）" }),
              "，手性底物得到单一对映体（构型反转）。"
            ] })
          ]
        }
      ),
      /* @__PURE__ */ l(
        "div",
        {
          className: [
            "rounded-lg border p-3",
            r.mechanism === "SN1" ? "border-rose-400 bg-rose-500/10" : "border-[var(--line)] bg-[var(--bg-muted)]"
          ].join(" "),
          children: [
            /* @__PURE__ */ e("p", { className: "mb-2 text-sm font-semibold text-[var(--md-sys-color-error)]", children: "SN1 机理" }),
            /* @__PURE__ */ e(k, {}),
            /* @__PURE__ */ l("p", { className: "mt-2 text-xs text-[var(--ink-soft)]", children: [
              "速率 = k[底物]，单分子决速步为电离生成",
              /* @__PURE__ */ e("strong", { children: "平面 sp² 碳正离子" }),
              "中间体。 亲核试剂可从平面两侧等概率进攻，手性底物因此",
              /* @__PURE__ */ e("strong", { children: "外消旋化" }),
              "（生成接近 1:1 的对映体）。"
            ] })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ e("p", { className: "mt-3 text-xs text-[var(--ink-soft)]", children: "规律小结：SN2 偏好「伯/甲基卤代烷 + 强亲核试剂 + 极性非质子溶剂」，构型翻转； SN1 偏好「叔卤代烷 + 极性质子溶剂」，经碳正离子外消旋化。仲卤代烷常处于竞争边界。" })
  ] });
}
const O = v(g);
export {
  O as default
};
