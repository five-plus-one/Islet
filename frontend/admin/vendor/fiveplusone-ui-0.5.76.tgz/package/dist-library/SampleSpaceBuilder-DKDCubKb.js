import { jsxs as l, jsx as t } from "react/jsx-runtime";
import { learningAlpha as $ } from "./index.js";
import { memo as J, useState as D } from "react";
const h = [1, 2, 3, 4, 5, 6], Q = {
  1: [[50, 50]],
  2: [
    [25, 25],
    [75, 75]
  ],
  3: [
    [25, 25],
    [50, 50],
    [75, 75]
  ],
  4: [
    [25, 25],
    [75, 25],
    [25, 75],
    [75, 75]
  ],
  5: [
    [25, 25],
    [75, 25],
    [50, 50],
    [25, 75],
    [75, 75]
  ],
  6: [
    [25, 25],
    [75, 25],
    [25, 50],
    [75, 50],
    [25, 75],
    [75, 75]
  ]
}, E = "var(--fp-primary)", x = "#7c3aed", g = "#0f766e", C = "#b45309", _ = "var(--ink-faint)", Z = {
  none: "A",
  A: "B",
  B: "AB",
  AB: "none"
}, ee = {
  none: "∉ A,B",
  A: "∈ A",
  B: "∈ B",
  AB: "∈ A∩B"
}, B = {
  none: _,
  A: x,
  B: g,
  AB: C
};
function te({
  face: c,
  membership: r,
  onClick: m
}) {
  const s = B[r], i = r === "none" ? "var(--bg-muted)" : r === "A" ? "#ede9fe" : r === "B" ? "#ccfbf1" : "#fef3c7";
  return /* @__PURE__ */ l(
    "button",
    {
      type: "button",
      onClick: m,
      title: `点击切换归属（当前：${ee[r]}）`,
      style: { outline: "none" },
      className: "group relative focus:outline-none",
      children: [
        /* @__PURE__ */ t(
          "svg",
          {
            viewBox: "0 0 100 100",
            width: 72,
            height: 72,
            style: {
              borderRadius: 14,
              border: `2.5px solid ${s}`,
              background: i,
              boxShadow: r !== "none" ? `0 0 0 3px ${s}33` : "0 1px 3px rgba(0,0,0,0.08)",
              transition: "all 0.18s ease",
              cursor: "pointer",
              display: "block"
            },
            children: Q[c].map(([o, u], y) => /* @__PURE__ */ t(
              "circle",
              {
                cx: o,
                cy: u,
                r: 9,
                fill: r !== "none" ? B[r] : "var(--ink-soft)",
                opacity: r !== "none" ? 0.85 : 0.7
              },
              y
            ))
          }
        ),
        /* @__PURE__ */ t(
          "span",
          {
            style: {
              position: "absolute",
              bottom: -18,
              left: "50%",
              transform: "translateX(-50%)",
              fontSize: 11,
              color: B[r],
              fontWeight: 600,
              whiteSpace: "nowrap"
            },
            children: c
          }
        )
      ]
    }
  );
}
function f({
  label: c,
  elements: r,
  color: m,
  subscript: s
}) {
  const i = r.length === 0 ? "∅" : "{" + r.map(String).join(", ") + "}";
  return /* @__PURE__ */ l("div", { className: "flex items-start gap-1.5 text-[13px]", children: [
    /* @__PURE__ */ l("span", { style: { color: m, fontWeight: 700, minWidth: 48, flexShrink: 0 }, children: [
      c,
      s && /* @__PURE__ */ t("sub", { style: { fontSize: 10 }, children: s }),
      " ="
    ] }),
    /* @__PURE__ */ t(
      "span",
      {
        className: "rounded-md px-2 py-0.5 font-mono",
        style: {
          background: r.length === 0 ? "var(--bg-muted)" : `${$(m, "18")}`,
          color: r.length === 0 ? _ : m,
          border: `1px solid ${r.length === 0 ? "var(--line)" : `${$(m, "40")}`}`,
          minWidth: 40,
          display: "inline-block"
        },
        children: i
      }
    )
  ] });
}
function ne() {
  const [c, r] = D(
    h.map((e) => ({ face: e, membership: "none" }))
  ), [m, s] = D(!0), i = c.filter((e) => e.membership === "A" || e.membership === "AB").map((e) => e.face), o = c.filter((e) => e.membership === "B" || e.membership === "AB").map((e) => e.face), u = [.../* @__PURE__ */ new Set([...i, ...o])].sort((e, n) => e - n), y = i.filter((e) => o.includes(e)).sort((e, n) => e - n), F = i.filter((e) => !o.includes(e)).sort((e, n) => e - n), H = o.filter((e) => !i.includes(e)).sort((e, n) => e - n), z = h.filter((e) => !i.includes(e)), j = h.filter((e) => !o.includes(e));
  function T(e) {
    s(!1), r(
      (n) => n.map(
        (a) => a.face === e ? { ...a, membership: Z[a.membership] } : a
      )
    );
  }
  function X() {
    r(h.map((e) => ({ face: e, membership: "none" }))), s(!0);
  }
  function G(e) {
    if (s(!1), e === "odd-even")
      r(
        h.map((n) => ({
          face: n,
          membership: n % 2 === 1 ? "A" : "B"
        }))
      );
    else if (e === "low-high")
      r(
        h.map((n) => ({
          face: n,
          membership: n <= 3 ? "A" : "B"
        }))
      );
    else if (e === "prime-gt3") {
      const n = [2, 3, 5], a = [4, 5, 6];
      r(
        h.map((b) => {
          const d = n.includes(b), p = a.includes(b);
          return { face: b, membership: d && p ? "AB" : d ? "A" : p ? "B" : "none" };
        })
      );
    }
  }
  const R = 320, L = 160, A = 120, k = 200, v = 80, N = 65, Y = {
    1: { x: 72, y: 65 },
    2: { x: 85, y: 105 },
    3: { x: 100, y: 48 },
    4: { x: 235, y: 65 },
    5: { x: 165, y: 78 },
    6: { x: 248, y: 105 }
  };
  function K(e) {
    const n = c.find((a) => a.face === e);
    return n ? B[n.membership] : _;
  }
  function U(e) {
    return c.find((a) => a.face === e)?.membership !== "none";
  }
  const S = 6, M = i.length / S, P = o.length / S, I = u.length / S, W = y.length / S;
  return /* @__PURE__ */ l("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4", children: [
    /* @__PURE__ */ l("div", { className: "mb-3 flex items-center justify-between", children: [
      /* @__PURE__ */ l("div", { children: [
        /* @__PURE__ */ t("h3", { className: "text-[15px] font-semibold text-[var(--ink)]", children: "样本空间构造器" }),
        /* @__PURE__ */ t("p", { className: "mt-0.5 text-[12px] text-[var(--ink-soft)]", children: "Ω = {1, 2, 3, 4, 5, 6}　投掷一枚均匀骰子" })
      ] }),
      /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: X,
          className: "rounded-lg bg-[var(--bg-muted)] px-3 py-1 text-[12px] font-medium text-[var(--ink-soft)] hover:bg-[var(--line)] transition-colors",
          children: "重置"
        }
      )
    ] }),
    m && /* @__PURE__ */ t("div", { className: "mb-3 rounded-lg border border-[var(--accent)] bg-[var(--accent-weak)] px-3 py-2 text-[12px] text-[var(--accent-ink)]", children: "点击骰子循环切换归属：无 → A → B → A∩B → 无" }),
    /* @__PURE__ */ l("div", { className: "mb-3 flex flex-wrap gap-1.5", children: [
      /* @__PURE__ */ t("span", { className: "self-center text-[11px] text-[var(--ink-soft)]", children: "预设：" }),
      [
        { key: "odd-even", label: "A=奇数 B=偶数" },
        { key: "low-high", label: "A=≤3 B=≥4" },
        { key: "prime-gt3", label: "A=质数 B=>3" }
      ].map((e) => /* @__PURE__ */ t(
        "button",
        {
          type: "button",
          onClick: () => G(e.key),
          className: "rounded-md border border-[var(--line)] px-2 py-0.5 text-[11px] text-[var(--ink-soft)] hover:border-[var(--accent)] hover:text-[var(--accent)] transition-colors",
          children: e.label
        },
        e.key
      ))
    ] }),
    /* @__PURE__ */ t(
      "div",
      {
        style: {
          display: "flex",
          gap: 16,
          justifyContent: "center",
          flexWrap: "wrap",
          marginBottom: 28,
          padding: "8px 4px"
        },
        children: c.map((e) => /* @__PURE__ */ t(
          te,
          {
            face: e.face,
            membership: e.membership,
            onClick: () => T(e.face)
          },
          e.face
        ))
      }
    ),
    /* @__PURE__ */ t("div", { className: "mb-3 flex flex-wrap gap-x-4 gap-y-1 text-[11px]", children: [
      { m: "none", label: "未分配" },
      { m: "A", label: "属于 A" },
      { m: "B", label: "属于 B" },
      { m: "AB", label: "属于 A 且 B" }
    ].map(({ m: e, label: n }) => /* @__PURE__ */ l("span", { className: "flex items-center gap-1", children: [
      /* @__PURE__ */ t(
        "span",
        {
          style: {
            width: 10,
            height: 10,
            borderRadius: 3,
            background: B[e],
            display: "inline-block"
          }
        }
      ),
      /* @__PURE__ */ t("span", { style: { color: B[e] }, children: n })
    ] }, e)) }),
    /* @__PURE__ */ t("div", { className: "mb-3 overflow-hidden rounded-lg border border-[var(--line)] bg-[var(--bg-muted)]", children: /* @__PURE__ */ l(
      "svg",
      {
        viewBox: `0 0 ${R} ${L}`,
        className: "w-full",
        style: { maxHeight: 180 },
        children: [
          /* @__PURE__ */ t(
            "rect",
            {
              x: 4,
              y: 4,
              width: R - 8,
              height: L - 8,
              rx: 10,
              fill: "var(--bg-muted)",
              stroke: "var(--line)",
              strokeWidth: 1.2
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: 12,
              y: 20,
              fontSize: 11,
              fill: "var(--ink-faint)",
              fontStyle: "italic",
              children: "Ω"
            }
          ),
          /* @__PURE__ */ t(
            "circle",
            {
              cx: A,
              cy: v,
              r: N,
              fill: i.length > 0 ? `${x}18` : "transparent",
              stroke: x,
              strokeWidth: 1.8,
              strokeDasharray: i.length === 0 ? "5 4" : void 0
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: A - N + 8,
              y: 22,
              fontSize: 12,
              fontWeight: 700,
              fill: x,
              children: "A"
            }
          ),
          /* @__PURE__ */ t(
            "circle",
            {
              cx: k,
              cy: v,
              r: N,
              fill: o.length > 0 ? `${g}18` : "transparent",
              stroke: g,
              strokeWidth: 1.8,
              strokeDasharray: o.length === 0 ? "5 4" : void 0
            }
          ),
          /* @__PURE__ */ t(
            "text",
            {
              x: k + N - 16,
              y: 22,
              fontSize: 12,
              fontWeight: 700,
              fill: g,
              children: "B"
            }
          ),
          c.map((e) => {
            const n = Y[e.face], a = e.membership === "A" || e.membership === "AB", b = e.membership === "B" || e.membership === "AB";
            let d = n.x, p = n.y;
            if (a && !b)
              d = A - 30 + (e.face - 1) % 3 * 20, p = v - 20 + Math.floor((e.face - 1) / 3) * 38;
            else if (b && !a)
              d = k + 10 + (e.face - 1) % 3 * 18, p = v - 18 + Math.floor((e.face - 1) / 3) * 36;
            else if (a && b)
              d = (A + k) / 2 - 12 + (e.face - 1) % 2 * 22, p = v - 14 + Math.floor((e.face - 1) / 2) * 26;
            else {
              const w = h.filter(
                (O) => c.find((q) => q.face === O)?.membership === "none"
              ).indexOf(e.face), V = c.filter(
                (O) => O.membership === "none"
              ).length;
              d = 270 + w % 2 * 28, p = 35 + Math.floor(w / 2) * 32 + (V <= 1 ? 16 : 0);
            }
            return /* @__PURE__ */ l("g", { style: { transition: "transform 0.3s ease" }, children: [
              /* @__PURE__ */ t(
                "circle",
                {
                  cx: d,
                  cy: p,
                  r: U(e.face) ? 13 : 11,
                  fill: K(e.face),
                  opacity: e.membership === "none" ? 0.35 : 0.82
                }
              ),
              /* @__PURE__ */ t(
                "text",
                {
                  x: d,
                  y: p + 4,
                  textAnchor: "middle",
                  fontSize: 11,
                  fontWeight: 700,
                  fill: e.membership === "none" ? "var(--ink)" : "white",
                  children: e.face
                }
              )
            ] }, e.face);
          })
        ]
      }
    ) }),
    /* @__PURE__ */ l("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-3 space-y-2", children: [
      /* @__PURE__ */ t("p", { className: "text-[11px] font-semibold text-[var(--ink-soft)] uppercase tracking-wide mb-1", children: "集合运算结果" }),
      /* @__PURE__ */ l("div", { className: "grid grid-cols-1 gap-1.5 sm:grid-cols-2", children: [
        /* @__PURE__ */ t(
          f,
          {
            label: "A",
            elements: [...i].sort((e, n) => e - n),
            color: x
          }
        ),
        /* @__PURE__ */ t(
          f,
          {
            label: "B",
            elements: [...o].sort((e, n) => e - n),
            color: g
          }
        ),
        /* @__PURE__ */ t(f, { label: "A ∪ B", elements: u, color: E }),
        /* @__PURE__ */ t(f, { label: "A ∩ B", elements: y, color: C }),
        /* @__PURE__ */ t(f, { label: "A − B", elements: F, color: "#dc2626" }),
        /* @__PURE__ */ t(f, { label: "B − A", elements: H, color: "#d97706" }),
        /* @__PURE__ */ t(f, { label: "Aᶜ", elements: z, color: "#64748b" }),
        /* @__PURE__ */ t(f, { label: "Bᶜ", elements: j, color: "#64748b" })
      ] })
    ] }),
    (i.length > 0 || o.length > 0) && /* @__PURE__ */ l("div", { className: "mt-3 rounded-lg bg-[var(--accent-weak)] border border-[var(--accent)] px-3 py-2", children: [
      /* @__PURE__ */ t("p", { className: "text-[11px] font-semibold text-[var(--accent-ink)] mb-1", children: "古典概型下（等可能，|Ω|=6）" }),
      /* @__PURE__ */ l("div", { className: "flex flex-wrap gap-x-6 gap-y-0.5 text-[12px] font-mono", children: [
        /* @__PURE__ */ l("span", { children: [
          /* @__PURE__ */ t("span", { style: { color: x }, children: "P(A)" }),
          " = ",
          /* @__PURE__ */ l("b", { style: { color: x }, children: [
            i.length,
            "/6 ≈ ",
            M.toFixed(3)
          ] })
        ] }),
        /* @__PURE__ */ l("span", { children: [
          /* @__PURE__ */ t("span", { style: { color: g }, children: "P(B)" }),
          " = ",
          /* @__PURE__ */ l("b", { style: { color: g }, children: [
            o.length,
            "/6 ≈ ",
            P.toFixed(3)
          ] })
        ] }),
        /* @__PURE__ */ l("span", { children: [
          /* @__PURE__ */ t("span", { style: { color: E }, children: "P(A∪B)" }),
          " = ",
          /* @__PURE__ */ l("b", { style: { color: E }, children: [
            u.length,
            "/6 ≈ ",
            I.toFixed(3)
          ] })
        ] }),
        /* @__PURE__ */ l("span", { children: [
          /* @__PURE__ */ t("span", { style: { color: C }, children: "P(A∩B)" }),
          " = ",
          /* @__PURE__ */ l("b", { style: { color: C }, children: [
            y.length,
            "/6 ≈ ",
            W.toFixed(3)
          ] })
        ] })
      ] }),
      i.length > 0 && o.length > 0 && /* @__PURE__ */ l("p", { className: "mt-1.5 text-[11px] text-[var(--accent-ink)]", children: [
        "验证加法公式：P(A∪B) = P(A) + P(B) − P(A∩B) =",
        " ",
        /* @__PURE__ */ l("b", { children: [
          i.length,
          "/6 + ",
          o.length,
          "/6 − ",
          y.length,
          "/6 =",
          " ",
          u.length,
          "/6"
        ] }),
        M + P - W === I ? " [OK]" : ""
      ] })
    ] }),
    /* @__PURE__ */ t("p", { className: "mt-3 text-[11px] leading-relaxed text-[var(--ink-soft)]", children: "事件 = 样本空间的子集。把样本点分配给 A、B 后，并 / 交 / 差 / 补即是标准集合运算。" })
  ] });
}
const oe = J(ne);
export {
  oe as default
};
