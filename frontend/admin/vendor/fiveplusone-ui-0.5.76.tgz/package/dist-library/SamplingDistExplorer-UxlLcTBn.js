import { jsxs as c, jsx as a, Fragment as q } from "react/jsx-runtime";
import { memo as B, useState as L, useMemo as Z } from "react";
const z = "var(--accent)", J = "var(--fp-primary-soft)", _ = "#0f766e", K = "#0f766e22", R = "#ea580c", Q = "#ea580c1f", X = "var(--line)", U = "var(--bg-muted)", V = 480, G = 220, s = { top: 18, right: 24, bottom: 38, left: 44 }, S = V - s.left - s.right, N = G - s.top - s.bottom;
function tt(t, n, e) {
  return s.left + (t - n) / (e - n) * S;
}
function et(t, n, e) {
  return s.top + N - (t - n) / (e - n) * N;
}
function D(t) {
  const e = [
    0.9999999999998099,
    676.5203681218851,
    -1259.1392167224028,
    771.3234287776531,
    -176.6150291621406,
    12.507343278686905,
    -0.13857109526572012,
    9984369578019572e-21,
    15056327351493116e-23
  ];
  if (t < 0.5)
    return Math.log(Math.PI / Math.sin(Math.PI * t)) - D(1 - t);
  t -= 1;
  let o = e[0];
  for (let i = 1; i < 9; i++) o += e[i] / (t + i);
  const r = t + 7 + 0.5;
  return 0.5 * Math.log(2 * Math.PI) + (t + 0.5) * Math.log(r) - r + Math.log(o);
}
function nt(t, n) {
  if (t <= 0) return 0;
  const e = (n / 2 - 1) * Math.log(t) - t / 2 - n / 2 * Math.log(2) - D(n / 2);
  return Math.exp(e);
}
function Y(t, n) {
  const e = D((n + 1) / 2) - 0.5 * Math.log(n * Math.PI) - D(n / 2) - (n + 1) / 2 * Math.log(1 + t * t / n);
  return Math.exp(e);
}
function O(t, n, e) {
  if (t <= 0) return 0;
  const o = 0.5 * n * Math.log(n) + 0.5 * e * Math.log(e) + (0.5 * n - 1) * Math.log(t) - (n + e) / 2 * Math.log(e + n * t) + D((n + e) / 2) - D(n / 2) - D(e / 2);
  return Math.exp(o);
}
function E(t) {
  return Math.exp(-0.5 * t * t) / Math.sqrt(2 * Math.PI);
}
function ot(t, n) {
  if (n < 0 || n === 0) return 0;
  let e = 1 / t, o = 1 / t, r = t;
  for (let i = 1; i < 150 && (r += 1, o *= n / r, e += o, !(Math.abs(o) < Math.abs(e) * 1e-9)); i++)
    ;
  return Math.exp(-n + t * Math.log(n) - D(t)) * e;
}
function rt(t, n) {
  return t <= 0 ? 0 : ot(n / 2, t / 2);
}
function I(t, n, e, o = 800) {
  const r = (e - n) / o;
  let i = 0.5 * (t(n) + t(e));
  for (let d = 1; d < o; d++) i += t(n + d * r);
  return i * r;
}
function it(t, n) {
  let e = 1e-3, o = t + 10 * Math.sqrt(2 * t) + 10;
  for (let r = 0; r < 100; r++) {
    const i = (e + o) / 2;
    if (1 - rt(i, t) > n ? e = i : o = i, o - e < 1e-7) return (e + o) / 2;
  }
  return (e + o) / 2;
}
function at(t, n) {
  const e = t + 30;
  return I((o) => Y(o, n), t, e, 600);
}
function lt(t, n) {
  const e = n / 2;
  let o = 1e-3, r = 20;
  for (let i = 0; i < 80; i++) {
    const d = (o + r) / 2;
    if (at(d, t) > e ? o = d : r = d, r - o < 1e-6) return (o + r) / 2;
  }
  return (o + r) / 2;
}
function st(t, n, e) {
  const o = t + 40;
  return I((r) => O(r, n, e), t, o, 600);
}
function ct(t, n, e) {
  let o = 1e-3, r = 20;
  for (let i = 0; i < 80; i++) {
    const d = (o + r) / 2;
    if (st(d, t, n) > e ? o = d : r = d, r - o < 1e-6) return (o + r) / 2;
  }
  return (o + r) / 2;
}
const H = [
  {
    id: "chi2",
    label: "χ²(n)",
    color: z,
    bg: J,
    tint: "#7c3aed"
  },
  { id: "t", label: "t(n)", color: _, bg: K, tint: _ },
  { id: "F", label: "F(m,n)", color: R, bg: Q, tint: R }
];
function W({
  label: t,
  value: n,
  min: e,
  max: o,
  step: r,
  color: i,
  bg: d,
  onChange: $,
  format: h
}) {
  return /* @__PURE__ */ c("div", { className: "space-y-1", children: [
    /* @__PURE__ */ c("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ a("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: t }),
      /* @__PURE__ */ a(
        "span",
        {
          className: "rounded-md px-2 py-0.5 text-[12px] font-mono font-bold",
          style: { background: d, color: i },
          children: h ? h(n) : n
        }
      )
    ] }),
    /* @__PURE__ */ a(
      "input",
      {
        type: "range",
        min: e,
        max: o,
        step: r,
        value: n,
        onChange: (y) => $(Number(y.target.value)),
        className: "w-full h-1.5 cursor-pointer",
        style: { accentColor: i }
      }
    ),
    /* @__PURE__ */ c("div", { className: "flex justify-between text-[10px] text-[var(--ink-soft)]", children: [
      /* @__PURE__ */ a("span", { children: e }),
      /* @__PURE__ */ a("span", { children: o })
    ] })
  ] });
}
function dt(t) {
  const { tabId: n, chi2N: e, tN: o, fM: r, fN: i, alpha: d } = t, $ = 400;
  let h, y, u, p, x;
  if (n === "chi2")
    h = 0.01, y = Math.max(e * 3, 20), u = (b) => nt(b, e), p = it(e, d), x = `χ²_α(${e}) = ${p.toFixed(3)}`;
  else if (n === "t") {
    const b = Math.max(4, Math.sqrt(o + 2) * 3);
    h = -b, y = b, u = (f) => Y(f, o), p = lt(o, d), x = `t_{α/2}(${o}) = ${p.toFixed(3)}`;
  } else
    h = 0.01, y = Math.max(r / i * 6 + 2, 6), u = (b) => O(b, r, i), p = ct(r, i, d), x = `F_α(${r},${i}) = ${p.toFixed(3)}`;
  const v = (y - h) / $, m = [], k = [], F = [];
  for (let b = 0; b <= $; b++) {
    const f = h + b * v;
    if (m.push(f), k.push(u(f)), n === "chi2") {
      const P = e, M = Math.sqrt(2 * e);
      F.push(E((f - P) / M) / M);
    } else if (n === "t")
      F.push(E(f));
    else {
      const P = i > 2 ? i / (i - 2) : 1, M = i > 4 ? 2 * i * i * (r + i - 2) / (r * (i - 2) ** 2 * (i - 4)) : 1, A = Math.sqrt(M);
      F.push(E((f - P) / A) / A);
    }
  }
  const T = Math.max(...k) * 1.12, C = I(u, p, y + 20, 600);
  return { xs: m, ys: k, normYs: F, xLo: h, xHi: y, yMax: T, critical: p, criticalLabel: x, tailArea: C };
}
function ft({ result: t, tabId: n, color: e, showNormal: o, alpha: r }) {
  const { xs: i, ys: d, normYs: $, xLo: h, xHi: y, yMax: u, critical: p } = t;
  function x(l) {
    return tt(l, h, y);
  }
  function v(l) {
    return et(l, 0, u);
  }
  const m = i.map(
    (l, g) => `${g === 0 ? "M" : "L"}${x(l).toFixed(2)},${v(d[g]).toFixed(2)}`
  ).join(" "), k = o ? i.map(
    (l, g) => `${g === 0 ? "M" : "L"}${x(l).toFixed(2)},${v($[g]).toFixed(2)}`
  ).join(" ") : "", F = i.filter((l) => l >= p), T = F.length > 1 ? [
    `M${x(p).toFixed(2)},${v(0).toFixed(2)}`,
    ...F.map(
      (l) => `L${x(l).toFixed(2)},${v(d[i.indexOf(l)]).toFixed(2)}`
    ),
    `L${x(F[F.length - 1]).toFixed(2)},${v(0).toFixed(2)}`,
    "Z"
  ].join(" ") : "";
  let C = "";
  if (n === "t") {
    const l = i.filter((g) => g <= -p);
    C = l.length > 1 ? [
      `M${x(l[0]).toFixed(2)},${v(0).toFixed(2)}`,
      ...l.map(
        (g) => `L${x(g).toFixed(2)},${v(d[i.indexOf(g)]).toFixed(2)}`
      ),
      `L${x(-p).toFixed(2)},${v(0).toFixed(2)}`,
      "Z"
    ].join(" ") : "";
  }
  const b = y - h, f = b <= 10 ? 1 : b <= 30 ? 5 : b <= 60 ? 10 : 20, P = Math.ceil(h / f) * f, M = [];
  for (let l = P; l <= y; l += f) M.push(l);
  const A = u / 4, j = [A, 2 * A, 3 * A].map((l) => l), w = x(p);
  return /* @__PURE__ */ c(
    "svg",
    {
      viewBox: `0 0 ${V} ${G}`,
      className: "w-full rounded-lg border border-[var(--line)]",
      style: { background: U },
      children: [
        j.map((l, g) => /* @__PURE__ */ a(
          "line",
          {
            x1: s.left,
            y1: v(l),
            x2: s.left + S,
            y2: v(l),
            stroke: X,
            strokeWidth: 1
          },
          `yg${g}`
        )),
        M.map((l, g) => /* @__PURE__ */ a(
          "line",
          {
            x1: x(l),
            y1: s.top,
            x2: x(l),
            y2: s.top + N,
            stroke: X,
            strokeWidth: 1
          },
          `xg${g}`
        )),
        n === "t" && C && /* @__PURE__ */ a("path", { d: C, fill: e, opacity: 0.25 }),
        T && /* @__PURE__ */ a("path", { d: T, fill: e, opacity: 0.25 }),
        o && k && /* @__PURE__ */ a(
          "path",
          {
            d: k,
            fill: "none",
            stroke: "var(--ink-faint)",
            strokeWidth: 1.5,
            strokeDasharray: "5 3",
            opacity: 0.7
          }
        ),
        /* @__PURE__ */ a("path", { d: m, fill: "none", stroke: e, strokeWidth: 2.2 }),
        p > h && p < y && /* @__PURE__ */ c(q, { children: [
          /* @__PURE__ */ a(
            "line",
            {
              x1: w,
              y1: s.top,
              x2: w,
              y2: s.top + N,
              stroke: e,
              strokeWidth: 1.8,
              strokeDasharray: "4 3"
            }
          ),
          n === "t" && /* @__PURE__ */ a(
            "line",
            {
              x1: x(-p),
              y1: s.top,
              x2: x(-p),
              y2: s.top + N,
              stroke: e,
              strokeWidth: 1.8,
              strokeDasharray: "4 3"
            }
          ),
          /* @__PURE__ */ c(
            "text",
            {
              x: Math.min(w + 6, s.left + S - 32),
              y: s.top + 16,
              fontSize: 10,
              fill: e,
              fontWeight: "700",
              children: [
                "α=",
                r.toFixed(2)
              ]
            }
          )
        ] }),
        /* @__PURE__ */ a(
          "line",
          {
            x1: s.left,
            y1: s.top,
            x2: s.left,
            y2: s.top + N,
            stroke: "var(--ink-faint)",
            strokeWidth: 1.5
          }
        ),
        /* @__PURE__ */ a(
          "line",
          {
            x1: s.left,
            y1: s.top + N,
            x2: s.left + S,
            y2: s.top + N,
            stroke: "var(--ink-faint)",
            strokeWidth: 1.5
          }
        ),
        M.map((l, g) => /* @__PURE__ */ c("g", { children: [
          /* @__PURE__ */ a(
            "line",
            {
              x1: x(l),
              y1: s.top + N,
              x2: x(l),
              y2: s.top + N + 4,
              stroke: "var(--ink-faint)",
              strokeWidth: 1
            }
          ),
          /* @__PURE__ */ a(
            "text",
            {
              x: x(l),
              y: s.top + N + 14,
              fontSize: 9,
              textAnchor: "middle",
              fill: "var(--ink-soft)",
              children: l % 1 === 0 ? l : l.toFixed(1)
            }
          )
        ] }, `xt${g}`)),
        j.map((l, g) => /* @__PURE__ */ c("g", { children: [
          /* @__PURE__ */ a(
            "line",
            {
              x1: s.left - 4,
              y1: v(l),
              x2: s.left,
              y2: v(l),
              stroke: "var(--ink-faint)",
              strokeWidth: 1
            }
          ),
          /* @__PURE__ */ a(
            "text",
            {
              x: s.left - 6,
              y: v(l) + 3,
              fontSize: 8,
              textAnchor: "end",
              fill: "var(--ink-soft)",
              children: l.toFixed(2)
            }
          )
        ] }, `yt${g}`)),
        /* @__PURE__ */ a(
          "text",
          {
            x: s.left + S / 2,
            y: G - 2,
            fontSize: 10,
            textAnchor: "middle",
            fill: "var(--ink-soft)",
            fontWeight: "600",
            children: "x"
          }
        ),
        /* @__PURE__ */ a(
          "text",
          {
            x: 9,
            y: s.top + N / 2,
            fontSize: 10,
            textAnchor: "middle",
            fill: "var(--ink-soft)",
            fontWeight: "600",
            transform: `rotate(-90,9,${s.top + N / 2})`,
            children: "f(x)"
          }
        ),
        o && /* @__PURE__ */ c("g", { children: [
          /* @__PURE__ */ a(
            "line",
            {
              x1: s.left + S - 74,
              y1: s.top + 8,
              x2: s.left + S - 54,
              y2: s.top + 8,
              stroke: "var(--ink-faint)",
              strokeWidth: 1.5,
              strokeDasharray: "5 3"
            }
          ),
          /* @__PURE__ */ a(
            "text",
            {
              x: s.left + S - 50,
              y: s.top + 11,
              fontSize: 9,
              fill: "var(--ink-faint)",
              children: "N(0,1)"
            }
          )
        ] })
      ]
    }
  );
}
function xt() {
  const [t, n] = L("chi2"), [e, o] = L(5), [r, i] = L(5), [d, $] = L(5), [h, y] = L(10), [u, p] = L(0.05), [x, v] = L(!0), m = H.find((f) => f.id === t), k = Z(
    () => dt({
      tabId: t,
      chi2N: e,
      tN: r,
      fM: d,
      fN: h,
      alpha: u
    }),
    [t, e, r, d, h, u, x]
  );
  function F() {
    return t === "chi2" ? `自由度 n = ${e}` : t === "t" ? `自由度 n = ${r}` : `自由度 m = ${d}, n = ${h}`;
  }
  function T() {
    return t === "chi2" ? {
      mean: `E(X) = n = ${e}`,
      variance: `Var(X) = 2n = ${2 * e}`,
      convergence: "n→∞ 时，(χ²-n)/√(2n) → N(0,1)"
    } : t === "t" ? {
      mean: "E(X) = 0（n>1）",
      variance: `Var(X) = ${r > 2 ? `n/(n-2) = ${(r / (r - 2)).toFixed(3)}` : "∞（n≤2时无定义）"}`,
      convergence: "n→∞ 时，t(n) → N(0,1)（图中虚线）"
    } : {
      mean: `E(X) = ${h > 2 ? `n/(n-2) = ${(h / (h - 2)).toFixed(3)}` : "∞（n≤2）"}`,
      variance: h > 4 ? "Var(X) = 2n²(m+n-2)/[m(n-2)²(n-4)]" : "∞（n≤4）",
      convergence: "m,n→∞ 时，F(m,n) 的标准化形式趋近 N(0,1)"
    };
  }
  const C = T();
  function b() {
    return t === "chi2" ? "若 X₁,…,Xₙ ~ N(0,1) 独立，则 X₁²+…+Xₙ² ~ χ²(n)。样本方差 S² 的抽样分布正是 χ²。" : t === "t" ? "若 X~N(0,1) 与 Y~χ²(n) 独立，则 X/√(Y/n) ~ t(n)。样本均值标准化后服从 t 分布。" : "若 X~χ²(m)，Y~χ²(n) 独立，则 (X/m)/(Y/n) ~ F(m,n)。方差比检验的基础分布。";
  }
  return /* @__PURE__ */ c("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ a("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "三大抽样分布探索器" }),
      /* @__PURE__ */ a("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5 leading-relaxed", children: "切换 χ²、t、F 分布，调整自由度与显著性水平，实时观察 PDF 曲线与右尾临界值。" })
    ] }),
    /* @__PURE__ */ c("div", { className: "flex gap-2 flex-wrap", children: [
      H.map((f) => /* @__PURE__ */ a(
        "button",
        {
          type: "button",
          onClick: () => n(f.id),
          className: "rounded-lg px-4 py-1.5 text-[13px] font-bold transition-all",
          style: {
            background: t === f.id ? f.color : "transparent",
            color: t === f.id ? "white" : f.color,
            border: `2px solid ${f.color}`
          },
          children: f.label
        },
        f.id
      )),
      /* @__PURE__ */ c(
        "button",
        {
          type: "button",
          onClick: () => v((f) => !f),
          className: "ml-auto rounded-lg px-3 py-1.5 text-[12px] font-medium transition-all border",
          style: {
            borderColor: X,
            background: x ? "var(--bg-muted)" : "var(--bg-elevated)",
            color: x ? "var(--ink-soft)" : "var(--ink-faint)"
          },
          children: [
            x ? "▣" : "□",
            " 正态对照"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ c("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-4", children: [
      t === "chi2" && /* @__PURE__ */ a(
        W,
        {
          label: "自由度 n",
          value: e,
          min: 1,
          max: 30,
          step: 1,
          color: m.color,
          bg: m.bg,
          onChange: o
        }
      ),
      t === "t" && /* @__PURE__ */ a(
        W,
        {
          label: "自由度 n",
          value: r,
          min: 1,
          max: 30,
          step: 1,
          color: m.color,
          bg: m.bg,
          onChange: i
        }
      ),
      t === "F" && /* @__PURE__ */ c("div", { className: "space-y-3", children: [
        /* @__PURE__ */ a(
          W,
          {
            label: "分子自由度 m",
            value: d,
            min: 1,
            max: 20,
            step: 1,
            color: m.color,
            bg: m.bg,
            onChange: $
          }
        ),
        /* @__PURE__ */ a(
          W,
          {
            label: "分母自由度 n",
            value: h,
            min: 2,
            max: 30,
            step: 1,
            color: m.color,
            bg: m.bg,
            onChange: y
          }
        )
      ] }),
      /* @__PURE__ */ a(
        W,
        {
          label: "显著性水平 α（右尾概率）",
          value: u,
          min: 0.01,
          max: 0.1,
          step: 0.01,
          color: "var(--md-sys-color-error)",
          bg: "#dc26261f",
          onChange: p,
          format: (f) => f.toFixed(2)
        }
      )
    ] }),
    /* @__PURE__ */ c("div", { children: [
      /* @__PURE__ */ c("div", { className: "mb-2 flex items-center justify-between flex-wrap gap-1", children: [
        /* @__PURE__ */ c("span", { className: "text-[12px] font-semibold text-[var(--ink)]", children: [
          "概率密度曲线 — ",
          F()
        ] }),
        /* @__PURE__ */ a(
          "span",
          {
            className: "rounded-md px-2 py-0.5 text-[11px] font-mono font-bold",
            style: {
              background: "#dc26261f",
              color: "var(--md-sys-color-error)"
            },
            children: k.criticalLabel
          }
        )
      ] }),
      /* @__PURE__ */ a(
        ft,
        {
          result: k,
          tabId: t,
          color: m.color,
          showNormal: x,
          alpha: u
        }
      ),
      /* @__PURE__ */ c("div", { className: "mt-2 flex flex-wrap gap-3 text-[11px]", children: [
        /* @__PURE__ */ c("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ a(
            "span",
            {
              className: "inline-block h-3 w-6 rounded-sm",
              style: { background: m.color, opacity: 0.3 }
            }
          ),
          /* @__PURE__ */ c("span", { className: "text-[var(--ink-soft)]", children: [
            "右尾面积 ≈ ",
            k.tailArea.toFixed(4),
            "（理论 =",
            " ",
            u.toFixed(2),
            "）"
          ] })
        ] }),
        x && /* @__PURE__ */ c("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ a("svg", { width: "18", height: "6", children: /* @__PURE__ */ a(
            "line",
            {
              x1: "0",
              y1: "3",
              x2: "18",
              y2: "3",
              stroke: "var(--ink-faint)",
              strokeWidth: "1.5",
              strokeDasharray: "5 3"
            }
          ) }),
          /* @__PURE__ */ a("span", { className: "text-[var(--ink-soft)]", children: "标准正态 N(0,1)" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ c(
      "div",
      {
        className: "rounded-lg border-2 p-4 space-y-3",
        style: { borderColor: m.color, background: m.bg },
        children: [
          /* @__PURE__ */ c("div", { className: "flex items-center justify-between flex-wrap gap-2", children: [
            /* @__PURE__ */ a("span", { className: "text-[14px] font-bold text-[var(--ink)]", children: "临界值" }),
            /* @__PURE__ */ a(
              "span",
              {
                className: "text-[20px] font-extrabold font-mono",
                style: { color: m.color },
                children: k.criticalLabel
              }
            )
          ] }),
          /* @__PURE__ */ c("p", { className: "text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
            t === "chi2" && `右尾面积 P(χ²(${e}) > ${k.critical.toFixed(3)}) = α = ${u.toFixed(2)}。
            当检验统计量超过此临界值，拒绝 H₀。`,
            t === "t" && `双侧临界值：P(|t(${r})| > ${k.critical.toFixed(3)}) = α = ${u.toFixed(2)}。
            左右两侧各占 α/2 = ${(u / 2).toFixed(3)}。`,
            t === "F" && `右尾面积 P(F(${d},${h}) > ${k.critical.toFixed(3)}) = α = ${u.toFixed(2)}。
            F 分布仅在右尾做单侧检验（方差比总为正）。`
          ] })
        ]
      }
    ),
    /* @__PURE__ */ a("div", { className: "grid grid-cols-1 gap-2 sm:grid-cols-3", children: [
      { label: "均值", val: C.mean, color: m.color, bg: m.bg },
      {
        label: "方差",
        val: C.variance,
        color: "var(--ink-soft)",
        bg: "var(--bg-muted)"
      },
      {
        label: "极限行为",
        val: C.convergence,
        color: "var(--ink-soft)",
        bg: "var(--bg-muted)"
      }
    ].map(({ label: f, val: P, color: M, bg: A }) => /* @__PURE__ */ c(
      "div",
      {
        className: "rounded-lg p-2.5",
        style: { background: A },
        children: [
          /* @__PURE__ */ a("div", { className: "text-[10px] font-semibold text-[var(--ink-soft)] mb-0.5", children: f }),
          /* @__PURE__ */ a(
            "div",
            {
              className: "text-[11px] font-mono font-bold leading-snug",
              style: { color: M },
              children: P
            }
          )
        ]
      },
      f
    )) }),
    x && /* @__PURE__ */ c(
      "div",
      {
        className: "rounded-lg border p-3 space-y-1",
        style: { borderColor: X, background: "var(--bg-muted)" },
        children: [
          /* @__PURE__ */ a("div", { className: "text-[12px] font-bold text-[var(--ink)]", children: "n → ∞ 收敛到正态（图中灰虚线）" }),
          /* @__PURE__ */ c("p", { className: "text-[11px] text-[var(--ink-soft)] leading-relaxed", children: [
            t === "chi2" && `自由度 n 增大时，χ²(n) 的 PDF 越来越接近正态形状：均值 n、标准差 √(2n)。
              当前 n=${e}，${e >= 20 ? "曲线已相当接近正态。" : "增大 n 可明显看到收敛效果。"}`,
            t === "t" && `自由度 n 增大时，t(n) 的尾部越来越细，趋近 N(0,1)。
              当前 n=${r}，${r >= 30 ? "与正态已十分接近（工程上常用 n≥30 直接用正态）。" : "可看到 t 分布比正态有更厚的尾部（重尾特性）。"}`,
            t === "F" && `m,n 均增大时，F(m,n) 的形状越来越对称，趋向正态。
              当前 F(${d},${h})，${Math.min(d, h) >= 15 ? "对称性已较好，中心近似正态。" : "可以看到明显的右偏形状。"}`
          ] })
        ]
      }
    ),
    /* @__PURE__ */ c("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed space-y-1.5", children: [
      /* @__PURE__ */ c("div", { className: "font-semibold text-[13px] text-[var(--ink)]", children: [
        t === "chi2" && "χ² 分布的来源",
        t === "t" && "t 分布的来源",
        t === "F" && "F 分布的来源"
      ] }),
      /* @__PURE__ */ a("p", { children: b() }),
      /* @__PURE__ */ c("p", { children: [
        /* @__PURE__ */ a("span", { className: "font-semibold text-[var(--ink)]", children: "检验用途：" }),
        t === "chi2" && "样本方差检验、拟合优度检验、独立性检验。",
        t === "t" && "单样本均值 t 检验、两样本均值 t 检验、回归系数显著性检验。",
        t === "F" && "方差齐性检验（F 检验）、方差分析（ANOVA）、回归方程整体显著性检验。"
      ] }),
      /* @__PURE__ */ c("p", { className: "text-[11px]", children: [
        /* @__PURE__ */ a("span", { className: "font-semibold text-[var(--ink)]", children: "使用提示：" }),
        "拖动自由度滑块观察曲线形状变化；调整 α 看临界值如何移动；开启「正态对照」直观感受收敛速度。"
      ] })
    ] })
  ] });
}
const mt = B(xt);
export {
  mt as default
};
