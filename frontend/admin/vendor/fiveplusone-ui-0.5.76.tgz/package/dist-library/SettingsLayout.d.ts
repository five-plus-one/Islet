import { type ReactNode } from "react";
export interface SettingsCategory {
    id: string;
    label: string;
    icon?: ReactNode;
}
export interface SettingsLayoutProps {
    items: SettingsCategory[];
    value: string;
    onChange: (id: string) => void;
    onClose: () => void;
    children: ReactNode;
}
export declare function SettingsLayout({ items, value, onChange, onClose, children }: SettingsLayoutProps): import("react").JSX.Element;
