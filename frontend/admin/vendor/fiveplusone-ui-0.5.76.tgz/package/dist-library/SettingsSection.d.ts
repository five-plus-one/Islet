/** SettingsSection - 从课栈 layout/SettingsSection 提取
 *
 * 设置页的分组卡片：图标 + 标题 + 摘要，点击展开内容。
 * 与 Accordion 的区别是带有图标容器与摘要行，适合设置面板。
 */
import { type ReactNode } from "react";
export interface SettingsSectionProps {
    title: string;
    icon: ReactNode;
    summary?: ReactNode;
    children: ReactNode;
    open: boolean;
    onToggle: () => void;
}
export declare function SettingsSection({ title, icon, summary, children, open, onToggle, }: SettingsSectionProps): import("react").JSX.Element;
