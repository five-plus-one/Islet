export interface ShareLinkProps {
    url?: string;
    enabled: boolean;
    onEnabledChange: (enabled: boolean) => Promise<void> | void;
    access: string;
    onAccessChange: (value: string) => void;
    options?: {
        value: string;
        label: string;
    }[];
    disabled?: boolean;
    onCopy?: (url: string) => Promise<void>;
}
export declare function ShareLink({ url, enabled, onEnabledChange, access, onAccessChange, options, disabled, onCopy }: ShareLinkProps): import("react").JSX.Element;
