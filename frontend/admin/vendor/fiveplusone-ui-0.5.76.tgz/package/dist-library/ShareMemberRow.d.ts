import type { ReactNode } from "react";
export interface ShareMemberRowProps {
    name: string;
    detail?: string;
    avatar?: ReactNode;
    role: ReactNode;
    actions?: ReactNode;
}
export declare function ShareMemberRow({ name, detail, avatar, role, actions }: ShareMemberRowProps): import("react").JSX.Element;
