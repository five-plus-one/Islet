import { type ReactNode } from "react";
import { type MarkdownContentProps } from "./MarkdownContent";
export interface SharedReadingEntry {
    id: string;
    title: string;
    group?: string;
}
export interface ReadingHeading {
    id: string;
    title: string;
    level: number;
}
export interface SharedReadingPageProps {
    title: string;
    markdown: string;
    entries?: SharedReadingEntry[];
    selectedId?: string;
    onNavigate?: (id: string) => void;
    headings?: ReadingHeading[];
    loading?: boolean;
    error?: string;
    onRetry?: () => void;
    access?: "granted" | "sign-in" | "denied";
    onSignIn?: () => void;
    toolbar?: ReactNode;
    footer?: ReactNode;
    onCopyReference?: (reference: {
        title: string;
        text: string;
        heading?: string;
    }) => Promise<void> | void;
    contentProps?: Omit<MarkdownContentProps, "markdown">;
    content?: ReactNode;
    navigation?: ReactNode;
    brand?: ReactNode;
    account?: ReactNode;
    collection?: {
        title: string;
        byline?: string;
        description?: string;
        actions?: ReactNode;
    };
}
export declare function SharedReadingPage({ title, markdown, entries, selectedId, onNavigate, headings, loading, error, onRetry, access, onSignIn, toolbar, footer, onCopyReference, contentProps, content, navigation, brand, account, collection, }: SharedReadingPageProps): import("react").JSX.Element;
export interface ReleaseNoticeProps {
    available: boolean;
    onRefresh: () => Promise<void> | void;
    onDismiss?: () => void;
    beforeRefresh?: () => Promise<boolean>;
}
export declare function ReleaseNotice({ available, onRefresh, onDismiss, beforeRefresh, }: ReleaseNoticeProps): import("react").JSX.Element;
export interface ReleaseUpdateOptions {
    currentVersion: string;
    checkVersion: (signal: AbortSignal) => Promise<string>;
    interval?: number;
    enabled?: boolean;
    onError?: (error: unknown) => void;
}
/** Checks the host release token while the page is visible; requests stop on unmount. */
export declare function useReleaseUpdate({ currentVersion, checkVersion, interval, enabled, onError, }: ReleaseUpdateOptions): {
    available: boolean;
    version: string;
    dismiss: () => void;
};
