import { jsxs as n, jsx as e, Fragment as j } from "react/jsx-runtime";
import { memo as B, useId as U, useState as M, useCallback as V } from "react";
const d = "var(--accent)", E = "var(--fp-primary-soft)", g = "#ea580c", w = "#0f766e", T = "#0f766e22", q = "var(--line)";
function F(s) {
  const i = s.length, v = s.reduce((c, u) => c + u, 0), f = v / i, m = s.map((c) => c - f), b = m.map((c) => c * c), N = b.reduce((c, u) => c + u, 0), C = N / i, k = i > 1 ? N / (i - 1) : 0;
  return {
    n: i,
    sum: v,
    mean: f,
    deviations: m,
    devSq: b,
    sumDevSq: N,
    varN: C,
    varN1: k,
    stdN: Math.sqrt(C),
    stdN1: Math.sqrt(k),
    sorted: [...s].sort((c, u) => c - u)
  };
}
function o(s, i = 4) {
  return s.toFixed(i);
}
function H(s, i) {
  const v = Math.random(), f = Math.random(), m = Math.sqrt(-2 * Math.log(v + 1e-12)) * Math.cos(2 * Math.PI * f);
  return s + i * m;
}
const D = 480, O = 100, p = 28, _ = D - 20, h = 60;
function Y({ data: s, mean: i, stdN1: v, useBiased: f }) {
  if (s.length === 0) return null;
  const m = f ? Math.sqrt(s.reduce((x, X) => x + (X - i) ** 2, 0) / s.length) : v, b = Math.min(...s), N = Math.max(...s), k = (N - b || 1) * 0.18, c = b - k, u = N + k;
  function a(x) {
    return p + (x - c) / (u - c) * (_ - p);
  }
  const A = a(i), S = a(i - m), I = a(i + m), t = Array.from(/* @__PURE__ */ new Set([b, i, N]));
  return /* @__PURE__ */ n("svg", { viewBox: `0 0 ${D} ${O}`, className: "w-full", children: [
    m > 0 && /* @__PURE__ */ e(
      "rect",
      {
        x: Math.max(p, S),
        y: h - 18,
        width: Math.max(0, Math.min(I, _) - Math.max(S, p)),
        height: 36,
        fill: E,
        opacity: 0.7,
        rx: 4
      }
    ),
    /* @__PURE__ */ e(
      "line",
      {
        x1: p,
        y1: h,
        x2: _,
        y2: h,
        stroke: q,
        strokeWidth: 1.5
      }
    ),
    t.map((x, X) => /* @__PURE__ */ n("g", { children: [
      /* @__PURE__ */ e(
        "line",
        {
          x1: a(x),
          y1: h - 4,
          x2: a(x),
          y2: h + 4,
          stroke: "var(--ink-faint)",
          strokeWidth: 1
        }
      ),
      /* @__PURE__ */ e(
        "text",
        {
          x: a(x),
          y: h + 16,
          fontSize: "9",
          textAnchor: "middle",
          fill: "var(--ink-faint)",
          children: o(x, 1)
        }
      )
    ] }, X)),
    s.map((x, X) => /* @__PURE__ */ e(
      "circle",
      {
        cx: a(x),
        cy: h,
        r: 5,
        fill: "white",
        stroke: d,
        strokeWidth: 1.8,
        opacity: 0.85
      },
      X
    )),
    /* @__PURE__ */ e(
      "line",
      {
        x1: A,
        y1: h - 22,
        x2: A,
        y2: h + 8,
        stroke: g,
        strokeWidth: 2
      }
    ),
    /* @__PURE__ */ n(
      "text",
      {
        x: A,
        y: h - 26,
        fontSize: "10",
        textAnchor: "middle",
        fill: g,
        fontWeight: "700",
        children: [
          "X̄=",
          o(i, 2)
        ]
      }
    ),
    m > 0 && /* @__PURE__ */ n(j, { children: [
      /* @__PURE__ */ e(
        "text",
        {
          x: S,
          y: h - 22,
          fontSize: "8",
          textAnchor: "middle",
          fill: d,
          opacity: 0.9,
          children: "X̄−S"
        }
      ),
      /* @__PURE__ */ e(
        "text",
        {
          x: I,
          y: h - 22,
          fontSize: "8",
          textAnchor: "middle",
          fill: d,
          opacity: 0.9,
          children: "X̄+S"
        }
      )
    ] }),
    /* @__PURE__ */ e(
      "circle",
      {
        cx: p + 4,
        cy: 18,
        r: 4,
        fill: "white",
        stroke: d,
        strokeWidth: 1.6
      }
    ),
    /* @__PURE__ */ e("text", { x: p + 11, y: 22, fontSize: "9", fill: "var(--ink-faint)", children: "样本点" }),
    /* @__PURE__ */ e(
      "line",
      {
        x1: p + 38,
        y1: 14,
        x2: p + 38,
        y2: 24,
        stroke: g,
        strokeWidth: 2
      }
    ),
    /* @__PURE__ */ e("text", { x: p + 44, y: 22, fontSize: "9", fill: "var(--ink-faint)", children: "均值 X̄" }),
    /* @__PURE__ */ e(
      "rect",
      {
        x: p + 72,
        y: 14,
        width: 10,
        height: 10,
        fill: E,
        rx: 2
      }
    ),
    /* @__PURE__ */ e("text", { x: p + 85, y: 22, fontSize: "9", fill: "var(--ink-faint)", children: "X̄±S 范围" })
  ] });
}
function W({ step: s, title: i, children: v }) {
  return /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-elevated)] overflow-hidden", children: [
    /* @__PURE__ */ n(
      "div",
      {
        className: "flex items-center gap-2 px-3 py-2",
        style: { background: E },
        children: [
          /* @__PURE__ */ e(
            "span",
            {
              className: "flex h-5 w-5 items-center justify-center rounded-full text-[11px] font-bold text-white flex-shrink-0",
              style: { background: d },
              children: s
            }
          ),
          /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold", style: { color: d }, children: i })
        ]
      }
    ),
    /* @__PURE__ */ e("div", { className: "px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: v })
  ] });
}
function P() {
  const s = U(), [i, v] = M("4 7 2 9 5 8 3 6"), [f, m] = M(""), [b, N] = M(
    "normal"
  ), [C, k] = M(8), [c, u] = M([4, 7, 2, 9, 5, 8, 3, 6]), [a, A] = M(!1), [S, I] = M(!1), t = c.length >= 2 ? F(c) : null, x = V((r) => {
    const l = r.trim().split(/[\s,，]+/).filter(Boolean);
    if (l.length < 2) return null;
    const y = l.map(Number);
    return y.some(isNaN) ? null : y;
  }, []);
  function X(r) {
    v(r);
    const l = x(r);
    l ? (u(l), m("")) : m("请输入至少 2 个数字，用空格或逗号分隔");
  }
  function L() {
    const r = C;
    let l;
    b === "normal" ? l = Array.from({ length: r }, () => H(5, 2)) : l = Array.from({ length: r }, () => Math.random() * 10), l = l.map((y) => Math.round(y * 100) / 100), u(l), v(l.join(" ")), m("");
  }
  const z = t ? a ? t.varN : t.varN1 : 0, R = Math.sqrt(z), G = a ? "n" : "n−1", $ = t ? a ? t.n : t.n - 1 : 1;
  return /* @__PURE__ */ n("div", { className: "rounded-xl border border-[var(--line)] bg-[var(--bg-elevated)] p-4 space-y-5", children: [
    /* @__PURE__ */ n("div", { children: [
      /* @__PURE__ */ e("h3", { className: "text-[15px] font-bold text-[var(--ink)]", children: "统计量计算器" }),
      /* @__PURE__ */ e("p", { className: "text-[12px] text-[var(--ink-soft)] mt-0.5", children: "输入样本数据，逐步展示 X̄、S²、S 的计算过程，并直观比较有偏 vs 无偏估计。" })
    ] }),
    /* @__PURE__ */ n("div", { className: "rounded-lg bg-[var(--bg-muted)] px-4 py-3 space-y-3", children: [
      /* @__PURE__ */ n("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ e(
          "label",
          {
            htmlFor: s,
            className: "text-[13px] font-semibold text-[var(--ink)]",
            children: "样本数据（空格或逗号分隔）"
          }
        ),
        /* @__PURE__ */ e(
          "input",
          {
            id: s,
            type: "text",
            value: i,
            onChange: (r) => X(r.target.value),
            placeholder: "例：4 7 2 9 5 8 3 6",
            className: "w-full rounded-lg border px-3 py-1.5 font-mono text-[13px] text-[var(--ink)] outline-none focus:border-[var(--accent)] focus:ring-1 focus:ring-[var(--accent)]",
            style: {
              borderColor: f ? "var(--md-sys-color-error)" : q
            }
          }
        ),
        f && /* @__PURE__ */ e("p", { className: "text-[11px] text-[var(--md-sys-color-error)]", children: f })
      ] }),
      /* @__PURE__ */ n("div", { className: "flex flex-wrap items-center gap-3", children: [
        /* @__PURE__ */ n("div", { className: "flex items-center gap-2 text-[12px] text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ e("span", { className: "font-medium text-[var(--ink)]", children: "分布：" }),
          ["normal", "uniform"].map((r) => /* @__PURE__ */ n("label", { className: "flex items-center gap-1 cursor-pointer", children: [
            /* @__PURE__ */ e(
              "input",
              {
                type: "radio",
                name: "distribution",
                value: r,
                checked: b === r,
                onChange: () => N(r),
                className: "accent-[var(--accent)]"
              }
            ),
            r === "normal" ? "正态 N(5,4)" : "均匀 U[0,10]"
          ] }, r))
        ] }),
        /* @__PURE__ */ n("div", { className: "flex items-center gap-2 text-[12px] text-[var(--ink-soft)]", children: [
          /* @__PURE__ */ e("span", { className: "font-medium text-[var(--ink)]", children: "样本量 n=" }),
          /* @__PURE__ */ e(
            "input",
            {
              type: "number",
              min: 2,
              max: 30,
              value: C,
              onChange: (r) => k(Math.max(2, Math.min(30, Number(r.target.value)))),
              className: "w-14 rounded border px-2 py-0.5 text-center font-mono text-[13px] text-[var(--ink)]",
              style: { borderColor: q }
            }
          )
        ] }),
        /* @__PURE__ */ e(
          "button",
          {
            type: "button",
            onClick: L,
            className: "rounded-lg px-3 py-1.5 text-[13px] font-medium text-white transition-opacity hover:opacity-90",
            style: { background: d },
            children: "随机生成"
          }
        )
      ] })
    ] }),
    t && /* @__PURE__ */ n("div", { className: "flex items-center gap-3 rounded-lg border border-[var(--line)] px-3 py-2.5 bg-[var(--bg-muted)]", children: [
      /* @__PURE__ */ e("span", { className: "text-[13px] font-semibold text-[var(--ink)] flex-shrink-0", children: "方差分母：" }),
      /* @__PURE__ */ e("div", { className: "flex gap-1.5", children: [!1, !0].map((r) => /* @__PURE__ */ e(
        "button",
        {
          type: "button",
          onClick: () => A(r),
          className: "rounded-md px-3 py-1 text-[12px] font-semibold transition-colors " + (a === r ? "text-white" : "text-[var(--ink-soft)] bg-[var(--bg-elevated)] border border-[var(--line)] hover:border-[var(--accent)]"),
          style: a === r ? { background: d } : {},
          children: r ? "n（有偏 / 总体方差）" : "n−1（无偏 / 样本方差 S²）"
        },
        String(r)
      )) }),
      /* @__PURE__ */ e("span", { className: "ml-auto text-[11px] text-[var(--ink-soft)]", children: a ? "以 n 为分母得有偏估计，会低估总体方差" : "以 n−1 为分母得无偏估计，是统计学标准 S²" })
    ] }),
    t && /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] px-2 py-3", children: [
      /* @__PURE__ */ e("div", { className: "mb-1 px-2 text-[12px] font-semibold text-[var(--ink)]", children: "样本数轴（X̄ 橙线 · 蓝区 = X̄ ± S）" }),
      /* @__PURE__ */ e(
        Y,
        {
          data: c,
          mean: t.mean,
          stdN1: t.stdN1,
          useBiased: a
        }
      )
    ] }),
    t && /* @__PURE__ */ n("div", { className: "space-y-3", children: [
      /* @__PURE__ */ n(W, { step: 1, title: "计算样本均值 X̄", children: [
        /* @__PURE__ */ n("div", { className: "font-mono", children: [
          "Σxᵢ = ",
          c.join(" + "),
          " =",
          " ",
          /* @__PURE__ */ e("strong", { style: { color: d }, children: o(t.sum) })
        ] }),
        /* @__PURE__ */ n("div", { className: "font-mono mt-1", children: [
          "X̄ = Σxᵢ / n = ",
          o(t.sum),
          " / ",
          t.n,
          " =",
          " ",
          /* @__PURE__ */ e("strong", { style: { color: g }, children: o(t.mean) })
        ] })
      ] }),
      /* @__PURE__ */ n(W, { step: 2, title: "计算各偏差 (xᵢ − X̄) 与平方", children: [
        /* @__PURE__ */ e("div", { className: "overflow-x-auto", children: /* @__PURE__ */ n("table", { className: "min-w-full text-center text-[11px]", children: [
          /* @__PURE__ */ e("thead", { children: /* @__PURE__ */ n("tr", { children: [
            /* @__PURE__ */ e("th", { className: "px-2 py-1 font-semibold text-[var(--ink)]", children: "i" }),
            /* @__PURE__ */ e("th", { className: "px-2 py-1 font-semibold text-[var(--ink)]", children: "xᵢ" }),
            /* @__PURE__ */ e(
              "th",
              {
                className: "px-2 py-1 font-semibold",
                style: { color: g },
                children: "xᵢ − X̄"
              }
            ),
            /* @__PURE__ */ e(
              "th",
              {
                className: "px-2 py-1 font-semibold",
                style: { color: w },
                children: "(xᵢ − X̄)²"
              }
            )
          ] }) }),
          /* @__PURE__ */ n("tbody", { children: [
            c.map((r, l) => /* @__PURE__ */ n(
              "tr",
              {
                className: l % 2 === 0 ? "bg-[var(--bg-muted)]" : "bg-[var(--bg-elevated)]",
                children: [
                  /* @__PURE__ */ e("td", { className: "px-2 py-0.5 font-mono", children: l + 1 }),
                  /* @__PURE__ */ e("td", { className: "px-2 py-0.5 font-mono", children: o(r, 2) }),
                  /* @__PURE__ */ n(
                    "td",
                    {
                      className: "px-2 py-0.5 font-mono",
                      style: { color: g },
                      children: [
                        t.deviations[l] >= 0 ? "+" : "",
                        o(t.deviations[l])
                      ]
                    }
                  ),
                  /* @__PURE__ */ e(
                    "td",
                    {
                      className: "px-2 py-0.5 font-mono font-semibold",
                      style: { color: w },
                      children: o(t.devSq[l])
                    }
                  )
                ]
              },
              l
            )),
            /* @__PURE__ */ n("tr", { className: "border-t border-[var(--line)]", children: [
              /* @__PURE__ */ e(
                "td",
                {
                  colSpan: 2,
                  className: "px-2 py-1 text-right font-semibold text-[var(--ink)] text-[12px]",
                  children: "Σ ="
                }
              ),
              /* @__PURE__ */ e(
                "td",
                {
                  className: "px-2 py-1 font-mono font-semibold",
                  style: { color: g },
                  children: o(t.deviations.reduce((r, l) => r + l, 0))
                }
              ),
              /* @__PURE__ */ e(
                "td",
                {
                  className: "px-2 py-1 font-mono font-bold",
                  style: { color: w },
                  children: o(t.sumDevSq)
                }
              )
            ] })
          ] })
        ] }) }),
        /* @__PURE__ */ n("p", { className: "mt-1.5 text-[11px] text-[var(--ink-soft)]", children: [
          "注：偏差之和 ≈ 0（均值定义保证），偏差平方和（SS） =",
          " ",
          /* @__PURE__ */ e("strong", { style: { color: w }, children: o(t.sumDevSq) })
        ] })
      ] }),
      /* @__PURE__ */ n(
        W,
        {
          step: 3,
          title: `计算方差 S² (分母 ${G}) 与标准差 S`,
          children: [
            /* @__PURE__ */ n("div", { className: "font-mono", children: [
              "S² = Σ(xᵢ−X̄)² / ",
              G,
              " = ",
              o(t.sumDevSq),
              " / ",
              $,
              " ",
              "= ",
              /* @__PURE__ */ e("strong", { style: { color: d }, children: o(z) })
            ] }),
            /* @__PURE__ */ n("div", { className: "font-mono mt-1", children: [
              "S = √S² = √",
              o(z),
              " =",
              " ",
              /* @__PURE__ */ e("strong", { style: { color: d }, children: o(R) })
            ] }),
            /* @__PURE__ */ n("div", { className: "mt-2.5 grid grid-cols-2 gap-2", children: [
              /* @__PURE__ */ n(
                "div",
                {
                  className: "rounded-md px-2.5 py-2 text-center",
                  style: {
                    background: a ? E : "var(--bg-muted)",
                    borderWidth: 1,
                    borderStyle: "solid",
                    borderColor: a ? d : q
                  },
                  children: [
                    /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: "有偏 S²（÷n）" }),
                    /* @__PURE__ */ e(
                      "div",
                      {
                        className: "text-[14px] font-extrabold font-mono",
                        style: { color: a ? d : "var(--ink-faint)" },
                        children: o(t.varN)
                      }
                    ),
                    /* @__PURE__ */ n("div", { className: "text-[9px] text-[var(--ink-soft)]", children: [
                      "S = ",
                      o(t.stdN)
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ n(
                "div",
                {
                  className: "rounded-md px-2.5 py-2 text-center",
                  style: {
                    background: a ? "var(--bg-muted)" : T,
                    borderWidth: 1,
                    borderStyle: "solid",
                    borderColor: a ? q : w
                  },
                  children: [
                    /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: "无偏 S²（÷n−1）" }),
                    /* @__PURE__ */ e(
                      "div",
                      {
                        className: "text-[14px] font-extrabold font-mono",
                        style: { color: a ? "var(--ink-faint)" : w },
                        children: o(t.varN1)
                      }
                    ),
                    /* @__PURE__ */ n("div", { className: "text-[9px] text-[var(--ink-soft)]", children: [
                      "S = ",
                      o(t.stdN1)
                    ] })
                  ]
                }
              )
            ] }),
            /* @__PURE__ */ n("p", { className: "mt-1.5 text-[11px] text-[var(--ink-soft)]", children: [
              /* @__PURE__ */ e("strong", { children: "为什么用 n−1？" }),
              " 样本均值 X̄ 已消耗了 1 个自由度， 用 n−1 作分母才能保证 E[S²] = σ²（无偏估计量）。"
            ] })
          ]
        }
      ),
      /* @__PURE__ */ n(W, { step: 4, title: "顺序统计量 X(1) ≤ X(2) ≤ … ≤ X(n)", children: [
        /* @__PURE__ */ e("div", { className: "flex items-center gap-2 flex-wrap", children: t.sorted.map((r, l) => /* @__PURE__ */ n("div", { className: "flex flex-col items-center gap-0.5", children: [
          /* @__PURE__ */ e(
            "span",
            {
              className: "rounded-md px-2 py-0.5 font-mono text-[12px] font-semibold text-white",
              style: {
                background: d,
                opacity: 0.75 + l / (t.n - 1 || 1) * 0.25
              },
              children: o(r, 2)
            }
          ),
          /* @__PURE__ */ n("span", { className: "text-[9px] text-[var(--ink-soft)]", children: [
            "X(",
            l + 1,
            ")"
          ] })
        ] }, l)) }),
        /* @__PURE__ */ n(
          "button",
          {
            type: "button",
            onClick: () => I(!S),
            className: "mt-2 text-[11px] text-[var(--accent)] underline",
            children: [
              S ? "收起" : "展开",
              " Min / Median / Max 解读"
            ]
          }
        ),
        S && /* @__PURE__ */ e("div", { className: "mt-2 grid grid-cols-3 gap-2 text-center", children: [
          {
            label: "最小值 X(1)",
            val: t.sorted[0],
            sub: "第1顺序统计量"
          },
          {
            label: "中位数",
            val: t.n % 2 === 1 ? t.sorted[Math.floor(t.n / 2)] : (t.sorted[t.n / 2 - 1] + t.sorted[t.n / 2]) / 2,
            sub: t.n % 2 === 1 ? `X(${Math.floor(t.n / 2) + 1})` : "两中间均值"
          },
          {
            label: "最大值 X(n)",
            val: t.sorted[t.n - 1],
            sub: `第${t.n}顺序统计量`
          }
        ].map(({ label: r, val: l, sub: y }) => /* @__PURE__ */ n(
          "div",
          {
            className: "rounded-lg px-2 py-1.5",
            style: { background: E },
            children: [
              /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)]", children: r }),
              /* @__PURE__ */ e(
                "div",
                {
                  className: "font-mono text-[14px] font-bold",
                  style: { color: d },
                  children: o(l, 2)
                }
              ),
              /* @__PURE__ */ e("div", { className: "text-[9px] text-[var(--ink-soft)]", children: y })
            ]
          },
          r
        )) })
      ] })
    ] }),
    t && /* @__PURE__ */ e("div", { className: "grid grid-cols-2 gap-2 sm:grid-cols-4", children: [
      { label: "样本均值 X̄", val: o(t.mean), color: g },
      {
        label: `样本方差 S² (÷${G})`,
        val: o(z),
        color: d
      },
      { label: "样本标准差 S", val: o(R), color: d },
      { label: "样本量 n", val: String(t.n), color: w }
    ].map(({ label: r, val: l, color: y }) => /* @__PURE__ */ n(
      "div",
      {
        className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] p-2.5 text-center",
        children: [
          /* @__PURE__ */ e("div", { className: "text-[10px] text-[var(--ink-soft)] leading-snug", children: r }),
          /* @__PURE__ */ e(
            "div",
            {
              className: "mt-1 font-mono text-[16px] font-extrabold",
              style: { color: y },
              children: l
            }
          )
        ]
      },
      r
    )) }),
    t && /* @__PURE__ */ n("div", { className: "rounded-lg border border-[var(--line)] bg-[var(--bg-muted)] px-3 py-2.5 text-[12px] text-[var(--ink-soft)] leading-relaxed", children: [
      /* @__PURE__ */ e("span", { className: "font-semibold text-[var(--ink)]", children: "核心概念：" }),
      "X̄、S² 等统计量是总体参数 μ、σ² 的估计量——它们本身是随机变量（不同样本得出不同值）。",
      /* @__PURE__ */ n("span", { className: "font-semibold text-[var(--ink)]", children: [
        " ",
        "S²（除以 n−1）是 σ² 的无偏估计"
      ] }),
      "， 意味着无数次抽样取平均后等于真实方差。 切换「分母」对比，感受差异在小样本时更明显。"
    ] }),
    c.length < 2 && /* @__PURE__ */ e("div", { className: "rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2.5 text-[12px] text-[var(--color-warning)]", children: "请输入至少 2 个数字以开始计算。" })
  ] });
}
const Q = B(P);
export {
  Q as default
};
