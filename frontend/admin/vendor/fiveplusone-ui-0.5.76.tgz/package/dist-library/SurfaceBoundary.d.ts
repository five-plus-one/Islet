import { Component, type ErrorInfo, type ReactNode } from "react";
export interface SurfaceBoundaryProps {
    children: ReactNode;
    title?: string;
    description?: string;
    resetKey?: string | number;
    onError?: (error: Error, info: ErrorInfo) => void;
}
/** Isolate a failed workspace surface and allow the reader to reopen it. */
export declare class SurfaceBoundary extends Component<SurfaceBoundaryProps, {
    failed: boolean;
    attempt: number;
}> {
    state: {
        failed: boolean;
        attempt: number;
    };
    static getDerivedStateFromError(): {
        failed: boolean;
    };
    componentDidCatch(error: Error, info: ErrorInfo): void;
    componentDidUpdate(previous: SurfaceBoundaryProps): void;
    retry: () => void;
    render(): import("react").JSX.Element;
}
