/** SyncStatus - 从课栈 account/CloudSyncStatus 提取
 *
 * 云同步状态条：显示待同步条目与冲突，允许保留本机或采用云端版本。
 * 无待同步条目时不渲染任何内容。
 */
export interface PendingSync {
    key: string;
    /** 该条目在云端也存在更新 */
    conflict?: boolean;
}
export interface SyncStatusProps {
    /** 读取待同步条目 */
    list: () => Promise<PendingSync[]>;
    /** 触发同步 */
    sync: () => Promise<void>;
    /** 冲突解决：keepLocal = true 保留本机 */
    resolve: (key: string, keepLocal: boolean) => Promise<void>;
    /** 轮询间隔（毫秒），设为 0 关闭 */
    intervalMs?: number;
    /** 外部事件名，收到该事件时刷新 */
    eventName?: string;
}
export declare function SyncStatus({ list, sync, resolve, intervalMs, eventName, }: SyncStatusProps): import("react").JSX.Element | null;
