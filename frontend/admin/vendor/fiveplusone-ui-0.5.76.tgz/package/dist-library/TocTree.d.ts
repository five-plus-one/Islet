/** TocTree - 从课栈 layout/TocTree 提取
 *
 * 文档标题目录：按层级缩进，点击滚动到对应章节，支持当前章节高亮。
 * 与 FileTree 的区别是用于页内导航，只有标题与层级。
 */
import { type ReactNode } from "react";
export interface TocItemNode {
    id: string;
    text: string;
    level?: number;
    children?: TocItemNode[];
}
export interface TocTreeProps {
    items: TocItemNode[];
    /** 当前章节 id */
    activeId?: string | null;
    onSelect?: (id: string) => void;
    /** 无滚动目标时用于定位，默认按 id 查找元素 */
    scrollContainer?: string;
    label?: string;
    empty?: ReactNode;
}
export declare function TocTree({ items, activeId, onSelect, label, empty, }: TocTreeProps): import("react").JSX.Element;
