/** KeZhan 组件提取 - TokenDashboard（积分仪表盘）
 *
 * 原组件功能：
 * - 显示用户积分余额
 * - 加载状态处理
 * - 点击打开计费面板
 *
 * 五加一设计规范重写：
 * - 使用 fp-* 变量
 * - 统一交互模式
 * - 完整可访问性
 */
export interface TokenDashboardProps {
    /** 当前余额（以 token 计） */
    balance?: number;
    /** 是否启用积分系统 */
    enabled?: boolean;
    /** 加载状态 */
    isLoading?: boolean;
    /** 点击回调 */
    onClick?: () => void;
    /** 自定义标签 */
    label?: string;
}
export declare function TokenDashboard({ balance, enabled, isLoading, onClick, label, }: TokenDashboardProps): import("react").JSX.Element;
/** 带自动加载的版本 */
export declare function TokenDashboardAuto({ apiEndpoint, onClick, }: {
    apiEndpoint?: string;
    onClick?: () => void;
}): import("react").JSX.Element;
