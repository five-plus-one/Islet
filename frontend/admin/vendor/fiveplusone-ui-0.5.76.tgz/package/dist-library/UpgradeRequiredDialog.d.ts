import type { ReactNode } from 'react';
export declare function UpgradeRequiredDialog({ open, version, minimum, children, actions, updateContent }: {
    open: boolean;
    version?: string;
    minimum?: string;
    children?: ReactNode;
    actions?: ReactNode;
    updateContent?: ReactNode;
}): import("react").JSX.Element;
