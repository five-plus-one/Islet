export interface UploadTask {
    id: string;
    name: string;
    status: 'waiting' | 'uploading' | 'processing' | 'done' | 'error';
    progress?: number;
    error?: string;
}
export interface UploadQueueProps {
    tasks: UploadTask[];
    onCancel?: (id: string) => void;
    onRetry?: (id: string) => void;
    onDismiss?: (id: string) => void;
}
export declare function UploadQueue({ tasks, onCancel, onRetry, onDismiss }: UploadQueueProps): import("react").JSX.Element;
