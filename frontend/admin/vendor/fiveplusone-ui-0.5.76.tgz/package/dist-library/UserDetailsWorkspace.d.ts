import { type ReactNode } from "react";
import { type DirectoryUser, type DirectoryGroup } from "./DirectoryWorkspace";
export interface UserDetailsWorkspaceProps {
    user: DirectoryUser;
    groups: DirectoryGroup[];
    existing?: boolean;
    protectedUser?: boolean;
    storage?: {
        used: number;
        capacity: number;
    };
    credits?: number;
    administrator?: boolean;
    loading?: boolean;
    error?: string;
    onSaveProfile: (user: DirectoryUser) => Promise<void> | void;
    onSaveCapacity?: (gigabytes: number, expectedBytes: number) => Promise<void> | void;
    onAdjustCredits?: (amount: number, reason: string) => Promise<void> | void;
    onSaveAdministrator?: (enabled: boolean) => Promise<void> | void;
    onRetry?: () => void;
    canManageAdministrator?: boolean;
    emailEditable?: boolean;
    usage?: ReactNode;
    notebooks?: ReactNode;
}
export declare function UserDetailsWorkspace(props: UserDetailsWorkspaceProps): import("react").JSX.Element;
