/** VideoPlayer - 从课栈 video/InlinePlayer 提取
 *
 * 轻量视频播放器：原生 video 元素加自绘控制条，支持播放/暂停、
 * 进度、音量、全屏与画中画。不依赖第三方播放器库。
 */
import { type Ref } from "react";
export interface VideoPlayerProps {
    src: string;
    poster?: string;
    title?: string;
    /** 初始播放位置（秒） */
    startAt?: number;
    autoPlay?: boolean;
    onReady?: (video: HTMLVideoElement) => void;
    onWindowPlayback?: (time: number) => void;
    onTimeUpdate?: (time: number) => void;
    onEnded?: () => void;
    resolveSource?: (src: string, signal: AbortSignal) => Promise<string>;
    videoRef?: Ref<HTMLVideoElement>;
    onSeek?: (time: number) => void;
    onPlaybackRateChange?: (rate: number) => void;
    onPlaybackError?: (error: string) => void;
    onPictureInPictureChange?: (active: boolean) => void;
    tracks?: {
        src: string;
        label: string;
        language: string;
        default?: boolean;
    }[];
    /** 仅在播放器内获得焦点时响应快捷键 */
    keyboardShortcuts?: boolean;
}
export declare function VideoPlayer({ src, poster, title, startAt, autoPlay, onReady, onWindowPlayback, onTimeUpdate, onEnded, resolveSource, videoRef, onSeek, onPlaybackRateChange, onPlaybackError, tracks, onPictureInPictureChange, keyboardShortcuts, }: VideoPlayerProps): import("react").JSX.Element;
