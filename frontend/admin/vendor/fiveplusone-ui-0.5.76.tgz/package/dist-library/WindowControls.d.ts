import type { HTMLAttributes, ReactNode } from 'react';
import './window-controls.css';
export interface WindowControlsProps {
    maximized: boolean;
    fullscreen?: boolean;
    onMinimize: () => void;
    onMaximize: () => void;
    onClose: () => void;
}
/** Embeds native window actions in an application's existing header. */
export declare function WindowControls({ maximized, fullscreen, onMinimize, onMaximize, onClose }: WindowControlsProps): import("react").JSX.Element;
export declare function WindowDragRegion({ enabled, as: Tag, children, className, ...props }: HTMLAttributes<HTMLElement> & {
    enabled?: boolean;
    as?: 'header' | 'div' | 'section';
    children?: ReactNode;
}): import("react").JSX.Element;
