/** WindowTaskbar - 从课栈 window/WindowTaskbar 提取
 *
 * 已打开窗口的任务栏：图标按钮，当前窗口高亮，超出宽度时收进溢出菜单。
 */
import { type ReactNode } from "react";
export interface TaskbarWindow {
    id: string;
    title: string;
    icon?: ReactNode;
    active?: boolean;
}
export interface WindowTaskbarProps {
    windows: TaskbarWindow[];
    onSelect: (id: string) => void;
    /** 最多直接显示的窗口数 */
    max?: number;
    label?: string;
}
export declare function WindowTaskbar({ windows, onSelect, max, label, }: WindowTaskbarProps): import("react").JSX.Element | null;
