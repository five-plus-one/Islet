import { type ReactNode } from "react";
import { type ContextMenuItem } from "./ContextMenu";
export interface NavigationItem {
    id: string;
    label: string;
    icon?: ReactNode;
    detail?: string;
    disabled?: boolean;
}
export declare function ProductNavigation({ items, value, onChange, label, variant, compact, }: {
    items: NavigationItem[];
    value: string;
    onChange: (id: string) => void;
    label?: string;
    variant?: 'tabs' | 'rail' | 'sidebar';
    compact?: boolean;
}): import("react").JSX.Element;
export interface BookshelfItem {
    id: string;
    title: string;
    subtitle?: string;
    coverUrl?: string;
    detail?: string;
    progress?: number;
    group?: string;
}
export declare function Bookshelf({ items, onOpen, actions, loading, error, onCreate, }: {
    items: BookshelfItem[];
    onOpen: (id: string) => void;
    actions?: (item: BookshelfItem) => ContextMenuItem[];
    loading?: boolean;
    error?: string;
    onCreate?: () => void;
}): import("react").JSX.Element;
export declare function MobileTopBar({ title, onBack, actions, }: {
    title: string;
    onBack?: () => void;
    actions?: ReactNode;
}): import("react").JSX.Element;
