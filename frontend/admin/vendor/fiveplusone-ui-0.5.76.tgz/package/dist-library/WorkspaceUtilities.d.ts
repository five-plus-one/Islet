import { type ReactNode } from "react";
export interface ShortcutBinding {
    id: string;
    keys: string;
    label: string;
    enabled?: boolean;
    allowInInput?: boolean;
    priority?: number;
    run: () => void;
}
export declare function ShortcutProvider({ children, paused, }: {
    children: ReactNode;
    paused?: boolean;
}): import("react").JSX.Element;
export declare function useShortcut(binding: ShortcutBinding): void;
export interface ShortcutSetting {
    id: string;
    label: string;
    keys: string;
    enabled: boolean;
}
export declare function ShortcutSettings({ items, onChange, onReset, }: {
    items: ShortcutSetting[];
    onChange: (id: string, keys: string, enabled: boolean) => void;
    onReset?: () => void;
}): import("react").JSX.Element;
export interface WindowGeometry {
    x: number;
    y: number;
    width: number;
    height: number;
}
/** Keep every title-bar control reachable inside its containing workspace. */
export declare function constrainWindowGeometry(geometry: WindowGeometry, bounds: {
    width: number;
    height: number;
}, minimum?: {
    width: number;
    height: number;
}): WindowGeometry;
export interface FloatingWindowProps {
    title: string;
    geometry: WindowGeometry;
    onGeometryChange: (value: WindowGeometry) => void;
    onClose: () => void;
    onMinimize?: () => void;
    onFocus?: () => void;
    children: ReactNode;
    zIndex?: number;
    minWidth?: number;
    minHeight?: number;
    contained?: boolean;
}
export declare function FloatingWindow({ title, geometry, onGeometryChange, onClose, onMinimize, onFocus, children, zIndex, minWidth, minHeight, contained, }: FloatingWindowProps): import("react").JSX.Element;
export declare function BrowserSurface({ url, onNavigate, onBack, onForward, canBack, canForward, loading, error, children, }: {
    url: string;
    onNavigate: (url: string) => void;
    onBack?: () => void;
    onForward?: () => void;
    canBack?: boolean;
    canForward?: boolean;
    loading?: boolean;
    error?: string;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function ImportPanel({ title, accept, multiple, onImport, children, }: {
    title?: string;
    accept?: string;
    multiple?: boolean;
    onImport: (files: File[]) => Promise<void> | void;
    children?: ReactNode;
}): import("react").JSX.Element;
export declare function LazyVisible({ children, fallback, margin, }: {
    children: ReactNode;
    fallback?: ReactNode;
    margin?: string;
}): import("react").JSX.Element;
