import type { CanvasBlock } from "./engines/types";
interface CanvasBlockRendererProps {
    block: CanvasBlock;
    revisionTopic?: string;
    onRevisionSubmit?: (instruction: string) => void | Promise<void>;
    onRevisionAccepted?: (block: CanvasBlock) => void;
}
export declare function CanvasBlockRenderer({ block, revisionTopic, onRevisionSubmit, onRevisionAccepted, }: CanvasBlockRendererProps): import("react").JSX.Element;
export {};
