interface CanvasControlsProps {
    onReset?: () => void;
    onZoomIn?: () => void;
    onZoomOut?: () => void;
    /** 「下载 HTML」；省略则不显示（仅 HTML 图层用）。 */
    onDownload?: () => void;
    /** 「新页面展开」；省略则不显示（仅 HTML 图层用）。 */
    onOpenExternal?: () => void;
    /** 进入/退出「放大查看」全屏；省略则不显示该键。 */
    onMaximize?: () => void;
    /** 当前是否全屏：决定 onMaximize 键显示 放大(Maximize2) 还是 退出(Minimize2)。 */
    fullscreen?: boolean;
}
/**
 * 画布右上角半透明悬浮控件——与正文 HTML（ContentPageClient）控件**完全同款**：
 * 深色半透明药丸 + 白色图标 + backdrop-blur。每个键按需出现：
 * 缩放体传 zoom/reset，HTML 图层传 onOpenExternal，全屏由壳层传 onMaximize。
 * 全屏时 onMaximize 键变 Minimize2（退出）——全屏内唯一退出件（另有 Esc / 点背板）。
 * 样式在 app/styles/canvas.css 的 .svg-canvas-controls（保留该类名供指针守卫选择器使用）。
 */
export declare function CanvasControls({ onReset, onZoomIn, onZoomOut, onDownload, onOpenExternal, onMaximize, fullscreen, }: CanvasControlsProps): import("react").JSX.Element;
export {};
