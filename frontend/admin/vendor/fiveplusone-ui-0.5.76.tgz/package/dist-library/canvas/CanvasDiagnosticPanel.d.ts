import type { CanvasDiagnostic } from "./engines/types";
export declare function CanvasDiagnosticPanel({ diagnostic, }: {
    diagnostic?: CanvasDiagnostic | null;
}): import("react").JSX.Element | null;
