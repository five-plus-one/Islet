import type { CanvasBlock, CanvasDiagnostic } from "./engines/types";
interface CanvasFrameProps {
    title?: string;
    source?: string;
    diagnostic?: CanvasDiagnostic | null;
    controls?: React.ReactNode;
    children: React.ReactNode;
    className?: string;
    style?: React.CSSProperties;
    onPointerDown?: React.PointerEventHandler<HTMLDivElement>;
    onPointerMove?: React.PointerEventHandler<HTMLDivElement>;
    onPointerUp?: React.PointerEventHandler<HTMLDivElement>;
    onPointerCancel?: React.PointerEventHandler<HTMLDivElement>;
    onWheel?: React.WheelEventHandler<HTMLDivElement>;
    revisionBlock?: CanvasBlock;
    revisionTopic?: string;
    revisionBusy?: boolean;
    revisionError?: string | null;
    onRevisionSubmit?: (instruction: string) => void | Promise<void>;
    onRevisionAccepted?: (block: CanvasBlock) => void;
}
export declare function CanvasFrame({ title, source, diagnostic, controls, children, className, style, onPointerDown, onPointerMove, onPointerUp, onPointerCancel, onWheel, revisionBlock, revisionTopic, revisionBusy, revisionError, onRevisionSubmit, onRevisionAccepted, }: CanvasFrameProps): import("react").JSX.Element;
export {};
