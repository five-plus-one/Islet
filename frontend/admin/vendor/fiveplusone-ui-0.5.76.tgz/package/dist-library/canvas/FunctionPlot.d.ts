export interface FunctionPlotProps {
    /** Math expression in x, e.g. "sin(x)/x" */
    fn: string;
    xMin: number;
    xMax: number;
    yMin: number;
    yMax: number;
    /** Pixel bounds of the plot area (set by parent SvgCanvas) */
    plotLeft: number;
    plotTop: number;
    plotWidth: number;
    plotHeight: number;
    /** Visual */
    color?: string;
    colorIndex?: number;
    label?: string;
    strokeWidth?: number;
    samples?: number;
}
export declare function FunctionPlot({ fn, xMin, xMax, yMin, yMax, plotLeft, plotTop, plotWidth, plotHeight, color, colorIndex, label, strokeWidth, samples, }: FunctionPlotProps): import("react").JSX.Element;
