import { type ReactNode } from "react";
export interface SvgCanvasProps {
    width?: number;
    height?: number;
    /** Math-space bounds: [xMin, xMax, yMin, yMax] */
    xMin?: number;
    xMax?: number;
    yMin?: number;
    yMax?: number;
    showGrid?: boolean;
    showAxes?: boolean;
    axisLabels?: {
        x?: string;
        y?: string;
    };
    pannable?: boolean;
    zoomable?: boolean;
    className?: string;
    children?: ReactNode;
}
export default function SvgCanvas({ width, height, xMin: xMinProp, xMax: xMaxProp, yMin: yMinProp, yMax: yMaxProp, showGrid, showAxes, axisLabels, pannable, zoomable, className, children, }: SvgCanvasProps): import("react").JSX.Element;
