/**
 * Compile a math expression string into a function of x.
 * Uses the Function constructor with a controlled scope — only math
 * functions and constants are available, no access to global scope.
 */
export declare function compileMathExpr(expr: string): (x: number) => number;
export interface TickMark {
    value: number;
    label: string;
}
/**
 * Calculate "nice" tick positions for a given range.
 * Returns 5-10 ticks with clean intervals (1, 2, 5 multiples).
 */
export declare function calculateTicks(min: number, max: number, maxTicks?: number): TickMark[];
export interface Point {
    x: number;
    y: number;
}
/**
 * Sample a function and generate SVG path data.
 * Breaks the path at discontinuities (large jumps or NaN).
 */
export declare function sampleFunctionToPath(fn: (x: number) => number, xMin: number, xMax: number, samples: number, toSvgX: (x: number) => number, toSvgY: (y: number) => number, yMin: number, yMax: number): string;
/**
 * Auto-range Y axis by sampling the function.
 */
export declare function autoRangeY(fn: (x: number) => number, xMin: number, xMax: number, samples?: number): {
    yMin: number;
    yMax: number;
};
export declare function getCurveColor(index: number, explicit?: string): string;
