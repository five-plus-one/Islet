import type { CanvasBlock, CanvasAttrs, PlotAttrs } from './types';
type LegacyProps = Record<string, unknown>;
export declare const SVG_ROOT_RE: RegExp;
export declare const BARE_SVG_CHILD_RE: RegExp;
export declare function ensureSvgRoot(source: string, width?: number, height?: number): string;
export declare function normalizePlotAttrs(props: LegacyProps): PlotAttrs;
export declare function normalizeCanvasAttrs(props: LegacyProps): CanvasAttrs;
export declare function normalizeSvgDiagramBlock(props: LegacyProps, childrenText: string): CanvasBlock;
export {};
