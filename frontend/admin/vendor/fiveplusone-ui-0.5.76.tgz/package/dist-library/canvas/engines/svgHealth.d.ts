export type SvgHealthReason = 'ok' | 'empty' | 'no-svg-root' | 'no-visible-elements' | 'out-of-viewbox';
export interface SvgHealthResult {
    ok: boolean;
    reason: SvgHealthReason;
    visibleElementCount: number;
}
export declare function analyzeSvgHealth(markup: string): SvgHealthResult;
