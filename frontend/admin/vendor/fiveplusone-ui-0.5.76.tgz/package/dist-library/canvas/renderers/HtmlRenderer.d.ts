import type { CanvasBlock, HtmlCanvasBlock } from "../engines/types";
interface HtmlRendererProps {
    block: HtmlCanvasBlock;
    revisionTopic?: string;
    onRevisionSubmit?: (instruction: string) => void | Promise<void>;
    onRevisionAccepted?: (block: CanvasBlock) => void;
}
export declare function HtmlRenderer({ block, revisionTopic, onRevisionSubmit, onRevisionAccepted, }: HtmlRendererProps): import("react").JSX.Element;
export {};
