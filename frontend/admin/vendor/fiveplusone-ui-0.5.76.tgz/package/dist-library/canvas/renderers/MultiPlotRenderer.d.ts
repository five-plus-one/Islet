import type { CanvasBlock, MultiPlotCanvasBlock } from "../engines/types";
interface MultiPlotRendererProps {
    block: MultiPlotCanvasBlock;
    revisionTopic?: string;
    onRevisionSubmit?: (instruction: string) => void | Promise<void>;
    onRevisionAccepted?: (block: CanvasBlock) => void;
}
export declare function MultiPlotRenderer({ block, revisionTopic, onRevisionSubmit, onRevisionAccepted, }: MultiPlotRendererProps): import("react").JSX.Element;
export {};
