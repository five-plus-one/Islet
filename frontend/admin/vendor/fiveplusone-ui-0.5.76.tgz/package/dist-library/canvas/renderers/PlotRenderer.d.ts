import type { CanvasBlock, PlotCanvasBlock } from "../engines/types";
interface PlotRendererProps {
    block: PlotCanvasBlock;
    revisionTopic?: string;
    onRevisionSubmit?: (instruction: string) => void | Promise<void>;
    onRevisionAccepted?: (block: CanvasBlock) => void;
}
export declare function PlotRenderer({ block, revisionTopic, onRevisionSubmit, onRevisionAccepted, }: PlotRendererProps): import("react").JSX.Element;
export {};
