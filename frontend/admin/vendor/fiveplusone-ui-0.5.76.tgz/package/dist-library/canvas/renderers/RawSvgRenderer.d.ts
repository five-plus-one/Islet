import type { CanvasBlock, RawSvgCanvasBlock } from "../engines/types";
interface RawSvgRendererProps {
    block: RawSvgCanvasBlock;
    revisionBlock?: CanvasBlock;
    revisionTopic?: string;
    onRevisionSubmit?: (instruction: string) => void | Promise<void>;
    onRevisionAccepted?: (block: CanvasBlock) => void;
}
export declare function RawSvgRenderer({ block, revisionBlock, revisionTopic, onRevisionSubmit, onRevisionAccepted, }: RawSvgRendererProps): import("react").JSX.Element;
export {};
