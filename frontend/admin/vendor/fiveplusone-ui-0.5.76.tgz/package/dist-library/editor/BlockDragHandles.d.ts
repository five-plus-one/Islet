import { Extension } from "@tiptap/core";
/** Native ProseMirror drag handling serializes the selected block, retaining rich node attributes. */
export declare const BlockDragHandles: Extension<any, any>;
