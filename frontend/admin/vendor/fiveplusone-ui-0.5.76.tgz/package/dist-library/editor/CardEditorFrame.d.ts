import type { ReactNode } from "react";
export interface CardEditorFrameProps {
    header: ReactNode;
    children: ReactNode;
    actions: ReactNode;
    onFinish?: () => void;
}
export declare function CardEditorFrame({ header, children, actions, onFinish }: CardEditorFrameProps): import("react").JSX.Element;
