export type CodeBlockLanguageSelectProps = {
    /** 当前语言；null / undefined / "" 表示无语言 */
    language?: string | null;
    /** 选择变化；选「无语言」时回调 null */
    onChange: (lang: string | null) => void;
    className?: string;
};
/**
 * 受控代码块语言下拉。可独立放进工具栏 / 浮动条，
 * 父组件用 languageFromNode 读节点、再把值写回 updateAttributes。
 */
export declare function CodeBlockLanguageSelect({ language, onChange, className }: CodeBlockLanguageSelectProps): import("react").JSX.Element;
export default CodeBlockLanguageSelect;
