import { type ReactNode } from "react";
export interface NoteVersion {
    id: string;
    label: string;
    date: string;
    author?: string;
    preview?: ReactNode;
}
export interface VersionHistoryProps {
    versions: NoteVersion[];
    selectedId?: string;
    onSelect: (id: string) => void;
    onRestore: (id: string) => Promise<void> | void;
    loading?: boolean;
    error?: string;
}
export declare function VersionHistory({ versions, selectedId, onSelect, onRestore, loading, error, }: VersionHistoryProps): import("react").JSX.Element;
export declare function SaveConflict({ local, remote, onResolve, }: {
    local: ReactNode;
    remote: ReactNode;
    onResolve: (choice: "local" | "remote") => Promise<void> | void;
}): import("react").JSX.Element;
export interface Backlink {
    id: string;
    title: string;
    excerpt?: string;
}
export declare function BacklinksPanel({ items, onOpen, loading, }: {
    items: Backlink[];
    onOpen: (id: string) => void;
    loading?: boolean;
}): import("react").JSX.Element;
export declare function ImagePasteOptions({ previewUrl, onChoose, onCancel, busy, error, }: {
    previewUrl: string;
    onChoose: (mode: "image" | "recognize") => void;
    onCancel: () => void;
    busy?: boolean;
    error?: string;
}): import("react").JSX.Element;
export interface DiffLine {
    kind: "same" | "added" | "removed";
    text: string;
}
export declare function VersionDiff({ lines }: {
    lines: DiffLine[];
}): import("react").JSX.Element;
