import { type ReactNode } from "react";
import { type NodeViewProps } from "@tiptap/react";
import type { Editor, Extensions, JSONContent } from "@tiptap/core";
import type { HocuspocusProvider } from "@hocuspocus/provider";
import type * as Y from "yjs";
export interface MarkdownEditorProps {
    /** Initial Markdown. Change documentKey when switching documents; use the Editor handle for external updates. */
    markdown?: string;
    content?: JSONContent | string;
    baseExtensions?: Extensions;
    documentKey?: string;
    document?: Y.Doc;
    provider?: HocuspocusProvider;
    user?: {
        id: string;
        name: string;
        color: string;
    };
    editable?: boolean;
    allowCards?: boolean;
    placeholder?: string;
    onChange?: (markdown: string, document: JSONContent) => void;
    onReady?: (editor: Editor) => void;
    onOpenLink?: (href: string, label: string) => void;
    onHistory?: () => void;
    onSnapshot?: () => void;
    onExport?: (markdown: string) => void;
    onAttachment?: (editor: Editor, kind: "file" | "video") => void;
    onInteractive?: (editor: Editor) => void;
    onOpenAttachment?: (attachment: {
        name: string;
        url: string;
        mediaType: string;
    }) => void;
    onFiles?: (files: File[], editor: Editor) => void;
    resolveResourceUrl?: (url: string) => string;
    renderDirective?: (props: NodeViewProps) => ReactNode;
    extensions?: Extensions;
    status?: ReactNode;
    toolbar?: boolean;
    getSuggestions?: (query: string, kind: "tag" | "link", signal: AbortSignal) => Promise<EditorSuggestion[]>;
    onUploadAction?: (id: string, action: "retry" | "cancel") => void;
    onConversionAction?: (id: string, action: "retry" | "insert" | "keep-image") => void;
}
export interface EditorSuggestion {
    id: string;
    label: string;
    detail?: string;
    href?: string;
    insertText?: string;
}
export declare function MarkdownEditor(props: MarkdownEditorProps): import("react").JSX.Element;
