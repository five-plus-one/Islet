import type { Editor } from "@tiptap/core";
type MathOpener = (editor: Editor, display: boolean, position?: number) => void;
export declare function bindNestedMathEditor(parent: Editor, editor: Editor, open: MathOpener): () => void;
export declare function openActiveMathEditor(parent: Editor, display: boolean, fallback: MathOpener): void;
export declare function useMathEditor(): {
    open: (editor: Editor, display: boolean, position?: number, range?: {
        from: number;
        to: number;
    }) => void;
    card: import("react").JSX.Element | null;
};
export {};
