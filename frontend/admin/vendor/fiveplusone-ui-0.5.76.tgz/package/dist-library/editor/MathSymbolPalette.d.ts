import type { MathShortcut } from "./mathShortcuts";
type KeyboardCommand = "undo" | "redo" | "moveToPreviousChar" | "moveToNextChar" | "deleteBackward" | "moveToNextPlaceholder" | "moveToPreviousPlaceholder";
export default function MathSymbolPalette({ onInsert, shortcuts, onCommand }: {
    onInsert: (value: string) => void;
    shortcuts: readonly MathShortcut[];
    onCommand?: (command: KeyboardCommand) => void;
}): import("react").JSX.Element;
export {};
