export default function ToolbarColorPicker({ mode, current, onApply, onClose, }: {
    mode: "text" | "highlight";
    current?: string | null;
    onApply: (color: string | null) => void;
    onClose: () => void;
}): import("react").JSX.Element;
