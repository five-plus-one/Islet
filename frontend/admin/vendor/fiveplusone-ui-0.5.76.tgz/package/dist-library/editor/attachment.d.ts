import { Node } from "@tiptap/core";
export declare const Attachment: Node<any, any>;
