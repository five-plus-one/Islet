import type { Editor } from "@tiptap/core";
/** Move a whole top-level block while retaining its node attributes and descendants. */
export declare function moveEditorBlock(editor: Editor, direction: "up" | "down"): boolean;
export declare function deleteEditorBlock(editor: Editor): boolean;
