export declare const CALLOUT_TYPES: readonly ["definition", "theorem", "example", "insight", "pitfall", "note", "tip", "memory"];
export type CalloutType = (typeof CALLOUT_TYPES)[number];
export declare const CALLOUTS: Set<string>;
export declare function canonicalDirectiveName(name: string): string;
export declare const CALLOUT_META: Record<string, {
    label: string;
    cls: string;
}>;
/**
 * Obsidian callout 类型 → 本项目 callout kind。
 * null 表示「不转 callout」（保持普通 blockquote）。
 * 未列出的未知类型在 resolveObsidianCallout 中回退为 note。
 */
export declare const OBSIDIAN_CALLOUT_ALIASES: Record<string, CalloutType | null>;
/** 把 Obsidian callout 类型解析为本项目 kind；未知类型回退 note。 */
export declare function resolveObsidianCallout(type: string): CalloutType;
/** quote/cite 等明确不转 callout 的类型。 */
export declare function isSkippedObsidianCallout(type: string): boolean;
