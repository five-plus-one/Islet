import type { Editor } from '@tiptap/core';
import type { KeyboardEvent as ReactKeyboardEvent } from 'react';
type Edit = {
    from: number;
    to: number;
    text: string;
};
/** Edit complete lines; a selection ending at the next line's start excludes that line. */
export declare function codeIndentEdits(text: string, from: number, to: number, outdent?: boolean, size?: number): Edit[];
export declare function mapCodeOffset(offset: number, edits: Edit[]): number;
export declare function indentCodeSelection(editor: Editor, outdent?: boolean): boolean;
export declare function continueCodeIndent(editor: Editor): boolean;
export declare function deleteCodeIndent(editor: Editor): boolean;
/** Use the browser edit command to keep textarea edits in native undo history. */
export declare function editCodeTextarea(event: ReactKeyboardEvent<HTMLTextAreaElement>, onChange: (value: string) => void): boolean;
export {};
