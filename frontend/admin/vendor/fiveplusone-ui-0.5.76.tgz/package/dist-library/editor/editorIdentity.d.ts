/** Initialize identities even when a collaborative provider synchronized before the editor mounted. */
export declare const EditorUniqueID: import("@tiptap/core").Extension<import("@tiptap/extension-unique-id").UniqueIDOptions, any>;
