/** Search user-facing names by Chinese, romanization, initials and command names. */
export declare function editorSearchText(...names: string[]): string;
export type EditorInsertCommand = readonly [string, string, string, string];
export declare const editorInsertCommands: readonly EditorInsertCommand[];
export declare function searchEditorCommands(query: string): EditorInsertCommand[];
export declare function codeLanguageForCommand(command: string): string | null | undefined;
export declare function cardTypeForCommand(command: string): string | undefined;
/** Explicit table dimensions are bounded to keep insertion responsive. */
export declare function tableSizeForCommand(command: string): {
    rows: number;
    cols: number;
} | undefined;
