import type { VirtualKeyboardLayout } from "mathlive";
export declare const mathFunctionNames: Record<string, string>;
export declare const mathKeyboards: readonly [{
    readonly id: "basic";
    readonly label: "常用";
    readonly layout: VirtualKeyboardLayout;
}, {
    readonly id: "calculus";
    readonly label: "高等数学";
    readonly layout: VirtualKeyboardLayout;
}, {
    readonly id: "discrete";
    readonly label: "离散数学";
    readonly layout: VirtualKeyboardLayout;
}, {
    readonly id: "linear";
    readonly label: "线性代数";
    readonly layout: VirtualKeyboardLayout;
}, {
    readonly id: "probability";
    readonly label: "概率统计";
    readonly layout: VirtualKeyboardLayout;
}, {
    readonly id: "letters";
    readonly label: "abc";
    readonly layout: "alphabetic";
}, {
    readonly id: "greek";
    readonly label: "αβγ";
    readonly layout: "greek";
}];
export declare const matrixStyles: readonly [readonly ["pmatrix", "圆括号 ( )"], readonly ["bmatrix", "方括号 [ ]"], readonly ["vmatrix", "行列式 | |"], readonly ["Vmatrix", "双竖线 ‖ ‖"], readonly ["Bmatrix", "花括号 { }"], readonly ["matrix", "无括号"]];
export type MatrixStyle = typeof matrixStyles[number][0];
export declare function matrixTemplate(rows: number, columns: number, style: MatrixStyle): string;
