export declare const mathPreferencesChanged = "fp:math-preferences-changed";
export interface MathPreferenceStorage {
    getItem: (key: string) => string | null;
    setItem: (key: string, value: string) => void;
    refresh?: () => Promise<void>;
}
/** The host may inject account-scoped storage and synchronize it with its service. */
export declare function configureMathPreferences(next?: MathPreferenceStorage): void;
export declare const mathStorage: MathPreferenceStorage;
export declare function refreshMathPreferences(): Promise<void>;
