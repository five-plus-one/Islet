/** Read-mode equivalents for MathLive's editable empty cells and multiline root. */
export declare const mathMacros: {
    "\\placeholder": string;
    "\\displaylines": string;
};
