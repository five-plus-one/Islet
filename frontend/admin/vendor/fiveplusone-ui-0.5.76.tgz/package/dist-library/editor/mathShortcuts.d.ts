import type { MathfieldElement } from "mathlive";
export type MathShortcut = {
    trigger: string;
    replacement: string;
    mode: "auto" | "tab";
    enabled: boolean;
    kind?: "matrix";
};
export declare const shortcutStorageKey = "fp.math.shortcuts.v1";
export declare const defaultMathShortcuts: MathShortcut[];
export declare function expandMatrixShortcut(typed: string, rules: MathShortcut[]): {
    length: number;
    replacement: string;
} | null;
export declare function validateShortcuts(rules: MathShortcut[]): string | null;
export declare function readShortcuts(): MathShortcut[];
export declare function installMathShortcuts(field: MathfieldElement, rules: MathShortcut[], changed: () => void): () => void;
