/** Keep the outer ProseMirror view from selecting or dragging a nested editor's card. */
export declare const nestedEditorNodeViewEvents: {
    stopEvent: ({ event }: {
        event: Event;
    }) => boolean;
};
