export declare function normalizeObsidianCallouts(src: string): string;
export default normalizeObsidianCallouts;
