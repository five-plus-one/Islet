/**
 * Obsidian 内联样式归一：
 *   ==text==                          → <mark>text</mark>
 *   <font color="X">t</font>          → <span style="color:X">t</span>
 *   <span style="background:X">t</span> → <mark data-color="X">t</mark>
 *
 * 在 normalizeObsidianCallouts / normalizeDirectiveLabels 之前调用。
 * 跳过代码围栏。
 */
export declare function normalizeObsidianInlineStyles(src: string): string;
export default normalizeObsidianInlineStyles;
