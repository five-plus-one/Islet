export declare const ResizableImage: import("@tiptap/core").Node<{
    resolveUrl: (url: string) => string;
} & import("@tiptap/extension-image").ImageOptions, any>;
