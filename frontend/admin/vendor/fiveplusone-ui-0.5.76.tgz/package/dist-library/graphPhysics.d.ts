export interface ForceNode {
    id: string;
    x: number;
    y: number;
    vx: number;
    vy: number;
    degree: number;
    fixed?: {
        x: number;
        y: number;
    };
}
export interface ForceLink {
    source: string;
    target: string;
}
export interface ForceOptions {
    centerForce: number;
    repelForce: number;
    linkForce: number;
    nodeSize: number;
}
/** Stateful simulation: dragging pins one body while every other body keeps moving. */
export declare class GraphSimulation {
    nodes: ForceNode[];
    links: [ForceNode, ForceNode][];
    heat: number;
    private byId;
    reconcile(ids: string[], links: ForceLink[]): void;
    get(id: string): ForceNode | undefined;
    wake(): void;
    pin(id: string, x: number, y: number): void;
    release(id: string): void;
    step(options: ForceOptions): boolean;
}
