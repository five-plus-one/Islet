import { type ReactElement } from "react";
declare function BondPolarityExplorerBase(): ReactElement;
declare const _default: import("react").MemoExoticComponent<typeof BondPolarityExplorerBase>;
export default _default;
