declare function IUPACNamingPracticeBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof IUPACNamingPracticeBase>;
export default _default;
