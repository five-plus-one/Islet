declare function ChairFlipBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ChairFlipBase>;
export default _default;
