declare function NewmanProjectionBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof NewmanProjectionBase>;
export default _default;
