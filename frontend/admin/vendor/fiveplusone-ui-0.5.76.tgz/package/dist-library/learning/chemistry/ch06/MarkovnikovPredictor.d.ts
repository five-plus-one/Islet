declare function MarkovnikovPredictorBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof MarkovnikovPredictorBase>;
export default _default;
