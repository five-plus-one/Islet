declare function DieneAdditionBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof DieneAdditionBase>;
export default _default;
