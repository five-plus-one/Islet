declare function DirectingEffectBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof DirectingEffectBase>;
export default _default;
