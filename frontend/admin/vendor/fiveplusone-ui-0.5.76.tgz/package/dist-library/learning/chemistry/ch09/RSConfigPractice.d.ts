declare function RSConfigPracticeBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof RSConfigPracticeBase>;
export default _default;
