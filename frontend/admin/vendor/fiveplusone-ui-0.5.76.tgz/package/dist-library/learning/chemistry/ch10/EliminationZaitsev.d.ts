declare function EliminationZaitsevBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof EliminationZaitsevBase>;
export default _default;
