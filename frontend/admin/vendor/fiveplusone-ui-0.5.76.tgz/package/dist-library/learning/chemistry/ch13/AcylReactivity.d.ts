declare function AcylReactivityBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof AcylReactivityBase>;
export default _default;
