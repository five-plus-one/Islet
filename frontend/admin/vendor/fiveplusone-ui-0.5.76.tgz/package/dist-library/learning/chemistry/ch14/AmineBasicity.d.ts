declare function AmineBasicityBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof AmineBasicityBase>;
export default _default;
