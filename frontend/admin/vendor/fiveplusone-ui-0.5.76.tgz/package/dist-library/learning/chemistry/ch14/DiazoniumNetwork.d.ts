declare function DiazoniumNetworkBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof DiazoniumNetworkBase>;
export default _default;
