export declare function interpolate(nodes: number[], values: number[], x: number): number;
export declare function fitLine(x: number[], y: number[]): {
    slope: number;
    intercept: number;
    residuals: number[];
    sse: number;
};
export declare function quadrature(f: (x: number) => number, a: number, b: number, n: number, method: 'trapezoid' | 'simpson'): number;
export type OdeMethod = 'euler' | 'heun' | 'rk4';
export declare function odeSteps(f: (t: number, y: number) => number, y0: number, h: number, steps: number, method: OdeMethod): {
    t: number;
    y: number;
}[];
export declare function linearSteps(method: 'jacobi' | 'seidel', count: number): {
    x: number;
    y: number;
    residual: number;
}[];
export declare function powerSteps(ratio: number, count: number): {
    x: number;
    y: number;
    eigenvalue: number;
    residual: number;
}[];
