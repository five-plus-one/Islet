export declare function LinearLab(): import("react").JSX.Element;
export declare function InterpolationLab(): import("react").JSX.Element;
export declare function FittingLab(): import("react").JSX.Element;
export declare function QuadratureLab(): import("react").JSX.Element;
export declare function OdeLab(): import("react").JSX.Element;
export declare function PowerLab(): import("react").JSX.Element;
