export declare function cholesky2(a: number, b: number, c: number): {
    l11: number;
    l21: number;
    l22: number;
} | null;
export declare function CholeskyLab(): import("react").JSX.Element;
export declare function LULab(): import("react").JSX.Element;
export declare function ThomasLab(): import("react").JSX.Element;
export declare function ConditionLab(): import("react").JSX.Element;
export declare function DividedDifferenceLab(): import("react").JSX.Element;
