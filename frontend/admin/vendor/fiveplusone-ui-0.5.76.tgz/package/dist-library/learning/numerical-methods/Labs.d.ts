export declare function ErrorLab(): import("react").JSX.Element;
export declare function BisectionLab(): import("react").JSX.Element;
export declare function IterationLab(): import("react").JSX.Element;
