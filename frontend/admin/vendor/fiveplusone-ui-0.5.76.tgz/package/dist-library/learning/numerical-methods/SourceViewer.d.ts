import { type ReactNode } from "react";
/** Course documents stay with the host; this slot receives its authenticated reading view. */
export declare const LearningSourceContext: import("react").Context<((id: string, kind: "audio" | "document" | "transcript") => ReactNode) | null>;
export declare const RecordingOne: () => import("react").JSX.Element;
export declare const RecordingTwo: () => import("react").JSX.Element;
export declare const Slides: () => import("react").JSX.Element;
export declare const Textbook: () => import("react").JSX.Element;
export declare const ReferenceTextbook: () => import("react").JSX.Element;
export declare const TranscriptOne: () => import("react").JSX.Element;
export declare const TranscriptTwo: () => import("react").JSX.Element;
export declare const SlidesThreeFour: () => import("react").JSX.Element;
export declare const SlidesFiveSix: () => import("react").JSX.Element;
export declare const SlidesSevenEight: () => import("react").JSX.Element;
