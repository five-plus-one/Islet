declare function ClassicalProbLabBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ClassicalProbLabBase>;
export default _default;
