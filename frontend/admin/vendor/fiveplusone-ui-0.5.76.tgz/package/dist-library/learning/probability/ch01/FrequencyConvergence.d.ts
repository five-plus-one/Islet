declare function FrequencyConvergenceBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof FrequencyConvergenceBase>;
export default _default;
