declare function SampleSpaceBuilderBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof SampleSpaceBuilderBase>;
export default _default;
