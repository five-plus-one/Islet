declare function VennPlaygroundBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof VennPlaygroundBase>;
export default _default;
