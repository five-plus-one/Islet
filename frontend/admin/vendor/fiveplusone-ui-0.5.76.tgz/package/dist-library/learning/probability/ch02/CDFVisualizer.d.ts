declare function CDFVisualizerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof CDFVisualizerBase>;
export default _default;
