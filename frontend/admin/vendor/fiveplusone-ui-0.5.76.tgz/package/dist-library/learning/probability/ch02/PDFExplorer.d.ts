declare function PDFExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof PDFExplorerBase>;
export default _default;
