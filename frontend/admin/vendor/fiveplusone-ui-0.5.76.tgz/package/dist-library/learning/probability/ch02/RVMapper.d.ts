declare function RVMapperBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof RVMapperBase>;
export default _default;
