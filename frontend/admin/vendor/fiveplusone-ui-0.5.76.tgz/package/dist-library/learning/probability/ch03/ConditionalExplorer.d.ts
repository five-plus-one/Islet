declare function ConditionalExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ConditionalExplorerBase>;
export default _default;
