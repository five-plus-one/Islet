declare function IndependenceCheckerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof IndependenceCheckerBase>;
export default _default;
