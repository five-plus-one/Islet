declare function JointDistExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof JointDistExplorerBase>;
export default _default;
