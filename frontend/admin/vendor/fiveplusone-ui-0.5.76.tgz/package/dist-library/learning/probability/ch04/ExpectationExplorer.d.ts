declare function ExpectationExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ExpectationExplorerBase>;
export default _default;
