declare function CLTSimulatorBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof CLTSimulatorBase>;
export default _default;
