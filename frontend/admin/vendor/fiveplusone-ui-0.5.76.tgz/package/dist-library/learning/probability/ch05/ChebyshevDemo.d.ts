declare function ChebyshevDemoBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ChebyshevDemoBase>;
export default _default;
