declare function NormalSamplingDemoBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof NormalSamplingDemoBase>;
export default _default;
