declare function QuantileExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof QuantileExplorerBase>;
export default _default;
