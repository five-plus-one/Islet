declare function SamplingDistExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof SamplingDistExplorerBase>;
export default _default;
