declare function ConfidenceIntervalExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof ConfidenceIntervalExplorerBase>;
export default _default;
