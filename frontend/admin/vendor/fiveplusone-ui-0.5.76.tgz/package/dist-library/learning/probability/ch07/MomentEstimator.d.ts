declare function MomentEstimatorBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof MomentEstimatorBase>;
export default _default;
