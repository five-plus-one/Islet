declare function MeanTestExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof MeanTestExplorerBase>;
export default _default;
