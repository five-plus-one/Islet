declare function VarianceTestExplorerBase(): import("react").JSX.Element;
declare const _default: import("react").MemoExoticComponent<typeof VarianceTestExplorerBase>;
export default _default;
