/** CSS variables remain usable when a chart requests an alpha variant. */
export declare function learningAlpha(color: string, hex: string): string;
