import React from "react";
export interface DistributionChartProps {
    type: "normal" | "binomial" | "poisson";
    params?: {
        /** normal: 均值，默认 0 */
        mu?: number;
        /** normal: 标准差，默认 1 */
        sigma?: number;
        /** binomial: 试验次数，默认 10 */
        n?: number;
        /** binomial: 成功概率，默认 0.5 */
        p?: number;
        /** poisson: 参数，默认 3 */
        lambda?: number;
    };
    /** 默认 false */
    interactive?: boolean;
}
export declare const DistributionChart: React.FC<DistributionChartProps>;
