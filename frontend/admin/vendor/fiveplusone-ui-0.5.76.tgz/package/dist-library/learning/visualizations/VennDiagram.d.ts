import React from "react";
/** 可被高亮的维恩图区域：a=仅A，b=仅B，ab=交集，out=两圆之外 */
export type VennRegion = "a" | "b" | "ab" | "out";
/** 高亮模式预设（映射到一组区域） */
export type VennHighlightMode = "union" | "intersection" | "difference" | "complement" | "symmetric-difference";
export interface VennDiagramProps {
    /** P(A)，默认 0.6 */
    a?: number;
    /** P(B)，默认 0.5 */
    b?: number;
    /** P(A∩B)，默认 0.2 */
    ab?: number;
    /** 默认 false（静态模式） */
    interactive?: boolean;
    /** 当交互模式下数值变化时回调 */
    onChange?: (a: number, b: number, ab: number) => void;
    /** 高亮模式预设；与 highlightRegions 二选一 */
    highlightMode?: VennHighlightMode;
    /** 显式指定高亮区域（优先于 highlightMode） */
    highlightRegions?: VennRegion[];
}
/**
 * VennDiagram 原语：纯 SVG 渲染两圆相交的维恩图。
 * - 静态模式：展示 P(A)、P(B)、P(A∩B)、P(A∪B) 等数值
 * - 交互模式：三个滑块调参，自动维持概率约束，圆距离随 P(AB) 变化
 */
export declare const VennDiagram: React.FC<VennDiagramProps>;
