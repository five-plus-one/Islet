const crypto = require('node:crypto');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

// The local frame and remote identity view have separate sessions and bridges.
function createOAuthLoginWindow({ BrowserWindow, WebContentsView, session, ipcMain, shell, dialog, screen, parent, issuer, authorizeUrl, icon, onCancel, theme = 'light', themePreference = theme, nativeTheme, title = '账号登录', product = 'brand' }) {
  const authorize = new URL(authorizeUrl), origin = new URL(issuer).origin;
  if (authorize.protocol !== 'https:' || authorize.origin !== origin || authorize.username || authorize.password) throw Error('登录地址无效。');
  const callback = new URL(authorize.searchParams.get('redirect_uri')), state = authorize.searchParams.get('state');
  if (callback.protocol !== 'http:' || callback.hostname !== '127.0.0.1' || !callback.port || callback.username || callback.password || callback.search || callback.hash || !state) throw Error('登录回调无效。');
  const id = crypto.randomUUID();
  const partition = 'fiveplusone-auth-' + id, channel = 'fiveplusone:auth-window:' + id;
  const local = pathToFileURL(path.join(__dirname, 'oauth-window-shell.html'));
  local.search = new URLSearchParams({ theme: theme === 'dark' ? 'dark' : 'light', title, product: ['brand','kezhan','marker','onepass'].includes(product) ? product : 'brand' }).toString();
  const isolated = session.fromPartition(partition, { cache: false });
  const chromeSession = session.fromPartition(partition + '-frame', { cache: false });
  for (const ses of [isolated, chromeSession]) {
    ses.setPermissionRequestHandler((_contents, _permission, answer) => answer(false));
    ses.setPermissionCheckHandler(() => false);
  }
  const area = screen.getDisplayMatching(parent.getBounds()).workArea;
  const popup = new BrowserWindow({
    parent, modal: true, width: Math.min(520, area.width - 32), height: Math.min(760, area.height - 32),
    minWidth: Math.min(420, area.width - 32), minHeight: Math.min(520, area.height - 32),
    frame: false, show: false, title, icon, minimizable: false, maximizable: false, fullscreenable: false,
    webPreferences: { session: chromeSession, preload: path.join(__dirname, 'oauth-window-preload.cjs'), additionalArguments: ['--fp-auth-shell=' + encodeURIComponent(local.href), '--fp-auth-channel=' + channel], contextIsolation: true, nodeIntegration: false, sandbox: true, webviewTag: false },
  });
  const view = new WebContentsView({ webPreferences: { session: isolated, contextIsolation: true, nodeIntegration: false, sandbox: true, webviewTag: false } });
  const contents = view.webContents;
  popup.contentView.addChildView(view);
  let disposed = false, browser = false, offering = false, currentTheme = theme;
  const backdropId = 'fp-auth-backdrop-' + id;
  const removeBackdrop = () => {
    if (!parent.webContents.isDestroyed()) void parent.webContents.executeJavaScript(`document.getElementById(${JSON.stringify(backdropId)})?.remove()`).catch(() => {});
  };
  const showBackdrop = () => {
    if (disposed || parent.webContents.isDestroyed()) return;
    void parent.webContents.executeJavaScript(`(() => {
      if (document.getElementById(${JSON.stringify(backdropId)})) return;
      const overlay = document.createElement('div');
      overlay.id = ${JSON.stringify(backdropId)};
      overlay.setAttribute('aria-hidden', 'true');
      overlay.setAttribute('data-fp-auth-backdrop', '');
      overlay.style.cssText = 'position:fixed;inset:0;z-index:2147483647;backdrop-filter:blur(5px);-webkit-backdrop-filter:blur(5px);background:var(--fp-auth-backdrop,rgba(0,0,0,.16));pointer-events:auto;-webkit-app-region:no-drag;';
      document.documentElement.appendChild(overlay);
    })()`).then(() => { if (disposed) removeBackdrop(); }).catch(() => {});
  };
  parent.webContents.on('dom-ready', showBackdrop);
  showBackdrop();
  const layout = () => {
    if (disposed) return;
    const { width, height } = popup.getContentBounds();
    view.setBounds({ x: 1, y: 55, width: Math.max(0, width - 2), height: Math.max(0, height - 56) });
  };
  const focus = () => {
    if (disposed || popup.isDestroyed()) return;
    if (parent.isMinimized()) parent.restore();
    parent.show(); popup.show(); popup.focus();
    if (!browser) contents.focus();
  };
  const dispose = () => {
    if (disposed) return;
    disposed = true;
    parent.removeListener('closed', cancel);
    parent.webContents.removeListener('dom-ready', showBackdrop);
    removeBackdrop();
    ipcMain.removeListener(channel, action);
    isolated.removeListener('will-download', denyDownload);
    if (!contents.isDestroyed()) contents.close();
    if (!popup.isDestroyed()) popup.destroy();
    for (const ses of [isolated, chromeSession]) {
      void ses.clearStorageData().catch(() => {});
      void ses.closeAllConnections().catch(() => {});
    }
  };
  const cancel = () => { if (!disposed) { dispose(); onCancel(); } };
  const useBrowser = async () => {
    if (disposed) return;
    try {
      await shell.openExternal(authorize.href);
      if (disposed) return;
      if (!browser) {
        browser = true; contents.stop(); popup.contentView.removeChildView(view);
        popup.webContents.send(channel + ':browser', true);
      }
    } catch {
      if (!disposed) await dialog.showMessageBox(popup, { type: 'error', title, message: '暂时无法打开浏览器，请重试。', buttons: ['知道了'] }).catch(() => {});
    }
  };
  const offerBrowser = async message => {
    if (disposed || browser || offering) return;
    offering = true;
    try {
      const { response } = await dialog.showMessageBox(popup, { type: 'info', title, message, buttons: ['在浏览器中继续', '返回登录'], defaultId: 0, cancelId: 1 });
      if (response === 0 && !disposed) await useBrowser();
    } catch { /* The host may close while the recovery prompt is open. */ }
    finally { offering = false; }
  };
  const allowed = raw => {
    try {
      const url = new URL(raw);
      if (url.username || url.password) return false;
      return (url.protocol === 'https:' && url.origin === origin) ||
        (url.origin === callback.origin && url.pathname === callback.pathname && !url.hash && url.searchParams.get('state') === state);
    } catch { return false; }
  };
  const navigate = (event, raw) => {
    if (allowed(raw)) return;
    event.preventDefault();
    if (/^https:\/\//i.test(raw)) void offerBrowser('此登录方式需要使用浏览器。完成登录后会自动返回应用。');
  };
  const denyDownload = event => event.preventDefault();
  const action = (event, command) => {
    if (disposed || event.sender !== popup.webContents || event.senderFrame !== popup.webContents.mainFrame || event.senderFrame.url !== local.href) return;
    if (command === 'close') cancel();
    if (command === 'browser') void useBrowser();
    if (command === 'reload' && !browser) contents.reload();
  };
  const setTheme = (value, preference = themePreference) => {
    if (disposed) return;
    const next = value === 'dark' ? 'dark' : 'light';
    currentTheme = next;
    themePreference = ['dark', 'light', 'system'].includes(preference) ? preference : next;
    if (nativeTheme) nativeTheme.themeSource = themePreference;
    popup.setBackgroundColor(next === 'dark' ? '#121315' : '#faf9f7');
    popup.webContents.send(channel + ':theme', next);
  };
  ipcMain.on(channel, action);
  isolated.on('will-download', denyDownload);
  contents.on('will-navigate', navigate);
  contents.on('will-redirect', navigate);
  contents.on('will-attach-webview', event => event.preventDefault());
  contents.setWindowOpenHandler(({ url }) => {
    if (allowed(url)) void contents.loadURL(url).catch(() => {});
    else if (/^https:\/\//i.test(url)) void shell.openExternal(url).catch(() => {});
    return { action: 'deny' };
  });
  for (const wc of [popup.webContents, contents]) {
    wc.on('before-input-event', (event, input) => {
      if (input.type === 'keyDown' && input.key === 'Escape') { event.preventDefault(); cancel(); }
    });
  }
  popup.webContents.on('will-navigate', event => event.preventDefault());
  popup.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  contents.on('did-fail-load', (_event, code, _description, _url, mainFrame) => {
    if (mainFrame && code !== -3) void offerBrowser('登录页面暂时无法加载，可以在浏览器中继续。');
  });
  contents.on('render-process-gone', () => { void offerBrowser('登录页面已关闭，可以在浏览器中继续。'); });
  popup.on('page-title-updated', event => event.preventDefault());
  popup.on('resize', layout);
  popup.on('close', event => { if (!disposed) { event.preventDefault(); cancel(); } });
  parent.once('closed', cancel);
  popup.setMenu(null);
  popup.once('ready-to-show', focus);
  popup.webContents.once('did-finish-load', () => { setTheme(currentTheme); popup.webContents.send(channel + ':browser', browser); });
  layout(); setTheme(theme); focus();
  void popup.loadURL(local.href).catch(() => cancel());
  void contents.loadURL(authorize.href).catch(() => {});
  return { focus, dispose, setTheme };
}
module.exports = { createOAuthLoginWindow };
