import type { Root } from "hast";
/** HTML tables preserve merged cells; their text needs math recognition after HTML parsing. */
export default function rehypeTableMath(): (tree: Root) => void;
