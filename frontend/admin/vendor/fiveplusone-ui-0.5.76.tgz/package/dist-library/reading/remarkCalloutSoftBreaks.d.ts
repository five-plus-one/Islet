export default function remarkCalloutSoftBreaks(): (tree: unknown) => void;
