/** Shared brand identity and independently configurable product palettes. */
export declare const brandColor = "#FD8B07";
export declare const productThemes: {
    readonly brand: {
        readonly name: "五加一";
        readonly primary: "#FD8B07";
        readonly onPrimary: "#542D0C";
        readonly action: "#B85E00";
        readonly onAction: "#FFFFFF";
        readonly darkAction: "#FFB65C";
        readonly darkOnAction: "#492600";
        readonly soft: "#FFF2E2";
        readonly ink: "#914600";
        readonly darkSoft: "#422D18";
        readonly darkInk: "#FFC98F";
    };
    readonly kezhan: {
        readonly name: "课栈笔记";
        readonly primary: "#1A73E8";
        readonly onPrimary: "#FFFFFF";
        readonly soft: "#E8F0FE";
        readonly ink: "#185ABC";
        readonly darkPrimary: "#A8C7FA";
        readonly darkSoft: "#263751";
        readonly darkInk: "#C2D7FA";
        readonly darkOnPrimary: "#142D50";
    };
    readonly marker: {
        readonly name: "AI 批改助手";
        readonly primary: "#13795B";
        readonly onPrimary: "#FFFFFF";
        readonly soft: "#E6F4ED";
        readonly ink: "#0C6248";
        readonly darkPrimary: "#8DD8B6";
        readonly darkSoft: "#193C30";
        readonly darkInk: "#B1E8CE";
        readonly darkOnPrimary: "#103C2B";
    };
    readonly onepass: {
        readonly name: "OnePass";
        readonly primary: "#7252C7";
        readonly onPrimary: "#FFFFFF";
        readonly soft: "#F0EAFC";
        readonly ink: "#5D3DA8";
        readonly darkPrimary: "#CDB8FF";
        readonly darkSoft: "#35294B";
        readonly darkInk: "#DFD0FF";
        readonly darkOnPrimary: "#342052";
    };
};
export type ProductTheme = keyof typeof productThemes;
