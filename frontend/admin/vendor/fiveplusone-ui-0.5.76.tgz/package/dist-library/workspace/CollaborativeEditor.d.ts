import type { JSONContent } from '@tiptap/core';
import { type MarkdownEditorProps } from '../editor/MarkdownEditor';
import { HocuspocusProvider } from '@hocuspocus/provider';
import * as Y from 'yjs';
export { Y };
export type CollaborationUser = {
    id: string;
    name: string;
    color: string;
};
export declare function useCollaboration({ url, room, token, user, enabled, }: {
    url: string;
    room: string;
    token: string | (() => Promise<string>);
    user: CollaborationUser;
    enabled?: boolean;
}): {
    session: {
        document: Y.Doc;
        provider: HocuspocusProvider;
    } | null;
    status: string;
};
export type CollaborativeEditorProps = Omit<MarkdownEditorProps, 'onChange' | 'status'> & {
    user: CollaborationUser;
    status?: string;
    onChange?: (json: JSONContent) => void;
    onMarkdownChange?: (markdown: string) => void;
};
export declare function CollaborativeEditor({ user, status, onChange, onMarkdownChange, ...props }: CollaborativeEditorProps): import("react").JSX.Element;
