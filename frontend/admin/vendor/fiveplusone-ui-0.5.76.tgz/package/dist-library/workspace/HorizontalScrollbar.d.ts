export default function HorizontalScrollbar({ value, max, viewport, controls, onChange, }: {
    value: number;
    max: number;
    viewport: number;
    controls: string;
    onChange: (value: number) => void;
}): import("react").JSX.Element;
