import { type ReactNode } from 'react';
export interface WorkspacePanel {
    id: string;
    label: string;
    content: ReactNode;
    defaultSize?: number;
    minSize?: number;
    maxSize?: number;
    collapsible?: boolean;
    collapsedSize?: number;
    onCollapse?: () => void;
    onExpand?: () => void;
}
export interface WorkspaceLayoutHandle {
    getLayout: () => number[];
    setLayout: (sizes: number[]) => void;
    collapse: (id: string) => void;
    expand: (id: string) => void;
    resize: (id: string, size: number) => void;
    isCollapsed: (id: string) => boolean;
}
export interface WorkspaceLayoutProps {
    panels: WorkspacePanel[];
    direction?: 'horizontal' | 'vertical';
    /** A product/account-scoped key; omit to keep the layout in memory. */
    persistenceKey?: string;
    onLayout?: (sizes: number[]) => void;
    className?: string;
}
/** Uses the same resize engine as the KeZhan workspace; nested groups provide split views. */
export declare const WorkspaceLayout: import("react").ForwardRefExoticComponent<WorkspaceLayoutProps & import("react").RefAttributes<WorkspaceLayoutHandle>>;
