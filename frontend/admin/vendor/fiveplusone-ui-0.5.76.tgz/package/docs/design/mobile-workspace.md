# 手机工作区

手机工作区使用五加一语义色与系统字体。主要控件圆角 6px，内容卡片 8px，浮层 12px。标题层级为 26px 页面标题、18px 页头、16px 分区与 15px 列表正文；辅助信息 12px。正文阅读保持 16px / 1.9。主要操作目标至少 44px。

`MobileHeader` 提供返回、标题与附加操作。`MobileSection` 提供分区标题与操作。`MobileActionGrid` 适合拍照、录音与导入等短操作；由调用方提供 disabled 状态。`MobileNotebookGrid` 在手机排列两列，在 600px 以上排列三列；`MobileNotebookCard` 的标题支持自然换行。`MobileCollectionRow` 用于继续阅读与设置入口。`MobileWelcome` 承载品牌、账号操作、错误提示与底部说明。组件的主题读取根元素的 data-theme 和 data-product。

```tsx
import {useState} from 'react';
import {BookOpen} from 'lucide-react';
import {MobileHeader,MobileSection,MobileNotebookGrid,MobileNotebookCard} from '@fiveplusone/ui';
import '@fiveplusone/ui/styles.css';

export function MobileLibraryExample() {
  const [selected,setSelected]=useState('');
  return <div data-product="kezhan">
    <MobileHeader title="我的笔记"/>
    <MobileSection title="笔记本">
      <MobileNotebookGrid>
        <MobileNotebookCard title="课堂笔记" description="3 篇内容" icon={<BookOpen size={24}/>} onClick={()=>setSelected('课堂笔记')}/>
      </MobileNotebookGrid>
    </MobileSection>
    <p role="status">{selected&&`已选择：${selected}`}</p>
  </div>;
}
```

调用方负责账号、真实课程内容、请求和导航。页头与行操作保留可见焦点，按钮支持 Tab、Enter 和 Space。页面在加载期间使用 ContentSkeleton，操作期间由调用方禁用重复提交并说明当前动作。错误保留输入与恢复入口。

验收覆盖 360px、412px、深浅主题、长标题、空数据、筛选层及输入焦点。底部导航由宿主定位并预留安全区域；键盘打开时宿主收起导航。录音或更新提示使用专用状态区域，持续操作期间保留当前输入。


## 录音

MobileRecorder 由调用方控制 idle、recording、paused、saved 四种状态，时长以调用方提供的真实录音服务为准。进入页面不自动开始录音；录制期间显示暂停或继续及结束保存，保存后提供上传和再次录制。busy 状态阻止重复操作，错误、权限、音频回放与后台服务仍由业务调用方管理。录音历史和上传队列通过独立页面进入。
