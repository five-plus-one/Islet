# Media workspace source

Version 0.5.77-media.2 adds MediaWorkspace.tsx and media-workspace.css to the published 0.5.77 baseline. Original entry points and sources are preserved. The module is MIT licensed. Build with scripts/build-media-release.mjs and the baseline archive.
