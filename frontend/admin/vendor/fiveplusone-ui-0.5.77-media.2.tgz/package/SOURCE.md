# Rebuilding the component library

The package includes editable src/lib and src/native sources under MIT. With Node.js 22.18+ installed, extract the package to a separate directory, copy source-lock.json to package-lock.json, run npm ci, then npm run build:library. Generated outputs are written to dist-library.

The library has independent MIT licensing; application licenses are specified by each application. Third-party notices are included in THIRD_PARTY_NOTICES.txt.
