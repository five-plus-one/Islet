import type { AnchorHTMLAttributes, ReactNode } from 'react';
import './app-surfaces.css';
export { Button, Spinner, Badge, Card, Tabs, Accordion } from './PageControls';
export { ThemeToggle } from './ThemeToggle';
export { AccountMenu, type AccountMenuItem } from './AccountMenu';
export { Tooltip, TooltipProvider } from './Tooltip';
export { ChoiceCards, type ChoiceCardOption } from './ChoiceCards';
export { ApplicationAccess, type ApplicationAccessProps } from './ApplicationAccess';
export { WindowChrome, type WindowChromeProps } from './WindowChrome';
export { AuthenticationWindow, type AuthenticationWindowProps } from './AuthenticationWindow';
export declare function ButtonLink({ variant, size, className, ...props }: AnchorHTMLAttributes<HTMLAnchorElement> & {
    variant?: 'primary' | 'secondary' | 'ghost';
    size?: 'sm' | 'md' | 'lg';
}): import("react").JSX.Element;
export interface AppEntryLayoutProps {
    brand: ReactNode;
    eyebrow?: string;
    title: ReactNode;
    description: string;
    benefits?: {
        icon: ReactNode;
        label: string;
    }[];
    children: ReactNode;
    actions?: ReactNode;
    footer?: ReactNode;
}
export declare function AppEntryLayout({ brand, eyebrow, title, description, benefits, children, actions, footer }: AppEntryLayoutProps): import("react").JSX.Element;
export interface StatusPageProps {
    brand?: ReactNode;
    title: string;
    description: string;
    tone?: 'success' | 'error' | 'loading' | 'neutral';
    children?: ReactNode;
    actions?: ReactNode;
    headerActions?: ReactNode;
    footer?: ReactNode;
}
export declare function StatusPage({ brand, title, description, tone, children, actions, headerActions, footer }: StatusPageProps): import("react").JSX.Element;
export interface ProductLandingProps {
    brand: ReactNode;
    navigation?: ReactNode;
    headerActions?: ReactNode;
    eyebrow?: string;
    title: ReactNode;
    description: string;
    actions: ReactNode;
    meta?: ReactNode;
    preview: ReactNode;
    children: ReactNode;
    footer: ReactNode;
}
export declare function ProductLanding({ brand, navigation, headerActions, eyebrow, title, description, actions, meta, preview, children, footer }: ProductLandingProps): import("react").JSX.Element;
export declare function ProductSection({ id, eyebrow, title, description, children }: {
    id?: string;
    eyebrow?: string;
    title: string;
    description?: string;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function ProductFeatures({ items }: {
    items: {
        icon: ReactNode;
        title: string;
        description: string;
    }[];
}): import("react").JSX.Element;
export declare function WorkspaceSkeleton({ brand, label, actions }: {
    brand?: ReactNode;
    label?: string;
    actions?: ReactNode;
}): import("react").JSX.Element;
export interface UpdatePanelProps {
    phase: 'checking' | 'preparing' | 'available' | 'downloading' | 'verifying' | 'installing' | 'ready' | 'current' | 'error';
    title: string;
    description: string;
    currentVersion?: string;
    version?: string;
    notes?: string;
    progress?: number;
    required?: boolean;
    compact?: boolean;
    actions: ReactNode;
}
export declare function UpdatePanel({ phase, title, description, currentVersion, version, notes, progress, required, compact, actions }: UpdatePanelProps): import("react").JSX.Element;
export * from './InstallerPanel';
export * from './FeatureCardStack';
export * from './DocumentationLayout';
