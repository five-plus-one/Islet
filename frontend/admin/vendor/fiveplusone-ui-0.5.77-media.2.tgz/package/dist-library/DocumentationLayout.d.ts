import { type ReactNode } from 'react';
import './documentation.css';
export interface DocumentationLink {
    label: string;
    href: string;
}
export interface DocumentationGroup {
    label: string;
    links: DocumentationLink[];
}
export interface DocumentationLayoutProps {
    brand: ReactNode;
    navigation?: ReactNode;
    actions?: ReactNode;
    groups: DocumentationGroup[];
    currentPath: string;
    outline?: DocumentationLink[];
    children: ReactNode;
    footer?: ReactNode;
    wide?: boolean;
}
export declare function DocumentationLayout({ brand, navigation, actions, groups, currentPath, outline, children, footer, wide }: DocumentationLayoutProps): import("react").JSX.Element;
export declare function DocumentationCards({ items, label }: {
    items: (DocumentationLink & {
        description?: string;
    })[];
    label?: string;
}): import("react").JSX.Element;
