import { type ReactElement, type ReactNode } from "react";
export interface MediaDropzoneProps {
    onFiles: (files: File[]) => void;
    limit: string;
    compact?: boolean;
}
export declare function MediaDropzone({ onFiles, limit, compact, }: MediaDropzoneProps): ReactElement;
export interface MediaUploadResult {
    id: string;
    name: string;
    preview?: string;
    size: string;
    status: "waiting" | "uploading" | "done" | "error";
    progress: number;
    error?: string;
    link?: string;
    canRetry?: boolean;
}
export interface MediaUploadResultsProps {
    items: MediaUploadResult[];
    formatControl: ReactNode;
    onCopy: (id: string) => void;
    onCopyAll: () => void;
    onRemove: (id: string) => void;
    onRetry: (id: string) => void;
    onClear: () => void;
    onOpen?: (id: string) => void;
}
export declare function MediaUploadResults({ items, formatControl, onCopy, onCopyAll, onRemove, onRetry, onClear, onOpen, }: MediaUploadResultsProps): ReactElement;
export interface MediaAlbum {
    id: string;
    name: string;
    description?: string;
    count: number;
    cover?: string;
}
export interface MediaAlbumGridProps {
    albums: MediaAlbum[];
    onOpen: (id: string) => void;
    onEdit: (id: string) => void;
    onDelete: (id: string) => void;
}
export declare function MediaAlbumGrid({ albums, onOpen, onEdit, onDelete, }: MediaAlbumGridProps): ReactElement;
export interface ConnectionPanelProps {
    title: string;
    onClose: () => void;
    children: ReactNode;
    footer?: ReactNode;
}
export interface MediaGalleryItem {
    id: string;
    name: string;
    preview: string;
    description: string;
    blocked?: boolean;
    status?: string;
}
export interface MediaGalleryProps {
    items: MediaGalleryItem[];
    selected: string[];
    onSelectionChange: (ids: string[]) => void;
    onOpen: (id: string) => void;
    onCopy?: (id: string) => void;
    empty: ReactNode;
}
export declare function MediaGallery({ items, selected, onSelectionChange, onOpen, onCopy, empty, }: MediaGalleryProps): ReactElement;
export declare function ConnectionPanel({ title, onClose, children, footer, }: ConnectionPanelProps): ReactElement;
export interface ConnectionValueProps {
    label: string;
    value: string;
    onCopy?: () => void;
    hint?: string;
}
export declare function ConnectionValue({ label, value, onCopy, hint, }: ConnectionValueProps): ReactElement;
export interface MediaWorkspaceFrameProps {
    sidebar: ReactNode;
    header: ReactNode;
    children: ReactNode;
}
export declare function MediaWorkspaceFrame({ sidebar, header, children, }: MediaWorkspaceFrameProps): ReactElement;
