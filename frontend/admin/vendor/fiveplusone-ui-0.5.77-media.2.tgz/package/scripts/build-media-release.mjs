import { build } from "esbuild";
import ts from "typescript";
import { cp, mkdir, readFile, writeFile } from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { resolve, join } from "node:path";

const [baseline, output] = process.argv.slice(2);
if (!baseline || !output)
  throw new Error(
    "Usage: node scripts/build-media-release.mjs baseline.tgz output-directory",
  );
const dest = resolve(output);
await mkdir(dest, { recursive: true });
execFileSync("tar", ["-xzf", resolve(baseline), "-C", dest]);
const pkgDir = join(dest, "package");
const pkg = JSON.parse(await readFile(join(pkgDir, "package.json"), "utf8"));
if (pkg.version !== "0.5.77")
  throw new Error("Expected the 0.5.77 release baseline");
pkg.version = "0.5.77-media.2";
pkg.exports["./media-workspace"] = {
  types: "./dist-library/MediaWorkspace.d.ts",
  import: "./dist-library/media-workspace.js",
};
pkg.exports["./media-workspace.css"] = "./dist-library/media-workspace.css";
pkg.files.push(
  "scripts/build-media-release.mjs",
  "docs/design/media-workspace.md",
  "tests/media-workspace.test.tsx",
  "MEDIA_SOURCE.md",
);
await writeFile(
  join(pkgDir, "package.json"),
  JSON.stringify(pkg, null, 2) + "\n",
);
await mkdir(join(pkgDir, "docs/design"), { recursive: true });
await mkdir(join(pkgDir, "tests"), { recursive: true });
for (const file of [
  "src/lib/MediaWorkspace.tsx",
  "src/lib/media-workspace.css",
  "scripts/build-media-release.mjs",
  "docs/design/media-workspace.md",
  "tests/media-workspace.test.tsx",
])
  await cp(file, join(pkgDir, file));
const lock = JSON.parse(
  await readFile(join(pkgDir, "source-lock.json"), "utf8"),
);
lock.version = pkg.version;
lock.packages[""].version = pkg.version;
await writeFile(
  join(pkgDir, "source-lock.json"),
  JSON.stringify(lock, null, 2) + "\n",
);
await cp(
  "src/lib/media-workspace.css",
  join(pkgDir, "dist-library/media-workspace.css"),
);
await build({
  entryPoints: ["src/lib/MediaWorkspace.tsx"],
  outfile: join(pkgDir, "dist-library/media-workspace.js"),
  bundle: true,
  format: "esm",
  jsx: "automatic",
  external: [
    "@fiveplusone/ui",
    "react",
    "react/jsx-runtime",
    "react-dom",
    "lucide-react",
  ],
  minify: true,
});
const source = await readFile("src/lib/MediaWorkspace.tsx", "utf8");
const decl = ts.transpileDeclaration(source, {
  fileName: "MediaWorkspace.tsx",
  compilerOptions: { jsx: ts.JsxEmit.ReactJSX, isolatedDeclarations: true },
});
if (decl.diagnostics?.length)
  throw new Error(
    ts.formatDiagnosticsWithColorAndContext(decl.diagnostics, {
      getCurrentDirectory: () => process.cwd(),
      getCanonicalFileName: (x) => x,
      getNewLine: () => "\n",
    }),
  );
await writeFile(
  join(pkgDir, "dist-library/MediaWorkspace.d.ts"),
  decl.outputText,
);
await writeFile(
  join(pkgDir, "MEDIA_SOURCE.md"),
  "# Media workspace source\n\nVersion 0.5.77-media.2 adds MediaWorkspace.tsx and media-workspace.css to the published 0.5.77 baseline. Original entry points and sources are preserved. The module is MIT licensed. Build with scripts/build-media-release.mjs and the baseline archive.\n",
);
if (process.platform === "win32") {
  execFileSync(
    process.env.ComSpec || "cmd.exe",
    ["/d", "/s", "/c", "npm pack --pack-destination .."],
    { cwd: pkgDir, stdio: "inherit" },
  );
} else {
  execFileSync("npm", ["pack", "--pack-destination", ".."], {
    cwd: pkgDir,
    stdio: "inherit",
  });
}
