import { build } from 'esbuild';
await build({ entryPoints: ['src/lib/window-titlebar.ts'], outfile: 'dist-library/window-titlebar.js', bundle: true, format: 'esm', minify: true });

await build({entryPoints:['src/lib/workspaceShortcuts.ts'],outfile:'dist-library/workspace-shortcuts.cjs',bundle:true,format:'cjs',platform:'node',minify:true});
