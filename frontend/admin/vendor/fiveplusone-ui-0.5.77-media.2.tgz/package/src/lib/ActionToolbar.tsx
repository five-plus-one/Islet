import { useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { MoreHorizontal } from 'lucide-react';
import { Popup } from './Popup';
export interface ToolbarAction { id: string; label: string; icon: ReactNode; onSelect: () => void; disabled?: boolean; danger?: boolean }
export function visibleActionCount(widths: number[], available: number, more: number, gap: number) {
  if (widths.reduce((n,w)=>n+w,0) + Math.max(0,widths.length-1)*gap <= available) return widths.length;
  let used = more, count = 0;
  for (const width of widths) { if (used + gap + width > available) break; used += gap + width; count++; }
  return count;
}
/** Expose actions as space permits and retain their order in the overflow menu. */
export function ActionToolbar({ actions, label = '操作', moreLabel = '更多操作', className = '' }: { actions: ToolbarAction[]; label?: string; moreLabel?: string; className?: string }) {
  const root = useRef<HTMLDivElement>(null), measure = useRef<HTMLDivElement>(null);
  const [count, setCount] = useState(0);
  const signature = actions.map(x=>x.id).join('\0');
  useLayoutEffect(() => {
    const host = root.current, row = measure.current;
    if (!host || !row) return;
    const update = () => {
      const style = getComputedStyle(host), gap = parseFloat(style.columnGap) || 4;
      const buttons = Array.from(row.querySelectorAll<HTMLElement>('[data-action-width]'));
      const widths = buttons.map(x=>x.getBoundingClientRect().width || 32);
      const more = row.querySelector<HTMLElement>('[data-more-width]')?.getBoundingClientRect().width || 32;
      setCount(visibleActionCount(widths, host.clientWidth - (parseFloat(style.paddingLeft)||0) - (parseFloat(style.paddingRight)||0), more, gap));
    };
    update();
    const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(update);
    observer?.observe(host); observer?.observe(row);
    document.fonts?.ready.then(update);
    return () => observer?.disconnect();
  }, [signature]);
  const button = (a: ToolbarAction, measuring = false) => <button key={a.id} type="button" data-action-width={measuring ? '' : undefined} data-fp-tooltip={a.label} aria-label={a.label} disabled={a.disabled} data-danger={a.danger || undefined} onClick={measuring ? undefined : a.onSelect}>{a.icon}</button>;
  return <div ref={root} className={`fp-action-toolbar ${className}`} role="toolbar" aria-label={label} onKeyDown={event=>{
    if (!['ArrowLeft','ArrowRight','Home','End'].includes(event.key)) return;
    const buttons=Array.from(root.current?.querySelectorAll<HTMLButtonElement>(':scope > button:not(:disabled), :scope > .fp-dropdown > button:not(:disabled)') || []);
    const index=buttons.indexOf(document.activeElement as HTMLButtonElement); if(index<0)return;
    event.preventDefault(); buttons[event.key==='Home'?0:event.key==='End'?buttons.length-1:(index+(event.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length]?.focus();
  }}>
    {actions.slice(0,count).map(a=>button(a))}
    {count<actions.length && <Popup label={moreLabel} icon={<MoreHorizontal size={18}/>} menu density="compact">{close=><div className="fp-action-menu">{actions.slice(count).map(a=><button key={a.id} role="menuitem" type="button" disabled={a.disabled} data-danger={a.danger || undefined} onClick={()=>{close();a.onSelect();}}>{a.icon}<span>{a.label}</span></button>)}</div>}</Popup>}
    <div ref={measure} className="fp-action-measure" aria-hidden="true" inert>{actions.map(a=>button(a,true))}<button type="button" data-more-width><MoreHorizontal size={18}/></button></div>
  </div>;
}
