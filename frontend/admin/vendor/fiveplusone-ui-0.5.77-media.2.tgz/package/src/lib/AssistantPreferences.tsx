import { useEffect, useState, type ReactNode } from 'react';
import { WorkspaceField, WorkspaceSection, WorkspaceToggle, SettingsTabs } from './WorkspaceForms';

export interface AssistantPreferenceValues {
  selectedModelId: string;
  recordModelId: string;
  floatingChatModelId: string;
  defaultImageModelId: string | null;
  imageModeTextModel: string;
  imageModeTextModelFallback: string;
  defaultThinking: boolean;
  defaultThinkingEffort: string;
  defaultSearch: boolean;
  disabledTools: string[];
  globalContext: string;
}
export interface AssistantPreferencesProps {
  value: AssistantPreferenceValues;
  onChange: <K extends keyof AssistantPreferenceValues>(key: K, value: AssistantPreferenceValues[K]) => void;
  models: { id: string; label: string; type?: string }[];
  tools: { name: string; label: string; desc: string }[];
  syncStatus: string;
  providers?: ReactNode;
  initialTab?: 'preferences'|'models'|'capabilities';
  children?: ReactNode;
}
/** Account-scoped assistant preferences. Persistence and model availability belong to the host. */
export function AssistantPreferences({ value, onChange, models, tools, syncStatus, providers, initialTab='preferences', children }: AssistantPreferencesProps) {
  const [tab,setTab] = useState<string>(initialTab);
  useEffect(()=>setTab(initialTab),[initialTab]);
  const textModels = models.filter(model => model.type !== 'image').map(model => ({ value: model.id, label: model.label }));
  const imageModels = models.filter(model => model.type === 'image').map(model => ({ value: model.id, label: model.label }));
  return <div className="fp-assistant-preferences">
    <p role="status" aria-live="polite">{syncStatus}</p>
    <SettingsTabs label="AI 设置分类" value={tab} onChange={setTab} density="compact" items={[{id:'preferences',label:'常用偏好'},{id:'models',label:'模型与供应商'},{id:'capabilities',label:'能力与备份'}]}/>
    {tab === 'preferences' && <div className="fp-assistant-page" role="tabpanel" aria-label="常用偏好">
    <WorkspaceSection title="对话偏好">
      <WorkspaceField label="默认对话模型" value={value.selectedModelId} options={textModels} onChange={next => onChange('selectedModelId', next)}/>
      <WorkspaceToggle label="深度思考" description="新对话默认开启深度思考。" checked={value.defaultThinking} onChange={next => onChange('defaultThinking', next)}/>
      <WorkspaceField label="默认思考力度" value={value.defaultThinkingEffort} options={[{value:'low',label:'轻量'},{value:'medium',label:'标准'},{value:'high',label:'深入'},{value:'max',label:'充分'}]} onChange={next => onChange('defaultThinkingEffort', next)}/>
      <WorkspaceToggle label="联网搜索" description="新对话默认启用联网搜索。" checked={value.defaultSearch} onChange={next => onChange('defaultSearch', next)}/>
    </WorkspaceSection>
    <WorkspaceSection title="回答偏好" description="告诉 AI 你的学习背景、称呼和回答习惯。">
      <WorkspaceField label="希望 AI 记住的偏好" value={value.globalContext} multiline onChange={next => onChange('globalContext', next)}/>
    </WorkspaceSection>
    </div>}
    {tab === 'models' && <div className="fp-assistant-page" role="tabpanel" aria-label="模型与供应商">{providers}
    <WorkspaceSection title="摘录与划词助手">
      <WorkspaceField label="摘录模型" value={value.recordModelId} options={textModels} onChange={next => onChange('recordModelId', next)}/>
      <WorkspaceField label="划词助手模型" value={value.floatingChatModelId} options={[{value:'',label:'跟随主对话'},...textModels]} onChange={next => onChange('floatingChatModelId', next)}/>
    </WorkspaceSection>
    {imageModels.length > 0 && <WorkspaceSection title="图片生成">
      <WorkspaceField label="默认生图模型" value={value.defaultImageModelId || ''} options={[{value:'',label:'自动选择'},...imageModels]} onChange={next => onChange('defaultImageModelId', next || null)}/>
      <WorkspaceField label="图片描述模型" value={value.imageModeTextModel} options={textModels} onChange={next => onChange('imageModeTextModel', next)}/>
      <WorkspaceField label="备用描述模型" value={value.imageModeTextModelFallback} options={textModels} onChange={next => onChange('imageModeTextModelFallback', next)}/>
    </WorkspaceSection>}
    </div>}
    {tab === 'capabilities' && <div className="fp-assistant-page" role="tabpanel" aria-label="能力与备份">
    <WorkspaceSection title="助手能力">{tools.map(tool => <WorkspaceToggle key={tool.name} label={tool.label} description={tool.desc} checked={!value.disabledTools.includes(tool.name)} onChange={enabled => onChange('disabledTools', enabled ? value.disabledTools.filter(name => name !== tool.name) : [...value.disabledTools, tool.name])}/>)}</WorkspaceSection>
    {children}
    </div>}
  </div>;
}
