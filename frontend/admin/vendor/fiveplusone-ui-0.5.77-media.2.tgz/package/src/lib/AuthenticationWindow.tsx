import type {ReactNode} from 'react';
import {BookOpen,ExternalLink,RefreshCw} from 'lucide-react';
import {WindowChrome} from './WindowChrome';
import {TooltipProvider} from './Tooltip';
import {Button} from './PageControls';

export interface AuthenticationWindowProps {
 mode?:'login'|'task';title?:string; icon?:ReactNode; onClose:()=>void; onBrowser:()=>void; onReload:()=>void; children?:ReactNode; className?:string; browserPending?:boolean;
}
/** Shared frame for a host-controlled, isolated authorization view. */
export function AuthenticationWindow({mode='login',title='账号登录',icon=<BookOpen size={18}/>,onClose,onBrowser,onReload,children,className,browserPending=false}:AuthenticationWindowProps){
 return <TooltipProvider><WindowChrome native title={title} icon={icon} closeLabel={mode==='task'?'关闭授权窗口':'取消登录'} closeShortcut="Esc" onClose={onClose} className={className}
  actions={<><Button variant="ghost" onClick={onBrowser} aria-label={mode==='task'?'在浏览器中继续':'在浏览器中继续登录'} data-fp-tooltip-side="left"><ExternalLink size={16}/>{mode==='task'?'浏览器继续':'浏览器登录'}</Button><Button variant="ghost" disabled={browserPending} aria-label={mode==='task'?'刷新授权信息':'重新加载登录页'} data-fp-tooltip-side="left" style={{width:44,padding:0}} onClick={onReload}><RefreshCw size={16}/></Button></>}>
  {browserPending?<div role="status" style={{padding:24,color:'var(--fp-muted)'}}>请在浏览器中完成登录，完成后会自动返回。</div>:children??<div role="status" style={{padding:24,color:'var(--fp-muted)'}}>{mode==='task'?'正在读取授权信息…':'正在打开登录页…'}</div>}
 </WindowChrome></TooltipProvider>;
}
