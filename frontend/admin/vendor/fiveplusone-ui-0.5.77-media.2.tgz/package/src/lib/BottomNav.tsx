/** BottomNav - 从课栈 layout/MobileBottomNav 提取
 *
 * 移动端底部导航：图标 + 文字，当前项有顶部指示条，
 * 自动避让 iOS 安全区。
 */

import type { ReactNode } from "react";

export interface BottomNavItem {
  id: string;
  label: string;
  icon: ReactNode;
  /** 角标数字 */
  badge?: number;
  href?: string;
  disabled?: boolean;
}

export interface BottomNavProps {
  items: BottomNavItem[];
  value: string;
  onChange: (id: string) => void;
  label?: string;
  className?: string;
  busy?: boolean;
}

export function BottomNav({
  items,
  value,
  onChange,
  label = "主导航",
  className = '',
  busy = false,
}: BottomNavProps) {
  return (
    <nav className={`fp-bottom-nav ${className}`} aria-label={label} aria-busy={busy}>
      {items.map((item) => {
        const active = item.id === value;
        const Tag = item.href ? 'a' : 'button';
        return (
          <Tag
            key={item.id}
            type="button"
            href={item.href}
            aria-disabled={item.disabled || undefined}
            className="fp-bottom-nav-item"
            aria-current={active ? "page" : undefined}
            onClick={event => {
              if (item.href && (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)) return;
              event.preventDefault();
              if (!item.disabled) onChange(item.id);
            }}
          >
            <span className="fp-bottom-nav-indicator" aria-hidden="true" />
            <span className="fp-bottom-nav-icon">
              {item.icon}
              {item.badge ? (
                <span className="fp-bottom-nav-badge">{item.badge}</span>
              ) : null}
            </span>
            <span>{item.label}</span>
          </Tag>
        );
      })}
    </nav>
  );
}
