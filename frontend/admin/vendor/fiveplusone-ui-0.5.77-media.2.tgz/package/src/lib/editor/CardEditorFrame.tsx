import type { ReactNode } from "react";
export interface CardEditorFrameProps { header: ReactNode; children: ReactNode; actions: ReactNode; onFinish?:()=>void; }
export function CardEditorFrame({ header, children, actions, onFinish }: CardEditorFrameProps) {
  return <section className="fp-card-editor-frame" data-nested-editor-boundary="" onKeyDownCapture={event=>{if(onFinish&&!event.nativeEvent.isComposing&&event.key==='Enter'&&(event.ctrlKey||event.metaKey)){event.preventDefault();event.stopPropagation();onFinish();}}}><header>{header}</header><div className="fp-card-editor-content">{children}</div><footer>{actions}</footer></section>;
}
