import { Plugin, TextSelection } from '@tiptap/pm/state';
import type { Editor } from '@tiptap/core';

const pairs: Record<string, string> = { '(': ')', '[': ']', '{': '}', '<': '>', '"': '"', "'": "'", '`': '`' };
const closers = new Set(Object.values(pairs));
type PairEdit = { from: number; to: number; text: string; anchor: number; head: number };

function contextAt(text: string, offset: number, language: string) {
  let quote = '', lineComment = false, blockComment = false;
  const hashComments = /^(python|py|bash|sh|shell|ruby|rb|yaml|yml|r)$/i.test(language);
  for (let i = 0; i < offset; i++) {
    const char = text[i], next = text[i + 1];
    if (lineComment) { if (char === '\n') lineComment = false; continue; }
    if (blockComment) { if (char === '*' && next === '/') { blockComment = false; i++; } continue; }
    if (quote) { if (char === '\\') i++; else if (char === quote) quote = ''; continue; }
    if (char === '/' && next === '/') { lineComment = true; i++; }
    else if (char === '/' && next === '*') { blockComment = true; i++; }
    else if (hashComments && char === '#') lineComment = true;
    else if ('"\'`'.includes(char)) quote = char;
  }
  return { quote, comment: lineComment || blockComment };
}

function angleContext(text: string, offset: number, language: string) {
  const prefix = text.slice(0, offset), line = prefix.slice(prefix.lastIndexOf('\n') + 1);
  if (/^(html|xml|vue|svelte|jsx|tsx)$/i.test(language)) return true;
  if (/^\s*$/.test(line) || /^\s*#\s*include\s*$/.test(line)) return true;
  return /^(c|cpp|c\+\+|java|rust|rs|csharp|cs|typescript|ts)$/i.test(language) && /[\w>:]$/.test(prefix);
}

/** A single typed symbol stays one undoable edit with its selection inside. */
export function codePairEdit(text: string, anchor: number, head: number, input: string, language = ''): PairEdit | null {
  if (input.length !== 1) return null;
  const from = Math.min(anchor, head), to = Math.max(anchor, head);
  const context = contextAt(text, from, language);
  if (context.comment) return null;
  const quote = input === '"' || input === "'" || input === '`';
  const escaped = (text.slice(0, from).match(/\\+$/)?.[0].length ?? 0) % 2 === 1;
  if (escaped) return null;
  if (from === to && text[from] === input && closers.has(input) &&
      (quote ? context.quote === input : !context.quote)) {
    return { from, to, text: '', anchor: from + 1, head: from + 1 };
  }
  const close = pairs[input];
  if (!close || context.quote || (input === '<' && !angleContext(text, from, language))) return null;
  if (quote && input === "'" && /[\p{L}\p{N}_]/u.test(text[from - 1] ?? '')) return null;
  if (from === to && text[to] && !/[\s)\]}>;,.:]/.test(text[to])) return null;
  return { from, to, text: input + text.slice(from, to) + close, anchor: anchor + 1, head: head + 1 };
}

export function deleteCodePair(editor: Editor) {
  if (!editor.isEditable || editor.view.composing) return false;
  const { selection } = editor.state;
  if (!selection.empty || selection.$from.parent.type.name !== 'codeBlock') return false;
  const text = selection.$from.parent.textContent, offset = selection.$from.parentOffset;
  const open = text[offset - 1];
  if (!pairs[open] || pairs[open] !== text[offset]) return false;
  const probe = codePairEdit(text.slice(0, offset - 1) + text.slice(offset + 1), offset - 1, offset - 1, open, String(selection.$from.parent.attrs.language || ''));
  if (!probe) return false;
  return editor.commands.deleteRange({ from: selection.from - 1, to: selection.from + 1 });
}

export function expandCodePair(editor: Editor) {
  if (!editor.isEditable || editor.view.composing) return false;
  const { selection } = editor.state;
  if (!selection.empty || selection.$from.parent.type.name !== 'codeBlock') return false;
  const text = selection.$from.parent.textContent, offset = selection.$from.parentOffset;
  if (!'([{'.includes(text[offset - 1] || ' ') || pairs[text[offset - 1]] !== text[offset]) return false;
  const context = contextAt(text, offset, String(selection.$from.parent.attrs.language || ''));
  if (context.quote || context.comment) return false;
  const prefix = text.slice(0, offset), indent = prefix.slice(prefix.lastIndexOf('\n') + 1).match(/^[\t ]*/)?.[0] || '';
  return editor.commands.command(({ tr }) => {
    tr.insertText('\n' + indent + '    ' + '\n' + indent, selection.from);
    tr.setSelection(TextSelection.create(tr.doc, selection.from + indent.length + 5)).scrollIntoView();
    return true;
  });
}

export function codePairsPlugin(editor: Editor) {
  return new Plugin({ props: { handleTextInput(view, from, to, text) {
    if (!editor.isEditable || view.composing) return false;
    const selection = view.state.selection;
    if (!(selection instanceof TextSelection) || !selection.$from.sameParent(selection.$to) ||
        selection.$from.parent.type.name !== 'codeBlock' || from !== selection.from || to !== selection.to) return false;
    const start = selection.$from.start();
    const edit = codePairEdit(selection.$from.parent.textContent, selection.anchor - start, selection.head - start, text, String(selection.$from.parent.attrs.language || ''));
    if (!edit) return false;
    const tr = view.state.tr;
    if (edit.text) tr.insertText(edit.text, start + edit.from, start + edit.to);
    tr.setSelection(TextSelection.create(tr.doc, start + edit.anchor, start + edit.head)).scrollIntoView();
    view.dispatch(tr);
    return true;
  } } });
}
