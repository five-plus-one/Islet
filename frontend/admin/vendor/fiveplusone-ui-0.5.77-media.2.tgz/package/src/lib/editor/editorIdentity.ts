import UniqueID from '@tiptap/extension-unique-id';
/** Initialize identities even when a collaborative provider synchronized before the editor mounted. */
export const EditorUniqueID=UniqueID.extend({
 onCreate(event){
  this.parent?.(event);
  if(!this.options.updateDocument)return;
  const provider=this.editor.extensionManager.extensions.find(extension=>['collaboration','collaborationCaret'].includes(extension.name)&&extension.options.provider)?.options.provider as {synced?:boolean}|undefined;
  if(!provider?.synced)return;
  const {state,view}=this.editor,{attributeName,generateID,types}=this.options;
  const tr=state.tr;
  state.doc.descendants((node,pos)=>{
   if((types==='all'?!['doc','text'].includes(node.type.name):types.includes(node.type.name))&&node.attrs[attributeName]===null)
    tr.setNodeMarkup(pos,undefined,{...node.attrs,[attributeName]:generateID({node,pos})});
  });
  if(tr.steps.length)view.dispatch(tr.setStoredMarks(state.storedMarks).setMeta('addToHistory',false).setMeta('__uniqueIDTransaction',true));
 },
});
