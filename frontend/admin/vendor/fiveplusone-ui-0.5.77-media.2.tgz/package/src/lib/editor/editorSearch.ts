import { editorCommandFrequencies } from './commandUsage';
import { pinyin } from 'pinyin-pro';
import { CODE_BLOCK_LANGUAGES } from './codeBlockLanguage';

/** Search user-facing names by Chinese, romanization, initials and command names. */
export function editorSearchText(...names: string[]) {
  const text = names.join(' ');
  const syllables = pinyin(text, { toneType: 'none', type: 'array' });
  return `${text} ${syllables.join('')} ${syllables.map(part => part[0]).join('')}`.toLowerCase();
}
export type EditorInsertCommand = readonly [string, string, string, string];
const contentCommands: readonly EditorInsertCommand[] = [
  ['text', '文本', '普通段落', 'paragraph wenben wb'],
  ['h1', '一级标题', '大标题', 'heading title yijibiaoti yjbt'],
  ['h2', '二级标题', '章节标题', 'heading erjibiaoti ejbt'],
  ['h3', '三级标题', '小节标题', 'heading sanjibiaoti sjbt'],
  ['h4', '四级标题', '细分内容', 'heading sijibiaoti sjbt'],
  ['h5', '五级标题', '细分内容', 'heading wujibiaoti wjbt'],
  ['h6', '六级标题', '细分内容', 'heading liujibiaoti ljbt'],
  ['bullet', '无序列表', '项目列表', 'list unordered wuxuliebiao wxlb'],
  ['ordered', '有序列表', '编号列表', 'list numbered youxuliebiao yxlb'],
  ['quote', '引用', '引用段落', 'blockquote yinyong yy'],
  ['code', '代码块', '代码内容', 'codeblock daima dm dmk'],
  ['divider', '分隔线', '划分内容', 'horizontal rule fengexian fgx'],
  ['table', '表格', '3 × 3', 'biaoge bg'],
  ['inlineMath', '行内公式', '在段落中输入公式', 'formula equation gongshi gs latex hangneigongshi hngs'],
  ['math', '独立公式', '独立成行的公式', 'blockmath equation duligongshi dlgs'],
  ['card', '卡片', '说明与重点', 'callout kapian kp'],
  ['mermaid', 'Mermaid 图表', '流程图与时序图', 'diagram flowchart liuchengtu lct tuxing tx'],
  ['interactive', '交互实验', '插入可探索的实验', 'experiment lab jiaohushiyan jhsy hudong hd'],
  ['attachment', '附件', '图片、视频或 PDF', 'file image pdf audio upload 图片 音频 文件 上传 fujian fj tupian tp'],
  ['video', '视频', '边看边记', 'movie shipin sp'],
] as const;
const languageAliases: Record<string, string> = { javascript: 'js node nodejs', typescript: 'ts', python: 'py', bash: 'sh shell terminal 终端', cpp: 'c++ cc cxx', csharp: 'c# cs', rust: 'rs', yaml: 'yml', markdown: 'md' };
const cardCommands: readonly EditorInsertCommand[] = [
  ['definition', '定义', '明确概念', '概念定义 dy'], ['theorem', '定理', '记录条件与结论', '定律 dl'],
  ['example', '例题', '题目与解答', '例子 示例 lt'], ['tip', '技巧', '记录解题方法', '提示 jq'],
  ['pitfall', '易错点', '记录常见错误', 'warning 注意 ycd'], ['memory', '记忆卡', '整理记忆要点', '记忆 flashcard jyk'],
  ['derivation', '推导', '分步说明推导', '推导过程 td'], ['compare', '对比', '比较概念与方法', '比较 comparison db'],
  ['keypoint', '核心要点', '突出重要内容', '重点 key hxyd'], ['concept', '概念', '整理概念边界', '术语 gn'],
  ['insight', '直觉', '解释直观理解', '理解 intuition zj'], ['note', '说明', '补充说明', '备注 callout sm'],
  ['cause-effect', '因果', '梳理原因与结果', '因果关系 cause effect yg'],
].map(([id, label, detail, aliases]) => ['card:' + id, label + '卡片', detail, id + ' ' + aliases] as const);
export const editorInsertCommands: readonly EditorInsertCommand[] = [
  ...contentCommands,
  ...CODE_BLOCK_LANGUAGES.filter(item => item.value !== 'mermaid').map(item => [
    'code:' + item.value, item.label + ' 代码块', '输入 ' + item.label + ' 代码',
    item.value + ' ' + (languageAliases[item.value] || '') + ' code 代码',
  ] as const),
  ['code:plaintext', '纯文本代码块', '按原样记录文本', 'text txt plaintext 纯文本'],
  ...cardCommands,
];
const indexes = new Map(editorInsertCommands.map(command => [command[0], editorSearchText(...command)]));
export function searchEditorCommands(query: string) {
  const normalized = query.trim().replace(/^\//, '').toLowerCase();
  const dimensions = tableSizeForCommand(normalized);
  if (dimensions) return [[`table:${dimensions.rows}x${dimensions.cols}`, `${dimensions.rows} × ${dimensions.cols} 表格`, `${dimensions.rows} 行 × ${dimensions.cols} 列`, normalized] as const];
  const terms = normalized.split(/\s+/);
  const matches = editorInsertCommands.filter(command => terms.every(term => indexes.get(command[0])!.includes(term)));
  const exact = (command: EditorInsertCommand) => [command[0], command[0].split(':').at(-1), ...command[3].toLowerCase().split(/\s+/)].includes(normalized);
  const explicit = normalized ? matches.filter(exact) : [];
  const ranked = explicit.length ? explicit : matches;
  const frequencies=editorCommandFrequencies();
  return ranked.sort((a, b) => Number(exact(b)) - Number(exact(a)) || (frequencies[b[0]]||0) - (frequencies[a[0]]||0));
}


export function codeLanguageForCommand(command: string): string | null | undefined {
  if (command === 'code:plaintext') return null;
  return CODE_BLOCK_LANGUAGES.find(item => command === 'code:' + item.value)?.value;
}
export function cardTypeForCommand(command: string): string | undefined {
  return cardCommands.find(item => item[0] === command)?.[0].slice(5);
}


/** Explicit table dimensions are bounded to keep insertion responsive. */
export function tableSizeForCommand(command:string):{rows:number;cols:number}|undefined {
 const match=command.trim().toLowerCase().replace(/^\//,'').match(/^(?:bg|table:?)([1-9]\d?)[x*×]([1-9]\d?)$/);
 if(!match)return;
 const rows=Number(match[1]),cols=Number(match[2]);
 return rows<=20 && cols<=20 ? {rows,cols}:undefined;
}
