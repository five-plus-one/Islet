export type WindowTitleBarHost = {
 minimize(): unknown; toggleMaximize(): unknown; closeWindow(): unknown; openMenu(): unknown;
 getWindowState(): Promise<{ maximized: boolean; fullscreen: boolean }>;
 onWindowState(callback: (state: { maximized: boolean; fullscreen: boolean }) => void): () => void;
};
/** Mounts accessible desktop chrome; window privileges remain with the host. */
export function mountWindowTitleBar(host: WindowTitleBarHost, title: string) {
 const element = document.createElement('header');
 element.style.cssText = 'position:fixed;inset:0 0 auto;height:36px;z-index:2147483647';
 const shadow = element.attachShadow({ mode: 'open' });
 shadow.innerHTML = `<style>:host{color-scheme:inherit}nav{height:36px;display:flex;align-items:center;background:var(--window-bar-background,light-dark(#f5f3f8,#211f26));color:var(--window-bar-color,light-dark(#29252f,#e7e0ed));font:12px system-ui;user-select:none;-webkit-app-region:drag}span{flex:1;padding:0 12px;pointer-events:none}button{width:46px;height:36px;border:0;background:transparent;color:inherit;font:16px system-ui;-webkit-app-region:no-drag;cursor:default}button:hover{background:light-dark(#e2dfe7,#3c3844)}button:focus-visible{outline:2px solid #a78bfa;outline-offset:-3px}button:last-child:hover{background:#c42b1c;color:white}</style><nav aria-label="窗口"><button aria-label="课栈菜单">☰</button><span></span><button aria-label="最小化">−</button><button aria-label="最大化">□</button><button aria-label="关闭窗口">×</button></nav>`;
 shadow.querySelector('span')!.textContent = title;
 const buttons = shadow.querySelectorAll('button');
 buttons[0].onclick = () => host.openMenu(); buttons[1].onclick = () => host.minimize();
 buttons[2].onclick = () => host.toggleMaximize(); buttons[3].onclick = () => host.closeWindow();
 const update = (state: { maximized: boolean; fullscreen: boolean }) => {
  buttons[2].textContent = state.maximized ? '❐' : '□';
  buttons[2].setAttribute('aria-label', state.maximized ? '还原窗口' : '最大化');
  element.hidden = state.fullscreen;
  document.documentElement.style.setProperty('--desktop-titlebar-height', state.fullscreen ? '0px' : '36px');
 };
 document.body.prepend(element);
 const stop = host.onWindowState(update); void host.getWindowState().then(update);
 return () => { stop(); element.remove(); };
}

