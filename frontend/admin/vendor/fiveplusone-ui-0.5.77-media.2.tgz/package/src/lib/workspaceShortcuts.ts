export type WorkspaceTabAction = 'new-note' | 'close-tab' | 'next-tab' | 'previous-tab' | 'reopen-tab' | `tab-${number}`;
export type WorkspaceKeyInput = { key: string; ctrlKey?: boolean; metaKey?: boolean; altKey?: boolean; shiftKey?: boolean; isComposing?: boolean; repeat?: boolean };
/** Native clients own reserved keys; browser clients retain explicit alternatives. */
export function workspaceTabShortcut(input: WorkspaceKeyInput, native = false): WorkspaceTabAction | null {
  if (input.isComposing || input.repeat || !(input.ctrlKey || input.metaKey)) return null;
  const key = input.key.toLowerCase();
  if (!native && !input.altKey) return null;
  if (native && input.altKey) return null;
  if (key === 'n' && !input.shiftKey) return 'new-note';
  if (key === 'w' && !input.shiftKey) return 'close-tab';
  if (key === 't' && input.shiftKey) return 'reopen-tab';
  if (!native && key === 'arrowright' && !input.shiftKey) return 'next-tab';
  if (!native && key === 'arrowleft' && !input.shiftKey) return 'previous-tab';
  if (native && key === 'tab') return input.shiftKey ? 'previous-tab' : 'next-tab';
  if (!input.shiftKey && /^[1-9]$/.test(key)) return `tab-${Number(key)}`;
  return null;
}
