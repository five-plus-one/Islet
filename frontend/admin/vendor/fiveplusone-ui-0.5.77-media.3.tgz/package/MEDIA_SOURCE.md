# Media workspace source

Version 0.5.77-media.3 provides MediaWorkspace.tsx and media-workspace.css with proportionate image previews. Original entry points and sources are preserved from the published 0.5.77 baseline. The module is MIT licensed. Build with scripts/build-media-release.mjs and the baseline archive.
